#!/bin/bash

cd "$(dirname "$0")"

# Check if we're in the correct directory
if [ ! -d "ComfyUI" ] || [ ! -d "python_embeded" ]; then
    echo -e "${RED}ERROR: This script must be run from the ComfyUI-Easy-Install directory.${RESET}"
    echo -e "${YELLOW}Please run this script from inside the 'ComfyUI-Easy-Install' folder.${RESET}"
    echo -e "${CYAN}Current directory: $(pwd)${RESET}"
    echo -e "${CYAN}Expected to find: ComfyUI folder and python_embeded folder${RESET}"
    echo ""
    echo -e "${GREEN}Press any key to exit...${RESET}"
    read -n 1 -s
    exit 1
fi

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
BOLD='\033[1m'
RESET='\033[0m'

# Animation functions
spinner() {
    local pid=$1
    local delay=0.1
    local spinstr='⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏'
    while [ "$(ps a | awk '{print $1}' | grep $pid)" ]; do
        local temp=${spinstr#?}
        printf " ${CYAN}[%c]${RESET}  " "$spinstr"
        local spinstr=$temp${spinstr%"$temp"}
        sleep $delay
        printf "\b\b\b\b\b\b"
    done
    printf "    \b\b\b\b"
}

print_header() {
    clear
    echo -e "${MAGENTA}╔═══════════════════════════════════════════════════════════╗${RESET}"
    echo -e "${MAGENTA}║${CYAN}                                                           ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}        ╔═╗╔═╗╔╦╗╔═╗╦ ╦╦ ╦╦  ${YELLOW}╔═╗╔═╗╔═╗╦ ╦              ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}        ║  ║ ║║║║╠╣ ╚╦╝║ ║║  ${YELLOW}║╣ ╠═╣╚═╗╚╦╝              ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}        ╚═╝╚═╝╩ ╩╚   ╩ ╚═╝╩  ${YELLOW}╚═╝╩ ╩╚═╝ ╩               ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}                                                           ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${GREEN}              🎨 Easy Install by VenimK 🚀                ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}                                                           ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}               🎨 Pixaroma Soldier 🚀                       ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}                                                           ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}                                                           ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}╚═══════════════════════════════════════════════════════════╝${RESET}"
    echo ""
}

loading_bar() {
    local duration=$1
    local message=$2
    local width=50
    echo -ne "${YELLOW}${message}${RESET}\n"
    for ((i = 0 ; i <= width ; i++)); do
        echo -ne "${GREEN}▓${RESET}"
        sleep $(echo "scale=4; $duration/$width" | bc)
    done
    echo -e " ${GREEN}✓${RESET}"
}

generate_ascii_art() {
    local delay=0.05
    echo -e "${CYAN}🎨 Initializing AI Image Generator...${RESET}"
    sleep 0.5
    echo ""
    
    # Frame 1 - Empty canvas
    echo -e "${YELLOW}[Generating...]${RESET} Step 1/4 - Preparing canvas"
    echo -e "${MAGENTA}┌────────────────────┐${RESET}"
    for i in {1..6}; do
        echo -e "${MAGENTA}│${RESET}                    ${MAGENTA}│${RESET}"
        sleep $delay
    done
    echo -e "${MAGENTA}└────────────────────┘${RESET}"
    sleep 0.3
    
    # Clear and redraw with noise
    clear
    print_header
    echo -e "${YELLOW}[Generating...]${RESET} Step 2/4 - Adding noise"
    echo -e "${MAGENTA}┌────────────────────┐${RESET}"
    local chars=".:░▒▓"
    for i in {1..6}; do
        echo -ne "${MAGENTA}│${RESET}"
        for j in {1..20}; do
            local rand_char=${chars:$((RANDOM % ${#chars})):1}
            echo -ne "${CYAN}${rand_char}${RESET}"
            sleep 0.002
        done
        echo -e "${MAGENTA}│${RESET}"
    done
    echo -e "${MAGENTA}└────────────────────┘${RESET}"
    sleep 0.3
    
    # Clear and redraw with pattern forming
    clear
    print_header
    echo -e "${YELLOW}[Generating...]${RESET} Step 3/4 - Forming patterns"
    echo -e "${MAGENTA}┌────────────────────┐${RESET}"
    echo -e "${MAGENTA}│${RESET}${GREEN}░░░▒▒▓▓██${YELLOW}☼☼${GREEN}██▓▓▒▒░░░${RESET}${MAGENTA}│${RESET}"
    sleep $delay
    echo -e "${MAGENTA}│${RESET}${GREEN}░░▒▒▓▓${CYAN}████${YELLOW}◉◉${CYAN}████${GREEN}▓▓▒▒░░${RESET}${MAGENTA}│${RESET}"
    sleep $delay
    echo -e "${MAGENTA}│${RESET}${GREEN}░▒▓${CYAN}██${BLUE}▓▓▓▓${YELLOW}││${BLUE}▓▓▓▓${CYAN}██${GREEN}▓▒░${RESET}${MAGENTA}│${RESET}"
    sleep $delay
    echo -e "${MAGENTA}│${RESET}${GREEN}░▒▓${CYAN}██${BLUE}▓${WHITE}◆◆◆◆${BLUE}▓${CYAN}██${GREEN}▓▒░${RESET}${MAGENTA}│${RESET}"
    sleep $delay
    echo -e "${MAGENTA}│${RESET}${GREEN}░░▒▓${CYAN}███${BLUE}▓▓▓▓${CYAN}███${GREEN}▓▒░░${RESET}${MAGENTA}│${RESET}"
    sleep $delay
    echo -e "${MAGENTA}│${RESET}${GREEN}░░░▒▓▓${CYAN}██████${GREEN}▓▓▒░░░${RESET}${MAGENTA}│${RESET}"
    echo -e "${MAGENTA}└────────────────────┘${RESET}"
    sleep 0.3
    
    # Clear and show final image
    clear
    print_header
    echo -e "${GREEN}[Complete!]${RESET} Step 4/4 - Rendering final image ✓"
    echo -e "${MAGENTA}┌────────────────────┐${RESET}"
    echo -e "${MAGENTA}│${RESET}${GREEN}░░░▒▒▓▓██${YELLOW}☼☼${GREEN}██▓▓▒▒░░░${RESET}${MAGENTA}│${RESET}"
    echo -e "${MAGENTA}│${RESET}${GREEN}░░▒▒▓▓${CYAN}████${YELLOW}◉◉${CYAN}████${GREEN}▓▓▒▒░░${RESET}${MAGENTA}│${RESET}"
    echo -e "${MAGENTA}│${RESET}${GREEN}░▒▓${CYAN}██${BLUE}▓▓▓▓${YELLOW}││${BLUE}▓▓▓▓${CYAN}██${GREEN}▓▒░${RESET}${MAGENTA}│${RESET}"
    echo -e "${MAGENTA}│${RESET}${GREEN}░▒▓${CYAN}██${BLUE}▓${WHITE}◆◆◆◆${BLUE}▓${CYAN}██${GREEN}▓▒░${RESET}${MAGENTA}│${RESET}"
    echo -e "${MAGENTA}│${RESET}${GREEN}░░▒▓${CYAN}███${BLUE}▓▓▓▓${CYAN}███${GREEN}▓▒░░${RESET}${MAGENTA}│${RESET}"
    echo -e "${MAGENTA}│${RESET}${GREEN}░░░▒▓▓${CYAN}██████${GREEN}▓▓▒░░░${RESET}${MAGENTA}│${RESET}"
    echo -e "${MAGENTA}└────────────────────┘${RESET}"
    echo ""
    
    # Stats display
    echo -e "${CYAN}╭─────────────────────────────────────╮${RESET}"
    echo -e "${CYAN}│${RESET} ${YELLOW}⚡${RESET} Seed: ${WHITE}42424242${RESET}                  ${CYAN}│${RESET}"
    echo -e "${CYAN}│${RESET} ${GREEN}✓${RESET} Steps: ${WHITE}20${RESET}                        ${CYAN}│${RESET}"
    echo -e "${CYAN}│${RESET} ${MAGENTA}🎨${RESET} Sampler: ${WHITE}DPM++ 2M Karras${RESET}      ${CYAN}│${RESET}"
    echo -e "${CYAN}│${RESET} ${BLUE}⏱${RESET}  Time: ${WHITE}0.${RANDOM:0:2}s${RESET}                   ${CYAN}│${RESET}"
    echo -e "${CYAN}╰─────────────────────────────────────╯${RESET}"
    echo ""
    sleep 1
}

print_header

# Detect Python environment
echo -e "${CYAN}🔍 Detecting Python environment...${RESET}"
PYTHON_EXEC=""

# Check for new installer structure (direct Python installation)
if [ -f "python_embeded/python" ]; then
    PYTHON_EXEC="./python_embeded/python"
    echo -e "${GREEN}   ✓ Found Python (embedded)${RESET}"
    echo -e "${GREEN}   ✓ Using direct embedded Python (no venv activation needed)${RESET}"
# Check for old virtual environment structure
elif [ -d "python_embeded_3.12/bin" ]; then
    PYTHON_PATH="python_embeded_3.12/bin"
    PYTHON_EXEC="./python_embeded_3.12/bin/python3"
    echo -e "${GREEN}   ✓ Found Python 3.12${RESET}"
elif [ -d "python_embeded_3.11/bin" ]; then
    PYTHON_PATH="python_embeded_3.11/bin"
    PYTHON_EXEC="./python_embeded_3.11/bin/python3"
    echo -e "${GREEN}   ✓ Found Python 3.11${RESET}"
elif [ -d "python_embeded/bin" ]; then
    PYTHON_PATH="python_embeded/bin"
    PYTHON_EXEC="./python_embeded/bin/python3"
    echo -e "${GREEN}   ✓ Found Python (embedded)${RESET}"
else
    echo -e "${RED}   ✗ No embedded Python found, using system Python${RESET}"
    PYTHON_EXEC="python3"
fi
echo ""

# Activate virtual environment if we have one (old installer structure)
if [ -n "$PYTHON_PATH" ]; then
    echo -e "${CYAN}🐍 Activating Python environment...${RESET}"
    sleep 0.5
    source "$PYTHON_PATH/activate" 2>/dev/null && echo -e "${GREEN}   ✓ Environment activated${RESET}" || echo -e "${YELLOW}   ⚠ Using direct Python${RESET}"
    echo ""
else
    # New installer structure - no activation needed
    echo -e "${CYAN}🐍 Python environment ready...${RESET}"
    echo ""
fi

# Show ASCII art generation animation
generate_ascii_art

# Ask for custom output directory
CONFIG_FILE=".output_dir_config"
custom_output_dir=""

# Check if config file exists
if [ -f "$CONFIG_FILE" ]; then
    custom_output_dir=$(cat "$CONFIG_FILE")
    clear
    print_header
    echo -e "${CYAN}📁 Output Directory Configuration${RESET}"
    echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo ""
    if [ -n "$custom_output_dir" ]; then
        echo -e "${GREEN}   ✓ Saved output directory: ${YELLOW}${custom_output_dir}${RESET}"
    else
        echo -e "${GREEN}   ✓ Using default output directory${RESET}"
    fi
    echo ""
    echo -e "${YELLOW}Press Enter to keep current, or type 'c' to change:${RESET}"
    read -p "> " change_choice
    
    if [ "$change_choice" = "c" ] || [ "$change_choice" = "C" ]; then
        clear
        print_header
        echo -e "${CYAN}📁 Output Directory Configuration${RESET}"
        echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
        echo ""
        echo -e "${YELLOW}Enter new output directory path:${RESET}"
        echo -e "${CYAN}Press Enter to use default, or type path:${RESET}"
        read -p "Path: " custom_output_dir
        echo "$custom_output_dir" > "$CONFIG_FILE"
        echo ""
    fi
else
    # First time setup
    clear
    print_header
    echo -e "${CYAN}📁 Output Directory Configuration${RESET}"
    echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo ""
    echo -e "${YELLOW}Do you want to use a custom output directory?${RESET}"
    echo -e "${CYAN}Press Enter to use default, or type path:${RESET}"
    read -p "Path: " custom_output_dir
    echo "$custom_output_dir" > "$CONFIG_FILE"
    echo ""
fi

# Ask for listening address
LISTEN_CONFIG_FILE=".listen_address_config"
LISTEN_ADDRESS=""

# Check if config file exists
if [ -f "$LISTEN_CONFIG_FILE" ]; then
    LISTEN_ADDRESS=$(cat "$LISTEN_CONFIG_FILE")
    clear
    print_header
    echo -e "${CYAN}🌐 Network Configuration${RESET}"
    echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo ""
    if [ -n "$LISTEN_ADDRESS" ]; then
        if [ "$LISTEN_ADDRESS" = "0.0.0.0" ]; then
            echo -e "${GREEN}   ✓ Saved setting: ${YELLOW}LAN Access (0.0.0.0)${RESET}"
            echo -e "${CYAN}     Accessible from other devices on your network${RESET}"
        elif [ "$LISTEN_ADDRESS" = "127.0.0.1" ]; then
            echo -e "${GREEN}   ✓ Saved setting: ${YELLOW}Local Only (127.0.0.1)${RESET}"
            echo -e "${CYAN}     Accessible only from this computer${RESET}"
        else
            echo -e "${GREEN}   ✓ Saved setting: ${YELLOW}Custom IP (${LISTEN_ADDRESS})${RESET}"
        fi
    else
        echo -e "${GREEN}   ✓ Using default: ${YELLOW}LAN Access (0.0.0.0)${RESET}"
        LISTEN_ADDRESS="0.0.0.0"
    fi
    echo ""
    echo -e "${YELLOW}Press Enter to keep current, or 'c' to change:${RESET}"
    read -p "> " change_choice
    
    if [ "$change_choice" = "c" ] || [ "$change_choice" = "C" ]; then
        clear
        print_header
        echo -e "${CYAN}🌐 Network Configuration${RESET}"
        echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
        echo ""
        echo -e "${YELLOW}Choose listening address:${RESET}"
        echo -e "${CYAN}1) LAN Access (0.0.0.0) - For Proxmox/Network access${RESET}"
        echo -e "${CYAN}2) Local Only (127.0.0.1) - For security${RESET}"
        echo -e "${CYAN}3) Custom IP address${RESET}"
        echo -e "${CYAN}Choose 1-3:${RESET}"
        read -p "Choice: " listen_choice
        
        case $listen_choice in
            1)
                LISTEN_ADDRESS="0.0.0.0"
                echo "$LISTEN_ADDRESS" > "$LISTEN_CONFIG_FILE"
                ;;
            2)
                LISTEN_ADDRESS="127.0.0.1"
                echo "$LISTEN_ADDRESS" > "$LISTEN_CONFIG_FILE"
                ;;
            3)
                read -p "Enter IP address: " custom_ip
                if [ -n "$custom_ip" ]; then
                    LISTEN_ADDRESS="$custom_ip"
                    echo "$LISTEN_ADDRESS" > "$LISTEN_CONFIG_FILE"
                fi
                ;;
            *)
                echo -e "${YELLOW}Keeping current setting${RESET}"
                ;;
        esac
        echo ""
    fi
else
    clear
    print_header
    echo -e "${CYAN}🌐 Network Configuration${RESET}"
    echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo ""
    echo -e "${YELLOW}Choose ComfyUI listening address:${RESET}"
    echo -e "${CYAN}1) LAN Access (0.0.0.0) - For Proxmox/Network access${RESET}"
    echo -e "${CYAN}2) Local Only (127.0.0.1) - For security${RESET}"
    echo -e "${CYAN}3) Custom IP address${RESET}"
    echo -e "${CYAN}Press Enter for LAN Access (default), or choose 1-3:${RESET}"
    read -p "Choice: " listen_choice
    
    case $listen_choice in
        1|"")
            LISTEN_ADDRESS="0.0.0.0"
            ;;
        2)
            LISTEN_ADDRESS="127.0.0.1"
            ;;
        3)
            read -p "Enter IP address: " custom_ip
            if [ -n "$custom_ip" ]; then
                LISTEN_ADDRESS="$custom_ip"
            else
                LISTEN_ADDRESS="0.0.0.0"
            fi
            ;;
        *)
            LISTEN_ADDRESS="0.0.0.0"
            ;;
    esac
    echo "$LISTEN_ADDRESS" > "$LISTEN_CONFIG_FILE"
    echo ""
fi

# Launch ComfyUI
clear
print_header
echo -e "${CYAN}🚀 Launching ComfyUI...${RESET}"
echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo ""

# Build command with optional output directory
if [ -n "$custom_output_dir" ]; then
    echo -e "${GREEN}   ✓ Using custom output: ${YELLOW}${custom_output_dir}${RESET}"
    echo -e "${GREEN}   ✓ Listening on: ${YELLOW}${LISTEN_ADDRESS}${RESET}"
    echo -e "${GREEN}   ✓ Using Python: ${YELLOW}$PYTHON_EXEC${RESET}"
    echo ""
    sleep 0.5
$PYTHON_EXEC -W ignore::FutureWarning -W ignore::UserWarning:pydantic._internal._fields ComfyUI/main.py --output-directory "$custom_output_dir" --listen "$LISTEN_ADDRESS"
else
    echo -e "${GREEN}   ✓ Using default output directory${RESET}"
    echo -e "${GREEN}   ✓ Listening on: ${YELLOW}${LISTEN_ADDRESS}${RESET}"
    echo -e "${GREEN}   ✓ Using Python: ${YELLOW}$PYTHON_EXEC${RESET}"
    echo ""
    sleep 0.5
$PYTHON_EXEC -W ignore::FutureWarning -W ignore::UserWarning:pydantic._internal._fields ComfyUI/main.py --listen "$LISTEN_ADDRESS"
fi

echo ""
echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${YELLOW}✨ ComfyUI session ended ✨${RESET}"
echo ""
echo -e "${GREEN}Press any key to exit...${RESET}"
read -n 1 -s
