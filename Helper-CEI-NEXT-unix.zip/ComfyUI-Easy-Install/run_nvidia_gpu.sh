#!/bin/bash

cd "$(dirname "$0")"

echo "Starting ComfyUI-Easy-Install By VenimK"

# Assuming the virtual environment is activated
source python_embeded/bin/activate
python -W ignore::FutureWarning ComfyUI/main.py

read -p "Press any key to continue..."
