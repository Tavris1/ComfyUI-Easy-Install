#!/bin/bash

cd "$(dirname "$0")"

echo "Starting ComfyUI-Easy-Install"

# Assuming the virtual environment is activated
python -W ignore::FutureWarning ComfyUI/main.py

read -p "Press any key to continue..."
