#!/bin/bash

# SageAttention for 'ComfyUI Easy Install' - Linux Version with CUDA detection
# Handles CUDA_HOME issues and provides fallback options

# Define color codes for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
RESET='\033[0m' # No Color

# Define the installation paths
COMFYUI_INSTALL_DIR="/root/ComfyUI-Easy-Install/ComfyUI-Easy-Install"
VENV_DIR="$COMFYUI_INSTALL_DIR/venv"
COMFYUI_DIR="$COMFYUI_INSTALL_DIR/ComfyUI"
BUILD_DIR="/tmp/sage_attention_build"

print_header() {
    echo -e "\n${GREEN}====================================================================${RESET}"
    echo -e "${GREEN}$1${RESET}"
    echo -e "${GREEN}====================================================================${RESET}\n"
}

print_success() {
    echo -e "${GREEN}$1${RESET}"
}

print_error() {
    echo -e "${RED}$1${RESET}"
}

print_warning() {
    echo -e "${YELLOW}$1${RESET}"
}

# Check if the directories exist
if [ ! -d "$COMFYUI_INSTALL_DIR" ]; then
    print_error "Error: ComfyUI installation directory not found at $COMFYUI_INSTALL_DIR"
    print_error "Please update the script with the correct path to your ComfyUI installation."
    exit 1
fi

if [ ! -d "$VENV_DIR" ]; then
    print_error "Error: Virtual environment not found at $VENV_DIR"
    print_error "Please update the script with the correct path to your virtual environment."
    exit 1
fi

# Activate the virtual environment
source "$VENV_DIR/bin/activate"

# Check PyTorch and CUDA versions
print_header "Checking PyTorch and CUDA versions"
TORCH_VERSION=$(python -c "import torch; print(torch.__version__)" 2>/dev/null)
CUDA_VERSION=$(python -c "import torch; print(torch.version.cuda)" 2>/dev/null)

if [ -z "$TORCH_VERSION" ]; then
    print_error "Error: PyTorch not found. Please install PyTorch first."
    exit 1
fi

if [ -z "$CUDA_VERSION" ]; then
    print_warning "Warning: CUDA not found in PyTorch. SageAttention requires CUDA."
    print_warning "Continuing anyway, but installation may fail."
else
    print_success "Found PyTorch $TORCH_VERSION with CUDA $CUDA_VERSION"
fi

# Detect and set CUDA_HOME
print_header "Detecting CUDA installation"

# Try common CUDA installation paths
CUDA_PATHS=(
    "/usr/local/cuda"
    "/usr/local/cuda-$CUDA_VERSION"
    "/opt/cuda"
    "/opt/cuda-$CUDA_VERSION"
    "/usr/lib/cuda"
    "/usr/lib/cuda-$CUDA_VERSION"
)

CUDA_HOME=""
for path in "${CUDA_PATHS[@]}"; do
    if [ -d "$path" ]; then
        CUDA_HOME="$path"
        print_success "Found CUDA installation at $CUDA_HOME"
        break
    fi
done

if [ -z "$CUDA_HOME" ]; then
    print_warning "Could not find CUDA installation directory."
    print_warning "Trying to locate nvcc..."
    
    NVCC_PATH=$(which nvcc 2>/dev/null)
    if [ -n "$NVCC_PATH" ]; then
        CUDA_HOME=$(dirname $(dirname "$NVCC_PATH"))
        print_success "Found CUDA installation via nvcc at $CUDA_HOME"
    else
        print_warning "Could not find nvcc. Trying to continue without setting CUDA_HOME..."
    fi
fi

# Set CUDA_HOME environment variable if found
if [ -n "$CUDA_HOME" ]; then
    export CUDA_HOME="$CUDA_HOME"
    print_success "Set CUDA_HOME=$CUDA_HOME"
else
    print_warning "CUDA_HOME could not be set. Build from source may fail."
    print_warning "Will attempt pip installation as fallback."
fi

# Install build dependencies
print_header "Installing build dependencies"
pip install build wheel setuptools pybind11 ninja

# Function to create startup scripts
create_startup_scripts() {
    # Create a startup script
    print_header "Creating Sage Attention Startup Script"
    cat > "$COMFYUI_DIR/run_with_sage_attention.sh" << 'EOFINNER'
#!/bin/bash

# Script to run ComfyUI with Sage attention
echo "Starting ComfyUI with Sage attention..."

# Run ComfyUI with Sage attention flag
python main.py --listen 0.0.0.0 --port 8188 --use-sage-attention "$@"
EOFINNER

    chmod +x "$COMFYUI_DIR/run_with_sage_attention.sh"
    print_success "Created startup script at $COMFYUI_DIR/run_with_sage_attention.sh"

    # Create a monitoring script
    print_header "Creating Sage Attention Monitoring Script"
    cat > "$COMFYUI_DIR/monitor_sage_attention.py" << 'EOFINNER'
#!/usr/bin/env python3
"""
SageAttention Monitoring Script
This script hooks into PyTorch to monitor when SageAttention is being used.
"""

import torch
import sys
import os
import time
from datetime import datetime

# Create a log file
log_file = "sage_attention_monitor.log"
with open(log_file, "w") as f:
    f.write(f"SageAttention Monitoring started at {datetime.now()}\n")
    f.write(f"PyTorch version: {torch.__version__}\n")
    f.write(f"CUDA available: {torch.cuda.is_available()}\n")
    if torch.cuda.is_available():
        f.write(f"CUDA device: {torch.cuda.get_device_name(0)}\n")
    f.write("\n")

# Check if SageAttention is installed
try:
    import sageattention
    with open(log_file, "a") as f:
        f.write(f"SageAttention package is installed: {sageattention.__version__ if hasattr(sageattention, '__version__') else 'version unknown'}\n\n")
except ImportError:
    with open(log_file, "a") as f:
        f.write("SageAttention package is NOT installed\n\n")

# Original function to monitor
original_sdpa = torch.nn.functional.scaled_dot_product_attention

# Counter for function calls
call_count = 0

# Hook function
def sdpa_hook(*args, **kwargs):
    global call_count
    call_count += 1
    
    # Log the call
    with open(log_file, "a") as f:
        f.write(f"[{datetime.now()}] SageAttention call #{call_count}\n")
        if args:
            f.write(f"  Query shape: {args[0].shape if hasattr(args[0], 'shape') else 'unknown'}\n")
        if 'attn_mask' in kwargs and kwargs['attn_mask'] is not None:
            f.write(f"  Attention mask: {type(kwargs['attn_mask'])}\n")
    
    # Call the original function
    return original_sdpa(*args, **kwargs)

# Replace the function with our hook
torch.nn.functional.scaled_dot_product_attention = sdpa_hook

print(f"SageAttention monitoring enabled. Logs will be written to {os.path.abspath(log_file)}")
EOFINNER

    chmod +x "$COMFYUI_DIR/monitor_sage_attention.py"
    print_success "Created monitoring script at $COMFYUI_DIR/monitor_sage_attention.py"

    # Create a combined startup script with monitoring
    print_header "Creating Combined Startup Script"
    cat > "$COMFYUI_DIR/run_with_sage_monitoring.sh" << 'EOFINNER'
#!/bin/bash

# Script to run ComfyUI with Sage attention and monitoring
echo "Starting ComfyUI with Sage attention and monitoring..."

# Set the environment variable to enable monitoring
export PYTHONPATH=$PYTHONPATH:$(pwd)

# Run the monitoring script first
python monitor_sage_attention.py &

# Run ComfyUI with Sage attention flag
python main.py --listen 0.0.0.0 --port 8188 --use-sage-attention "$@"
EOFINNER

    chmod +x "$COMFYUI_DIR/run_with_sage_monitoring.sh"
    print_success "Created combined startup script at $COMFYUI_DIR/run_with_sage_monitoring.sh"
}

# Function to attempt installation via pip
install_via_pip() {
    print_header "Attempting installation via pip"
    
    # Try to install sageattention via pip
    pip install sageattention
    
    # Check if installation succeeded
    if pip list | grep -q sageattention; then
        print_success "SageAttention successfully installed via pip!"
        return 0
    else
        print_error "Failed to install SageAttention via pip."
        return 1
    fi
}

# Function to attempt installation from source
install_from_source() {
    print_header "Attempting installation from source"
    
    # Create and navigate to build directory
    rm -rf "$BUILD_DIR"
    mkdir -p "$BUILD_DIR"
    cd "$BUILD_DIR"

    # Clone the SageAttention repository
    print_header "Cloning SageAttention repository"
    git clone https://github.com/thu-ml/SageAttention.git
    cd SageAttention

    # Install dependencies from pyproject.toml
    print_header "Installing dependencies from pyproject.toml"
    echo "Installing pybind11..."
    pip install pybind11

    echo "Installing ninja..."
    pip install ninja

    # Try to build and install SageAttention
    print_header "Building and installing SageAttention"
    
    # Try setup.py install with error handling
    python setup.py install 2> build_error.log
    
    if [ $? -ne 0 ]; then
        print_error "Build failed. See error log below:"
        cat build_error.log
        return 1
    fi

    # Verify installation
    if pip list | grep -q sageattention; then
        print_success "SageAttention successfully built and installed from source!"
        return 0
    else
        print_error "SageAttention installation verification failed."
        return 1
    fi
}

# Function to create a patch for ComfyUI to use PyTorch SDPA directly
create_sdpa_patch() {
    print_header "Creating PyTorch SDPA patch for ComfyUI"
    
    # Create a backup of model_management.py if it doesn't exist
    if [ ! -f "$COMFYUI_DIR/comfy/model_management.py.bak" ]; then
        cp "$COMFYUI_DIR/comfy/model_management.py" "$COMFYUI_DIR/comfy/model_management.py.bak"
        print_success "Created backup of model_management.py"
    fi
    
    # Create a patch script
    cat > "$COMFYUI_DIR/patch_sage_attention.py" << 'EOFINNER'
#!/usr/bin/env python3
"""
Patch ComfyUI to use PyTorch SDPA (Sage Attention) directly
"""
import os
import re

def patch_model_management():
    file_path = "comfy/model_management.py"
    with open(file_path, 'r') as f:
        content = f.read()
    
    # Check if already patched
    if "COMFYUI_FORCE_SDPA_ATTENTION" in content:
        print("File already contains SDPA patch. No changes made.")
        return False
    
    # Add import os if not present
    if "import os" not in content:
        content = "import os\n" + content
    
    # Find the sage_attention_enabled function
    pattern = r"def sage_attention_enabled\(\):(.*?)return False"
    replacement = """def sage_attention_enabled():
    # Force SDPA (Sage) attention if environment variable is set
    if os.environ.get('COMFYUI_FORCE_SDPA_ATTENTION') == '1':
        print("Forcing SDPA (Sage) attention via environment variable")
        return True
        
    # Original function logic follows
\\1return False"""
    
    new_content = re.sub(pattern, replacement, content, flags=re.DOTALL)
    
    if new_content == content:
        print("Could not find sage_attention_enabled function to patch.")
        return False
    
    with open(file_path, 'w') as f:
        f.write(new_content)
    
    print("Successfully patched model_management.py to force SDPA attention.")
    return True

if __name__ == "__main__":
    patch_model_management()
EOFINNER

    chmod +x "$COMFYUI_DIR/patch_sage_attention.py"
    
    # Apply the patch
    cd "$COMFYUI_DIR"
    python patch_sage_attention.py
    
    # Create a startup script for patched version
    cat > "$COMFYUI_DIR/run_with_forced_sage.sh" << 'EOFINNER'
#!/bin/bash

# Script to run ComfyUI with forced Sage attention via environment variable
echo "Starting ComfyUI with forced Sage attention..."

# Force SDPA attention
export COMFYUI_FORCE_SDPA_ATTENTION=1

# Run ComfyUI
python main.py --listen 0.0.0.0 --port 8188 "$@"
EOFINNER

    chmod +x "$COMFYUI_DIR/run_with_forced_sage.sh"
    print_success "Created patched startup script at $COMFYUI_DIR/run_with_forced_sage.sh"
    
    return 0
}

# Try different installation methods in order of preference
print_header "Starting SageAttention installation"

# First try: Install from source
install_from_source
SOURCE_RESULT=$?

# Second try: Install via pip if source installation failed
if [ $SOURCE_RESULT -ne 0 ]; then
    print_warning "Source installation failed. Trying pip installation..."
    install_via_pip
    PIP_RESULT=$?
    
    # Third try: Create patch for direct PyTorch SDPA if both failed
    if [ $PIP_RESULT -ne 0 ]; then
        print_warning "Both source and pip installations failed. Creating direct PyTorch SDPA patch..."
        create_sdpa_patch
        PATCH_RESULT=$?
        
        if [ $PATCH_RESULT -eq 0 ]; then
            print_success "Created PyTorch SDPA patch. You can run ComfyUI with forced Sage attention."
        else
            print_error "All installation methods failed. Please check your CUDA setup."
            exit 1
        fi
    fi
fi

# Create startup scripts regardless of installation method
create_startup_scripts

# Clean up
print_header "Cleaning up"
rm -rf "$BUILD_DIR"
print_success "Build directory removed"

print_header "Installation Complete!"
echo "To run ComfyUI with Sage attention:"
echo "1. Navigate to your ComfyUI directory: cd $COMFYUI_DIR"
echo "2. Run: ./run_with_sage_attention.sh"
echo ""
echo "To run with monitoring enabled:"
echo "Run: ./run_with_sage_monitoring.sh"
echo ""
echo "If SageAttention package installation failed, try:"
echo "Run: ./run_with_forced_sage.sh"
echo ""
echo "Would you like to run ComfyUI with Sage attention now? (y/n)"
read -r response
if [[ "$response" =~ ^([yY][eE][sS]|[yY])$ ]]; then
    cd "$COMFYUI_DIR"
    if [ -f "./run_with_sage_attention.sh" ]; then
        ./run_with_sage_attention.sh
    elif [ -f "./run_with_forced_sage.sh" ]; then
        ./run_with_forced_sage.sh
    else
        echo "No startup script found. Please check installation."
    fi
else
    echo "You can run ComfyUI with Sage attention later using the instructions above."
fi
