#!/usr/bin/env python3
"""
Desktop EZi v3.24.0 — PyWebView wrapper
Opens ComfyUI in a native desktop window instead of a browser.
Part of ComfyUI-Easy-Install by Pixaroma / VenimK
"""

import os
import sys

if sys.platform.startswith("linux"):
    # GTK draws a white client-side header bar on Linux; let the window
    # manager paint the titlebar instead (set GTK_CSD=1 to restore it).
    os.environ.setdefault("GTK_CSD", "0")
    # WebKitGTK's DMA-BUF renderer flickers/goes blank on some GPU drivers.
    os.environ.setdefault("WEBKIT_DISABLE_DMABUF_RENDERER", "1")

import time
import signal
import socket
import threading
import webbrowser
import urllib.request
import urllib.parse
import base64
import json
import subprocess
import traceback
import locale

EZI_VERSION = "3.30.3"

EZI_AURORA_PALETTE_ID = "ezi_aurora"
EZI_AURORA_PALETTE_VERSION = 1

EZI_AURORA_PALETTE = {
    "id": EZI_AURORA_PALETTE_ID,
    "name": "EZi Aurora",
    "light_theme": False,
    "colors": {
        "node_slot": {
            "CLIP": "#ffd166", "CLIP_VISION": "#8fd3e0", "CLIP_VISION_OUTPUT": "#c08a64",
            "CONDITIONING": "#ffa65c", "CONTROL_NET": "#6ee7b7", "IMAGE": "#6cb8ff",
            "LATENT": "#f29cff", "MASK": "#8ddc9a", "MODEL": "#b49cf0",
            "STYLE_MODEL": "#c2ffae", "VAE": "#ff7a8a", "NOISE": "#b0bccd",
            "GUIDER": "#66f0e6", "SAMPLER": "#e8b4c4", "SIGMAS": "#cdf5d0", "TAESD": "#dcc274",
        },
        "litegraph_base": {
            "CLEAR_BACKGROUND_COLOR": "#0b1926", "NODE_TITLE_COLOR": "#a1b3cc",
            "NODE_SELECTED_TITLE_COLOR": "#ffffff", "NODE_TEXT_COLOR": "#b7c6dc",
            "NODE_TEXT_HIGHLIGHT_COLOR": "#ffffff", "NODE_DEFAULT_COLOR": "#304b63",
            "NODE_DEFAULT_BGCOLOR": "#22374b", "NODE_DEFAULT_BOXCOLOR": "#49758a",
            "NODE_DEFAULT_SHAPE": 2, "NODE_BOX_OUTLINE_COLOR": "#82dfcd",
            "NODE_BYPASS_BGCOLOR": "#FF00FF", "NODE_ERROR_COLOUR": "#ff3b4e",
            "DEFAULT_SHADOW_COLOR": "rgba(0,0,0,0.5)", "WIDGET_BGCOLOR": "#0d2433",
            "WIDGET_OUTLINE_COLOR": "#49758a", "WIDGET_TEXT_COLOR": "#e3ecfb",
            "WIDGET_SECONDARY_TEXT_COLOR": "#a1b3cc", "WIDGET_DISABLED_TEXT_COLOR": "#5f7893",
            "LINK_COLOR": "#7fc9bd", "EVENT_LINK_COLOR": "#e0a96d", "CONNECTING_LINK_COLOR": "#9be9d9",
            "BADGE_FG_COLOR": "#edf3ff", "BADGE_BG_COLOR": "#12303f",
        },
        "comfy_base": {
            "fg-color": "#edf3ff", "bg-color": "#0f2233", "comfy-menu-bg": "#102638",
            "comfy-menu-secondary-bg": "#122438", "comfy-input-bg": "#09232d",
            "input-text": "#e3ecfb", "descrip-text": "#a1b3cc", "drag-text": "#c3d1e6",
            "error-text": "#ff5d6c", "border-color": "#304659",
            "tr-even-bg-color": "#0d2230", "tr-odd-bg-color": "#162c40",
            "content-bg": "#304659", "content-fg": "#edf3ff",
            "content-hover-bg": "#203649", "content-hover-fg": "#ffffff",
            "bar-shadow": "rgba(4, 12, 20, 0.6) 0 0 0.5rem",
            "interface-stroke": "#3b566f", "interface-panel-surface": "#102638",
            "interface-panel-hover-surface": "#203649", "interface-panel-selected-surface": "#304b63",
            "interface-button-hover-surface": "#304b63",
        },
    },
}


def _log_error(label=''):
    """Log exception details to stderr for debugging without crashing."""
    try:
        msg = traceback.format_exc()
        if label:
            msg = f"[EZi:{label}] {msg}"
        print(msg, file=sys.stderr, flush=True)
    except Exception:
        pass


_EZI_AI_LANGS = (
    "en", "zh-CN", "zh-TW", "es", "ru", "ja", "ko", "de", "fr", "pt-BR", "it", "tr", "ar", "hi", "id", "vi", "pl", "uk", "nl",
    "th", "fa", "bg", "cs", "ro", "el", "hu", "sr", "he", "bn", "sv", "ms", "fil"
)


def _ezi_system_lang():
    try:
        name = ""
        try:
            loc = locale.getlocale()
            if loc and loc[0]:
                name = loc[0]
        except Exception:
            pass
        if not name:
            name = os.environ.get("LANG", "") or os.environ.get("LC_ALL", "") or os.environ.get("LC_MESSAGES", "")
        low = name.lower().replace("_", "-").split(".")[0].split("@")[0]
        if not low:
            return "en"
        primary = low.split("-")[0]
        if primary == "zh":
            return "zh-TW" if any(t in low for t in ("tw", "hk", "mo", "hant")) else "zh-CN"
        if primary == "pt":
            return "pt-BR"
        primary = {"tl": "fil", "iw": "he", "in": "id"}.get(primary, primary)
        for code in _EZI_AI_LANGS:
            if code.lower() == primary:
                return code
    except Exception:
        pass
    return "en"

COMFYUI_HOST = os.environ.get("COMFYUI_HOST", "127.0.0.1")
COMFYUI_PORT = int(os.environ.get("COMFYUI_PORT", 8188))
COMFYUI_REMOTE = os.environ.get("COMFYUI_REMOTE", "0") == "1"

# Mutable scheme so --tls-keyfile/--tls-certfile can switch ComfyUI URLs to https
_COMFY_SCHEME = ["http"]
_LOOPBACK_SSL = [None]


def _detect_comfy_scheme_from_state():
    """If saved launch args include both TLS flags, default to https."""
    try:
        with open(WINDOW_STATE_FILE, "r") as f:
            state = json.load(f)
        args = state.get("launch_args", "")
        if "--tls-keyfile" in args and "--tls-certfile" in args:
            return "https"
    except Exception:
        pass
    return "http"


def _comfy_ssl():
    """Return an unverified SSL context for https://127.0.0.1 (self-signed certs)."""
    if _COMFY_SCHEME[0] != "https":
        return None
    if _LOOPBACK_SSL[0] is None:
        import ssl
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        _LOOPBACK_SSL[0] = ctx
    return _LOOPBACK_SSL[0]


def _comfy_origin(port=None):
    port = port if port is not None else COMFYUI_PORT
    return f"{_COMFY_SCHEME[0]}://{COMFYUI_HOST}:{port}"


def comfyui_url():
    """Return the current ComfyUI URL (http or https depending on launch args)."""
    return _comfy_origin(COMFYUI_PORT)


# Initialise scheme early from saved state; updated later when launch args change
_COMFY_SCHEME[0] = _detect_comfy_scheme_from_state()

if COMFYUI_REMOTE:
    WINDOW_TITLE = f"ComfyUI \u2014 {COMFYUI_HOST}"
else:
    WINDOW_TITLE = "ComfyUI \u2014 Pixaroma"

WINDOW_WIDTH = 1400
WINDOW_HEIGHT = 900

# Path to icon (relative to this script)
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
ICON_PATH = os.path.join(SCRIPT_DIR, "comfyui_icon.png")
WINDOW_STATE_FILE = os.path.join(SCRIPT_DIR, ".comfyui_desktop_state.json")
SERVER_LOG_FILE = os.path.join(SCRIPT_DIR, ".comfyui_server.log")

# Embed icon as base64 for the loading splash
_ICON_B64 = ""
if os.path.isfile(ICON_PATH):
    with open(ICON_PATH, "rb") as _f:
        _ICON_B64 = base64.b64encode(_f.read()).decode("ascii")


def wait_for_server(host, port, timeout=120):
    """Wait for ComfyUI server to start accepting connections."""
    start = time.time()
    while time.time() - start < timeout:
        try:
            with socket.create_connection((host, port), timeout=2):
                return True
        except (ConnectionRefusedError, OSError, socket.timeout):
            time.sleep(0.5)
    return False


def open_in_browser():
    """Fallback: open ComfyUI in the default browser."""
    print(f"Opening ComfyUI in browser: {comfyui_url()}")
    webbrowser.open(comfyui_url())


def is_port_in_use(port, host="127.0.0.1"):
    """Return True if port is already bound."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.5)
            return s.connect_ex((host, port)) == 0
    except Exception:
        return False


def load_window_state():
    """Load saved window geometry. Returns dict or {}."""
    try:
        if os.path.isfile(WINDOW_STATE_FILE):
            with open(WINDOW_STATE_FILE, "r") as f:
                data = json.load(f)
            if isinstance(data, dict):
                return data
    except Exception:
        pass
    return {}


def save_window_state(window):
    """Persist current window size/position to disk."""
    try:
        geometry = {
            "width":  window.width,
            "height": window.height,
            "x":      window.x,
            "y":      window.y,
        }
        # Filter out None / negative values that pywebview may return on some platforms
        if any(v is None or v < 0 for v in geometry.values()):
            return
        state = load_window_state()
        state.update(geometry)
        with open(WINDOW_STATE_FILE, "w") as f:
            json.dump(state, f)
    except Exception:
        pass


_STORAGE_SKIP_PREFIXES = (
    "Comfy.Workflow.DraftIndex.v2:",
    "Comfy.Workflow.Draft.v2:",
    "Comfy.Workflow.LastActivePath:",
    "Comfy.Workflow.LastOpenPaths:",
    "workflow",
)
_MAX_STORAGE_BYTES = 2 * 1024 * 1024


def save_comfy_storage(data):
    """Persist ComfyUI localStorage without workflow drafts, capped at 2 MB."""
    if not isinstance(data, dict) or not data:
        return
    data = {k: v for k, v in data.items() if not k.startswith(_STORAGE_SKIP_PREFIXES)}
    if len(json.dumps(data)) > _MAX_STORAGE_BYTES:
        return
    state = load_window_state()
    state["comfy_storage"] = data
    with open(WINDOW_STATE_FILE, "w") as f:
        json.dump(state, f)


def _load_settings():
    state = load_window_state()
    settings = state.get("settings", {})
    return settings if isinstance(settings, dict) else {}


def _save_settings(settings):
    if not isinstance(settings, dict):
        return
    state = load_window_state()
    state["settings"] = settings
    with open(WINDOW_STATE_FILE, "w") as f:
        json.dump(state, f)


def _ensure_ezi_aurora_palette(settings):
    try:
        if not isinstance(settings, dict):
            return
        try:
            done = int(settings.get("ezi_aurora_palette_ver", 0) or 0)
        except (TypeError, ValueError):
            done = 0
        if done >= EZI_AURORA_PALETTE_VERSION:
            return
        user_dir = os.path.join(SCRIPT_DIR, "ComfyUI", "user", "default")
        settings_file = os.path.join(user_dir, "comfy.settings.json")
        data = {}
        if os.path.exists(settings_file):
            with open(settings_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict):
                return
        palettes = data.get("Comfy.CustomColorPalettes")
        if palettes is None:
            palettes = {}
        if not isinstance(palettes, dict):
            return
        palettes[EZI_AURORA_PALETTE_ID] = json.loads(json.dumps(EZI_AURORA_PALETTE))
        data["Comfy.CustomColorPalettes"] = palettes
        os.makedirs(user_dir, exist_ok=True)
        tmp = settings_file + ".ezi.tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
        os.replace(tmp, settings_file)
        settings["ezi_aurora_palette_ver"] = EZI_AURORA_PALETTE_VERSION
        _save_settings(settings)
    except Exception:
        _log_error('_ensure_ezi_aurora_palette')


def _installed_frontend_version():
    """Return installed comfyui_frontend_package version, or None/0.1.0."""
    try:
        import importlib.metadata as _im
        for _pkg in ("comfyui_frontend_package", "comfyui-frontend-package"):
            try:
                ver = _im.version(_pkg)
                if ver and ver != "0.1.0":
                    return ver
            except Exception:
                continue
    except Exception:
        _log_error('_installed_frontend_version/importlib')
    try:
        import glob as _glob, site as _site
        site_dir = _site.getsitepackages()[0]
        matches = sorted(_glob.glob(
            os.path.join(site_dir, "comfyui_frontend_package-*.dist-info", "METADATA")
        ), reverse=True)
        for meta_path in matches:
            with open(meta_path, "r", errors="replace") as _f:
                for line in _f:
                    if line.startswith("Version:"):
                        ver = line.split(":", 1)[1].strip()
                        if ver and ver != "0.1.0":
                            return ver
                        break
            break
    except Exception:
        _log_error('_installed_frontend_version/metadata')
    return None


def get_system_info():
    """Return a dict with Python, Torch, ComfyUI and platform info."""
    info = {}
    info["platform"] = sys.platform
    info["python"] = sys.version.split()[0]

    # PyTorch
    try:
        import torch
        info["torch"] = torch.__version__
        if sys.platform == "darwin":
            info["mps"] = str(torch.backends.mps.is_available())
            info["gpu"] = "MPS (Apple Silicon)" if torch.backends.mps.is_available() else "CPU"
        elif torch.cuda.is_available():
            info["gpu"] = torch.cuda.get_device_name(0)
            info["cuda"] = torch.version.cuda or "unknown"
        else:
            info["gpu"] = "CPU only"
    except Exception:
        _log_error('get_system_info/torch')
        info["torch"] = "not installed"
        info["gpu"] = "unknown"

    # ComfyUI git version (prefer tag, fall back to short rev)
    comfy_dir = os.path.join(SCRIPT_DIR, "ComfyUI")
    try:
        r = subprocess.run(
            ["git", "describe", "--tags", "--exact-match", "HEAD"],
            cwd=comfy_dir, capture_output=True, text=True, timeout=5,
        )
        if r.returncode == 0 and r.stdout.strip():
            info["comfyui_rev"] = r.stdout.strip()  # exact tag match
        else:
            r3 = subprocess.run(
                ["git", "rev-parse", "--short", "HEAD"],
                cwd=comfy_dir, capture_output=True, text=True, timeout=5,
            )
            rev = r3.stdout.strip() if r3.returncode == 0 else "unknown"
            # git describe with abbrev gives "tag-N-gSHA" when not on tag
            r2 = subprocess.run(
                ["git", "describe", "--tags", "--abbrev=4", "HEAD"],
                cwd=comfy_dir, capture_output=True, text=True, timeout=5,
            )
            desc = r2.stdout.strip() if r2.returncode == 0 else ""
            info["comfyui_rev"] = desc if desc else rev
    except Exception:
        _log_error('get_system_info/git')
        info["comfyui_rev"] = "unknown"

    # ComfyUI frontend package version
    try:
        fe_ver = _installed_frontend_version()
        info["frontend"] = fe_ver if fe_ver else "not installed"
    except Exception:
        _log_error('get_system_info/frontend')
        info["frontend"] = "unknown"

    # Free disk space
    try:
        import shutil
        _, _, free = shutil.disk_usage(SCRIPT_DIR)
        info["disk_free_gb"] = f"{free / 1e9:.1f}"
    except Exception:
        _log_error('get_system_info/disk')

    return info


def get_cache_info():
    """Return sizes (MB) of pip and uv caches."""
    result = {}
    home = os.path.expanduser("~")
    for name, path in [
        ("pip", os.path.join(home, ".cache", "pip")),
        ("uv",  os.path.join(home, ".cache", "uv")),
    ]:
        try:
            total = sum(
                os.path.getsize(os.path.join(dp, f))
                for dp, _, files in os.walk(path)
                for f in files
            )
            result[name] = round(total / 1_048_576, 1)
        except Exception:
            _log_error('get_cache_info')
            result[name] = 0
    return result


def clear_cache(cache_type):
    """Delete pip or uv cache. cache_type: 'pip' | 'uv' | 'all'"""
    import shutil
    home = os.path.expanduser("~")
    targets = {
        "pip": os.path.join(home, ".cache", "pip"),
        "uv":  os.path.join(home, ".cache", "uv"),
    }
    cleared = []
    for name, path in targets.items():
        if cache_type in (name, "all") and os.path.isdir(path):
            try:
                shutil.rmtree(path)
                os.makedirs(path)
                cleared.append(name)
            except Exception:
                pass
    return cleared


def check_comfyui_update():
    """Fetch git status for ComfyUI. Returns dict with update info."""
    comfy_dir = os.path.join(SCRIPT_DIR, "ComfyUI")
    if not os.path.isdir(os.path.join(comfy_dir, ".git")):
        return {"error": "ComfyUI directory not a git repo"}
    try:
        subprocess.run(
            ["git", "fetch", "--quiet"],
            cwd=comfy_dir, capture_output=True, timeout=10,
        )
        local = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=comfy_dir, capture_output=True, text=True, timeout=5,
        ).stdout.strip()
        remote = subprocess.run(
            ["git", "rev-parse", "@{u}"],
            cwd=comfy_dir, capture_output=True, text=True, timeout=5,
        ).stdout.strip()
        behind = subprocess.run(
            ["git", "rev-list", "--count", "HEAD..@{u}"],
            cwd=comfy_dir, capture_output=True, text=True, timeout=5,
        ).stdout.strip()
        return {
            "local": local[:8],
            "remote": remote[:8],
            "up_to_date": local == remote,
            "commits_behind": int(behind) if behind.isdigit() else 0,
        }
    except Exception as e:
        _log_error('check_comfyui_update')
        return {"error": str(e)}


def get_frontend_versions():
    """Return dict with current, versions list, and isNightly flag."""
    current = None
    try:
        current = _installed_frontend_version()
    except Exception:
        _log_error('get_frontend_versions/current')
    try:
        import urllib.request as _ur
        with _ur.urlopen(
            "https://pypi.org/pypi/comfyui_frontend_package/json", timeout=8
        ) as r:
            data = json.loads(r.read())
        all_versions = sorted(
            data.get("releases", {}).keys(),
            key=lambda v: [int(x) for x in v.replace(".post", ".").split(".") if x.isdigit()],
            reverse=True
        )
        versions = all_versions[:100]
        if current and current not in versions:
            versions.append(current)
            versions.sort(key=lambda v: [int(x) for x in v.replace(".post", ".").split(".") if x.isdigit()], reverse=True)
    except Exception:
        versions = [current] if current else []
    is_nightly = get_frontend_is_nightly()
    return {"current": current, "versions": versions, "isNightly": bool(is_nightly)}


def install_frontend_version(version):
    """pip-install a specific comfyui_frontend_package version. Returns dict."""
    python = os.path.join(SCRIPT_DIR, "python_embeded", "python")
    if not os.path.isfile(python):
        python = sys.executable
    try:
        r = subprocess.run(
            [python, "-m", "pip", "install",
             f"comfyui_frontend_package=={version}", "--quiet"],
            capture_output=True, text=True, timeout=120,
        )
        if r.returncode == 0:
            return {"ok": True, "version": version}
        return {"error": r.stderr.strip()[-300:]}
    except Exception as e:
        _log_error('install_frontend_version')
        return {"error": str(e)}


def get_frontend_is_nightly():
    """Detect if installed frontend is a nightly/dev build. Returns bool or None."""
    try:
        import glob as _glob, site as _site, re as _re
        site_dir = _site.getsitepackages()[0]
        pkg_dir = None
        candidates = _glob.glob(os.path.join(site_dir, "comfyui_frontend_package*"))
        for c in candidates:
            if os.path.isdir(c) and "dist-info" not in c:
                pkg_dir = c
                break
        if not pkg_dir:
            return None
        assets_dir = os.path.join(pkg_dir, "static", "assets")
        if not os.path.isdir(assets_dir):
            return None
        patterns = [
            _re.compile(r'__IS_NIGHTLY__\s*[=:]\s*(true|false)', _re.IGNORECASE),
            _re.compile(r'isNightly\s*=\s*(true|false)',           _re.IGNORECASE),
        ]
        js_files = sorted(
            _glob.glob(os.path.join(assets_dir, "index-*.js")),
            key=os.path.getsize, reverse=True
        )
        if not js_files:
            js_files = _glob.glob(os.path.join(assets_dir, "*.js"))
        for js_path in js_files[:3]:
            try:
                with open(js_path, "r", errors="replace") as f:
                    chunk_size = 256 * 1024
                    prev_tail = ""
                    while True:
                        chunk = f.read(chunk_size)
                        if not chunk:
                            break
                        search_text = prev_tail + chunk
                        for pat in patterns:
                            m = pat.search(search_text)
                            if m:
                                return m.group(1).lower() == "true"
                        prev_tail = chunk[-200:]
            except Exception:
                continue
        return None
    except Exception:
        return None


def get_comfyui_required_frontend(tag):
    """Read requirements.txt from a ComfyUI git tag to find required frontend version.
    Returns version string or None if not specified."""
    if not tag or tag == "NIGHTLY":
        return None
    import re as _re
    comfy_dir = os.path.join(SCRIPT_DIR, "ComfyUI")

    def _parse_fe_version(line):
        m = _re.search(r'==\s*([^\s,;#]+)', line)
        return m.group(1).strip() if m else None

    def _find_in_lines(lines):
        for line in lines:
            line = line.strip()
            if line.lower().startswith("comfyui-frontend-package"):
                return _parse_fe_version(line)
        return None

    # Try git show first
    try:
        r = subprocess.run(
            ["git", "show", f"tags/{tag}:requirements.txt"],
            cwd=comfy_dir, capture_output=True, text=True, timeout=5,
        )
        if r.returncode == 0:
            result = _find_in_lines(r.stdout.splitlines())
            if result is not None:
                return result
    except Exception:
        pass

    # Fallback: fetch from GitHub raw URL
    try:
        import urllib.request as _ur
        url = (f"https://raw.githubusercontent.com/comfyanonymous/ComfyUI"
               f"/{tag}/requirements.txt")
        req = _ur.Request(url, headers={"User-Agent": "ComfyUI-EZi"})
        with _ur.urlopen(req, timeout=8) as resp:
            text = resp.read().decode("utf-8", errors="replace")
        result = _find_in_lines(text.splitlines())
        if result is not None:
            return result
    except Exception:
        pass

    # Fallback: if tag matches current checkout, read local requirements.txt
    try:
        r = subprocess.run(
            ["git", "describe", "--tags", "--exact-match", "HEAD"],
            cwd=comfy_dir, capture_output=True, text=True, timeout=3,
        )
        current_tag = r.stdout.strip() if r.returncode == 0 else None
        if current_tag and current_tag == tag:
            req_path = os.path.join(comfy_dir, "requirements.txt")
            if os.path.exists(req_path):
                with open(req_path, "r", errors="replace") as f:
                    return _find_in_lines(f)
    except Exception:
        pass

    return None


def _pip_install_comfyui_requirements():
    """Install ComfyUI requirements.txt after a version switch. Returns dict."""
    req_path = os.path.join(SCRIPT_DIR, "ComfyUI", "requirements.txt")
    if not os.path.isfile(req_path):
        return {"skipped": "requirements.txt not found"}
    python = os.path.join(SCRIPT_DIR, "python_embeded", "python")
    if not os.path.isfile(python):
        python = sys.executable
    try:
        r = subprocess.run(
            [python, "-I", "-m", "pip", "install", "-r", req_path,
             "--no-warn-script-location"],
            capture_output=True, text=True, timeout=300,
        )
        if r.returncode == 0:
            return {"ok": True}
        return {"error": r.stderr.strip()[-300:]}
    except Exception as e:
        return {"error": str(e)}


def switch_comfyui_and_frontend(tag, fe_version=None):
    """Switch ComfyUI to a specific tag and optionally/install matching frontend.
    If fe_version is None, auto-detect from requirements.txt."""
    comfy_dir = os.path.join(SCRIPT_DIR, "ComfyUI")
    results = {"comfyui": None, "frontend": None}

    # Step 1: Checkout ComfyUI tag
    try:
        subprocess.run(
            ["git", "fetch", "--tags", "--quiet"], cwd=comfy_dir,
            capture_output=True, timeout=30,
        )
        r = subprocess.run(
            ["git", "checkout", f"tags/{tag}"], cwd=comfy_dir,
            capture_output=True, text=True, timeout=15,
        )
        if r.returncode != 0:
            return {"error": f"Git checkout failed: {r.stderr}"}
        results["comfyui"] = tag
    except Exception as e:
        return {"error": f"ComfyUI switch failed: {e}"}

    # Step 1b: Install ComfyUI requirements for the new tag (parity with EZi v3.27.1)
    req_result = _pip_install_comfyui_requirements()
    results["requirements"] = req_result
    if req_result.get("error"):
        return {"error": f"Requirements install failed: {req_result['error']}", "partial": results}

    # Step 2: Determine frontend version
    if fe_version is None or fe_version == "auto":
        fe_version = get_comfyui_required_frontend(tag)
        results["auto_detected"] = fe_version

    # Step 3: Install frontend if needed
    if fe_version:
        fe_result = install_frontend_version(fe_version)
        results["frontend"] = fe_result
        if fe_result.get("error"):
            return {"error": f"Frontend install failed: {fe_result['error']}", "partial": results}

    return {"ok": True, "results": results}



def check_installer_update():
    """Check if the local installer is behind the MAC-Linux branch HEAD on GitHub."""
    try:
        import urllib.request as _ur
        # Get remote HEAD SHA of MAC-Linux branch via GitHub API
        req = _ur.Request(
            "https://api.github.com/repos/Tavris1/ComfyUI-Easy-Install/commits/MAC-Linux?per_page=1",
            headers={"User-Agent": "ComfyUI-Desktop-Mac"}
        )
        with _ur.urlopen(req, timeout=8) as r:
            data = json.loads(r.read())
        remote_sha = data.get("sha", "")[:8]
        remote_date = data.get("commit", {}).get("committer", {}).get("date", "")[:10]
        if not remote_sha:
            return {"error": "could not read remote SHA"}

        # Get local git SHA (SCRIPT_DIR is the installer repo root)
        local_sha = ""
        local_date = ""
        try:
            r2 = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                cwd=SCRIPT_DIR, capture_output=True, text=True, timeout=5,
            )
            local_sha = r2.stdout.strip()[:8] if r2.returncode == 0 else ""
            r3 = subprocess.run(
                ["git", "log", "-1", "--format=%ci"],
                cwd=SCRIPT_DIR, capture_output=True, text=True, timeout=5,
            )
            local_date = r3.stdout.strip()[:10] if r3.returncode == 0 else ""
        except Exception:
            pass

        # Count commits behind via GitHub compare API
        commits_behind = 0
        if local_sha:
            try:
                cmp_req = _ur.Request(
                    f"https://api.github.com/repos/Tavris1/ComfyUI-Easy-Install/compare/{local_sha}...MAC-Linux",
                    headers={"User-Agent": "ComfyUI-Desktop-Mac"}
                )
                with _ur.urlopen(cmp_req, timeout=8) as rc:
                    cmp = json.loads(rc.read())
                commits_behind = cmp.get("behind_by", 0)
            except Exception:
                pass

        return {
            "local":          local_sha or "unknown",
            "local_date":     local_date,
            "remote":         remote_sha,
            "remote_date":    remote_date,
            "up_to_date":     local_sha == remote_sha or commits_behind == 0,
            "commits_behind": commits_behind,
            "release_url":    "https://github.com/Tavris1/ComfyUI-Easy-Install/tree/MAC-Linux",
        }
    except Exception as e:
        import urllib.error as _ue
        if isinstance(e, _ue.HTTPError) and e.code == 403:
            return {"error": "GitHub API rate limit exceeded"}
        _log_error('check_installer_update')
        return {"error": str(e)}


def get_custom_paths():
    """Read --input-directory / --output-directory / --user-directory from saved launch args."""
    state = {}
    try:
        if os.path.isfile(WINDOW_STATE_FILE):
            with open(WINDOW_STATE_FILE) as f:
                state = json.load(f)
    except Exception:
        pass
    args_str = state.get("launch_args", "")
    paths = {"input": "", "output": "", "user": ""}
    param_map = {
        "--input-directory":  "input",
        "--output-directory": "output",
        "--user-directory":   "user",
    }
    tokens = args_str.split()
    for i, tok in enumerate(tokens):
        if tok in param_map and i + 1 < len(tokens):
            paths[param_map[tok]] = tokens[i + 1]
    return paths


def set_custom_paths(input_dir, output_dir, user_dir):
    """Write custom paths into launch_args in the window state file."""
    try:
        state = {}
        if os.path.isfile(WINDOW_STATE_FILE):
            with open(WINDOW_STATE_FILE) as f:
                state = json.load(f)
        args_str = state.get("launch_args", "")
        # Remove existing path flags
        tokens = args_str.split()
        flags = {"--input-directory", "--output-directory", "--user-directory"}
        clean = []
        skip = False
        for tok in tokens:
            if skip:
                skip = False
                continue
            if tok in flags:
                skip = True
                continue
            clean.append(tok)
        # Append new non-empty paths
        pairs = [
            ("--input-directory",  input_dir.strip()),
            ("--output-directory", output_dir.strip()),
            ("--user-directory",   user_dir.strip()),
        ]
        for flag, val in pairs:
            if val:
                clean += [flag, val]
        state["launch_args"] = " ".join(clean)
        with open(WINDOW_STATE_FILE, "w") as f:
            json.dump(state, f)
        return {"ok": True, "launch_args": state["launch_args"]}
    except Exception as e:
        return {"error": str(e)}


# ─── ComfyUI-Manager security level ─────────────────────────────────────────

MANAGER_CONFIG_PATH = os.path.join(
    SCRIPT_DIR, "ComfyUI", "custom_nodes", "ComfyUI-Manager", "config.ini"
)


def get_manager_security_level():
    """Read security_level from ComfyUI-Manager config.ini."""
    import configparser
    try:
        # Manager's config.ini can hold duplicate keys: strict parsing raises there.
        cfg = configparser.ConfigParser(strict=False, interpolation=None)
        if os.path.isfile(MANAGER_CONFIG_PATH):
            cfg.read(MANAGER_CONFIG_PATH, encoding="utf-8")
            return cfg.get("default", "security_level", fallback="weak")
    except Exception:
        pass
    return "weak"


def set_manager_security_level(level):
    """Write security_level to ComfyUI-Manager config.ini."""
    import configparser
    valid = {"weak", "normal-", "normal", "strong"}
    if level not in valid:
        return {"error": f"Invalid level '{level}'. Must be one of: {sorted(valid)}"}
    try:
        cfg = configparser.ConfigParser(strict=False, interpolation=None)
        if os.path.isfile(MANAGER_CONFIG_PATH):
            cfg.read(MANAGER_CONFIG_PATH, encoding="utf-8")
        if not cfg.has_section("default"):
            cfg.add_section("default")
        cfg.set("default", "security_level", level)
        os.makedirs(os.path.dirname(MANAGER_CONFIG_PATH), exist_ok=True)
        with open(MANAGER_CONFIG_PATH, "w") as f:
            cfg.write(f)
        return {"ok": True, "level": level}
    except Exception as e:
        return {"error": str(e)}


def manager_config_exists():
    """Return True if ComfyUI-Manager is installed and config.ini exists."""
    return os.path.isfile(MANAGER_CONFIG_PATH)


# ─── Pinned packages ──────────────────────────────────────────────────────────

PINNED_PACKAGES_FILE = os.path.join(SCRIPT_DIR, ".pinned_packages.json")


def get_pinned_packages():
    """Return list of pinned package specs, e.g. ['numpy==1.26.4']."""
    try:
        if os.path.isfile(PINNED_PACKAGES_FILE):
            with open(PINNED_PACKAGES_FILE) as f:
                data = json.load(f)
            return data if isinstance(data, list) else []
    except Exception:
        pass
    return []


def add_pinned_package(spec):
    """Add a pip package spec to the pinned list. Returns dict."""
    spec = spec.strip()
    if not spec:
        return {"error": "Empty package spec"}
    try:
        pkgs = get_pinned_packages()
        pkg_name = spec.split("==")[0].split(">=")[0].split("<=")[0].split("!=")[0].strip().lower()
        pkgs = [p for p in pkgs
                if p.split("==")[0].split(">=")[0].split("<=")[0].split("!=")[0].strip().lower() != pkg_name]
        pkgs.append(spec)
        with open(PINNED_PACKAGES_FILE, "w") as f:
            json.dump(pkgs, f, indent=2)
        return {"ok": True, "packages": pkgs}
    except Exception as e:
        return {"error": str(e)}


def remove_pinned_package(spec):
    """Remove a package spec from the pinned list. Returns dict."""
    try:
        pkgs = get_pinned_packages()
        pkgs = [p for p in pkgs if p != spec]
        with open(PINNED_PACKAGES_FILE, "w") as f:
            json.dump(pkgs, f, indent=2)
        return {"ok": True, "packages": pkgs}
    except Exception as e:
        return {"error": str(e)}


def check_pinned_packages():
    """Return per-package install status for all pinned specs."""
    pkgs = get_pinned_packages()
    if not pkgs:
        return []
    python = os.path.join(SCRIPT_DIR, "python_embeded", "python")
    if not os.path.isfile(python):
        python = sys.executable
    installed_map = {}
    try:
        r = subprocess.run(
            [python, "-m", "pip", "list", "--format=json"],
            capture_output=True, text=True, timeout=20,
        )
        if r.returncode == 0:
            for pkg in json.loads(r.stdout):
                installed_map[pkg["name"].lower().replace("-", "_")] = pkg["version"]
    except Exception:
        pass
    results = []
    for spec in pkgs:
        pkg_name = spec.split("==")[0].split(">=")[0].split("<=")[0].split("!=")[0].strip()
        key = pkg_name.lower().replace("-", "_")
        installed_ver = installed_map.get(key)
        results.append({"spec": spec, "installed": installed_ver, "ok": installed_ver is not None})
    return results


def enforce_pinned_packages():
    """pip-install all pinned packages. Called at startup to enforce versions."""
    pkgs = get_pinned_packages()
    if not pkgs:
        return
    python = os.path.join(SCRIPT_DIR, "python_embeded", "python")
    if not os.path.isfile(python):
        python = sys.executable
    try:
        print(f"  Enforcing {len(pkgs)} pinned package(s): {', '.join(pkgs)}")
        subprocess.run(
            [python, "-m", "pip", "install", "--quiet"] + pkgs,
            capture_output=True, timeout=120,
        )
    except Exception as e:
        print(f"  Warning: pinned packages enforcement failed: {e}")


_COMMON_NODE_SLOT = {
    'CLIP': '#FFD500', 'CLIP_VISION': '#A8DADC', 'CLIP_VISION_OUTPUT': '#ad7452',
    'CONDITIONING': '#FFA931', 'CONTROL_NET': '#6EE7B7', 'IMAGE': '#64B5F6',
    'LATENT': '#FF9CF9', 'MASK': '#81C784', 'MODEL': '#B39DDB',
    'STYLE_MODEL': '#C2FFAE', 'VAE': '#FF6E6E', 'NOISE': '#B0B0B0',
    'GUIDER': '#66FFFF', 'SAMPLER': '#ECB4B4', 'SIGMAS': '#CDFFCD', 'TAESD': '#DCC274',
}

_FALLBACK_PALETTES = {
    'dark': {
        'node_slot': _COMMON_NODE_SLOT,
        'litegraph_base': {
            'CLEAR_BACKGROUND_COLOR': '#141414', 'NODE_TITLE_COLOR': '#999',
            'NODE_SELECTED_TITLE_COLOR': '#FFF', 'NODE_TEXT_COLOR': '#AAA',
            'NODE_TEXT_HIGHLIGHT_COLOR': '#FFF', 'NODE_DEFAULT_COLOR': '#333',
            'NODE_DEFAULT_BGCOLOR': '#353535', 'NODE_DEFAULT_BOXCOLOR': '#666',
            'NODE_DEFAULT_SHAPE': 2, 'NODE_BOX_OUTLINE_COLOR': '#FFF',
            'NODE_BYPASS_BGCOLOR': '#FF00FF', 'NODE_ERROR_COLOUR': '#E00',
            'DEFAULT_SHADOW_COLOR': 'rgba(0,0,0,0.5)', 'WIDGET_BGCOLOR': '#222',
            'WIDGET_OUTLINE_COLOR': '#666', 'WIDGET_TEXT_COLOR': '#DDD',
            'WIDGET_SECONDARY_TEXT_COLOR': '#999', 'WIDGET_DISABLED_TEXT_COLOR': '#666',
            'LINK_COLOR': '#9A9', 'EVENT_LINK_COLOR': '#A86', 'CONNECTING_LINK_COLOR': '#AFA',
            'BADGE_FG_COLOR': '#FFF', 'BADGE_BG_COLOR': '#0F1F0F',
        },
        'comfy_base': {
            'fg-color': '#fff', 'bg-color': '#202020', 'comfy-menu-bg': '#171718',
            'comfy-menu-secondary-bg': '#303030', 'comfy-input-bg': '#222',
            'input-text': '#ddd', 'descrip-text': '#999', 'drag-text': '#ccc',
            'error-text': '#ff4444', 'border-color': '#4e4e4e',
            'tr-even-bg-color': '#222', 'tr-odd-bg-color': '#353535',
            'content-bg': '#4e4e4e', 'content-fg': '#fff',
            'content-hover-bg': '#222', 'content-hover-fg': '#fff',
            'bar-shadow': 'rgba(16, 16, 16, 0.5) 0 0 0.5rem',
        },
    },
    'light': {
        'node_slot': _COMMON_NODE_SLOT,
        'litegraph_base': {
            'CLEAR_BACKGROUND_COLOR': '#e0e0e0', 'NODE_TITLE_COLOR': '#222',
            'NODE_SELECTED_TITLE_COLOR': '#000', 'NODE_TEXT_COLOR': '#333',
            'NODE_TEXT_HIGHLIGHT_COLOR': '#000', 'NODE_DEFAULT_COLOR': '#ccc',
            'NODE_DEFAULT_BGCOLOR': '#f5f5f5', 'NODE_DEFAULT_BOXCOLOR': '#999',
            'NODE_DEFAULT_SHAPE': 2, 'NODE_BOX_OUTLINE_COLOR': '#000',
            'NODE_BYPASS_BGCOLOR': '#FF00FF', 'NODE_ERROR_COLOUR': '#E00',
            'DEFAULT_SHADOW_COLOR': 'rgba(0,0,0,0.1)', 'WIDGET_BGCOLOR': '#e0e0e0',
            'WIDGET_OUTLINE_COLOR': '#999', 'WIDGET_TEXT_COLOR': '#333',
            'WIDGET_SECONDARY_TEXT_COLOR': '#666', 'WIDGET_DISABLED_TEXT_COLOR': '#999',
            'LINK_COLOR': '#4CAF50', 'EVENT_LINK_COLOR': '#FF9800', 'CONNECTING_LINK_COLOR': '#2196F3',
            'BADGE_FG_COLOR': '#000', 'BADGE_BG_COLOR': '#e0f0e0',
        },
        'comfy_base': {
            'fg-color': '#222', 'bg-color': '#e9e9e9', 'comfy-menu-bg': '#f5f5f5',
            'comfy-menu-secondary-bg': '#e0e0e0', 'comfy-input-bg': '#d0d0d0',
            'input-text': '#222', 'descrip-text': '#666', 'drag-text': '#888',
            'error-text': '#cc0000', 'border-color': '#bbb',
            'tr-even-bg-color': '#e5e5e5', 'tr-odd-bg-color': '#f0f0f0',
            'content-bg': '#bbb', 'content-fg': '#222',
            'content-hover-bg': '#d0d0d0', 'content-hover-fg': '#000',
            'bar-shadow': 'rgba(0, 0, 0, 0.1) 0 0 0.5rem',
        },
    },
    'solarized': {
        'node_slot': _COMMON_NODE_SLOT,
        'litegraph_base': {
            'CLEAR_BACKGROUND_COLOR': '#002b36', 'NODE_TITLE_COLOR': '#93a1a1',
            'NODE_SELECTED_TITLE_COLOR': '#fdf6e3', 'NODE_TEXT_COLOR': '#839496',
            'NODE_TEXT_HIGHLIGHT_COLOR': '#fdf6e3', 'NODE_DEFAULT_COLOR': '#073642',
            'NODE_DEFAULT_BGCOLOR': '#073642', 'NODE_DEFAULT_BOXCOLOR': '#586e75',
            'NODE_DEFAULT_SHAPE': 2, 'NODE_BOX_OUTLINE_COLOR': '#268bd2',
            'NODE_BYPASS_BGCOLOR': '#FF00FF', 'NODE_ERROR_COLOUR': '#dc322f',
            'DEFAULT_SHADOW_COLOR': 'rgba(0,0,0,0.5)', 'WIDGET_BGCOLOR': '#003847',
            'WIDGET_OUTLINE_COLOR': '#586e75', 'WIDGET_TEXT_COLOR': '#839496',
            'WIDGET_SECONDARY_TEXT_COLOR': '#657b83', 'WIDGET_DISABLED_TEXT_COLOR': '#586e75',
            'LINK_COLOR': '#2aa198', 'EVENT_LINK_COLOR': '#cb4b16', 'CONNECTING_LINK_COLOR': '#859900',
            'BADGE_FG_COLOR': '#fdf6e3', 'BADGE_BG_COLOR': '#073642',
        },
        'comfy_base': {
            'fg-color': '#839496', 'bg-color': '#002b36', 'comfy-menu-bg': '#073642',
            'comfy-menu-secondary-bg': '#003847', 'comfy-input-bg': '#003847',
            'input-text': '#839496', 'descrip-text': '#657b83', 'drag-text': '#586e75',
            'error-text': '#dc322f', 'border-color': '#0d525e',
            'tr-even-bg-color': '#003847', 'tr-odd-bg-color': '#073642',
            'content-bg': '#0d525e', 'content-fg': '#839496',
            'content-hover-bg': '#003847', 'content-hover-fg': '#93a1a1',
            'bar-shadow': 'rgba(0, 0, 0, 0.5) 0 0 0.5rem',
        },
    },
    'arc': {
        'node_slot': _COMMON_NODE_SLOT,
        'litegraph_base': {
            'CLEAR_BACKGROUND_COLOR': '#2f343f', 'NODE_TITLE_COLOR': '#d3dae3',
            'NODE_SELECTED_TITLE_COLOR': '#fff', 'NODE_TEXT_COLOR': '#d3dae3',
            'NODE_TEXT_HIGHLIGHT_COLOR': '#fff', 'NODE_DEFAULT_COLOR': '#383c4a',
            'NODE_DEFAULT_BGCOLOR': '#383c4a', 'NODE_DEFAULT_BOXCOLOR': '#4b5162',
            'NODE_DEFAULT_SHAPE': 2, 'NODE_BOX_OUTLINE_COLOR': '#5294e2',
            'NODE_BYPASS_BGCOLOR': '#FF00FF', 'NODE_ERROR_COLOUR': '#E00',
            'DEFAULT_SHADOW_COLOR': 'rgba(0,0,0,0.5)', 'WIDGET_BGCOLOR': '#404552',
            'WIDGET_OUTLINE_COLOR': '#4b5162', 'WIDGET_TEXT_COLOR': '#d3dae3',
            'WIDGET_SECONDARY_TEXT_COLOR': '#9c9fa8', 'WIDGET_DISABLED_TEXT_COLOR': '#666',
            'LINK_COLOR': '#5294e2', 'EVENT_LINK_COLOR': '#cba6f7', 'CONNECTING_LINK_COLOR': '#5294e2',
            'BADGE_FG_COLOR': '#d3dae3', 'BADGE_BG_COLOR': '#2f343f',
        },
        'comfy_base': {
            'fg-color': '#d3dae3', 'bg-color': '#2f343f', 'comfy-menu-bg': '#383c4a',
            'comfy-menu-secondary-bg': '#404552', 'comfy-input-bg': '#404552',
            'input-text': '#d3dae3', 'descrip-text': '#9c9fa8', 'drag-text': '#9c9fa8',
            'error-text': '#ff4444', 'border-color': '#4b5162',
            'tr-even-bg-color': '#404552', 'tr-odd-bg-color': '#383c4a',
            'content-bg': '#4b5162', 'content-fg': '#d3dae3',
            'content-hover-bg': '#404552', 'content-hover-fg': '#fff',
            'bar-shadow': 'rgba(0, 0, 0, 0.5) 0 0 0.5rem',
        },
    },
    'nord': {
        'node_slot': _COMMON_NODE_SLOT,
        'litegraph_base': {
            'CLEAR_BACKGROUND_COLOR': '#2e3440', 'NODE_TITLE_COLOR': '#d8dee9',
            'NODE_SELECTED_TITLE_COLOR': '#eceff4', 'NODE_TEXT_COLOR': '#d8dee9',
            'NODE_TEXT_HIGHLIGHT_COLOR': '#eceff4', 'NODE_DEFAULT_COLOR': '#3b4252',
            'NODE_DEFAULT_BGCOLOR': '#3b4252', 'NODE_DEFAULT_BOXCOLOR': '#4c566a',
            'NODE_DEFAULT_SHAPE': 2, 'NODE_BOX_OUTLINE_COLOR': '#88c0d0',
            'NODE_BYPASS_BGCOLOR': '#FF00FF', 'NODE_ERROR_COLOUR': '#bf616a',
            'DEFAULT_SHADOW_COLOR': 'rgba(0,0,0,0.5)', 'WIDGET_BGCOLOR': '#434c5e',
            'WIDGET_OUTLINE_COLOR': '#4c566a', 'WIDGET_TEXT_COLOR': '#d8dee9',
            'WIDGET_SECONDARY_TEXT_COLOR': '#81a1c1', 'WIDGET_DISABLED_TEXT_COLOR': '#4c566a',
            'LINK_COLOR': '#88c0d0', 'EVENT_LINK_COLOR': '#d08770', 'CONNECTING_LINK_COLOR': '#a3be8c',
            'BADGE_FG_COLOR': '#eceff4', 'BADGE_BG_COLOR': '#2e3440',
        },
        'comfy_base': {
            'fg-color': '#d8dee9', 'bg-color': '#2e3440', 'comfy-menu-bg': '#3b4252',
            'comfy-menu-secondary-bg': '#434c5e', 'comfy-input-bg': '#434c5e',
            'input-text': '#d8dee9', 'descrip-text': '#81a1c1', 'drag-text': '#81a1c1',
            'error-text': '#bf616a', 'border-color': '#4c566a',
            'tr-even-bg-color': '#434c5e', 'tr-odd-bg-color': '#3b4252',
            'content-bg': '#4c566a', 'content-fg': '#d8dee9',
            'content-hover-bg': '#434c5e', 'content-hover-fg': '#eceff4',
            'bar-shadow': 'rgba(0, 0, 0, 0.5) 0 0 0.5rem',
        },
    },
    'github': {
        'node_slot': _COMMON_NODE_SLOT,
        'litegraph_base': {
            'CLEAR_BACKGROUND_COLOR': '#0d1117', 'NODE_TITLE_COLOR': '#c9d1d9',
            'NODE_SELECTED_TITLE_COLOR': '#f0f6fc', 'NODE_TEXT_COLOR': '#c9d1d9',
            'NODE_TEXT_HIGHLIGHT_COLOR': '#f0f6fc', 'NODE_DEFAULT_COLOR': '#161b22',
            'NODE_DEFAULT_BGCOLOR': '#161b22', 'NODE_DEFAULT_BOXCOLOR': '#30363d',
            'NODE_DEFAULT_SHAPE': 2, 'NODE_BOX_OUTLINE_COLOR': '#388bfd',
            'NODE_BYPASS_BGCOLOR': '#FF00FF', 'NODE_ERROR_COLOUR': '#f85149',
            'DEFAULT_SHADOW_COLOR': 'rgba(0,0,0,0.5)', 'WIDGET_BGCOLOR': '#21262d',
            'WIDGET_OUTLINE_COLOR': '#30363d', 'WIDGET_TEXT_COLOR': '#c9d1d9',
            'WIDGET_SECONDARY_TEXT_COLOR': '#8b949e', 'WIDGET_DISABLED_TEXT_COLOR': '#484f58',
            'LINK_COLOR': '#3fb950', 'EVENT_LINK_COLOR': '#d29922', 'CONNECTING_LINK_COLOR': '#388bfd',
            'BADGE_FG_COLOR': '#f0f6fc', 'BADGE_BG_COLOR': '#0d1117',
        },
        'comfy_base': {
            'fg-color': '#c9d1d9', 'bg-color': '#0d1117', 'comfy-menu-bg': '#161b22',
            'comfy-menu-secondary-bg': '#21262d', 'comfy-input-bg': '#21262d',
            'input-text': '#c9d1d9', 'descrip-text': '#8b949e', 'drag-text': '#8b949e',
            'error-text': '#f85149', 'border-color': '#30363d',
            'tr-even-bg-color': '#21262d', 'tr-odd-bg-color': '#161b22',
            'content-bg': '#30363d', 'content-fg': '#c9d1d9',
            'content-hover-bg': '#21262d', 'content-hover-fg': '#f0f6fc',
            'bar-shadow': 'rgba(0, 0, 0, 0.5) 0 0 0.5rem',
        },
    },
}


def _get_builtin_palettes_from_frontend():
    """Try to load palette JSON files from the comfyui_frontend_package."""
    try:
        import glob as _glob, site as _site
        site_dirs = _site.getsitepackages()
    except Exception:
        return {}
    for site_pkgs in site_dirs:
        if not os.path.isdir(site_pkgs):
            continue
        pkg_dir = os.path.join(site_pkgs, 'comfyui_frontend_package')
        if not os.path.isdir(pkg_dir):
            candidates = _glob.glob(os.path.join(site_pkgs, 'comfyui_frontend_package*'))
            pkg_dir = next((c for c in candidates if os.path.isdir(c) and 'dist-info' not in c), None)
            if not pkg_dir:
                continue
        palettes_dir = os.path.join(pkg_dir, 'static', 'assets', 'palettes')
        if not os.path.isdir(palettes_dir):
            continue
        palettes = {}
        try:
            for fname in os.listdir(palettes_dir):
                if not fname.endswith('.json'):
                    continue
                fpath = os.path.join(palettes_dir, fname)
                try:
                    with open(fpath, 'r', encoding='utf-8', errors='replace') as f:
                        data = json.load(f)
                    pid = data.get('id')
                    colors = data.get('colors', {})
                    if pid and colors:
                        palettes[pid] = colors
                except Exception:
                    continue
        except Exception:
            return {}
        if palettes:
            return palettes
    return {}


_BUILTIN_PALETTES_CACHE = None

def _get_builtin_palettes():
    global _BUILTIN_PALETTES_CACHE
    if _BUILTIN_PALETTES_CACHE is not None:
        return _BUILTIN_PALETTES_CACHE
    from_frontend = _get_builtin_palettes_from_frontend()
    if from_frontend:
        _BUILTIN_PALETTES_CACHE = from_frontend
        return _BUILTIN_PALETTES_CACHE
    _BUILTIN_PALETTES_CACHE = _FALLBACK_PALETTES
    return _BUILTIN_PALETTES_CACHE


def _blend_hex(hex1, hex2, t=0.35):
    try:
        h1, h2 = hex1.lstrip('#'), hex2.lstrip('#')
        if len(h1) == 3: h1 = h1[0]*2 + h1[1]*2 + h1[2]*2
        if len(h2) == 3: h2 = h2[0]*2 + h2[1]*2 + h2[2]*2
        r1,g1,b1 = int(h1[0:2],16), int(h1[2:4],16), int(h1[4:6],16)
        r2,g2,b2 = int(h2[0:2],16), int(h2[2:4],16), int(h2[4:6],16)
        return '#{:02x}{:02x}{:02x}'.format(
            int(r1*(1-t)+r2*t), int(g1*(1-t)+g2*t), int(b1*(1-t)+b2*t))
    except Exception:
        return hex1


def _hex_luminance(h):
    try:
        h = h.lstrip('#')
        if len(h) == 3: h = h[0]*2+h[1]*2+h[2]*2
        r,g,b = int(h[0:2],16)/255, int(h[2:4],16)/255, int(h[4:6],16)/255
        def lin(c): return c/12.92 if c <= 0.04045 else ((c+0.055)/1.055)**2.4
        return 0.2126*lin(r)+0.7152*lin(g)+0.0722*lin(b)
    except Exception:
        return 0.5


def get_comfy_theme():
    """Read ComfyUI's active palette and derive CSS vars for the desktop panel."""
    try:
        user_dir = os.path.join(SCRIPT_DIR, "ComfyUI", "user", "default")
        settings_file = os.path.join(user_dir, "comfy.settings.json")
        palette_id = "dark"
        custom_palettes = {}
        if os.path.isfile(settings_file):
            with open(settings_file, "r", errors="replace") as f:
                data = json.load(f)
            palette_id = data.get("Comfy.ColorPalette", "") or "dark"
            custom_palettes = data.get("Comfy.CustomColorPalettes", {})

        # Get colors from custom palette first, then builtins (frontend or fallback)
        colors = {}
        if palette_id in custom_palettes:
            c = custom_palettes[palette_id].get("colors", {})
            cb = c.get("comfy_base", {})
            lg = c.get("litegraph_base", {})
        else:
            builtin = _get_builtin_palettes()
            c = builtin.get(palette_id, builtin.get("dark", {}))
            cb = c.get("comfy_base", {})
            lg = c.get("litegraph_base", {})

        bg       = cb.get("bg-color", "#202020")
        menu_bg  = cb.get("comfy-menu-bg", "#171718")
        fg       = cb.get("fg-color", "#ffffff")
        border   = cb.get("border-color", "#4e4e4e")
        input_bg = cb.get("comfy-input-bg", "#222222")
        accent   = lg.get("NODE_BOX_OUTLINE_COLOR") or lg.get("LINK_COLOR") or "#888"
        node_bg  = lg.get("NODE_DEFAULT_BGCOLOR", "#353535")

        # If accent is too bright or too dark, try LINK_COLOR instead
        acc_lum = _hex_luminance(accent)
        if acc_lum > 0.80 or acc_lum < 0.05:
            link_color = lg.get("LINK_COLOR", "")
            if link_color:
                link_lum = _hex_luminance(link_color)
                if 0.05 <= link_lum <= 0.80:
                    accent = link_color
                    acc_lum = link_lum

        # Derive accent variants
        if acc_lum >= 0.18:
            acc_bg       = _blend_hex(accent, "#000000", 0.60)
            acc_bg_hover = _blend_hex(accent, "#000000", 0.45)
        else:
            acc_bg       = _blend_hex(accent, "#ffffff", 0.60)
            acc_bg_hover = _blend_hex(accent, "#ffffff", 0.45)
        acc_lum2 = _hex_luminance(acc_bg)
        text_on_accent = "#ffffff" if acc_lum2 < 0.35 else "#111111"
        acc_hover = _blend_hex(accent, "#ffffff", 0.30)

        # Muted text (blend fg toward bg)
        muted = _blend_hex(fg, bg, 0.55)

        return {
            "palette_id":       palette_id,
            "--bg":             menu_bg,
            "--panel-bg":       menu_bg,
            "--node-bg":        node_bg,
            "--fg":             fg,
            "--muted":          muted,
            "--border":         border,
            "--input-bg":       input_bg,
            "--accent":         accent,
            "--accent-hover":   acc_hover,
            "--accent-bg":      acc_bg,
            "--accent-bg-hover":acc_bg_hover,
            "--text-on-accent": text_on_accent,
        }
    except Exception as e:
        _log_error('get_comfy_theme')
        return {"error": str(e)}


def list_comfy_themes():
    """Return list of available palette IDs: builtins + any custom palettes."""
    ids = list(_get_builtin_palettes().keys())
    try:
        user_dir = os.path.join(SCRIPT_DIR, "ComfyUI", "user", "default")
        settings_file = os.path.join(user_dir, "comfy.settings.json")
        if os.path.isfile(settings_file):
            with open(settings_file, "r", errors="replace") as f:
                data = json.load(f)
            custom = list(data.get("Comfy.CustomColorPalettes", {}).keys())
            ids = ids + [c for c in custom if c not in ids]
    except Exception:
        pass
    return ids


def set_comfy_theme(palette_id):
    """Write Comfy.ColorPalette into comfy.settings.json. Returns dict."""
    try:
        user_dir = os.path.join(SCRIPT_DIR, "ComfyUI", "user", "default")
        os.makedirs(user_dir, exist_ok=True)
        settings_file = os.path.join(user_dir, "comfy.settings.json")
        data = {}
        if os.path.isfile(settings_file):
            with open(settings_file, "r", errors="replace") as f:
                data = json.load(f)
        data["Comfy.ColorPalette"] = palette_id
        tmp = settings_file + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        os.replace(tmp, settings_file)
        return {"ok": True, "palette_id": palette_id}
    except Exception as e:
        return {"error": str(e)}


def _mac_linux_ezi_version():
    """Return EZI_VERSION from comfyui_desktop.py on the MAC-Linux branch, or ''."""
    try:
        import re as _re
        import urllib.request as _ur
        req = _ur.Request(
            "https://raw.githubusercontent.com/Tavris1/ComfyUI-Easy-Install/MAC-Linux/comfyui_desktop.py",
            headers={"User-Agent": "ComfyUI-EZi"},
        )
        with _ur.urlopen(req, timeout=8) as r:
            head = r.read(8192).decode("utf-8", errors="replace")
        m = _re.search(r'^EZI_VERSION = "([^"]+)"', head, _re.MULTILINE)
        return m.group(1) if m else ""
    except Exception:
        _log_error('_mac_linux_ezi_version')
    return ""


def _latest_release_tag(repo_owner, repo_name):
    """Get latest release tag from GitHub redirect or API. Returns tag string or ''."""
    try:
        import urllib.request as _ur
        headers = {"User-Agent": "ComfyUI-EZi"}
        req = _ur.Request(
            f"https://github.com/{repo_owner}/{repo_name}/releases/latest",
            headers=headers, method="HEAD",
        )
        with _ur.urlopen(req, timeout=8) as r:
            tag = r.geturl().rstrip("/").rsplit("/", 1)[-1].strip()
        if tag:
            return tag
    except Exception:
        _log_error('_latest_release_tag/head')
    try:
        import urllib.request as _ur, json as _json
        req = _ur.Request(
            f"https://api.github.com/repos/{repo_owner}/{repo_name}/releases/latest",
            headers={"User-Agent": "ComfyUI-EZi"},
        )
        with _ur.urlopen(req, timeout=8) as r:
            data = _json.loads(r.read())
        return (data.get("tag_name") or "").strip()
    except Exception:
        _log_error('_latest_release_tag/api')
    return ""


def get_comfyui_versions():
    """Return ComfyUI git tags (local + remote GitHub, newest first, max 20) with stable label."""
    import re as _re
    import urllib.request as _ur

    def _ver_key(tag):
        nums = [int(x) for x in _re.findall(r'\d+', tag)]
        return nums if nums else [0]

    comfy_dir = os.path.join(SCRIPT_DIR, "ComfyUI")

    # Current checked-out tag
    current = None
    try:
        r = subprocess.run(
            ["git", "describe", "--tags", "--exact-match", "HEAD"],
            cwd=comfy_dir, capture_output=True, text=True, timeout=5,
        )
        if r.returncode == 0:
            current = r.stdout.strip() or None
    except Exception:
        pass

    # Local tags
    local_tags = []
    try:
        r = subprocess.run(
            ["git", "tag", "--sort=-creatordate"],
            cwd=comfy_dir, capture_output=True, text=True, timeout=10,
        )
        local_tags = [t.strip() for t in r.stdout.splitlines() if t.strip()]
    except Exception:
        pass

    # Remote GitHub tags (up to 200)
    remote_tags = []
    for page in (1, 2):
        try:
            req = _ur.Request(
                f"https://api.github.com/repos/comfyanonymous/ComfyUI/tags?per_page=100&page={page}",
                headers={"User-Agent": "ComfyUI-EZi"},
            )
            with _ur.urlopen(req, timeout=8) as resp:
                data = json.loads(resp.read())
            batch = [t["name"] for t in data if t.get("name")]
            remote_tags.extend(batch)
            if len(batch) < 100:
                break
        except Exception:
            break

    all_tags = list({t for t in (local_tags + remote_tags) if _re.match(r'^v?\d+\.\d+', t)})
    all_tags.sort(key=_ver_key, reverse=True)
    all_tags = all_tags[:20]
    if current and current not in all_tags:
        all_tags.insert(0, current)
        all_tags = all_tags[:20]
    if not current:
        all_tags.insert(0, "NIGHTLY")
        current = "NIGHTLY"

    # Latest stable release from GitHub
    stable_version = None
    try:
        stable_version = _latest_release_tag("comfyanonymous", "ComfyUI")
        if stable_version:
            try:
                state = load_window_state()
                state["cached_comfy_stable_version"] = stable_version
                with open(WINDOW_STATE_FILE, "w") as _sf:
                    json.dump(state, _sf)
            except Exception:
                _log_error('get_comfyui_versions/cache_stable')
    except Exception:
        _log_error('get_comfyui_versions/stable')
    if not stable_version:
        try:
            state = load_window_state()
            stable_version = state.get("cached_comfy_stable_version") or None
        except Exception:
            _log_error('get_comfyui_versions/cache_read')

    return {"current": current, "versions": all_tags, "stableVersion": stable_version}


# Loading splash shown instantly while server starts up
LOADING_HTML = f"""
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
  *{{margin:0;padding:0;box-sizing:border-box}}
  body{{background:#1e1e28;color:#e0e0e0;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;
       display:flex;align-items:center;justify-content:center;height:100vh;overflow:hidden}}
  .wrap{{text-align:center}}
  .logo img{{width:96px;height:96px;margin-bottom:16px}}
  .status{{font-size:15px;color:#888;margin-bottom:24px}}
  .bar{{width:200px;height:3px;background:#333;border-radius:2px;margin:0 auto;overflow:hidden}}
  .bar .fill{{width:30%;height:100%;background:linear-gradient(90deg,#50c878,#ffc832);border-radius:2px;
              animation:slide 1.2s ease-in-out infinite}}
  @keyframes slide{{0%{{transform:translateX(-100%)}}100%{{transform:translateX(400%)}}}}
  .hint{{position:fixed;bottom:20px;left:0;right:0;text-align:center;font-size:12px;color:#555}}
</style>
</head>
<body>
<div class="wrap">
  <div class="logo">{('<img src="data:image/png;base64,' + _ICON_B64 + '" alt="ComfyUI">') if _ICON_B64 else ''}</div>
  <div class="status" id="status">Connecting to {COMFYUI_HOST}:{COMFYUI_PORT}...</div>
  <div class="bar"><div class="fill"></div></div>
</div>
<div class="hint">Cmd+B to open in browser &bull; Pixaroma</div>
</body>
</html>
"""

# Combined JS injected once after ComfyUI loads — shortcuts + performance + download fix
INJECTED_JS = """
(function() {
    if (window._comfyDesktopReady) return;
    window._comfyDesktopReady = true;

    /* ── Restore persisted localStorage (matches Windows v3.18+ behavior) ── */
    try {
        if (window._eziRestoreStorage && typeof window._eziRestoreStorage === 'function') {
            window._eziRestoreStorage();
        }
    } catch(e) {}

    /* ── Bridge to Python for storage/WS events ── */
    window._eziPostToShell = function(msg) {
        try {
            if (!msg || !msg.type) return;
            if (msg.type === 'ezi_storage_save') {
                pywebview.api.ezi_storage_save(JSON.stringify(msg.ls || {}), msg.settled ? 1 : 0);
            } else if (msg.type === 'ezi_comfy_ready') {
                pywebview.api.ezi_comfy_ready();
            } else if (msg.type === 'ezi_ws_lost') {
                pywebview.api.ezi_ws_lost();
            }
        } catch(e) {}
    };

    /* ── Flush localStorage back to Python before pagehide/unload ── */
    window.__eziFlushStorageNow = function() {
        try {
            var out = {};
            var ls = window.localStorage;
            for (var i = 0; i < ls.length; i++) {
                var k = ls.key(i);
                if (k) out[k] = ls.getItem(k);
            }
            window._eziPostToShell({ type: 'ezi_storage_save', settled: performance.now() > 5000, ls: out });
        } catch(e) {}
    };
    window.addEventListener('pagehide', window.__eziFlushStorageNow);
    window.addEventListener('beforeunload', window.__eziFlushStorageNow);

    /* ── WebSocket readiness / disconnect detector (matches Windows v3.19+) ── */
    var _eziComfyReady = false;
    var _OrigWS = window.WebSocket;
    function _eziCheckMsg(data) {
        if (_eziComfyReady) return;
        try {
            var d = JSON.parse(data);
            if (d && d.type === 'status') {
                _eziComfyReady = true;
                if (window._eziPostToShell) window._eziPostToShell({ type: 'ezi_comfy_ready' });
            }
        } catch(e) {}
    }
    window.WebSocket = function(url, protocols) {
        var ws = protocols ? new _OrigWS(url, protocols) : new _OrigWS(url);
        var _origAEL = ws.addEventListener.bind(ws);
        ws.addEventListener = function(type, fn, opts) {
            if (type === 'message') {
                return _origAEL('message', function(ev) { _eziCheckMsg(ev.data); return fn.apply(this, arguments); }, opts);
            }
            if (type === 'close' || type === 'error') {
                return _origAEL(type, function(ev) {
                    if (_eziComfyReady && window._eziPostToShell) {
                        _eziComfyReady = false;
                        window._eziPostToShell({ type: 'ezi_ws_lost' });
                    }
                    return fn.apply(this, arguments);
                }, opts);
            }
            return _origAEL(type, fn, opts);
        };
        var _onmsg = null;
        Object.defineProperty(ws, 'onmessage', {
            get: function() { return _onmsg; },
            set: function(fn) {
                _onmsg = fn ? function(ev) { _eziCheckMsg(ev.data); return fn.apply(this, arguments); } : fn;
            },
            configurable: true
        });
        return ws;
    };
    window.WebSocket.prototype = _OrigWS.prototype;
    window.WebSocket.CONNECTING = _OrigWS.CONNECTING;
    window.WebSocket.OPEN = _OrigWS.OPEN;
    window.WebSocket.CLOSING = _OrigWS.CLOSING;
    window.WebSocket.CLOSED = _OrigWS.CLOSED;

    /* Cmd+B / Ctrl+B → open in browser */
    document.addEventListener('keydown', function(e) {
        if ((e.metaKey || e.ctrlKey) && e.key === 'b') {
            e.preventDefault();
            pywebview.api.open_browser();
        }
    });

    /* Performance: GPU compositing hint on canvas + EZi Panel Themes */
    var style = document.createElement('style');
    style.textContent = [
        'canvas { will-change: transform; }',
        '* { scroll-behavior: auto !important; }',
        '#_comfy_toast{position:fixed;top:16px;right:16px;background:#333;color:#e0e0e0;padding:10px 18px;',
        'border-radius:8px;font-size:13px;z-index:99999;opacity:0;transition:opacity .3s;pointer-events:none}',
        '#_comfy_toast.show{opacity:1}',
        /* EZi Panel Themes */
        '._ezi-theme-dark{--bg:#1a1a1a;--panel-bg:#1e1e28;--node-bg:#252530;--fg:#e0e0e0;--muted:#888;--border:#444;--input-bg:#111;--accent:#e8530a;--accent-hover:#ff7040;--accent-bg:#6e2200;--accent-bg-hover:#8a3000;--text-on-accent:#fff}',
        '._ezi-theme-pixaroma{--bg:#1a1a1a;--panel-bg:#1e1e28;--node-bg:#252530;--fg:#cccccc;--muted:#888;--border:#444;--input-bg:#111;--accent:#e8530a;--accent-hover:#ff7040;--accent-bg:#6e2200;--accent-bg-hover:#8a3000;--text-on-accent:#fff}',
        '._ezi-theme-light{--bg:#f0f2f5;--panel-bg:#ffffff;--node-bg:#e2e6eb;--fg:#333;--muted:#666;--border:#c8cdd5;--input-bg:#fff;--accent:#e8530a;--accent-hover:#ff7040;--accent-bg:#ffdcc8;--accent-bg-hover:#ffcbb0;--text-on-accent:#000}',
        '._ezi-theme-aurora{--bg:#0b1926;--panel-bg:#102638;--node-bg:#122438;--fg:#edf3ff;--muted:#a1b3cc;--border:#304659;--input-bg:#09232d;--accent:#82dfcd;--accent-hover:#9be9d9;--accent-bg:#224c56;--accent-bg-hover:#2b616c;--text-on-accent:#0b1926}',
        '._ezi-theme-comfyui{/* Uses ComfyUI theme vars applied via JS */}',
    ].join('\\n');
    document.head.appendChild(style);

    /* Toast helper */
    var toast = document.createElement('div');
    toast.id = '_comfy_toast';
    document.body.appendChild(toast);
    function showToast(msg, ms) {
        toast.textContent = msg;
        toast.classList.add('show');
        setTimeout(function(){ toast.classList.remove('show'); }, ms || 3000);
    }

    /* Extract filename from URL or download attribute */
    function getFilename(a) {
        if (a.getAttribute('download')) return a.getAttribute('download');
        try {
            var u = new URL(a.href);
            var p = u.searchParams.get('filename');
            if (p) return p;
            var parts = u.pathname.split('/');
            var last = parts[parts.length - 1];
            if (last && last.includes('.')) return decodeURIComponent(last);
        } catch(e) {}
        return 'download';
    }

    /* Find the model subfolder matching a download, based on the workflow's model info */
    function eziFindModelDir(href, filename) {
        try {
            var app = window.app;
            if (!app || !app.graph) return '';
            var strip = function(u) { return String(u || '').split('?')[0].split('#')[0]; };
            var hrefBase = strip(href);
            var seen = [];
            var match = function(models) {
                if (!Array.isArray(models)) return '';
                for (var i = 0; i < models.length; i++) {
                    var m = models[i];
                    if (!m || !m.directory) continue;
                    if ((m.url && strip(m.url) === hrefBase) || (m.name && m.name === filename)) return String(m.directory);
                }
                return '';
            };
            var scan = function(graph) {
                if (!graph || seen.indexOf(graph) !== -1) return '';
                seen.push(graph);
                var nodes = graph._nodes || graph.nodes || [];
                for (var i = 0; i < nodes.length; i++) {
                    var n = nodes[i];
                    var r = match(n && n.properties && n.properties.models);
                    if (r) return r;
                    if (n && n.subgraph) {
                        r = scan(n.subgraph);
                        if (r) return r;
                    }
                }
                if (graph.subgraphs && typeof graph.subgraphs.values === 'function') {
                    var it = Array.from(graph.subgraphs.values());
                    for (var j = 0; j < it.length; j++) {
                        r = scan(it[j]);
                        if (r) return r;
                    }
                }
                return '';
            };
            return scan(app.graph);
        } catch(e) { return ''; }
    }

    /* Download interceptor — catch <a download> clicks and image/video URLs */
    document.addEventListener('click', function(e) {
        var a = e.target.closest('a[download], a[href$=".png"], a[href$=".jpg"], a[href$=".mp4"], a[href$=".webp"], a[href$=".jpeg"], a[href$=".gif"]');
        if (a && a.href && !a.href.startsWith('blob:')) {
            e.preventDefault();
            e.stopPropagation();
            var fname = getFilename(a);
            showToast('Saving ' + fname + '...', 2000);
            pywebview.api.save_file(a.href, fname, eziFindModelDir(a.href, fname));
            return false;
        }
    }, true);

    /* Override anchor.click() to catch programmatic download links */
    var origClick = HTMLAnchorElement.prototype.click;
    HTMLAnchorElement.prototype.click = function() {
        if (this.hasAttribute('download') && this.href && !this.href.startsWith('blob:')) {
            var fname = getFilename(this);
            showToast('Saving ' + fname + '...', 2000);
            pywebview.api.save_file(this.href, fname, eziFindModelDir(this.href, fname));
            return;
        }
        return origClick.apply(this, arguments);
    };

    /* File upload interceptor — fix WKWebView broken <input type=file> */
    var _activeFileInput = null;
    document.addEventListener('click', function(e) {
        var inp = e.target.closest('input[type="file"]');
        if (!inp) {
            /* Only intercept elements explicitly marked for file upload */
            var btn = e.target.closest('.comfy-file-input, [data-upload], label[for]');
            if (btn) {
                var linkedId = btn.getAttribute('for');
                if (linkedId) {
                    var linked = document.getElementById(linkedId);
                    if (linked && linked.type === 'file') inp = linked;
                }
                if (!inp) {
                    var form = btn.closest('.comfy-widget, .comfy-modal, form');
                    if (form) inp = form.querySelector('input[type="file"]');
                }
            }
        }
        if (inp) {
            e.preventDefault();
            e.stopPropagation();
            _activeFileInput = inp;
            var accept = inp.getAttribute('accept') || '*';
            showToast('Opening file picker...', 2000);
            pywebview.api.pick_and_upload(accept);
            return false;
        }
    }, true);

    /* Override input.click() for programmatic file input triggers */
    var origInputClick = HTMLInputElement.prototype.click;
    HTMLInputElement.prototype.click = function() {
        if (this.type === 'file') {
            _activeFileInput = this;
            var accept = this.getAttribute('accept') || '*';
            pywebview.api.pick_and_upload(accept);
            return;
        }
        return origInputClick.apply(this, arguments);
    };

    /* Called by Python after successful upload to update ComfyUI widget */
    window._comfyDesktopUploadDone = function(filename, subfolder, type) {
        showToast('Uploaded: ' + filename, 3000);
        /* Try to refresh ComfyUI's image/video list */
        if (window.app && window.app.refreshComboInNodes) {
            window.app.refreshComboInNodes();
        }
    };

    /* Restore saved zoom level */
    (function(){
        var z = localStorage.getItem('_comfy_zoom');
        if (z) document.body.style.zoom = z;
    })();

    (function() {
        var seen = new WeakSet();
        function scheduleKill(el) {
            if (seen.has(el)) return;
            seen.add(el);
            setTimeout(function() {
                if (document.body.contains(el)) el.remove();
            }, 8000);
        }
        function scan(node) {
            if (!node || node.nodeType !== 1) return;
            if (node.matches && node.matches('.p-tooltip')) scheduleKill(node);
            if (node.querySelectorAll) node.querySelectorAll('.p-tooltip').forEach(scheduleKill);
        }
        function init() {
            document.querySelectorAll('.p-tooltip').forEach(scheduleKill);
            new MutationObserver(function(mutations) {
                mutations.forEach(function(mutation) {
                    mutation.addedNodes.forEach(scan);
                });
            }).observe(document.body, {childList: true, subtree: true});
        }
        if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
        else init();
    })();

    /* ── Desktop Settings Panel (Cmd+Shift+U / Ctrl+Shift+U) ── */
    (function() {
        var PANEL_ID = '_comfy_desktop_panel';

        function removePanel() {
            var p = document.getElementById(PANEL_ID);
            if (p) p.remove();
        }

        function row(label, value) {
            return '<tr><td style="color:var(--muted);padding:4px 12px 4px 0;white-space:nowrap">' +
                   label + '</td><td style="color:var(--fg);padding:4px 0">' + (value||'…') + '</td></tr>';
        }

        function applyTheme(el, t) {
            Object.keys(t).forEach(function(k){
                if (k.startsWith('--')) el.style.setProperty(k, t[k]);
            });
        }

        function buildPanel() {
            if (document.getElementById(PANEL_ID)) { removePanel(); return; }

            var overlay = document.createElement('div');
            overlay.id = PANEL_ID;
            overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:999999;' +
                            'display:flex;align-items:center;justify-content:center;font-family:system-ui';
            overlay.onclick = function(e){ if(e.target===overlay) removePanel(); };

            var S = 'flex:1;background:var(--input-bg,#111);border:1px solid var(--border,#444);border-radius:5px;padding:5px 8px;font-size:12px;color:var(--fg,#e0e0e0)';
            var BOX_HD = 'font-size:10px;font-weight:bold;text-transform:uppercase;letter-spacing:.06em;color:var(--muted,#888);background:var(--input-bg,#111);padding:4px 10px;border-bottom:1px solid var(--border,#444)';
            function box(title, body) { return '<div style="border:1px solid var(--accent,#5294e2);border-radius:6px;overflow:hidden;margin-bottom:10px"><div style="'+BOX_HD+'">'+title+'</div><div style="padding:8px 10px">'+body+'</div></div>'; }
            overlay.innerHTML =
                '<style>' +
                '#_cdp_inner._ezi-theme-dark{--bg:#0c0e12;--border:#30363d;--fg:#ccc;--muted:#8b949e;--input-bg:#0d1117;--accent:#388bfd;--accent-hover:#58a6ff;--accent-bg:#1f6feb;--accent-bg-hover:#388bfd;--text-on-accent:#fff}' +
                '#_cdp_inner._ezi-theme-light{--bg:#f6f8fa;--border:#d0d7de;--fg:#24292f;--muted:#57606a;--input-bg:#fff;--accent:#0969da;--accent-hover:#218bff;--accent-bg:#daf0ff;--accent-bg-hover:#b6e3ff;--text-on-accent:#fff}' +
                '#_cdp_inner._ezi-theme-pixaroma{--bg:#1a1a1a;--border:#444;--fg:#e0e0e0;--muted:#888;--input-bg:#111;--accent:#e8530a;--accent-hover:#ff7040;--accent-bg:#6e2200;--accent-bg-hover:#8a3000;--text-on-accent:#fff}' +
                '#_cdp_inner._ezi-theme-aurora{--bg:#0b1926;--border:#304659;--fg:#edf3ff;--muted:#a1b3cc;--input-bg:#09232d;--accent:#82dfcd;--accent-hover:#9be9d9;--accent-bg:#224c56;--accent-bg-hover:#2b616c;--text-on-accent:#0b1926}' +
                '#_cdp_inner{--bg:#161616;--border:#2a2a2a;--fg:#e0e0e0;--muted:#888;--input-bg:#111;--accent:#e8530a;--accent-hover:#ff7040;--accent-bg:#6e2200;--accent-bg-hover:#8a3000;--text-on-accent:#fff}' +
                '#_cdp_overlay{position:fixed;top:0;left:0;right:0;bottom:0;z-index:99998;background:rgba(0,0,0,.45);display:flex;align-items:center;justify-content:center}' +
                '#_cdp_inner{background:var(--bg,#161616);border:1px solid var(--border,#2a2a2a);border-radius:10px;box-shadow:0 10px 40px rgba(0,0,0,.7);width:min(920px,94vw);height:min(680px,88vh);display:flex;overflow:hidden;color:var(--fg,#e0e0e0);font-family:system-ui,-apple-system,sans-serif}' +
                '#_cdp_sidebar{width:190px;background:#111;border-right:1px solid var(--border,#2a2a2a);display:flex;flex-direction:column;flex-shrink:0}' +
                '#_cdp_sidebar .search{padding:10px 10px 8px;border-bottom:1px solid var(--border,#2a2a2a)}' +
                '#_cdp_sidebar .search input{width:100%;padding:7px 10px;background:var(--input-bg,#1e1e28);border:1px solid var(--border,#333);border-radius:6px;color:var(--fg,#e0e0e0);font-size:12px;outline:none}' +
                '#_cdp_ts{display:none;align-items:center;gap:4px;margin-bottom:8px;user-select:none}' +
                '#_cdp_ts.show{display:flex}' +
                '#_cdp_ts input{width:200px;padding:3px 6px;background:var(--input-bg,#1e1e28);border:1px solid var(--border,#333);border-radius:4px;color:var(--fg,#e0e0e0);font-family:inherit;font-size:12px;outline:none;user-select:text}' +
                '#_cdp_ts input:focus{border-color:var(--accent,#e8530a)}' +
                '#_cdp_ts .count{min-width:56px;text-align:center;font-size:11px;color:var(--muted,#888);white-space:nowrap}' +
                '#_cdp_ts .count.none{color:#ff5555}' +
                '#_cdp_ts .ts-btn{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;width:26px;height:22px;padding:0;border:1px solid var(--border,#333);border-radius:4px;background:#222;color:var(--fg,#e0e0e0);cursor:pointer;font-family:inherit;font-size:11px;font-weight:bold;line-height:1;transition:background .15s,color .15s}' +
                '#_cdp_ts .ts-btn:hover{background:var(--accent-bg,#6e2200);color:var(--text-on-accent,#fff)}' +
                '#_cdp_ts .ts-btn.on{background:var(--accent,#e8530a);color:var(--text-on-accent,#fff)}' +
                '::highlight(cdp-search){background-color:rgba(255,214,0,.35);color:inherit}' +
                '::highlight(cdp-search-cur){background-color:#ff9632;color:#000}' +
                '#_cdp_log_view .cdp-hl{background:rgba(255,214,0,.35);color:inherit;border-radius:2px}' +
                '#_cdp_log_view .cdp-hl.cur{background:#ff9632;color:#000}' +
                '#_cdp_nav_list{flex:1;overflow-y:auto;padding:6px 4px}' +
                '._cdp_nav{display:flex;align-items:center;gap:8px;width:100%;padding:8px 10px;margin-bottom:2px;background:none;border:none;border-radius:6px;color:#ccc;font-size:12px;font-weight:500;cursor:pointer;text-align:left;transition:background .15s,color .15s}' +
                '._cdp_nav:hover{background:#222;color:#fff}' +
                '._cdp_nav.on{background:#2a4a7a;color:#fff}' +
                '#_cdp_nav_bottom{border-top:1px solid var(--border,#2a2a2a);padding:6px 4px}' +
                '._cdp_nav_bottom .label{padding:6px 10px 4px;font-size:10px;color:#666;text-transform:uppercase;letter-spacing:.05em}' +
                '#_cdp_content{flex:1;overflow-y:auto;padding:16px 20px;align-items:flex-start}' +
                '#_cdp_content .title{font-size:18px;font-weight:600;margin-bottom:14px;padding-bottom:10px;border-bottom:1px solid var(--border,#2a2a2a)}' +
                '#_cdp_content .item{display:flex;align-items:center;justify-content:space-between;padding:10px 0;border-bottom:1px solid var(--border,#2a2a2a)}' +
                '#_cdp_content .item:last-child{border-bottom:none}' +
                '#_cdp_content .item .name{color:#4a9eff;font-size:13px;font-weight:500}' +
                '#_cdp_content .item .run{padding:4px 14px;background:#2a4a7a;color:#fff;border:none;border-radius:5px;font-size:11px;font-weight:600;cursor:pointer}' +
                '#_cdp_content .item .run:hover{background:#3a5a8a}' +
                '#_cdp_footer{padding:10px 16px;border-top:1px solid var(--border,#2a2a2a);display:flex;justify-content:space-between;align-items:center;flex-shrink:0}' +
                '#_cdp_footer button{padding:6px 16px;background:#2a2a2a;color:#ccc;border:1px solid #444;border-radius:5px;font-size:12px;cursor:pointer}' +
                '#_cdp_footer button:hover{background:#333;color:#fff}' +
                '#_cdp_msg{font-size:12px;color:var(--muted,#888);min-height:16px}' +
                '._cdp_tab{display:none}' +
                '#_cdp_t_pxr .px-card{background:#1d1d1d;border:1px solid #2a2a2a;border-radius:12px;padding:28px 30px;display:flex;gap:24px;align-items:flex-start}' +
                '#_cdp_t_pxr .px-card .px-hero-copy{flex:1;min-width:0}' +
                '#_cdp_t_pxr .px-eyebrow{font-size:12px;color:#f66744;font-weight:700;letter-spacing:.06em;text-transform:uppercase;margin-bottom:8px}' +
                '#_cdp_t_pxr .px-lead{font-size:24px;font-weight:700;line-height:1.2;margin:0 0 10px}' +
                '#_cdp_t_pxr .px-sub{font-size:14px;color:#bdb6b2;line-height:1.5;margin-bottom:16px}' +
                '#_cdp_t_pxr .px-btn{display:inline-flex;align-items:center;gap:8px;padding:10px 18px;background:#f66744;color:#fff;border:none;border-radius:8px;font-weight:600;cursor:pointer}' +
                '#_cdp_t_pxr .px-btn:hover{background:#ff7040}' +
                '#_cdp_t_pxr .px-cadence{display:flex;align-items:center;gap:6px;margin-top:10px;font-size:12px;color:#bdb6b2}' +
                '#_cdp_t_pxr .px-flow-art{width:200px;flex-shrink:0}' +
                '#_cdp_t_pxr .px-community{background:#1d1d1d;border:1px solid #2a2a2a;border-radius:12px;padding:20px;margin-top:16px;display:flex;align-items:center;gap:16px}' +
                '#_cdp_t_pxr .px-community-icon{width:40px;height:40px;background:#2a2a2a;border-radius:8px;display:flex;align-items:center;justify-content:center;color:#f66744}' +
                '#_cdp_t_pxr .px-community-copy{flex:1}' +
                '#_cdp_t_pxr .px-community-title{font-size:16px;font-weight:600;margin-bottom:2px}' +
                '#_cdp_t_pxr .px-community-sub{font-size:13px;color:#bdb6b2}' +
                '#_cdp_t_pxr .px-badge-link{margin-left:auto}' +
                '#_cdp_t_pxr .px-badge{height:32px;border-radius:6px}' +
                '#_cdp_t_pxr .px-resource-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:16px}' +
                '#_cdp_t_pxr .px-link{display:flex;align-items:center;gap:12px;background:#1d1d1d;border:1px solid #2a2a2a;border-radius:10px;padding:14px;text-decoration:none;color:inherit;transition:border-color .15s}' +
                '#_cdp_t_pxr .px-link:hover{border-color:#f66744}' +
                '#_cdp_t_pxr .px-link-icon{width:36px;height:36px;background:#2a2a2a;border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0}' +
                '#_cdp_t_pxr .px-link-copy{flex:1;min-width:0}' +
                '#_cdp_t_pxr .px-link-name{display:block;font-size:14px;font-weight:650}' +
                '#_cdp_t_pxr .px-link-desc{display:block;margin-top:3px;color:#bdb6b2;font-size:12px;line-height:1.4}' +
                '#_cdp_t_pxr .px-link-url{display:block;margin-top:7px;color:#d78670;font-size:10px;overflow-wrap:anywhere}' +
                '#_cdp_t_pxr .px-link .px-ext{color:#bdb6b2;transition:transform .16s}' +
                '#_cdp_t_pxr .px-link:hover .px-ext{transform:translate(2px,-2px)}' +
                '@media (max-width:620px){#_cdp_t_pxr .px-flow-art{display:none}#_cdp_t_pxr .px-hero-copy{max-width:100%}#_cdp_t_pxr .px-community{flex-wrap:wrap}#_cdp_t_pxr .px-community .px-discord{margin-left:60px}}' +
                '@media (max-width:450px){#_cdp_t_pxr .px-card{padding:22px}#_cdp_t_pxr .px-resource-grid{grid-template-columns:1fr}#_cdp_t_pxr .px-community{padding:16px;gap:12px}#_cdp_t_pxr .px-community .px-discord{margin-left:0;width:100%}}' +
                '</style>' +
                '<div id="_cdp_inner">' +
                '<div id="_cdp_sidebar">' +
                '<div class="search"><input type="text" placeholder="Search settings\u2026"></div>' +
                '<div id="_cdp_nav_list">' +
                '<button class="_cdp_nav" data-tab="sys">📌 System Info</button>' +
                '<button class="_cdp_nav" data-tab="add">📦 Add-ons</button>' +
                '<button class="_cdp_nav" data-tab="torch">⚡ Torch Pack</button>' +
                '<button class="_cdp_nav" data-tab="tls">🛠 Tools</button>' +
                '<button class="_cdp_nav" data-tab="app">🎨 Appearance</button>' +
                '<button class="_cdp_nav" data-tab="adv">⚙️ Advanced</button>' +
                '<button class="_cdp_nav" data-tab="log">📋 Logs</button>' +
                '</div>' +
                '<div id="_cdp_nav_bottom">' +
                '<div class="label">About</div>' +
                '<button class="_cdp_nav" data-tab="pxr">🌍 Pixaroma Workflows</button>' +
                '<button class="_cdp_nav" data-tab="about">ℹ️ About EZi</button>' +
                '</div>' +
                '</div>' +
                '<div style="flex:1;display:flex;flex-direction:column;overflow:hidden">' +
                /* scrollable content */
                '<div id="_cdp_content" style="padding:16px 20px">' +
                /* TAB: Pixaroma */
                '<div id="_cdp_t_pxr">' +
                '<div class="px-card">' +
                '<div class="px-hero-copy">' +
                '<div class="px-eyebrow">Pixaroma ComfyUI course</div>' +
                '<h2 class="px-lead">Your next idea starts with a workflow.</h2>' +
                '<div class="px-sub">Free workflow files for every course episode. Follow the lessons, then bring your own ideas to life.</div>' +
                '<div class="px-actions"><button class="px-btn" onclick="pywebview.api.open_url(\\'https://workflows.pixaroma.com/\\')"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/><path d="M10 6.5h4a3.5 3.5 0 0 1 3.5 3.5v4"/></svg><span>ComfyUI Workflows</span><svg class="px-ext" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 17L17 7M8 7h9v9"/></svg></button></div>' +
                '<div class="px-cadence"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>A new episode lands almost every week.</div>' +
                '</div>' +
                '<svg class="px-flow-art" viewBox="0 0 200 180" fill="none" aria-hidden="true" style="flex-shrink:0">' +
                '<path d="M56 40h34q14 0 14 14v63h27M56 140h20q14 0 14-14V75q0-14 14-14h27" stroke="#f66744" stroke-width="1.5" opacity=".45"/>' +
                '<rect x="4" y="16" width="52" height="48" rx="9" fill="#2a2a2a" stroke="#705044"/><rect x="4" y="16" width="52" height="12" rx="6" fill="#f66744" opacity=".45"/>' +
                '<path d="M15 39h29M15 47h18" stroke="#84716a" stroke-width="3" stroke-linecap="round"/>' +
                '<rect x="4" y="116" width="52" height="48" rx="9" fill="#2a2a2a" stroke="#705044"/><rect x="4" y="116" width="52" height="12" rx="6" fill="#f66744" opacity=".45"/>' +
                '<path d="M15 139h29M15 147h18" stroke="#84716a" stroke-width="3" stroke-linecap="round"/>' +
                '<rect x="131" y="40" width="65" height="98" rx="10" fill="#2a2a2a" stroke="#b56750"/>' +
                '<rect x="131" y="40" width="65" height="14" rx="7" fill="#f66744" opacity=".8"/>' +
                '<rect x="143" y="66" width="41" height="39" rx="5" fill="#3b302b"/>' +
                '<path d="m150 97 10-15 7 9 5-6 7 12" stroke="#f66744" stroke-width="1.5" stroke-linejoin="round"/>' +
                '<path d="M143 118h32M143 126h21" stroke="#84716a" stroke-width="3" stroke-linecap="round"/>' +
                '<circle cx="56" cy="40" r="3" fill="#f66744"/><circle cx="56" cy="140" r="3" fill="#f66744"/><circle cx="131" cy="61" r="3" fill="#f66744"/><circle cx="131" cy="117" r="3" fill="#f66744"/>' +
                '</svg>' +
                '</div>' +
                '<div class="px-community">' +
                '<div class="px-community-icon"><svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true"><path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.865-.608 1.25a16.2 16.2 0 0 0-5.487 0c-.163-.394-.405-.875-.617-1.25a.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.95 4.37a.07.07 0 0 0-.032.027C.533 9.046-.319 13.58.099 18.058a.082.082 0 0 0 .031.056c2.053 1.508 4.041 2.423 5.993 3.03a.078.078 0 0 0 .084-.028c.462-.63.873-1.295 1.226-1.994a.076.076 0 0 0-.042-.106 12.3 12.3 0 0 1-1.872-.892.077.077 0 0 1-.008-.128c.126-.094.252-.192.372-.291a.074.074 0 0 1 .078-.01c3.928 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .079.01c.12.099.246.198.373.292a.077.077 0 0 1-.007.128 12.298 12.298 0 0 1-1.873.891.077.077 0 0 0-.041.107c.36.698.772 1.363 1.225 1.993a.076.076 0 0 0 .084.029c1.961-.607 3.95-1.522 6.002-3.03a.077.077 0 0 0 .032-.055c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.029zM8.02 15.331a2.157 2.157 0 1 1 0-4.314 2.157 2.157 0 0 1 0 4.314zm7.975 0a2.157 2.157 0 1 1 0-4.314 2.157 2.157 0 0 1 0 4.314z"/></svg></div>' +
                '<div class="px-community-copy">' +
                '<div class="px-community-title">Create together.</div>' +
                '<div class="px-community-sub">Join the Pixaroma Discord community.</div>' +
                '<a class="px-badge-link" href="https://discord.com/invite/gggpkVgBf3" onclick="pywebview.api.open_url(this.href);return false" aria-label="Join Pixaroma Discord"><img class="px-badge" alt="Join Pixaroma Discord" title="Join Pixaroma Discord" loading="lazy" src="https://img.shields.io/badge/dynamic/json?url=https%3A%2F%2Fdiscord.com%2Fapi%2Finvites%2FgggpkVgBf3%3Fwith_counts%3Dtrue&query=%24.approximate_member_count&logo=discord&logoColor=white&labelColor=3b3633&label=Community&color=f66744&suffix=%20users" onerror="this.parentElement.style.display=\\'none\\'"></a>' +
                '</div>' +
                '<button class="px-btn px-discord" onclick="pywebview.api.open_url(\\'https://discord.com/invite/gggpkVgBf3\\')"><svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true"><path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.865-.608 1.25a16.2 16.2 0 0 0-5.487 0c-.163-.394-.405-.875-.617-1.25a.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.95 4.37a.07.07 0 0 0-.032.027C.533 9.046-.319 13.58.099 18.058a.082.082 0 0 0 .031.056c2.053 1.508 4.041 2.423 5.993 3.03a.078.078 0 0 0 .084-.028c.462-.63.873-1.295 1.226-1.994a.076.076 0 0 0-.042-.106 12.3 12.3 0 0 1-1.872-.892.077.077 0 0 1-.008-.128c.126-.094.252-.192.372-.291a.074.074 0 0 1 .078-.01c3.928 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .079.01c.12.099.246.198.373.292a.077.077 0 0 1-.007.128 12.298 12.298 0 0 1-1.873.891.077.077 0 0 0-.041.107c.36.698.772 1.363 1.225 1.993a.076.076 0 0 0 .084.029c1.961-.607 3.95-1.522 6.002-3.03a.077.077 0 0 0 .032-.055c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.029zM8.02 15.331a2.157 2.157 0 1 1 0-4.314 2.157 2.157 0 0 1 0 4.314zm7.975 0a2.157 2.157 0 1 1 0-4.314 2.157 2.157 0 0 1 0 4.314z"/></svg><span>Join Discord</span><svg class="px-ext" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 17L17 7M8 7h9v9"/></svg></button>' +
                '</div>' +
                '<div class="px-resources">' +
                '<h3 class="px-resource-head">Keep exploring</h3>' +
                '<div class="px-resource-grid">' +
                '<button class="px-link" onclick="pywebview.api.open_url(\\'https://workflows.pixaroma.com/help/\\')"><span class="px-link-icon"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M9.6 9.4a2.5 2.5 0 1 1 3.5 2.3c-.7.4-1.1 1-1.1 1.8M12 17h.01"/></svg></span><span class="px-link-copy"><span class="px-link-name">Help</span><span class="px-link-desc">Guides &amp; troubleshooting</span><span class="px-link-url">workflows.pixaroma.com/help</span></span><svg class="px-ext" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 17L17 7M8 7h9v9"/></svg></button>' +
                '<button class="px-link" onclick="pywebview.api.open_url(\\'https://www.youtube.com/@pixaroma\\')"><span class="px-link-icon"><svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><rect x="1.5" y="4.5" width="21" height="15" rx="4.5" fill="#FF0000"/><path d="M10 9l5.2 3-5.2 3z" fill="#fff"/></svg></span><span class="px-link-copy"><span class="px-link-name">YouTube</span><span class="px-link-desc">Watch the ComfyUI course</span><span class="px-link-url">@pixaroma</span></span><svg class="px-ext" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 17L17 7M8 7h9v9"/></svg></button>' +
                '</div>' +
                '</div>' +
                '</div>' +
                /* TAB: System Info */
                '<div id="_cdp_t_sys">' +
                '<table id="_cdp_info" style="width:100%;border-collapse:collapse;font-size:12px;margin-bottom:8px"><tr><td colspan="2" style="color:var(--muted,#555)">Loading\u2026</td></tr></table>' +
                '<div id="_cdp_stats" style="font-size:11px;color:var(--muted,#666);margin-bottom:10px">Loading stats\u2026</div>' +
                box('Package Cache', '<div style="display:flex;gap:8px;flex-wrap:wrap">' +
                    '<button id="_cdp_upd" style="'+btnStyle('#2d5a27')+'">Check for updates</button>' +
                    '<button id="_cdp_clr" style="'+btnStyle('#5a2727')+'">Clear cache</button>' +
                    '<button id="_cdp_rst" style="'+btnStyle('#5a4010')+'">Restart server</button>' +
                    '</div>') +
                '</div>' +
                /* TAB: Logs */
                '<div id="_cdp_t_log">' +
                box('Server Log',
                    '<div style="display:flex;gap:8px;align-items:center;margin-bottom:8px">' +
                    '<button id="_cdp_log_save" style="'+btnStyle('#2a3a5a')+'">Save log</button>' +
                    '<button id="_cdp_log_refresh" style="'+btnStyle('#333')+'">Refresh</button>' +
                    '<button id="_cdp_log_whatsnew" style="'+btnStyle('#3a2a5a')+'">What\\'s new</button>' +
                    '<button id="_cdp_log_find" style="'+btnStyle('#333')+'" title="Find in log (Ctrl+F)">Find</button></div>' +
                    '<div id="_cdp_ts"><input type="text" id="_cdp_ts_input" placeholder="Find" autocomplete="off" spellcheck="false"><span' +
                    ' id="_cdp_ts_count" class="count"></span><button type="button" class="ts-btn" id="_cdp_ts_case" title="Match case">Aa' +
                    '</button><button type="button" class="ts-btn" id="_cdp_ts_prev" title="Previous match (Shift+Enter)">&#x2191;' +
                    '</button><button type="button" class="ts-btn" id="_cdp_ts_next" title="Next match (Enter)">&#x2193;' +
                    '</button><button type="button" class="ts-btn" id="_cdp_ts_close" title="Close (Esc)">&#x2715;</button></div>' +
                    '<pre id="_cdp_log_view" style="margin:0;background:#0d0d0d;border:1px solid var(--border,#444);border-radius:5px;padding:8px;font-size:11px;color:#c8c8c8;height:320px;overflow-y:auto;white-space:pre-wrap;word-break:break-all;font-family:monospace">Loading log...</pre>') +
                '</div>' +
                /* TAB: Add-ons */
                '<div id="_cdp_t_add">' +
                '<div id="_cdp_ezi_upd_badge" style="display:none;background:#3a1a6e;color:#bd93f9;border:1px solid #bd93f9;border-radius:6px;padding:5px 12px;font-size:12px;font-weight:bold;margin-bottom:10px"></div>' +
                box('ComfyUI Version',
                    '<div style="display:flex;gap:8px;align-items:center;margin-bottom:6px">' +
                    '<select id="_cdp_ver" style="'+S+'"><option value="">versions\u2026</option></select>' +
                    '<button id="_cdp_switch" style="'+btnStyle('#3a2a5a')+'">Switch</button>' +
                    '<button id="_cdp_switch_both" style="'+btnStyle('#5a2a5a')+'" title="Switch ComfyUI + auto-install matching frontend">Switch Both</button>' +
                    '</div><label style="font-size:11px;color:var(--muted,#888);display:flex;align-items:center;gap:6px;cursor:pointer">' +
                    '<input type="checkbox" id="_cdp_auto_fe" checked> Auto-detect frontend from requirements.txt' +
                    '<span id="_cdp_nightly_badge" style="display:none;background:#ff9800;color:#000;padding:1px 6px;border-radius:3px;font-size:10px;font-weight:600;margin-left:auto">NIGHTLY</span></label>') +
                box('Frontend Version',
                    '<div style="display:flex;gap:8px;align-items:center">' +
                    '<select id="_cdp_fe_ver" style="'+S+'"><option value="">loading\u2026</option></select>' +
                    '<button id="_cdp_fe_switch" style="'+btnStyle('#3a2a5a')+'">Switch</button></div>') +
                box('Updates', '<button id="_cdp_inst_upd" style="'+btnStyle('#1a3a3a')+'">Check installer update</button>') +
                box('🔥 Torch Pack Installer',
                    '<div style="display:flex;gap:8px;align-items:center;margin-bottom:8px">' +
                    '<select id="_cdp_tp_sel" style="'+S+';flex:1"><option value="">Loading\u2026</option></select>' +
                    '<button id="_cdp_tp_run" style="'+btnStyle('#3a5a2a')+'">Install</button>' +
                    '<button id="_cdp_tp_cancel" style="'+btnStyle('#5a2a2a')+'">Cancel</button></div>' +
                    '<pre id="_cdp_tp_log" style="margin:0;background:var(--input-bg,#0d0d0d);border:1px solid var(--border,#444);border-radius:5px;padding:8px;font-size:11px;color:#c8c8c8;height:180px;overflow-y:auto;white-space:pre-wrap;word-break:break-all;font-family:monospace">Select a script and click Install\u2026</pre>') +
                box('Add-on Scripts', '<div id="_cdp_add_list" style="min-height:40px"><div style="color:var(--muted,#888);padding:10px 0">Loading\u2026</div></div>') +
                '</div>' +
                /* TAB: Torch Pack */
                '<div id="_cdp_t_torch">' +
                '<div class="title">Torch Pack</div>' +
                '<div id="_cdp_tp_list" style="min-height:100px">' +
                '<div style="color:var(--muted,#888);padding:10px 0">Loading…</div>' +
                '</div>' +
                '</div>' +
                /* TAB: Tools */
                '<div id="_cdp_t_tls">' +
                box('Server',
                    '<div style="display:flex;gap:8px;align-items:center">' +
                    '<code id="_cdp_url" style="flex:1;background:var(--input-bg,#111);border:1px solid var(--border,#333);border-radius:5px;padding:5px 10px;font-size:12px;color:#7ec8e3;cursor:pointer;overflow:hidden;white-space:nowrap" title="Click to copy"></code>' +
                    '<button id="_cdp_browser" style="'+btnStyle('#2a3a5a')+'">Open in browser</button></div>') +
                box('Open Folder', '<div style="display:flex;gap:6px;flex-wrap:wrap">' +
                    '<button id="_cdp_fol_out"       style="'+btnStyle('#2a3a5a')+'">📂 Output</button>' +
                    '<button id="_cdp_fol_in"        style="'+btnStyle('#2a3a5a')+'">📂 Input</button>' +
                    '<button id="_cdp_fol_workflows" style="'+btnStyle('#2a3a5a')+'">📂 Workflows</button>' +
                    '<button id="_cdp_fol_models"    style="'+btnStyle('#2a3a5a')+'">📂 Models</button>' +
                    '<button id="_cdp_fol_root"      style="'+btnStyle('#2a3a5a')+'">📂 ComfyUI</button></div>') +
                box('Launch Args (applied on next start)',
                    '<div style="display:flex;gap:8px"><input id="_cdp_args" type="text" placeholder="e.g. --lowvram --cpu" style="'+S+';outline:none">' +
                    '<button id="_cdp_args_save" style="'+btnStyle('#2d5a27')+';padding:5px 12px">Save</button></div>') +
                box('Custom Paths (applied on next start)',
                    '<div style="display:grid;grid-template-columns:70px 1fr;gap:5px;align-items:center;margin-bottom:8px">' +
                    '<label style="font-size:11px;color:var(--muted,#666)">Input:</label><input id="_cdp_path_in" type="text" placeholder="default" style="background:var(--input-bg,#111);border:1px solid var(--border,#444);border-radius:4px;padding:4px 7px;font-size:11px;color:var(--fg,#e0e0e0);outline:none">' +
                    '<label style="font-size:11px;color:var(--muted,#666)">Output:</label><input id="_cdp_path_out" type="text" placeholder="default" style="background:var(--input-bg,#111);border:1px solid var(--border,#444);border-radius:4px;padding:4px 7px;font-size:11px;color:var(--fg,#e0e0e0);outline:none">' +
                    '<label style="font-size:11px;color:var(--muted,#666)">User:</label><input id="_cdp_path_usr" type="text" placeholder="default" style="background:var(--input-bg,#111);border:1px solid var(--border,#444);border-radius:4px;padding:4px 7px;font-size:11px;color:var(--fg,#e0e0e0);outline:none"></div>' +
                    '<button id="_cdp_paths_save" style="'+btnStyle('#2d5a27')+';padding:5px 14px">Save paths</button>') +
                '</div>' +
                /* TAB: Appearance */
                '<div id="_cdp_t_app">' +
                box('EZi Panel Theme',
                    '<div style="display:flex;gap:8px;align-items:center">' +
                    '<select id="_cdp_panel_theme" style="'+S+'"><option value="pixaroma" selected>Pixaroma \u2014 orange</option><option value="comfyui">ComfyUI (auto-sync)</option><option value="dark">EZi Dark</option><option value="light">EZi Light</option><option value="aurora">Aurora</option></select>' +
                    '<button id="_cdp_panel_theme_apply" style="'+btnStyle('#2a3a5a')+'">Apply</button></div>') +
                box('ComfyUI Node Editor Theme',
                    '<div style="display:flex;gap:8px;align-items:center">' +
                    '<select id="_cdp_theme" style="'+S+'"><option value="">Loading\u2026</option></select>' +
                    '<button id="_cdp_theme_apply" style="'+btnStyle('#2a3a5a')+'">Set Theme</button></div>') +
                box('View',
                    '<div style="display:flex;gap:8px;align-items:center;margin-bottom:8px">' +
                    '<span style="font-size:12px;color:var(--muted,#888)">Zoom:</span>' +
                    '<button id="_cdp_zm_out" style="'+btnStyle('#333')+';padding:4px 10px">\u2212</button>' +
                    '<span id="_cdp_zm_val" style="font-size:12px;color:var(--fg,#e0e0e0);min-width:36px;text-align:center">100%</span>' +
                    '<button id="_cdp_zm_in"  style="'+btnStyle('#333')+';padding:4px 10px">+</button>' +
                    '<button id="_cdp_zm_rst" style="'+btnStyle('#333')+';padding:4px 10px;font-size:11px">Reset</button></div>' +
                    '<label style="font-size:12px;color:var(--muted,#888);display:flex;align-items:center;gap:6px;cursor:pointer"><input type="checkbox" id="_cdp_aot"> Always on top</label>') +
                box('AI Language',
                    '<div style="display:flex;gap:8px;align-items:center">' +
                    '<select id="_cdp_ai_lang" style="'+S+'">' +
                    '<option value="en">English</option><option value="zh-CN">Chinese (Simplified)</option><option value="zh-TW">Chinese (Traditional)</option><option value="es">Spanish</option><option value="ru">Russian</option><option value="ja">Japanese</option><option value="ko">Korean</option><option value="de">German</option><option value="fr">French</option><option value="pt-BR">Portuguese (BR)</option><option value="it">Italian</option><option value="tr">Turkish</option><option value="ar">Arabic</option><option value="hi">Hindi</option><option value="id">Indonesian</option><option value="vi">Vietnamese</option><option value="pl">Polish</option><option value="uk">Ukrainian</option><option value="nl">Dutch</option><option value="th">Thai</option><option value="fa">Persian</option><option value="bg">Bulgarian</option><option value="cs">Czech</option><option value="ro">Romanian</option><option value="el">Greek</option><option value="hu">Hungarian</option><option value="sr">Serbian</option><option value="he">Hebrew</option><option value="bn">Bengali</option><option value="sv">Swedish</option><option value="ms">Malay</option><option value="fil">Filipino</option>' +
                    '</select>' +
                    '<button id="_cdp_ai_lang_apply" style="'+btnStyle('#2a3a5a')+'">Apply</button></div>' +
                    '<div style="font-size:11px;color:var(--muted,#888);margin-top:6px">Language for ChatGPT / Claude links</div>') +
                '</div>' +
                /* TAB: Advanced */
                '<div id="_cdp_t_adv">' +
                box('ComfyUI-Manager Security Level',
                    '<div style="position:relative"><div style="display:flex;gap:8px;align-items:center">' +
                    '<select id="_cdp_sec_lvl" style="'+S+'"><option value="weak">weak</option><option value="normal-">normal-</option><option value="normal">normal</option><option value="strong">strong</option></select>' +
                    '<button id="_cdp_sec_info" title="Security level info" style="width:20px;height:20px;border-radius:50%;border:1px solid var(--accent,#5294e2);background:none;color:var(--accent,#5294e2);font-size:11px;font-weight:bold;cursor:pointer;flex-shrink:0;display:inline-flex;align-items:center;justify-content:center;padding:0">i</button>' +
                    '<button id="_cdp_sec_apply" style="'+btnStyle('#2a3a5a')+';padding:5px 12px">Apply</button></div>' +
                    '<div id="_cdp_sec_tip" style="display:none;position:absolute;z-index:10;left:0;top:100%;margin-top:4px;background:var(--bg,#202020);border:1px solid var(--border,#444);border-radius:6px;padding:8px 12px;font-size:11px;color:var(--fg,#e0e0e0);line-height:1.7;max-width:340px;box-shadow:0 4px 16px rgba(0,0,0,.5)">' +
                    '<b>strong</b> \u2014 blocks high and middle risk features<br><b>normal</b> \u2014 blocks only high risk features<br><b>normal-</b> \u2014 blocks high risk only when --listen is non-localhost<br><b>weak</b> \u2014 all features available</div></div>') +
                box('Pinned Packages Manager',
                    '<div id="_cdp_pins" style="margin-bottom:6px"></div>' +
                    '<div style="display:flex;gap:8px"><input id="_cdp_pin_inp" type="text" placeholder="e.g. numpy==1.26.4" style="'+S+';outline:none">' +
                    '<button id="_cdp_pin_add" style="'+btnStyle('#2d5a27')+';padding:5px 12px">Add</button></div>') +
                box('Fixes & Utilities',
                    '<div id="_cdp_fixes_list" style="min-height:40px"><div style="color:var(--muted,#888);padding:10px 0">Loading…</div></div>') +
                '</div>' +
                /* TAB: About EZi */
                '<div id="_cdp_t_about">' +
                '<div class="title" style="display:flex;justify-content:space-between;align-items:center;gap:10px">About EZi' +
                '<span style="display:flex;gap:8px;align-items:center">' +
                '<span style="font-size:13px;font-weight:600;background:var(--panel-bg,#1d1d1d);border:1px solid var(--border,#2a2a2a);color:var(--fg,#e0e0e0);border-radius:6px;padding:4px 10px">v' + EZI_VERSION + '</span>' +
                '<a href="https://github.com/Tavris1/ComfyUI-Easy-Install/releases" onclick="pywebview.api.open_url(\\'https://github.com/Tavris1/ComfyUI-Easy-Install/releases\\')" style="display:none;align-items:center;gap:6px" aria-label="Downloads"><img src="https://img.shields.io/endpoint?url=https://gist.githubusercontent.com/Tavris1/95cfc6f0535930f25591dcfe08f34cc1/raw/downloads.json&amp;style=flat-square" alt="Downloads" onload="this.parentElement.style.display=\\'inline-flex\\'" onerror="this.parentElement.style.display=\\'none\\'"></a>' +
                '</span></div>' +
                '<div style="background:var(--panel-bg,#1d1d1d);border:1px solid var(--border,#2a2a2a);border-radius:12px;padding:24px;text-align:center">' +
                '<div style="font-size:28px;margin-bottom:8px">⚡ EZi Desktop</div>' +
                '<div style="color:var(--muted,#888);margin-bottom:16px">COMFYUI EASY INSTALL</div>' +
                '<div style="font-size:20px;font-weight:600;margin-bottom:6px">Portable ComfyUI.</div>' +
                '<div style="color:var(--muted,#888);margin-bottom:16px">It\\'s a simplified way of using ComfyUI.</div>' +
                '<div style="color:var(--muted,#888);margin-bottom:16px">A dashboard for your packages, environments, and configuration.</div>' +
                '<div style="display:flex;gap:10px;justify-content:center;margin-bottom:16px">' +
                '<button onclick="pywebview.api.open_url(\\'https://github.com/Tavris1/ComfyUI-Easy-Install\\')" style="padding:8px 16px;background:var(--node-bg,#2a2a2a);color:var(--fg,#ccc);border:1px solid var(--border,#444);border-radius:6px;cursor:pointer">Packages</button>' +
                '<button onclick="pywebview.api.open_url(\\'https://github.com/Tavris1/ComfyUI-Easy-Install\\')" style="padding:8px 16px;background:var(--node-bg,#2a2a2a);color:var(--fg,#ccc);border:1px solid var(--border,#444);border-radius:6px;cursor:pointer">Environments</button>' +
                '<button onclick="pywebview.api.open_url(\\'https://github.com/Tavris1/ComfyUI-Easy-Install\\')" style="padding:8px 16px;background:var(--node-bg,#2a2a2a);color:var(--fg,#ccc);border:1px solid var(--border,#444);border-radius:6px;cursor:pointer">Configuration</button>' +
                '</div>' +
                '<div style="margin:16px 0;padding:14px;background:var(--input-bg,#111);border:1px solid var(--border,#444);border-radius:8px">' +
                '<div style="font-size:18px;margin-bottom:6px;color:var(--fg,#e0e0e0)">💛 A Hidden Thank You</div>' +
                '<div style="color:var(--muted,#888);font-size:13px;margin-bottom:8px">Dedicated to <b style="color:var(--fg,#e0e0e0)">Sebastian Antony</b></div>' +
                '<div style="color:var(--muted,#888);font-size:12px;margin-bottom:4px">He said this project was an inspiration.</div>' +
                '<div style="color:var(--muted,#888);font-size:12px;margin-bottom:8px">Little did he know that people like him are the inspiration behind it.</div>' +
                '<div style="color:var(--muted,#888);font-size:12px">- EZi / ivo</div>' +
                '</div>' +
                '<div style="color:var(--muted,#888);font-size:13px">Made with love by <b>Ivo</b>, a.k.a. Tavris1</div>' +
                '</div>' +
                '<div style="margin-top:16px;display:flex;gap:10px">' +
                '<button onclick="pywebview.api.open_url(\\'https://github.com/Tavris1/ComfyUI-Easy-Install\\')" style="flex:1;padding:12px;background:var(--panel-bg,#1d1d1d);border:1px solid var(--border,#2a2a2a);border-radius:8px;color:var(--accent,#4a9eff);cursor:pointer;text-align:left">🏠 Home Page<br><span style="color:var(--muted,#888);font-size:12px">Explore the project on GitHub</span></button>' +
                '<button onclick="pywebview.api.open_url(\\'https://github.com/Tavris1/ComfyUI-Easy-Install/releases\\')" style="flex:1;padding:12px;background:var(--panel-bg,#1d1d1d);border:1px solid var(--border,#2a2a2a);border-radius:8px;color:var(--accent,#4a9eff);cursor:pointer;text-align:left">📥 See what\\'s new<br><span style="color:var(--muted,#888);font-size:12px">Latest release &amp; improvements</span></button>' +
                '</div>' +
                '<div style="margin-top:20px;text-align:center">' +
                '<div style="color:#f00;font-size:18px">♥ Like Easy Install?</div>' +
                '<div style="color:var(--muted,#888);margin:6px 0 12px">Support Ivo and the future of EZi.</div>' +
                '<div style="display:flex;gap:10px;justify-content:center">' +
                '<button onclick="pywebview.api.open_url(\\'https://paypal.me/tavris1\\')" style="padding:10px 20px;background:var(--node-bg,#2a2a2a);color:var(--fg,#ccc);border:1px solid var(--border,#444);border-radius:8px;cursor:pointer">PayPal</button>' +
                '<button onclick="pywebview.api.open_url(\\'https://buymeacoffee.com/tavris1\\')" style="padding:10px 20px;background:var(--node-bg,#2a2a2a);color:var(--fg,#ccc);border:1px solid var(--border,#444);border-radius:8px;cursor:pointer">Buy Me a Coffee</button>' +
                '<button onclick="pywebview.api.open_url(\\'https://github.com/sponsors/Tavris1\\')" style="padding:10px 20px;background:var(--node-bg,#2a2a2a);color:var(--fg,#ccc);border:1px solid var(--border,#444);border-radius:8px;cursor:pointer">♥ Sponsor</button>' +
                '</div>' +
                '</div>' +
                '</div>' +
                '</div>' +
                /* footer */
                '<div id="_cdp_footer"><div id="_cdp_msg"></div><button id="_cdp_close">Close</button></div>' +
                '</div>' +
                '</div>';

            document.body.appendChild(overlay);
            document.getElementById('_cdp_close').onclick = removePanel;

            /* ── Sidebar tab switching ── */
            (function() {
                var _tabs = ['sys','add','torch','tls','app','adv','log','pxr','about'];
                function showTab(name) {
                    _tabs.forEach(function(t) {
                        var el = document.getElementById('_cdp_t_' + t);
                        if (el) el.style.display = (t === name) ? 'block' : 'none';
                        var b = document.querySelector('._cdp_nav[data-tab="' + t + '"]');
                        if (b) b.classList.toggle('on', t === name);
                    });
                    try { localStorage.setItem('_cdp_tab', name); } catch(e) {}
                }
                document.querySelectorAll('._cdp_nav').forEach(function(b) {
                    b.addEventListener('click', function() { showTab(this.getAttribute('data-tab')); });
                });
                var st = 'sys';
                try { st = localStorage.getItem('_cdp_tab') || 'sys'; } catch(e) {}
                showTab(st);
            })();

            /* ── Panel Theme (EZi Dark/Light/Pixaroma) ── */
            /* Map ComfyUI theme IDs to EZi panel themes */
            var _comfyToPanel = {
                'dark': 'dark', 'light': 'light', 'github': 'dark', 'nord': 'dark',
                'solarized': 'dark', 'arc': 'dark', 'pixaroma': 'pixaroma'
            };
            /* Current panel theme — default Pixaroma orange; never clobber with ComfyUI auto-sync unless chosen */
            var _panelThemeId = 'pixaroma';
            try {
                _panelThemeId = localStorage.getItem('_comfy_panel_theme') || 'pixaroma';
            } catch (e) {}

            function clearInlineThemeVars(el) {
                var toRemove = [];
                for (var i = 0; i < el.style.length; i++) {
                    var prop = el.style[i];
                    if (prop.startsWith('--')) toRemove.push(prop);
                }
                toRemove.forEach(function(p) { el.style.removeProperty(p); });
            }
            function applyPanelTheme(themeId) {
                var inner = document.getElementById('_cdp_inner');
                if (!inner) return;
                if (!themeId) themeId = 'pixaroma';
                _panelThemeId = themeId;
                /* Remove existing theme classes and inline vars (inline vars override class CSS) */
                inner.classList.remove('_ezi-theme-dark', '_ezi-theme-pixaroma', '_ezi-theme-light', '_ezi-theme-aurora', '_ezi-theme-comfyui');
                clearInlineThemeVars(inner);
                /* If auto-sync mode, fetch current ComfyUI theme and map to panel theme */
                if (themeId === 'comfyui') {
                    inner.classList.add('_ezi-theme-comfyui');
                    pywebview.api.get_comfy_theme().then(function(raw) {
                        /* Guard: user may have switched theme before this resolved */
                        if (_panelThemeId !== 'comfyui') return;
                        var t = JSON.parse(raw);
                        if (!t.error) {
                            var comfyId = t.palette_id || 'dark';
                            var panelId = _comfyToPanel[comfyId] || 'dark';
                            inner.classList.remove('_ezi-theme-dark', '_ezi-theme-pixaroma', '_ezi-theme-light', '_ezi-theme-aurora', '_ezi-theme-comfyui');
                            clearInlineThemeVars(inner);
                            inner.classList.add('_ezi-theme-' + panelId);
                            applyTheme(inner, t);
                        }
                    });
                    return;
                }
                /* Fixed panel themes (pixaroma / dark / light) — class vars only, no inline override */
                inner.classList.add('_ezi-theme-' + themeId);
            }
            function savePanelTheme(themeId) {
                _panelThemeId = themeId;
                try { localStorage.setItem('_comfy_panel_theme', themeId); } catch (e) {}
                /* Persist to disk so it survives webview storage resets */
                try {
                    pywebview.api.get_ui_settings().then(function(raw) {
                        var s = {};
                        try { s = JSON.parse(raw) || {}; } catch (e2) {}
                        s.panel_theme = themeId;
                        pywebview.api.save_ui_settings(JSON.stringify(s));
                    });
                } catch (e3) {}
            }

            /* Apply immediately on open (no need to click Apply) */
            applyPanelTheme(_panelThemeId);
            var _panelSel = document.getElementById('_cdp_panel_theme');
            if (_panelSel) _panelSel.value = _panelThemeId;
            /* Prefer disk-backed preference when available */
            try {
                pywebview.api.get_ui_settings().then(function(raw) {
                    var s = {};
                    try { s = JSON.parse(raw) || {}; } catch (e) {}
                    var diskTheme = s.panel_theme;
                    if (diskTheme && diskTheme !== _panelThemeId) {
                        _panelThemeId = diskTheme;
                        try { localStorage.setItem('_comfy_panel_theme', diskTheme); } catch (e2) {}
                        if (_panelSel) _panelSel.value = diskTheme;
                        applyPanelTheme(diskTheme);
                    } else if (!diskTheme) {
                        /* Seed disk with current default (pixaroma) */
                        savePanelTheme(_panelThemeId);
                    }
                });
            } catch (e) {}

            /* Auto-apply on dropdown change + Apply button (same action) */
            if (_panelSel) {
                _panelSel.onchange = function() {
                    var themeId = _panelSel.value || 'pixaroma';
                    savePanelTheme(themeId);
                    applyPanelTheme(themeId);
                    setMsg('✓ Panel theme: ' + themeId, '#8f8');
                };
            }
            document.getElementById('_cdp_panel_theme_apply').onclick = function() {
                var themeId = (_panelSel && _panelSel.value) || 'pixaroma';
                savePanelTheme(themeId);
                applyPanelTheme(themeId);
                setMsg('✓ Panel theme: ' + themeId, '#8f8');
            };

            /* ── AI Language selector ── */
            var _aiLangSel = document.getElementById('_cdp_ai_lang');
            var _aiLangBtn = document.getElementById('_cdp_ai_lang_apply');
            if (_aiLangSel && _aiLangBtn) {
                try {
                    pywebview.api.get_ui_settings().then(function(raw) {
                        var s = {};
                        try { s = JSON.parse(raw) || {}; } catch (e) {}
                        if (s.sel_ai_lang && _aiLangSel.querySelector('option[value="' + s.sel_ai_lang + '"]')) {
                            _aiLangSel.value = s.sel_ai_lang;
                        } else {
                            /* Auto-detect system language on first load */
                            pywebview.api.get_system_lang().then(function(raw2) {
                                var d = JSON.parse(raw2);
                                if (d.lang && _aiLangSel.querySelector('option[value="' + d.lang + '"]')) {
                                    _aiLangSel.value = d.lang;
                                }
                            });
                        }
                    });
                } catch (e) {}
                _aiLangBtn.onclick = function() {
                    var lang = _aiLangSel.value || 'en';
                    try {
                        pywebview.api.get_ui_settings().then(function(raw) {
                            var s = {};
                            try { s = JSON.parse(raw) || {}; } catch (e) {}
                            s.sel_ai_lang = lang;
                            pywebview.api.save_ui_settings(JSON.stringify(s));
                        });
                    } catch (e) {}
                    setMsg('✓ AI language: ' + lang, '#8f8');
                };
            }

            /* ── Populate ComfyUI node-editor theme selector (do NOT override panel theme) ── */
            pywebview.api.get_comfy_theme().then(function(raw) {
                var t = JSON.parse(raw);
                var currentPalette = t.palette_id || '';
                /* Only sync panel from ComfyUI when user chose ComfyUI auto-sync */
                if (_panelThemeId === 'comfyui' && !t.error) {
                    applyPanelTheme('comfyui');
                }
                pywebview.api.list_comfy_themes().then(function(raw2) {
                    var themes = JSON.parse(raw2);
                    var sel = document.getElementById('_cdp_theme');
                    sel.innerHTML = themes.map(function(id) {
                        var isCur = id === currentPalette;
                        return '<option value="'+id+'"'+(isCur?' selected':'')+'>'+id+(isCur?' ✓':'')+' </option>';
                    }).join('');
                });
            });

            document.getElementById('_cdp_theme_apply').onclick = function() {
                var sel = document.getElementById('_cdp_theme');
                var pid = sel.value;
                if (!pid) { setMsg('Select a theme first.', '#f88'); return; }
                pywebview.api.set_comfy_theme(pid).then(function(raw) {
                    var d = JSON.parse(raw);
                    if (d.error) { setMsg('Theme error: ' + d.error, '#f88'); return; }
                    setMsg('✓ Theme set to "' + pid + '" — reload page to see it', '#8f8');
                    /* Keep EZi panel theme; only re-sync panel if in comfyui auto mode */
                    if (_panelThemeId === 'comfyui') applyPanelTheme('comfyui');
                    /* Trigger ComfyUI to reload so the node-editor theme takes effect */
                    setTimeout(function() { window.location.reload(); }, 800);
                });
            };

            /* ── populate URL field ── */
            var urlEl = document.getElementById('_cdp_url');
            urlEl.textContent = window.location.origin;
            urlEl.onclick = function() {
                navigator.clipboard.writeText(window.location.origin).then(function() {
                    urlEl.textContent = '✓ Copied!';
                    setTimeout(function(){ urlEl.textContent = window.location.origin; }, 1500);
                });
            };

            /* ── system info ── */
            pywebview.api.get_system_info().then(function(raw) {
                var d = JSON.parse(raw);
                var html = '<tr><td colspan="2" style="color:#555;font-size:11px;padding-bottom:6px;' +
                           'text-transform:uppercase;letter-spacing:.06em">System</td></tr>';
                html += row('Platform', d.platform);
                html += row('Python', d.python);
                html += row('PyTorch', d.torch||'—');
                html += row('GPU / Backend', d.gpu||'—');
                if (d.cuda) html += row('CUDA', d.cuda);
                if (d.mps)  html += row('MPS available', d.mps);
                html += row('ComfyUI rev', d.comfyui_rev||'—');
                html += row('Frontend', d.frontend||'—');
                if (d.disk_free_gb) html += row('Disk free', d.disk_free_gb + ' GB');
                document.getElementById('_cdp_info').innerHTML = html;
            });

            /* ── cache info ── */
            function refreshCache() {
                pywebview.api.get_cache_info().then(function(raw) {
                    var d = JSON.parse(raw);
                    setMsg('Cache — pip: ' + (d.pip||0) + ' MB   uv: ' + (d.uv||0) + ' MB');
                });
            }
            refreshCache();

            /* ── zoom controls ── */
            var _zoom = parseFloat(localStorage.getItem('_comfy_zoom') || '1.0');
            function applyZoom(z) {
                _zoom = Math.max(0.5, Math.min(2.0, Math.round(z * 10) / 10));
                document.getElementById('_cdp_zm_val').textContent = Math.round(_zoom*100) + '%';
                pywebview.api.set_zoom(_zoom);
            }
            applyZoom(_zoom);
            document.getElementById('_cdp_zm_in').onclick  = function(){ applyZoom(_zoom + 0.1); };
            document.getElementById('_cdp_zm_out').onclick = function(){ applyZoom(_zoom - 0.1); };
            document.getElementById('_cdp_zm_rst').onclick = function(){ applyZoom(1.0); };

            /* ── always on top ── */
            document.getElementById('_cdp_aot').onchange = function() {
                pywebview.api.set_always_on_top(this.checked);
            };

            /* ── runtime stats (auto-refresh every 3s while panel open) ── */
            function refreshStats() {
                if (!document.getElementById(PANEL_ID)) return;
                pywebview.api.get_runtime_stats().then(function(raw) {
                    var d = JSON.parse(raw);
                    var parts = [];
                    if (d.process_ram_mb) parts.push('ComfyUI RAM: ' + d.process_ram_mb + ' MB');
                    if (d.ram_total_gb)   parts.push('System RAM: ' + d.ram_total_gb + ' GB total' + (d.ram_avail_gb ? ' / ' + d.ram_avail_gb + ' GB free' : ''));
                    if (d.vram_used_mb !== undefined) {
                        var v = 'VRAM: ' + d.vram_used_mb + ' MB used';
                        if (d.vram_total_mb) v += ' / ' + d.vram_total_mb + ' MB';
                        parts.push(v);
                    }
                    var el = document.getElementById('_cdp_stats');
                    if (el) el.textContent = parts.join('   ') || 'Stats unavailable';
                });
                pywebview.api.get_queue().then(function(raw) {
                    var d = JSON.parse(raw);
                    if (!d.error) {
                        var el = document.getElementById('_cdp_stats');
                        if (el) el.textContent += '   Queue: ' + d.running + ' running / ' + d.pending + ' pending';
                    }
                });
                setTimeout(function(){ if(document.getElementById(PANEL_ID)) refreshStats(); }, 3000);
            }
            refreshStats();

            /* ── launch args ── */
            pywebview.api.get_launch_args().then(function(raw) {
                var d = JSON.parse(raw);
                var inp = document.getElementById('_cdp_args');
                if (inp) inp.value = d.args || '';
            });
            document.getElementById('_cdp_args_save').onclick = function() {
                var val = document.getElementById('_cdp_args').value;
                pywebview.api.save_launch_args(val).then(function(raw) {
                    var d = JSON.parse(raw);
                    setMsg(d.ok ? '✓ Launch args saved (restart to apply)' : 'Error: ' + d.error,
                           d.ok ? '#8f8' : '#f88');
                });
            };

            /* ── ComfyUI-Manager security level ── */
            pywebview.api.get_manager_security_level().then(function(raw) {
                var d = JSON.parse(raw);
                var sel = document.getElementById('_cdp_sec_lvl');
                if (sel && d.level) sel.value = d.level;
            });
            document.getElementById('_cdp_sec_apply').onclick = function() {
                var lvl = document.getElementById('_cdp_sec_lvl').value;
                pywebview.api.set_manager_security_level(lvl).then(function(raw) {
                    var d = JSON.parse(raw);
                    setMsg(d.ok ? '\u2713 Security level set to "' + lvl + '" \u2014 restart ComfyUI to apply'
                                : 'Error: ' + d.error,
                           d.ok ? '#8f8' : '#f88');
                });
            };
            (function() {
                var infoBtn = document.getElementById('_cdp_sec_info');
                var tip = document.getElementById('_cdp_sec_tip');
                if (!infoBtn || !tip) return;
                infoBtn.onclick = function(e) {
                    e.stopPropagation();
                    tip.style.display = tip.style.display === 'none' ? 'block' : 'none';
                };
                document.addEventListener('click', function() { tip.style.display = 'none'; });
            })();

            /* ── Pinned packages ── */
            function refreshPins() {
                pywebview.api.check_pinned_packages().then(function(raw) {
                    var pkgs = JSON.parse(raw);
                    var el = document.getElementById('_cdp_pins');
                    if (!el) return;
                    if (!pkgs.length) {
                        el.innerHTML = '<span style="font-size:11px;color:#555">No pinned packages</span>';
                        return;
                    }
                    el.innerHTML = pkgs.map(function(p) {
                        var icon = p.ok ? '\u2713' : '\u26a0';
                        var icol = p.ok ? '#8f8' : '#fa8';
                        var ver  = p.ok ? (' <span style="font-size:10px;color:#666">' + p.installed + '</span>') : ' <span style="font-size:10px;color:#f88">not installed</span>';
                        return '<div style="display:flex;align-items:center;gap:6px;margin-bottom:3px">' +
                               '<span style="color:' + icol + ';font-size:14px">' + icon + '</span>' +
                               '<span style="font-size:12px;color:var(--fg,#e0e0e0);flex:1">' + p.spec + ver + '</span>' +
                               '<button class="_cdp_pin_rm" data-pkg="' + p.spec.replace(/"/g, '&quot;') + '" ' +
                               'style="background:none;border:none;color:#888;cursor:pointer;font-size:14px;padding:0 4px" title="Remove">\u2715</button>' +
                               '</div>';
                    }).join('');
                    el.querySelectorAll('._cdp_pin_rm').forEach(function(btn) {
                        btn.onclick = function() {
                            var pkg = this.getAttribute('data-pkg');
                            pywebview.api.remove_pinned_package(pkg).then(function() { refreshPins(); });
                        };
                    });
                });
            }
            refreshPins();
            document.getElementById('_cdp_pin_add').onclick = function() {
                var spec = document.getElementById('_cdp_pin_inp').value.trim();
                if (!spec) { setMsg('Enter a package spec (e.g. numpy==1.26.4)', '#f88'); return; }
                pywebview.api.add_pinned_package(spec).then(function(raw) {
                    var d = JSON.parse(raw);
                    if (d.error) { setMsg('Error: ' + d.error, '#f88'); return; }
                    document.getElementById('_cdp_pin_inp').value = '';
                    setMsg('\u2713 Pinned: ' + spec + ' (enforced on next start)', '#8f8');
                    refreshPins();
                });
            };
            document.getElementById('_cdp_pin_inp').addEventListener('keydown', function(e) {
                if (e.key === 'Enter') document.getElementById('_cdp_pin_add').click();
            });

            /* ── Torch Pack installer ── */
            (function() {
                var _tp_iid = null;
                var _tp_last = 0;
                /* populate dropdown */
                pywebview.api.list_torch_packs().then(function(raw) {
                    var packs = JSON.parse(raw);
                    var sel = document.getElementById('_cdp_tp_sel');
                    if (!sel) return;
                    if (!packs.length) {
                        sel.innerHTML = '<option value="">No Torch Pack scripts found</option>';
                        return;
                    }
                    var isMac = /mac/i.test(navigator.platform);
                    sel.innerHTML = packs.map(function(p) {
                        var label = p.name + (p.mac ? ' \u2014 macOS' : (p.cuda ? ' \u2014 CUDA' : ''));
                        var hi = (isMac && p.mac) || (!isMac && p.cuda);
                        return '<option value="' + p.filename + '"' + (hi ? ' style="font-weight:bold;color:#8f8"' : '') + '>' + label + '</option>';
                    }).join('');
                });
                /* install button */
                document.getElementById('_cdp_tp_run').onclick = function() {
                    var sel = document.getElementById('_cdp_tp_sel');
                    var fn = sel ? sel.value : '';
                    if (!fn) { setMsg('Select a Torch Pack script first.', '#f88'); return; }
                    var log = document.getElementById('_cdp_tp_log');
                    if (log) { log.textContent = 'Starting ' + fn + '\u2026\\n'; }
                    _tp_last = 0;
                    if (_tp_iid) { clearInterval(_tp_iid); _tp_iid = null; }
                    pywebview.api.run_torch_pack(fn).then(function(raw) {
                        var d = JSON.parse(raw);
                        if (d.error) { if (log) log.textContent += 'ERROR: ' + d.error + '\\n'; return; }
                        _tp_iid = setInterval(function() {
                            pywebview.api.get_torch_pack_log().then(function(raw2) {
                                var ld = JSON.parse(raw2);
                                if (ld.lines.length > _tp_last) {
                                    var added = ld.lines.slice(_tp_last).join('\\n');
                                    if (log) { log.textContent += added + '\\n'; log.scrollTop = log.scrollHeight; }
                                    _tp_last = ld.lines.length;
                                }
                                if (ld.done) {
                                    clearInterval(_tp_iid); _tp_iid = null;
                                    if (log) { log.textContent += '\u2014 Done \u2014\\n'; log.scrollTop = log.scrollHeight; }
                                }
                            });
                        }, 500);
                    });
                };
                /* cancel button */
                document.getElementById('_cdp_tp_cancel').onclick = function() {
                    if (_tp_iid) { clearInterval(_tp_iid); _tp_iid = null; }
                    pywebview.api.cancel_torch_pack().then(function() {
                        var log = document.getElementById('_cdp_tp_log');
                        if (log) { log.textContent += '\u2014 Cancelled \u2014\\n'; log.scrollTop = log.scrollHeight; }
                    });
                };
            })();

            /* ── installer update check ── */
            document.getElementById('_cdp_inst_upd').onclick = function() {
                var btn = this; btn.disabled = true; btn.textContent = 'Checking…';
                pywebview.api.check_installer_update().then(function(raw) {
                    var d = JSON.parse(raw);
                    if (d.error) setMsg('Installer check failed: ' + d.error, '#f88');
                    else if (d.up_to_date) {
                        var msg = '✓ Installer up to date';
                        if (d.local && d.local !== 'unknown') msg += '  local: ' + d.local + ' (' + (d.local_date||'?') + ')';
                        setMsg(msg, '#8f8');
                    } else {
                        var msg = '↑ ' + d.commits_behind + ' commit(s) behind MAC-Linux';
                        if (d.local && d.local !== 'unknown') msg += '  local: ' + d.local + ' (' + (d.local_date||'?') + ')';
                        msg += '  remote: ' + d.remote + ' (' + (d.remote_date||'?') + ')';
                        setMsg(msg, '#fc8');
                    }
                    btn.disabled = false; btn.textContent = 'Check installer update';
                });
            };

            /* ── Version dropdowns (ComfyUI + Frontend) ── */
            pywebview.api.get_system_info().then(function(infoRaw) {
                var sysInfo = JSON.parse(infoRaw);
                var currentRev = (sysInfo.comfyui_rev || '').split('-')[0].split('+')[0];
                var currentFe  = sysInfo.frontend || '';

                pywebview.api.get_versions().then(function(raw) {
                    var d = JSON.parse(raw);
                    var tags = d.versions || [];
                    var sel = document.getElementById('_cdp_ver');
                    if (!tags.length) { sel.innerHTML = '<option value="">No ComfyUI tags found</option>'; return; }
                    sel.innerHTML = tags.map(function(t) {
                        var isCur = currentRev && t === currentRev;
                        return '<option value="'+t+'"'+(isCur?' selected':'')+'>'+t+(isCur?' ✓':'')+' </option>';
                    }).join('');
                    if (!currentRev) sel.innerHTML = '<option value="">— select version —</option>' + sel.innerHTML;
                });

                pywebview.api.get_frontend_versions().then(function(raw) {
                    var d = JSON.parse(raw);
                    var vers = d.versions || [];
                    var isNightly = d.isNightly;
                    var sel = document.getElementById('_cdp_fe_ver');
                    if (!vers.length) { sel.innerHTML = '<option value="">No frontend versions found</option>'; return; }
                    sel.innerHTML = vers.map(function(v) {
                        var isCur = v === currentFe;
                        return '<option value="'+v+'"'+(isCur?' selected':'')+'>'+v+(isCur?' ✓':'')+' </option>';
                    }).join('');
                    if (!currentFe) sel.innerHTML = '<option value="">— select frontend version —</option>' + sel.innerHTML;
                    if (isNightly && currentFe) {
                        var badge = document.getElementById('_cdp_fe_nightly');
                        if (badge) { badge.textContent = 'NIGHTLY'; badge.style.color = '#fc8'; }
                    }
                });

            /* ── Add-on lists (Torch Pack / Tools / Fixes) ── */
            pywebview.api.list_addons().then(function(raw) {
                try {
                    var d = JSON.parse(raw);
                    if (d.error) { console.error('list_addons error:', d.error); return; }
                    function renderList(elId, items) {
                        var el = document.getElementById(elId);
                        if (!el) return;
                        if (!items || !items.length) {
                            el.innerHTML = '<div style="color:var(--muted,#888);padding:10px 0">No scripts found.</div>';
                            return;
                        }
                        el.innerHTML = items.map(function(it) {
                            return '<div class="item"><span class="name">' + it.name + '</span><button class="run" data-path="' + it.path + '">Run</button></div>';
                        }).join('');
                    }
                    renderList('_cdp_add_list', d.addons);
                    renderList('_cdp_tp_list', d.torch_packs);
                    renderList('_cdp_tls_list', d.tools);
                    renderList('_cdp_fixes_list', d.fixes);
                } catch(e) { console.error('list_addons parse:', e); }
            });

            // Delegate Run button clicks
            document.getElementById('_cdp_t_add').addEventListener('click', function(e) {
                if (e.target.classList.contains('run')) {
                    pywebview.api.run_addon(e.target.getAttribute('data-path'));
                }
            });
            document.getElementById('_cdp_t_torch').addEventListener('click', function(e) {
                if (e.target.classList.contains('run')) {
                    pywebview.api.run_addon(e.target.getAttribute('data-path'));
                }
            });
            document.getElementById('_cdp_t_tls').addEventListener('click', function(e) {
                if (e.target.classList.contains('run')) {
                    pywebview.api.run_addon(e.target.getAttribute('data-path'));
                }
            });
            document.getElementById('_cdp_t_adv').addEventListener('click', function(e) {
                if (e.target.classList.contains('run')) {
                    pywebview.api.run_addon(e.target.getAttribute('data-path'));
                }
            });
            });

            document.getElementById('_cdp_fe_switch').onclick = function() {
                var sel = document.getElementById('_cdp_fe_ver');
                var ver = sel.value;
                if (!ver) { setMsg('Select a frontend version first.', '#f88'); return; }
                if (!confirm('Install frontend v' + ver + '? Server will restart.')) return;
                setMsg('Installing frontend v' + ver + ' — please wait…', '#fc8');
                pywebview.api.set_frontend_version(ver).then(function(raw) {
                    var d = JSON.parse(raw);
                    if (d.error) setMsg('Frontend install failed: ' + d.error, '#f88');
                    else { setMsg('Installing frontend v' + ver + ' — server will restart automatically…', '#fc8'); setTimeout(removePanel, 2000); }
                });
            };

            /* ── Custom paths ── */
            pywebview.api.get_custom_paths().then(function(raw) {
                var d = JSON.parse(raw);
                var fi = document.getElementById('_cdp_path_in');
                var fo = document.getElementById('_cdp_path_out');
                var fu = document.getElementById('_cdp_path_usr');
                if (fi) fi.value = d.input || '';
                if (fo) fo.value = d.output || '';
                if (fu) fu.value = d.user || '';
            });
            document.getElementById('_cdp_paths_save').onclick = function() {
                var fi = document.getElementById('_cdp_path_in').value;
                var fo = document.getElementById('_cdp_path_out').value;
                var fu = document.getElementById('_cdp_path_usr').value;
                pywebview.api.set_custom_paths(fi, fo, fu).then(function(raw) {
                    var d = JSON.parse(raw);
                    setMsg(d.ok ? '✓ Paths saved (restart to apply)' : 'Error: ' + d.error,
                           d.ok ? '#8f8' : '#f88');
                });
            };

            function setMsg(txt, color) {
                var el = document.getElementById('_cdp_msg');
                if (el) { el.textContent = txt; el.style.color = color||'#888'; }
            }

            /* ── button handlers ── */
            document.getElementById('_cdp_upd').onclick = function() {
                var btn = this; btn.disabled = true; btn.textContent = 'Checking…';
                pywebview.api.check_update().then(function(raw) {
                    var d = JSON.parse(raw);
                    if (d.error) setMsg('Update check failed: ' + d.error, '#f88');
                    else if (d.up_to_date) setMsg('✓ Up to date (' + d.local + ')', '#8f8');
                    else setMsg('↑ ' + d.commits_behind + ' commit(s) behind  local:' + d.local + '  remote:' + d.remote, '#fc8');
                    btn.disabled = false; btn.textContent = 'Check for updates';
                });
            };

            document.getElementById('_cdp_clr').onclick = function() {
                var btn = this; btn.disabled = true; btn.textContent = 'Clearing…';
                pywebview.api.clear_cache('all').then(function(raw) {
                    var d = JSON.parse(raw);
                    setMsg(d.cleared.length ? 'Cleared: ' + d.cleared.join(', ') : 'Nothing to clear.');
                    btn.disabled = false; btn.textContent = 'Clear cache';
                    refreshCache();
                });
            };

            document.getElementById('_cdp_rst').onclick = function() {
                var btn = this; btn.disabled = true; btn.textContent = 'Restarting…';
                setMsg('Restarting server — window will reload automatically…', '#fc8');
                pywebview.api.restart_server().then(function(raw) {
                    var d = JSON.parse(raw);
                    if (d.error) { setMsg('Restart failed: ' + d.error, '#f88'); btn.disabled=false; btn.textContent='Restart server'; }
                    else { removePanel(); }
                });
            };

            document.getElementById('_cdp_fol_out').onclick       = function(){ pywebview.api.open_folder('output'); };
            document.getElementById('_cdp_fol_in').onclick          = function(){ pywebview.api.open_folder('input'); };
            document.getElementById('_cdp_fol_workflows').onclick    = function(){ pywebview.api.open_sub_folder('workflows'); };
            document.getElementById('_cdp_fol_models').onclick       = function(){ pywebview.api.open_folder('models'); };
            document.getElementById('_cdp_fol_root').onclick         = function(){ pywebview.api.open_folder('comfyui'); };

            /* ── EZi installer update badge (auto-check on panel open) ── */
            pywebview.api.check_installer_update().then(function(raw) {
                try {
                    var d = JSON.parse(raw);
                    if (!d.error && !d.up_to_date) {
                        var badge = document.getElementById('_cdp_ezi_upd_badge');
                        if (badge) {
                            badge.textContent = '⬆ Installer update available (' + d.commits_behind + ' commits behind)';
                            badge.style.display = 'block';
                        }
                    }
                } catch(e) {}
            });

            document.getElementById('_cdp_browser').onclick = function() {
                pywebview.api.open_browser(); removePanel();
            };

            /* ── Log viewer ── */
            try {
            var _logTimer = null;
            var view = document.getElementById('_cdp_log_view');
            var bar = document.getElementById('_cdp_ts');
            var inp = document.getElementById('_cdp_ts_input');
            var cnt = document.getElementById('_cdp_ts_count');
            var caseBtn = document.getElementById('_cdp_ts_case');
            var hl = null;
            try {
                if (window.CSS && CSS.highlights && typeof Highlight === 'function') {
                    hl = { all: new Highlight(), cur: new Highlight() };
                    CSS.highlights.set('cdp-search', hl.all);
                    CSS.highlights.set('cdp-search-cur', hl.cur);
                }
            } catch (e) { hl = null; }
            var MAXM = 10000, MAXH = 3000;
            var matches = [], idx = -1, caseOn = false, isOpen = false;
            function escText(s) {
                return String(s).replace(/[&<>"]/g, function(c) {
                    return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];
                });
            }
            function paint() {
                if (!view) return;
                var text = view.textContent || '';
                if (!matches.length) {
                    view.textContent = text;
                    return;
                }
                if (hl) {
                    view.textContent = text;
                    hl.all.clear(); hl.cur.clear();
                    var node = view.firstChild;
                    if (!node || node.nodeType !== 3) return;
                    var limit = Math.min(matches.length, MAXH);
                    var start = 0;
                    if (matches.length > MAXH && idx >= 0) start = Math.max(0, Math.min(idx - Math.floor(MAXH / 2), matches.length - MAXH));
                    for (var i = start; i < start + limit; i++) {
                        var m = matches[i];
                        var rg = document.createRange();
                        rg.setStart(node, m.s); rg.setEnd(node, m.s + m.l);
                        (i === idx ? hl.cur : hl.all).add(rg);
                    }
                    return;
                }
                var html = '', last = 0;
                for (var i = 0; i < matches.length; i++) {
                    html += escText(text.slice(last, matches[i].s));
                    html += '<span class="cdp-hl' + (i === idx ? ' cur' : '') + '">' + escText(text.slice(matches[i].s, matches[i].s + matches[i].l)) + '</span>';
                    last = matches[i].s + matches[i].l;
                }
                view.innerHTML = html + escText(text.slice(last));
            }
            function updateCount() {
                if (!cnt) return;
                cnt.classList.remove('none');
                if (!inp || !inp.value) { cnt.textContent = ''; return; }
                if (!matches.length) { cnt.textContent = 'No results'; cnt.classList.add('none'); return; }
                cnt.textContent = (idx + 1) + '/' + matches.length + (matches.length >= MAXM ? '+' : '');
            }
            function reveal() {
                if (idx < 0 || !matches.length || !view) return;
                var el = view.querySelector('.cdp-hl.cur');
                if (el) { try { el.scrollIntoView({ block: 'center' }); } catch (e) {} return; }
                var node = view.firstChild;
                if (!node || node.nodeType !== 3) return;
                var m = matches[idx];
                var rg = document.createRange();
                try {
                    rg.setStart(node, m.s); rg.setEnd(node, m.s + m.l);
                    var r1 = rg.getBoundingClientRect(), r2 = view.getBoundingClientRect();
                    if (!r1 || !r2) return;
                    var top = view.scrollTop + (r1.top - r2.top) - view.clientHeight / 2;
                    view.scrollTop = Math.max(0, Math.min(top, view.scrollHeight));
                } catch (e) {}
            }
            function compute(keep) {
                matches = [];
                if (view && inp && inp.value) {
                    var nq = caseOn ? inp.value : inp.value.toLowerCase();
                    var text = view.textContent || '';
                    if (!caseOn) text = text.toLowerCase();
                    var p = text.indexOf(nq);
                    while (p !== -1 && matches.length < MAXM) {
                        matches.push({ s: p, l: nq.length });
                        p = text.indexOf(nq, p + nq.length);
                    }
                }
                if (!matches.length) idx = -1;
                else if (keep && idx >= 0) idx = Math.min(idx, matches.length - 1);
                else idx = matches.length - 1;
                paint();
                updateCount();
            }
            function go(d) {
                if (!matches.length) { compute(false); if (!matches.length) return; }
                idx = (idx + d + matches.length) % matches.length;
                paint();
                updateCount();
                reveal();
            }
            function openSearch() {
                if (!bar || !inp) return;
                isOpen = true;
                bar.classList.add('show');
                var sel = window.getSelection();
                if (sel && !sel.isCollapsed && sel.rangeCount && view && view.contains(sel.getRangeAt(0).commonAncestorContainer)) {
                    var t = sel.toString();
                    if (t && t.length < 200 && t.split(String.fromCharCode(10)).length < 2) inp.value = t;
                }
                inp.focus();
                inp.select();
                compute(false);
                reveal();
            }
            function closeSearch() {
                isOpen = false;
                if (bar) bar.classList.remove('show');
                matches = [];
                idx = -1;
                paint();
                updateCount();
                if (inp) { try { inp.blur(); } catch (e) {} }
            }
            function refreshLog() {
                if (!view) { console.log('[EZi log] view not found'); return; }
                pywebview.api.get_server_log(300).then(function(raw) {
                    try {
                        var d = JSON.parse(raw);
                        if (d.error) { console.log('[EZi log] error:', d.error); return; }
                        var lines = d.lines || [];
                        view.textContent = lines.join('\\n') || 'No log lines yet.';
                        if (isOpen && inp && inp.value) { compute(true); reveal(); }
                        else { view.scrollTop = view.scrollHeight; }
                    } catch(e) { console.log('[EZi log] parse error:', e); }
                }).catch(function(err) { console.log('[EZi log] api error:', err); });
            }
            document.getElementById('_cdp_log_refresh').onclick = refreshLog;
            document.getElementById('_cdp_log_save').onclick = function() {
                var btn = this; btn.disabled = true;
                pywebview.api.save_server_log().then(function() {
                    btn.disabled = false;
                });
            };
            document.getElementById('_cdp_log_whatsnew').onclick = function() {
                pywebview.api.open_whats_new();
            };
            // Search bindings (Windows #term-search parity)
            if (bar && inp && cnt && caseBtn) {
                document.getElementById('_cdp_log_find').onclick = openSearch;
                document.getElementById('_cdp_ts_prev').onclick = function() { go(-1); inp.focus(); };
                document.getElementById('_cdp_ts_next').onclick = function() { go(1); inp.focus(); };
                document.getElementById('_cdp_ts_close').onclick = closeSearch;
                caseBtn.onclick = function() {
                    caseOn = !caseOn;
                    caseBtn.classList.toggle('on', caseOn);
                    compute(false);
                    reveal();
                    inp.focus();
                };
                inp.addEventListener('input', function() { compute(false); reveal(); });
                inp.addEventListener('keydown', function(e) {
                    if (e.key === 'Enter') {
                        e.preventDefault();
                        go(e.shiftKey ? -1 : 1);
                    } else if (e.key === 'Escape') {
                        e.preventDefault();
                        e.stopPropagation();
                        closeSearch();
                    }
                });
                // Ctrl+F / Cmd+F opens search on the log tab; F3 repeats the search
                document.addEventListener('keydown', function(e) {
                    if ((e.ctrlKey || e.metaKey) && !e.altKey && !e.shiftKey && (e.code === 'KeyF' || e.key === 'f' || e.key === 'F')) {
                        e.preventDefault();
                        var logTab = document.querySelector('._cdp_nav[data-tab="log"]');
                        if (logTab) logTab.click();
                        openSearch();
                    } else if (e.key === 'F3' && isOpen) {
                        e.preventDefault();
                        go(e.shiftKey ? -1 : 1);
                    }
                }, true);
            }
            // Auto-refresh log while the log tab is active
            function startLogRefresh() {
                if (_logTimer) return;
                refreshLog();
                _logTimer = setInterval(refreshLog, 2000);
            }
            function stopLogRefresh() {
                if (_logTimer) { clearInterval(_logTimer); _logTimer = null; }
            }
            // Hook into tab switching without relying on the local showTab variable
            var _logTabBtn = document.querySelector('._cdp_nav[data-tab="log"]');
            if (_logTabBtn) {
                _logTabBtn.addEventListener('click', function() {
                    startLogRefresh();
                });
            }
            // Stop auto-refresh when any other tab is clicked
            document.querySelectorAll('._cdp_nav:not([data-tab="log"])').forEach(function(btn) {
                btn.addEventListener('click', stopLogRefresh);
            });
            } catch(e) { console.error('[EZi log viewer] init failed:', e); }

            document.getElementById('_cdp_switch').onclick = function() {
                var sel = document.getElementById('_cdp_ver');
                var tag = sel.value;
                if (!tag) { setMsg('Select a version first.', '#f88'); return; }
                if (!confirm('Switch ComfyUI to ' + tag + '? Server will restart.')) return;
                setMsg('Switching to ' + tag + ' — server will restart…', '#fc8');
                pywebview.api.switch_version(tag).then(function(raw) {
                    var d = JSON.parse(raw);
                    if (d.error) setMsg('Switch failed: ' + d.error, '#f88');
                    else { setMsg('Switching to ' + tag + ' — server will restart automatically…', '#fc8'); setTimeout(removePanel, 2000); }
                });
            };

            /* Combined ComfyUI + Frontend switcher (EZi v3.6.2 feature) */
            document.getElementById('_cdp_switch_both').onclick = function() {
                var sel = document.getElementById('_cdp_ver');
                var tag = sel.value;
                if (!tag) { setMsg('Select a ComfyUI version first.', '#f88'); return; }
                var autoFe = document.getElementById('_cdp_auto_fe').checked;
                var feMode = autoFe ? 'auto' : null;
                var msg = autoFe ? 'Switching to ' + tag + ' with auto-detected frontend…' : 'Switching to ' + tag + ' (keeping current frontend)…';
                if (!confirm(msg + ' Server will restart.')) return;
                setMsg(msg, '#fc8');
                pywebview.api.switch_version_and_frontend(tag, feMode).then(function(raw) {
                    var d = JSON.parse(raw);
                    if (d.error) {
                        setMsg('Switch failed: ' + d.error, '#f88');
                        return;
                    }
                    setMsg('Switching to ' + tag + ' — server will restart automatically…', '#fc8');
                    setTimeout(removePanel, 2000);
                });
            };

            /* Check if frontend is nightly and show badge */
            pywebview.api.get_frontend_is_nightly().then(function(raw) {
                var isNightly = JSON.parse(raw);
                if (isNightly) {
                    var badge = document.getElementById('_cdp_nightly_badge');
                    if (badge) badge.style.display = 'inline';
                }
            });
        }

        function btnStyle(bg) {
            return 'background:' + bg + ';color:var(--fg,#e0e0e0);border:1px solid var(--border,#555);border-radius:6px;' +
                   'padding:7px 16px;font-size:13px;cursor:pointer';
        }

        /* Keyboard shortcut: Cmd+Shift+U (mac) or Ctrl+Shift+U (linux) */
        document.addEventListener('keydown', function(e) {
            var isU = e.key === 'U' || e.code === 'KeyU' || e.keyCode === 85;
            if (e.shiftKey && isU && (e.metaKey || e.ctrlKey)) {
                e.preventDefault();
                e.stopPropagation();
                buildPanel();
                return false;
            }
        }, true);

        /* Floating settings button as a reliable fallback */
        (function() {
            if (document.getElementById('_ezi_settings_btn')) return;
            var btn = document.createElement('button');
            btn.id = '_ezi_settings_btn';
            btn.innerHTML = '⚙';
            btn.title = 'EZi Settings (Cmd+Shift+U / Ctrl+Shift+U)';
            btn.style.cssText = 'position:fixed;bottom:16px;right:16px;z-index:99999;width:38px;height:38px;border-radius:50%;border:1px solid var(--accent,#e8530a);background:rgba(0,0,0,.75);color:var(--accent,#e8530a);font-size:18px;line-height:1;cursor:pointer;opacity:.75;transition:opacity .2s,transform .2s';
            btn.onmouseenter = function() { btn.style.opacity = '1'; btn.style.transform = 'scale(1.1)'; };
            btn.onmouseleave = function() { btn.style.opacity = '.75'; btn.style.transform = 'scale(1)'; };
            btn.onclick = function() { buildPanel(); };
            document.body.appendChild(btn);
        })();

        /* Also expose globally so it can be called from console */
        window._comfyDesktopPanel = buildPanel;
    })();

    /* ── Text selection popup (Copy / Google / ChatGPT / Claude / Save) ── */
    (function() {
        var pop = document.createElement('div');
        pop.id = '_ezi_sel_pop';
        pop.style.cssText = 'display:none;position:fixed;z-index:99999;background:#1e1e28;border:1px solid #e8530a;border-radius:6px;box-shadow:0 4px 14px rgba(0,0,0,.55);overflow:hidden;user-select:none;';
        var buttons = [
            {key:'copy', label:'Copy'},
            {key:'google', label:'Google'},
            {key:'chatgpt', label:'ChatGPT'},
            {key:'claude', label:'Claude'},
            {key:'save', label:'Save'}
        ];
        buttons.forEach(function(btn){
            var b = document.createElement('button');
            b.textContent = btn.label;
            b.style.cssText = 'padding:5px 11px;font-family:inherit;font-size:11px;font-weight:bold;background:transparent;border:none;border-right:1px solid rgba(232,83,10,0.6);color:#e0e0e0;cursor:pointer;line-height:1;transition:background .15s,color .15s;';
            b.addEventListener('mousedown', function(e){ e.preventDefault(); });
            b.addEventListener('click', function(e){
                e.preventDefault();
                var t = window.getSelection().toString().trim();
                if (!t) return;
                if (btn.key === 'copy') {
                    try { pywebview.api.write_clipboard(t); } catch(err) {}
                } else if (btn.key === 'google') {
                    try { pywebview.api.open_url('https://www.google.com/search?q=' + encodeURIComponent(t)); } catch(err) {}
                } else if (btn.key === 'chatgpt') {
                    try { pywebview.api.open_url('https://chatgpt.com/?q=' + encodeURIComponent(t)); } catch(err) {}
                } else if (btn.key === 'claude') {
                    try { pywebview.api.open_url('https://claude.ai/new?q=' + encodeURIComponent(t)); } catch(err) {}
                } else if (btn.key === 'save') {
                    try { pywebview.api.save_text(t); } catch(err) {}
                }
                hide();
            });
            pop.appendChild(b);
        });
        document.body.appendChild(pop);

        function hide(){ pop.style.display = 'none'; }
        function show(x, y){
            pop.style.display = 'flex';
            var rect = pop.getBoundingClientRect();
            var px = Math.min(window.innerWidth - rect.width - 8, Math.max(8, x));
            var py = Math.min(window.innerHeight - rect.height - 8, Math.max(8, y));
            pop.style.left = px + 'px';
            pop.style.top = py + 'px';
        }

        document.addEventListener('mouseup', function(e){
            setTimeout(function(){
                var sel = window.getSelection().toString().trim();
                if (sel && e.button === 0) show(e.clientX + 10, e.clientY + 10);
                else hide();
            }, 10);
        });
        document.addEventListener('mousedown', function(e){ if (!pop.contains(e.target)) hide(); });
        window.addEventListener('scroll', hide, {passive:true});
        window.addEventListener('resize', hide);
    })();

    /* ── EZi top toolbar (Folders / Easy menu) ── */
    (function() {
        if (document.getElementById('_ezi_topbar')) return;
        function btnStyle(bg) {
            return 'background:' + bg + ';color:#fff;border:1px solid rgba(255,255,255,.15);border-radius:5px;padding:4px 10px;font-family:inherit;font-size:12px;font-weight:600;cursor:pointer;transition:opacity .15s;';
        }
        function menuStyle() {
            return 'display:none;position:absolute;top:100%;right:0;margin-top:4px;min-width:150px;background:#1e1e28;border:1px solid #444;border-radius:6px;box-shadow:0 4px 14px rgba(0,0,0,.55);overflow:hidden;z-index:100000;';
        }
        function itemStyle() {
            return 'display:block;width:100%;text-align:left;padding:7px 12px;background:transparent;border:none;border-bottom:1px solid rgba(255,255,255,.08);color:#e0e0e0;font-family:inherit;font-size:12px;cursor:pointer;transition:background .15s;';
        }
        function sepStyle() {
            return 'height:1px;background:rgba(255,255,255,.1);margin:4px 0;';
        }

        var bar = document.createElement('div');
        bar.id = '_ezi_topbar';
        bar.style.cssText = 'position:fixed;top:0;right:0;z-index:99999;display:flex;gap:6px;padding:6px 10px;';

        // Folders dropdown
        var folWrap = document.createElement('div');
        folWrap.style.cssText = 'position:relative;';
        var folBtn = document.createElement('button');
        folBtn.innerHTML = '📂 Folders &#9662;';
        folBtn.style.cssText = btnStyle('#2a3a5a');
        var folMenu = document.createElement('div');
        folMenu.style.cssText = menuStyle();
        folMenu.innerHTML =
            '<button style="' + itemStyle() + '" data-act="folder" data-target="output">📂 Output</button>' +
            '<button style="' + itemStyle() + '" data-act="folder" data-target="input">📂 Input</button>' +
            '<button style="' + itemStyle() + '" data-act="subfolder" data-target="workflows">📂 Workflows</button>' +
            '<button style="' + itemStyle() + '" data-act="folder" data-target="models">📂 Models</button>' +
            '<button style="' + itemStyle() + '" data-act="folder" data-target="comfyui">📂 ComfyUI</button>';
        folWrap.appendChild(folBtn);
        folWrap.appendChild(folMenu);

        // Easy menu dropdown
        var easyWrap = document.createElement('div');
        easyWrap.style.cssText = 'position:relative;';
        var easyBtn = document.createElement('button');
        easyBtn.innerHTML = '&#9776; Easy';
        easyBtn.style.cssText = btnStyle('#3a2a5a');
        var easyMenu = document.createElement('div');
        easyMenu.style.cssText = menuStyle();
        easyMenu.innerHTML =
            '<button style="' + itemStyle() + '" data-act="save_log">📰 Save log as .txt</button>' +
            '<div style="' + sepStyle() + '"></div>' +
            '<button style="' + itemStyle() + '" data-act="sel_copy">Copy selection</button>' +
            '<button style="' + itemStyle() + '" data-act="sel_save">Save selection</button>' +
            '<button style="' + itemStyle() + '" data-act="sel_google">Google selection</button>' +
            '<button style="' + itemStyle() + '" data-act="sel_chatgpt">Ask ChatGPT</button>' +
            '<button style="' + itemStyle() + '" data-act="sel_claude">Ask Claude</button>';
        easyWrap.appendChild(easyBtn);
        easyWrap.appendChild(easyMenu);

        bar.appendChild(folWrap);
        bar.appendChild(easyWrap);
        document.body.appendChild(bar);

        function toggleMenu(menu, other) {
            var showing = menu.style.display === 'block';
            if (other) other.style.display = 'none';
            menu.style.display = showing ? 'none' : 'block';
        }
        function hideAll() {
            folMenu.style.display = 'none';
            easyMenu.style.display = 'none';
        }

        folBtn.onclick = function(e) { e.stopPropagation(); toggleMenu(folMenu, easyMenu); };
        easyBtn.onclick = function(e) { e.stopPropagation(); toggleMenu(easyMenu, folMenu); };
        document.addEventListener('click', function(e) {
            if (!folWrap.contains(e.target) && !easyWrap.contains(e.target)) hideAll();
        });

        folMenu.addEventListener('click', function(e) {
            var t = e.target;
            if (t.tagName !== 'BUTTON') return;
            var act = t.getAttribute('data-act');
            var target = t.getAttribute('data-target');
            if (act === 'folder') pywebview.api.open_folder(target);
            else if (act === 'subfolder') pywebview.api.open_sub_folder(target);
            hideAll();
        });

        function getSel() { return window.getSelection().toString().trim(); }
        easyMenu.addEventListener('click', function(e) {
            var t = e.target;
            if (t.tagName !== 'BUTTON') return;
            var act = t.getAttribute('data-act');
            var sel = getSel();
            if (act === 'save_log') {
                pywebview.api.save_server_log();
            } else if (!sel) {
                alert('Select some text first.');
            } else if (act === 'sel_copy') {
                try { pywebview.api.write_clipboard(sel); } catch(err) {}
            } else if (act === 'sel_save') {
                try { pywebview.api.save_text(sel); } catch(err) {}
            } else if (act === 'sel_google') {
                try { pywebview.api.open_url('https://www.google.com/search?q=' + encodeURIComponent(sel)); } catch(err) {}
            } else if (act === 'sel_chatgpt') {
                try { pywebview.api.open_url('https://chatgpt.com/?q=' + encodeURIComponent(sel)); } catch(err) {}
            } else if (act === 'sel_claude') {
                try { pywebview.api.open_url('https://claude.ai/new?q=' + encodeURIComponent(sel)); } catch(err) {}
            }
            hideAll();
        });
    })();

    /* ── Focus restore on window re-activation (Windows v3.30.3 parity) ── */
    // Windows hooks Form.Activated and calls CoreWebView2Controller.MoveFocus
    // once the mouse button is released, so keyboard shortcuts go back to the
    // graph instead of the shell. On Unix the settings panel is a DOM overlay:
    // the same idea applies to focus left on a closed panel or on <body>.
    (function() {
        var _mouseDown = false;
        document.addEventListener('mousedown', function() { _mouseDown = true; });
        document.addEventListener('mouseup', function() { _mouseDown = false; });
        document.addEventListener('mouseleave', function() { _mouseDown = false; });

        function _focusTarget() {
            var c = document.getElementById('graph-canvas');
            var host = c ? (c.closest('.comfyui-body') || c.parentElement || c) : document.body;
            try { if (host && !host.getAttribute('tabindex')) host.setAttribute('tabindex', '-1'); } catch(e) {}
            return host;
        }

        function _restoreComfyFocus() {
            try {
                if (document.getElementById('_cdp_overlay')) return;   // panel open: leave focus alone
                if (_mouseDown) return;                                // Windows GetAsyncKeyState guard
                var ae = document.activeElement;
                if (ae) {
                    var tag = (ae.tagName || '').toUpperCase();
                    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || ae.isContentEditable) return;
                    if (ae.id === 'graph-canvas') return;              // already on the graph
                    var cls = (ae.className || '').toString();
                    var stale = (ae.id || '').indexOf('_cdp_') === 0 || cls.indexOf('_cdp_') >= 0 || cls.indexOf('px-') >= 0;
                    if (ae !== document.body && !stale) return;        // deliberate focus elsewhere
                }
                var t = _focusTarget();
                if (t && t.focus) t.focus({ preventScroll: true });
            } catch(e) {}
        }

        // Same 80 ms delay Windows uses, so a drag that ends on re-activation is not stolen from
        window.addEventListener('focus', function() { setTimeout(_restoreComfyFocus, 80); });
    })();
})();
"""


def open_in_webview():
    """Open ComfyUI in a native pywebview window."""
    try:
        import webview
    except ImportError:
        print("pywebview not installed — falling back to browser")
        open_in_browser()
        return

    icon = ICON_PATH if os.path.isfile(ICON_PATH) else None

    class Api:
        def open_browser(self):
            """Called from JS when user presses Cmd+B / Ctrl+B."""
            webbrowser.open(comfyui_url())

        def pick_and_upload(self, accept="*"):
            """Open native file picker and upload selected file to ComfyUI."""
            threading.Thread(
                target=self._do_pick_and_upload, args=(accept,), daemon=True
            ).start()

        def _do_pick_and_upload(self, accept):
            """Actual pick+upload logic."""
            file_path = self._native_open_dialog(accept)
            if not file_path:
                self._toast('Upload cancelled')
                return

            filename = os.path.basename(file_path)
            self._toast(f'Uploading {filename}...')

            # Determine upload subfolder based on extension
            ext = os.path.splitext(filename)[1].lower()
            upload_type = 'input'
            subfolder = ''

            # Upload to ComfyUI server
            try:
                import http.client
                import mimetypes

                boundary = '----ComfyDesktopUpload'
                content_type = mimetypes.guess_type(filename)[0] or 'application/octet-stream'

                with open(file_path, 'rb') as f:
                    file_data = f.read()

                body = (
                    f'--{boundary}\r\n'
                    f'Content-Disposition: form-data; name="image"; filename="{filename}"\r\n'
                    f'Content-Type: {content_type}\r\n\r\n'
                ).encode() + file_data + (
                    f'\r\n--{boundary}\r\n'
                    f'Content-Disposition: form-data; name="type"\r\n\r\n'
                    f'{upload_type}'
                    f'\r\n--{boundary}\r\n'
                    f'Content-Disposition: form-data; name="subfolder"\r\n\r\n'
                    f'{subfolder}'
                    f'\r\n--{boundary}\r\n'
                    f'Content-Disposition: form-data; name="overwrite"\r\n\r\n'
                    f'true'
                    f'\r\n--{boundary}--\r\n'
                ).encode()

                if _COMFY_SCHEME[0] == "https":
                    conn = http.client.HTTPSConnection(COMFYUI_HOST, COMFYUI_PORT, timeout=30, context=_comfy_ssl())
                else:
                    conn = http.client.HTTPConnection(COMFYUI_HOST, COMFYUI_PORT, timeout=30)
                conn.request(
                    'POST', '/upload/image',
                    body=body,
                    headers={'Content-Type': f'multipart/form-data; boundary={boundary}'}
                )
                resp = conn.getresponse()
                resp_data = resp.read().decode()
                conn.close()

                if resp.status == 200:
                    import json
                    result = json.loads(resp_data)
                    upl_name = result.get('name', filename)
                    upl_sub = result.get('subfolder', '')
                    upl_type = result.get('type', 'input')
                    self._toast(f'Uploaded: {upl_name}')
                    print(f"  Uploaded: {upl_name} (subfolder={upl_sub}, type={upl_type})")
                    # Notify JS to refresh widgets
                    try:
                        safe_upl_name = upl_name.replace('\\', '\\\\').replace("'", "\\'")
                        safe_upl_sub = upl_sub.replace('\\', '\\\\').replace("'", "\\'")
                        safe_upl_type = upl_type.replace('\\', '\\\\').replace("'", "\\'")
                        window.evaluate_js(
                            f"window._comfyDesktopUploadDone('{safe_upl_name}','{safe_upl_sub}','{safe_upl_type}');"
                        )
                    except Exception:
                        pass
                else:
                    self._toast(f'Upload failed: HTTP {resp.status}')
                    print(f"  Upload failed: {resp.status} {resp_data}")
            except Exception as e:
                self._toast(f'Upload failed: {e}')
                print(f"  Upload error: {e}")

        def _native_open_dialog(self, accept="*"):
            """Open a native file picker. Returns path or None."""
            if sys.platform == 'darwin':
                import subprocess
                # Build file type filter for osascript
                type_str = ''
                if accept and accept != '*':
                    exts = []
                    for part in accept.split(','):
                        part = part.strip().lower()
                        if part.startswith('.'):
                            exts.append('"' + part[1:] + '"')
                        elif 'image' in part:
                            exts.extend(['"png"', '"jpg"', '"jpeg"', '"gif"', '"webp"', '"bmp"', '"tiff"'])
                        elif 'video' in part:
                            exts.extend(['"mp4"', '"mov"', '"webm"', '"avi"', '"mkv"'])
                    if exts:
                        unique = sorted(set(exts))
                        type_str = ' of type {' + ', '.join(unique) + '}'

                script = (
                    f'set f to POSIX path of (choose file with prompt "Choose a file to upload:"{type_str})\n'
                    f'return f'
                )
                try:
                    r = subprocess.run(
                        ['osascript', '-e', script],
                        capture_output=True, text=True, timeout=120,
                    )
                    path = r.stdout.strip()
                    if r.returncode == 0 and path and os.path.isfile(path):
                        return path
                except Exception:
                    pass
                return None

            path = self._pick_via_window_dialog()
            if path:
                return path

            # Linux: tkinter fallback
            try:
                import tkinter as tk
                from tkinter import filedialog
                root = tk.Tk()
                root.withdraw()
                ftypes = [('All Files', '*.*')]
                if accept and accept != '*':
                    if 'image' in accept:
                        ftypes.insert(0, ('Images', '*.png *.jpg *.jpeg *.gif *.webp *.bmp'))
                    elif 'video' in accept:
                        ftypes.insert(0, ('Videos', '*.mp4 *.mov *.webm *.avi *.mkv'))
                path = filedialog.askopenfilename(
                    initialdir=os.path.expanduser('~/Downloads'),
                    filetypes=ftypes,
                )
                root.destroy()
                return path if path else None
            except Exception as e:
                print(f"  File dialog failed: {e}")
            return None

        def _pick_via_window_dialog(self):
            """open_file() result shape differs between pywebview versions."""
            picker = getattr(getattr(self, '_window', None), 'open_file', None)
            if not picker:
                return None
            try:
                result = picker()
            except Exception as e:
                print(f"  Window dialog failed: {e}")
                return None
            if isinstance(result, dict):
                result = result.get('paths') or result.get('filenames')
            path = result if isinstance(result, str) else (result[0] if result else None)
            return path if path and os.path.isfile(path) else None

        def write_clipboard(self, text):
            """Copy text to system clipboard (Mac: pbcopy, Linux: xclip/xsel)."""
            if not text:
                return
            try:
                if sys.platform == "darwin":
                    p = subprocess.Popen(["pbcopy"], stdin=subprocess.PIPE)
                    p.communicate(text.encode("utf-8"))
                else:
                    for cmd in (["xclip", "-selection", "clipboard"],
                                ["xsel", "--clipboard", "--input"]):
                        try:
                            p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
                            p.communicate(text.encode("utf-8"))
                            if p.returncode == 0:
                                break
                        except FileNotFoundError:
                            continue
            except Exception:
                pass

        def save_text(self, text):
            """Open a native Save As dialog for the selected text."""
            if not text or not isinstance(text, str):
                return
            threading.Thread(
                target=self._do_save_text, args=(text,), daemon=True
            ).start()

        def _do_save_text(self, text):
            """Actual save-text logic."""
            from datetime import datetime
            default_name = f"ComfyUI-EZi-selection-{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
            save_path = self._native_save_dialog(default_name)
            if not save_path:
                self._toast('Save cancelled')
                return
            try:
                with open(save_path, "w", encoding="utf-8") as f:
                    f.write(text.replace("\r\n", "\n").replace("\r", "\n"))
                self._toast(f'Saved: {os.path.basename(save_path)}')
            except Exception as e:
                self._toast(f'Save failed: {e}')

        def read_clipboard(self):
            """Read text from system clipboard (Mac: pbpaste, Linux: xclip/xsel)."""
            try:
                if sys.platform == "darwin":
                    r = subprocess.run(["pbpaste"], capture_output=True, text=True, timeout=5)
                    return r.stdout if r.returncode == 0 else ""
                for cmd in (["xclip", "-selection", "clipboard", "-o"],
                            ["xsel", "--clipboard", "--output"]):
                    try:
                        r = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
                        if r.returncode == 0:
                            return r.stdout
                    except FileNotFoundError:
                        continue
                return ""
            except Exception:
                return ""

        def save_file(self, url, filename="download", directory=""):
            """Download file from server and open native Save As dialog.

            directory: optional model subfolder (from the workflow's model info)
            the dialog should open in; falls back to ~/Downloads when empty or invalid.
            """
            if not url or not isinstance(url, str):
                return
            # Run in a thread so it doesn't block the webview
            threading.Thread(
                target=self._do_save, args=(url, filename, directory), daemon=True
            ).start()

        def _do_save(self, url, filename, directory=""):
            """Actual save logic — runs in background thread."""
            save_path = self._native_save_dialog(filename, directory)
            if not save_path:
                self._toast('Save cancelled')
                return
            try:
                if url.startswith(comfyui_url()) or url.startswith('https://127.0.0.1') or url.startswith('http://127.0.0.1'):
                    req = urllib.request.Request(url, headers={"User-Agent": "EZiDesktop"})
                    with _comfy_urlopen(req, timeout=30) as src, open(save_path, 'wb') as dst:
                        import shutil
                        shutil.copyfileobj(src, dst)
                else:
                    urllib.request.urlretrieve(url, save_path)
                basename = os.path.basename(save_path)
                self._toast(f'Saved: {basename}')
                print(f"  Saved: {save_path}")
            except Exception as e:
                self._toast(f'Save failed: {e}')
                print(f"  Save error: {e}")

        def _model_target_dir(self, directory):
            """Resolve a model subfolder (relative, from workflow model info) to a real path."""
            try:
                directory = str(directory or '').strip().strip('/')
                if not directory or os.path.isabs(directory) or ':' in directory:
                    return None
                parts = [p for p in directory.split('/') if p]
                if not parts or any(p in ('.', '..') for p in parts):
                    return None
                models = os.path.normpath(os.path.join(SCRIPT_DIR, 'ComfyUI', 'models'))
                if not os.path.isdir(models):
                    return None
                target = os.path.normpath(os.path.join(models, *parts))
                base = os.path.abspath(models)
                if not os.path.abspath(target).startswith(base + os.sep):
                    return None
                os.makedirs(target, exist_ok=True)
                return target if os.path.isdir(target) else None
            except Exception:
                return None

        def _native_save_dialog(self, filename, directory=""):
            """Open a native Save As dialog. Returns path or None."""
            downloads = os.path.expanduser('~/Downloads')
            # Open in the model subfolder when the workflow model info gave one
            start_dir = self._model_target_dir(directory) or downloads

            # macOS: use osascript for a real Finder save dialog
            if sys.platform == 'darwin':
                import subprocess
                safe_name = filename.replace('"', '\\"')
                script = (
                    f'set f to POSIX path of (choose file name with prompt '
                    f'"Save as:" default name "{safe_name}" '
                    f'default location POSIX file "{start_dir}")\n'
                    f'return f'
                )
                try:
                    r = subprocess.run(
                        ['osascript', '-e', script],
                        capture_output=True, text=True, timeout=120,
                    )
                    path = r.stdout.strip()
                    if r.returncode == 0 and path:
                        return path
                except Exception:
                    pass
                return None

            # Linux: try tkinter file dialog
            try:
                import tkinter as tk
                from tkinter import filedialog
                root = tk.Tk()
                root.withdraw()
                ext = os.path.splitext(filename)[1].lower()
                ftypes = [('All Files', '*.*')]
                if ext in ('.png', '.jpg', '.jpeg', '.webp', '.gif'):
                    ftypes.insert(0, ('Image Files', f'*{ext}'))
                elif ext == '.mp4':
                    ftypes.insert(0, ('Video Files', '*.mp4'))
                path = filedialog.asksaveasfilename(
                    initialdir=start_dir,
                    initialfile=filename,
                    filetypes=ftypes,
                )
                root.destroy()
                return path if path else None
            except Exception:
                pass

            # Final fallback: save directly to ~/Downloads (or model subfolder)
            fallback = os.path.join(start_dir, filename)
            # Avoid overwriting — add number suffix
            base, ext = os.path.splitext(fallback)
            counter = 1
            while os.path.exists(fallback):
                fallback = f"{base}_{counter}{ext}"
                counter += 1
            return fallback

        def get_system_info(self):
            """Return system/platform info as a JSON string (called from JS)."""
            if COMFYUI_REMOTE:
                try:
                    url = f"{comfyui_url()}/system_stats"
                    req = urllib.request.Request(url, headers={"User-Agent": "EZiDesktop"})
                    with urllib.request.urlopen(req, timeout=5) as resp:
                        raw = json.loads(resp.read().decode())
                    sys_raw = raw.get("system", {})
                    devices  = raw.get("devices", [])
                    info = {}
                    info["platform"] = sys_raw.get("os", "unknown") + " (remote)"
                    info["python"]   = sys_raw.get("python_version", "—")
                    info["torch"]    = sys_raw.get("pytorch_version", "—")
                    gpu_parts = []
                    for dev in devices:
                        name = dev.get("name", "")
                        dtype = dev.get("type", "")
                        vram_total = dev.get("vram_total", 0)
                        vram_free  = dev.get("vram_free",  0)
                        vram_str = ""
                        if vram_total:
                            used_mb  = round((vram_total - vram_free) / 1024 / 1024)
                            total_mb = round(vram_total / 1024 / 1024)
                            vram_str = f" ({used_mb}/{total_mb} MB)"
                        gpu_parts.append(f"{name}{vram_str}" if name else dtype)
                        if dtype == "cuda":
                            info["cuda"] = "remote"
                    info["gpu"] = ", ".join(gpu_parts) if gpu_parts else "unknown"
                    info["comfyui_rev"] = sys_raw.get("comfyui_version", "—")
                    info["frontend"]   = "— (remote)"
                    return json.dumps(info)
                except Exception as e:
                    return json.dumps({"platform": f"remote ({COMFYUI_HOST})",
                                       "python": "—", "torch": "—",
                                       "gpu": f"fetch error: {e}",
                                       "comfyui_rev": "—", "frontend": "—"})
            return json.dumps(get_system_info())

        def get_cache_info(self):
            """Return pip/uv cache sizes as a JSON string (called from JS)."""
            return json.dumps(get_cache_info())

        def clear_cache(self, cache_type="all"):
            """Clear pip/uv cache. cache_type: 'pip'|'uv'|'all'"""
            cleared = clear_cache(cache_type)
            self._toast(f"Cache cleared: {', '.join(cleared) if cleared else 'nothing to clear'}")
            return json.dumps({"cleared": cleared})

        def check_update(self):
            """Check if ComfyUI has upstream updates. Returns JSON."""
            return json.dumps(check_comfyui_update())

        def get_versions(self):
            """Return list of ComfyUI git tags as a JSON array."""
            return json.dumps(get_comfyui_versions())

        def get_frontend_is_nightly(self):
            """Return true/false/None if installed frontend is a nightly/dev build."""
            return json.dumps(get_frontend_is_nightly())

        def get_required_frontend(self, tag):
            """Get the required frontend version for a specific ComfyUI tag."""
            return json.dumps(get_comfyui_required_frontend(tag))

        def switch_version_and_frontend(self, tag, fe_version=None):
            """Switch ComfyUI version and auto-install matching frontend (threaded).
            fe_version can be 'auto' to auto-detect from requirements.txt."""
            if COMFYUI_REMOTE:
                return json.dumps({"error": "Not available in remote mode"})
            comfy_dir = os.path.join(SCRIPT_DIR, "ComfyUI")
            if not tag or not os.path.isdir(os.path.join(comfy_dir, ".git")):
                return json.dumps({"error": "Invalid tag or not a git repo"})
            def _do_switch():
                try:
                    self.restart_server()
                    import time as _time
                    _time.sleep(1)
                    subprocess.run(["git", "fetch", "--tags", "--quiet"],
                                   cwd=comfy_dir, capture_output=True, timeout=30)
                    r = subprocess.run(["git", "checkout", f"tags/{tag}"],
                                       cwd=comfy_dir, capture_output=True, text=True, timeout=15)
                    if r.returncode != 0:
                        return
                    if fe_version is None or fe_version == "auto":
                        fe_version = get_comfyui_required_frontend(tag)
                    if fe_version:
                        install_frontend_version(fe_version)
                except Exception:
                    pass
            threading.Thread(target=_do_switch, daemon=True).start()
            return json.dumps({"ok": True, "tag": tag})

        def get_comfy_theme(self):
            """Return ComfyUI's active palette CSS vars for the desktop panel."""
            return json.dumps(get_comfy_theme())

        def list_comfy_themes(self):
            """Return list of available ComfyUI palette IDs."""
            return json.dumps(list_comfy_themes())

        def set_comfy_theme(self, palette_id):
            """Write palette_id into comfy.settings.json."""
            return json.dumps(set_comfy_theme(palette_id))

        def get_frontend_versions(self):
            """Return recent comfyui_frontend_package versions from PyPI."""
            return json.dumps(get_frontend_versions())

        def set_frontend_version(self, version):
            """Install a specific frontend version via pip (threaded, restarts server)."""
            if COMFYUI_REMOTE:
                return json.dumps({"error": "Not available in remote mode"})
            def _do_install():
                try:
                    self.restart_server()
                    import time as _time
                    _time.sleep(1)
                    install_frontend_version(version)
                except Exception:
                    pass
            threading.Thread(target=_do_install, daemon=True).start()
            return json.dumps({"ok": True, "version": version})

        def check_installer_update(self):
            """Check GitHub for a newer ComfyUI-Easy-Install release."""
            return json.dumps(check_installer_update())

        def _check_ezi_update(self):
            """Background: check the MAC-Linux branch to see if a newer EZi Desktop is available."""
            try:
                tag = _mac_linux_ezi_version().lstrip("v")
                if not tag:
                    return
                local_parts = [int(x) for x in EZI_VERSION.split(".") if x.isdigit()]
                remote_parts = [int(x) for x in tag.split(".") if x.isdigit()]
                if remote_parts > local_parts:
                    display = "v" + tag
                    safe = display.replace("'", "\\'")
                    self._toast(f"EZi Desktop {safe} available — visit GitHub to update")
            except Exception:
                _log_error('_check_ezi_update')

        def get_ui_settings(self):
            """Return persisted UI settings as JSON."""
            state = load_window_state()
            settings = state.get("ui_settings", {})
            return json.dumps(settings)

        def save_ui_settings(self, settings_json):
            """Persist UI settings (theme, zoom, etc.) to window state file."""
            try:
                if not settings_json or not isinstance(settings_json, str):
                    return json.dumps({"error": "invalid input"})
                data = json.loads(settings_json)
                if not isinstance(data, dict):
                    return json.dumps({"error": "not a dict"})
                state = load_window_state()
                state["ui_settings"] = data
                with open(WINDOW_STATE_FILE, "w") as f:
                    json.dump(state, f)
                return json.dumps({"ok": True})
            except Exception as e:
                return json.dumps({"error": str(e)})

        def get_system_lang(self):
            """Return detected system language code for AI links."""
            return json.dumps({"lang": _ezi_system_lang()})

        def get_custom_paths(self):
            """Return saved custom input/output/user paths."""
            return json.dumps(get_custom_paths())

        def set_custom_paths(self, input_dir, output_dir, user_dir):
            """Save custom paths into launch args."""
            return json.dumps(set_custom_paths(input_dir, output_dir, user_dir))

        def get_manager_security_level(self):
            """Return current ComfyUI-Manager security level."""
            return json.dumps({"level": get_manager_security_level()})

        def set_manager_security_level(self, level):
            """Set ComfyUI-Manager security level (restart ComfyUI to apply)."""
            return json.dumps(set_manager_security_level(level))

        def get_pinned_packages(self):
            """Return list of pinned package specs."""
            return json.dumps(get_pinned_packages())

        def add_pinned_package(self, spec):
            """Add a package spec to the pinned list."""
            return json.dumps(add_pinned_package(spec))

        def remove_pinned_package(self, spec):
            """Remove a package spec from the pinned list."""
            return json.dumps(remove_pinned_package(spec))

        def manager_config_exists(self):
            """Return True if ComfyUI-Manager config.ini exists."""
            return json.dumps(manager_config_exists())

        def check_pinned_packages(self):
            """Return per-package install status for all pinned specs."""
            return json.dumps(check_pinned_packages())

        def open_url(self, url):
            """Open an arbitrary URL in the system browser."""
            try:
                webbrowser.open(url)
            except Exception:
                pass

        def apply_api_key(self, key):
            """Auto-fill a Comfy.org API key into the ComfyUI settings dialog via JS injection."""
            key = (key or "").strip()
            if not key:
                return
            try:
                self.write_clipboard(key)
            except Exception:
                pass
            key_js = json.dumps(key)
            auto_js = (
                "(function(){"
                "  try {"
                "    var iframe = document.getElementById('ui-frame');"
                "    var doc = iframe && iframe.contentDocument;"
                "    var win = iframe && iframe.contentWindow;"
                "    if (!doc || !win) return 'no-doc';"
                "    var KEY = " + key_js + ";"
                "    var clicked = false;"
                "    var cands = doc.querySelectorAll('button, [role=\"button\"], a');"
                "    for (var i = 0; i < cands.length; i++) {"
                "      var txt = (cands[i].textContent || '').trim();"
                "      if (txt === 'Comfy API Key' || txt.indexOf('Comfy API Key') !== -1) {"
                "        cands[i].click(); clicked = true; break;"
                "      }"
                "    }"
                "    function clickUseApiKey(){"
                "      var bs = doc.querySelectorAll('button');"
                "      for (var j = 0; j < bs.length; j++) {"
                "        var t = (bs[j].textContent || '').trim();"
                "        if (/API Key/i.test(t) && !/Comfy API Key/i.test(t)) { bs[j].click(); return true; }"
                "      }"
                "      return false;"
                "    }"
                "    function submitForm(input){"
                "      var form = input.closest('form');"
                "      if (!form) return false;"
                "      try { if (typeof form.requestSubmit === 'function') { form.requestSubmit(); return true; } } catch(e){}"
                "      var btn = form.querySelector('button[type=\"submit\"]');"
                "      try { form.dispatchEvent(new win.Event('submit', {bubbles: true, cancelable: true})); } catch(e){}"
                "      if (btn && !btn.disabled) { btn.click(); return true; }"
                "      return false;"
                "    }"
                "    var tries = 0;"
                "    function fill(){"
                "      tries++;"
                "      var input = doc.getElementById('comfy-org-api-key');"
                "      if (!input) {"
                "        if (tries === 5) { clickUseApiKey(); }"
                "        if (tries < 80) { setTimeout(fill, 100); return; }"
                "        return;"
                "      }"
                "      var nativeInput = win.Object.getOwnPropertyDescriptor(win.HTMLInputElement.prototype, 'value');"
                "      nativeInput.set.call(input, KEY);"
                "      input.dispatchEvent(new win.Event('input',  {bubbles: true}));"
                "      input.dispatchEvent(new win.Event('change', {bubbles: true}));"
                "      setTimeout(function(){ submitForm(input); }, 120);"
                "    }"
                "    fill();"
                "  } catch(e) { return String(e); }"
                "})();"
            )
            try:
                window = self._window
                if window:
                    window.evaluate_js(auto_js)
            except Exception:
                pass

        def get_runtime_stats(self):
            """Return RAM usage of the ComfyUI server process and system RAM."""
            if COMFYUI_REMOTE:
                try:
                    url = f"{comfyui_url()}/system_stats"
                    req = urllib.request.Request(url, headers={"User-Agent": "EZiDesktop"})
                    with urllib.request.urlopen(req, timeout=5) as resp:
                        raw = json.loads(resp.read().decode())
                    sys_raw = raw.get("system", {})
                    devices  = raw.get("devices", [])
                    stats = {}
                    ram_total = sys_raw.get("ram_total", 0)
                    ram_free  = sys_raw.get("ram_free",  0)
                    if ram_total:
                        stats["ram_total_gb"] = round(ram_total / 1e9, 1)
                    if ram_free and ram_total:
                        stats["ram_avail_gb"] = round(ram_free / 1e9, 1)
                    if devices:
                        dev = devices[0]
                        vram_total = dev.get("vram_total", 0)
                        vram_free  = dev.get("vram_free",  0)
                        if vram_total:
                            stats["vram_total_mb"] = round(vram_total / 1024 / 1024)
                            stats["vram_used_mb"]  = round((vram_total - vram_free) / 1024 / 1024)
                    return json.dumps(stats)
                except Exception:
                    return json.dumps({})
            stats = {}
            pid_file = os.path.join(SCRIPT_DIR, ".comfyui_server.pid")
            try:
                import resource
                # System RAM via /proc or sysctl
                if sys.platform == "darwin":
                    r = subprocess.run(["sysctl", "-n", "hw.memsize"],
                                       capture_output=True, text=True, timeout=3)
                    total_bytes = int(r.stdout.strip())
                    stats["ram_total_gb"] = round(total_bytes / 1e9, 1)
                elif os.path.isfile("/proc/meminfo"):
                    with open("/proc/meminfo") as f:
                        for line in f:
                            if line.startswith("MemTotal:"):
                                stats["ram_total_gb"] = round(int(line.split()[1]) / 1e6, 1)
                            elif line.startswith("MemAvailable:"):
                                stats["ram_avail_gb"] = round(int(line.split()[1]) / 1e6, 1)
            except Exception:
                pass
            # ComfyUI process RSS
            try:
                if os.path.isfile(pid_file):
                    with open(pid_file) as f:
                        pid = int(f.read().strip())
                    if sys.platform == "darwin":
                        r = subprocess.run(["ps", "-o", "rss=", "-p", str(pid)],
                                           capture_output=True, text=True, timeout=3)
                        rss_kb = int(r.stdout.strip())
                        stats["process_ram_mb"] = round(rss_kb / 1024, 0)
                    elif os.path.isfile(f"/proc/{pid}/status"):
                        with open(f"/proc/{pid}/status") as f2:
                            for line in f2:
                                if line.startswith("VmRSS:"):
                                    stats["process_ram_mb"] = round(int(line.split()[1]) / 1024, 0)
            except Exception:
                pass
            # GPU VRAM
            try:
                import torch
                if sys.platform == "darwin" and torch.backends.mps.is_available():
                    stats["vram_used_mb"] = round(torch.mps.current_allocated_memory() / 1e6, 0)
                elif torch.cuda.is_available():
                    stats["vram_used_mb"]  = round(torch.cuda.memory_allocated(0) / 1e6, 0)
                    stats["vram_total_mb"] = round(torch.cuda.get_device_properties(0).total_memory / 1e6, 0)
            except Exception:
                pass
            return json.dumps(stats)

        def get_queue(self):
            """Return ComfyUI queue depth via its REST API."""
            try:
                import urllib.request as ur
                with ur.urlopen(f"http://{COMFYUI_HOST}:{COMFYUI_PORT}/queue", timeout=2) as r:
                    data = json.loads(r.read())
                running = len(data.get("queue_running", []))
                pending = len(data.get("queue_pending", []))
                return json.dumps({"running": running, "pending": pending})
            except Exception:
                return json.dumps({"error": "unavailable"})

        def set_always_on_top(self, on_top):
            """Toggle always-on-top for the window."""
            try:
                window.on_top = bool(on_top)
            except Exception:
                pass

        def set_zoom(self, level):
            """Set webview zoom level. level: float, e.g. 1.0 = 100%"""
            try:
                window.evaluate_js(
                    f"document.body.style.zoom='{float(level)}';"
                    f"localStorage.setItem('_comfy_zoom','{float(level)}');"
                )
            except Exception:
                pass

        def get_launch_args(self):
            """Return saved extra launch args from window state file."""
            state = load_window_state()
            return json.dumps({"args": state.get("launch_args", "")})

        def save_launch_args(self, args):
            """Persist extra launch args (e.g. --lowvram) to window state file."""
            try:
                state = load_window_state()
                state["launch_args"] = args.strip()
                with open(WINDOW_STATE_FILE, "w") as f:
                    json.dump(state, f)
                # Refresh scheme if TLS flags were added/removed
                if "--tls-keyfile" in args and "--tls-certfile" in args:
                    _COMFY_SCHEME[0] = "https"
                else:
                    _COMFY_SCHEME[0] = "http"
                return json.dumps({"ok": True})
            except Exception as e:
                return json.dumps({"error": str(e)})

        def open_folder(self, target="comfyui"):
            """Open a folder in Finder/Files. target: 'comfyui'|'output'|'input'|'models'"""
            paths = {
                "comfyui": os.path.join(SCRIPT_DIR, "ComfyUI"),
                "output":  os.path.join(SCRIPT_DIR, "ComfyUI", "output"),
                "input":   os.path.join(SCRIPT_DIR, "ComfyUI", "input"),
                "models":  os.path.join(SCRIPT_DIR, "ComfyUI", "models"),
            }
            path = paths.get(target, paths["comfyui"])
            os.makedirs(path, exist_ok=True)
            try:
                if sys.platform == "darwin":
                    subprocess.Popen(["open", path])
                else:
                    subprocess.Popen(["xdg-open", path])
            except Exception:
                pass

        def open_sub_folder(self, folder_type):
            """Open a ComfyUI sub-folder. folder_type: 'workflows'|'input'|'models'"""
            user_dir = os.path.join(SCRIPT_DIR, "ComfyUI", "user", "default")
            paths = {
                "workflows": os.path.join(user_dir, "workflows"),
                "input":     os.path.join(SCRIPT_DIR, "ComfyUI", "input"),
                "models":    os.path.join(SCRIPT_DIR, "ComfyUI", "models"),
            }
            path = paths.get(folder_type)
            if not path:
                return
            os.makedirs(path, exist_ok=True)
            try:
                if sys.platform == "darwin":
                    subprocess.Popen(["open", path])
                else:
                    subprocess.Popen(["xdg-open", path])
            except Exception:
                pass

        def restart_server(self):
            """Kill the ComfyUI server process — port_monitor will reload the webview when it comes back."""
            if COMFYUI_REMOTE:
                return json.dumps({"error": "Restart not available in remote mode"})
            pid_file = os.path.join(SCRIPT_DIR, ".comfyui_server.pid")
            if not os.path.isfile(pid_file):
                return json.dumps({"error": "No PID file found"})
            try:
                with open(pid_file) as f:
                    pid = int(f.read().strip())
                os.kill(pid, signal.SIGTERM)
                return json.dumps({"ok": True, "pid": pid})
            except Exception as e:
                return json.dumps({"error": str(e)})

        def retry(self, cols=0):
            """Restart ComfyUI with optional custom TQDM column width."""
            if COMFYUI_REMOTE:
                return json.dumps({"error": "Restart not available in remote mode"})
            try:
                if cols and int(cols) > 0:
                    os.environ['TQDM_NCOLS'] = str(max(40, int(cols)))
            except Exception:
                pass
            self.restart_server()
            return json.dumps({"ok": True})

        def switch_version(self, tag):
            """Git checkout a specific ComfyUI tag then restart the server."""
            comfy_dir = os.path.join(SCRIPT_DIR, "ComfyUI")
            if not tag or not os.path.isdir(os.path.join(comfy_dir, ".git")):
                return json.dumps({"error": "Invalid tag or not a git repo"})
            def _do_switch():
                try:
                    self.restart_server()
                    import time as _time
                    _time.sleep(1)
                    subprocess.run(["git", "fetch", "--tags", "--quiet"],
                                   cwd=comfy_dir, capture_output=True, timeout=30)
                    subprocess.run(["git", "checkout", f"tags/{tag}"],
                                   cwd=comfy_dir, capture_output=True, timeout=15)
                except Exception:
                    pass
            threading.Thread(target=_do_switch, daemon=True).start()
            return json.dumps({"ok": True, "tag": tag})

        def list_torch_packs(self):
            """Return metadata for every .sh file in Add-Ons/Torch-Pack/."""
            tp_dir = os.path.join(SCRIPT_DIR, "Add-Ons", "Torch-Pack")
            if not os.path.isdir(tp_dir):
                return json.dumps([])
            results = []
            for fname in sorted(os.listdir(tp_dir)):
                if not fname.endswith(".sh"):
                    continue
                is_mac  = "-mac" in fname.lower()
                is_cuda = any(x in fname for x in ("cu118", "cu121", "cu124", "cu126", "cu128", "cu130"))
                # derive a pretty display name
                stem = fname.replace(".sh", "")
                name = stem.replace("-mac", " (macOS)").replace("+", " ").replace("-", " ")
                results.append({
                    "filename": fname,
                    "name":     name,
                    "mac":      is_mac,
                    "cuda":     is_cuda,
                })
            return json.dumps(results)

        def run_torch_pack(self, filename):
            """Launch a Torch-Pack installer script and stream its output."""
            import re as _re
            # Safety: filename must be a plain basename ending in .sh, no path separators
            if not filename or not filename.endswith(".sh") or os.sep in filename or "/" in filename:
                return json.dumps({"error": "Invalid filename"})
            tp_dir  = os.path.join(SCRIPT_DIR, "Add-Ons", "Torch-Pack")
            script  = os.path.join(tp_dir, filename)
            if not os.path.isfile(script):
                return json.dumps({"error": "Script not found"})
            # Kill any previous install still running
            if getattr(self, "_tp_proc", None) and self._tp_proc.poll() is None:
                try:
                    self._tp_proc.terminate()
                except Exception:
                    pass
            self._tp_buf  = []
            self._tp_done = False
            _ANSI = _re.compile(r"\x1b\[[0-9;]*[mGKHF]")
            def _reader(proc):
                try:
                    for line in proc.stdout:
                        self._tp_buf.append(_ANSI.sub("", line.rstrip("\n")))
                except Exception:
                    pass
                finally:
                    proc.wait()
                    self._tp_done = True
            try:
                proc = subprocess.Popen(
                    ["bash", script],
                    cwd=tp_dir,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    bufsize=1,
                )
                self._tp_proc = proc
                threading.Thread(target=_reader, args=(proc,), daemon=True).start()
                return json.dumps({"ok": True})
            except Exception as e:
                return json.dumps({"error": str(e)})

        def get_torch_pack_log(self):
            """Return accumulated installer output lines and done flag."""
            lines = list(getattr(self, "_tp_buf", []))
            done  = bool(getattr(self, "_tp_done", True))
            return json.dumps({"lines": lines, "done": done})

        def cancel_torch_pack(self):
            """Kill the running Torch-Pack installer."""
            proc = getattr(self, "_tp_proc", None)
            if proc and proc.poll() is None:
                try:
                    proc.terminate()
                except Exception:
                    pass
            self._tp_done = True
            return json.dumps({"ok": True})

        def get_server_log(self, lines=200):
            """Return the last N lines of the ComfyUI server log."""
            try:
                if not os.path.isfile(SERVER_LOG_FILE):
                    return json.dumps({"lines": []})
                with open(SERVER_LOG_FILE, "r", encoding="utf-8", errors="replace") as f:
                    all_lines = f.read().splitlines()
                # Strip ANSI escape codes and keep last N lines
                import re as _re
                ansi = _re.compile(r"\x1b\[[0-9;]*[mGKHF]")
                out = [ansi.sub("", ln).rstrip() for ln in all_lines[-int(lines):]]
                return json.dumps({"lines": out})
            except Exception as e:
                return json.dumps({"error": str(e), "lines": []})

        def save_server_log(self):
            """Copy the current server log to a user-selected location."""
            if not os.path.isfile(SERVER_LOG_FILE):
                self._toast('No server log available')
                return json.dumps({"error": "no log"})
            threading.Thread(target=self._do_save_log, daemon=True).start()
            return json.dumps({"ok": True})

        def _do_save_log(self):
            from datetime import datetime
            default = f"ComfyUI-server-log-{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
            save_path = self._native_save_dialog(default)
            if not save_path:
                self._toast('Save cancelled')
                return
            try:
                import shutil
                shutil.copy2(SERVER_LOG_FILE, save_path)
                self._toast(f'Saved: {os.path.basename(save_path)}')
            except Exception as e:
                self._toast(f'Save failed: {e}')

        def open_whats_new(self):
            """Open the release notes / changelog in the default browser."""
            try:
                webbrowser.open("https://github.com/Tavris1/ComfyUI-Easy-Install/releases")
            except Exception:
                pass

        def list_addons(self):
            """Return add-on scripts organized by category."""
            try:
                base = os.path.join(SCRIPT_DIR, "Add-Ons")
                def _scripts_in(d):
                    out = []
                    if os.path.isdir(d):
                        for f in sorted(os.listdir(d)):
                            if f.endswith('.sh') and not f.startswith('.'):
                                out.append({"name": os.path.splitext(f)[0], "path": os.path.relpath(os.path.join(d, f), SCRIPT_DIR)})
                    return out
                return json.dumps({
                    "addons": _scripts_in(os.path.join(base)),
                    "torch_packs": _scripts_in(os.path.join(base, "Torch-Pack")),
                    "tools": _scripts_in(os.path.join(base, "Tools")),
                    "fixes": _scripts_in(os.path.join(base, "Fixes")),
                })
            except Exception as e:
                return json.dumps({"error": str(e)})

        def run_addon(self, rel_path):
            """Run an add-on script in a terminal, then restart the desktop."""
            import threading
            def _run():
                try:
                    script = os.path.join(SCRIPT_DIR, rel_path)
                    if not os.path.isfile(script):
                        self._toast('Script not found')
                        return
                    # Build a wrapper: run add-on, then restart desktop launcher
                    wrapper = os.path.join(SCRIPT_DIR, '.run_addon.sh')
                    with open(wrapper, 'w') as f:
                        f.write('#!/bin/bash\n')
                        f.write('cd "' + SCRIPT_DIR + '"\n')
                        f.write('echo "Running ' + os.path.basename(rel_path) + '..."\n')
                        f.write('"' + script + '"\n')
                        f.write('echo "Waiting for server to stop..."\n')
                        f.write('for i in {1..15}; do\n')
                        f.write('    if [ -f .comfyui_server.pid ]; then\n')
                        f.write('        sleep 1\n')
                        f.write('    else\n')
                        f.write('        break\n')
                        f.write('    fi\n')
                        f.write('done\n')
                        f.write('echo "Restarting EZi Desktop..."\n')
                        f.write('sleep 1\n')
                        f.write('"./run_comfyui_desktop.sh"\n')
                    os.chmod(wrapper, 0o755)

                    # Open in a terminal
                    if sys.platform == 'darwin':
                        # macOS: open Terminal.app
                        subprocess.Popen(['open', '-a', 'Terminal', wrapper])
                    elif os.name == 'posix':
                        # Linux: try common terminal emulators
                        for term in ('x-terminal-emulator', 'gnome-terminal', 'konsole', 'xterm'):
                            try:
                                if term == 'gnome-terminal':
                                    subprocess.Popen([term, '--', wrapper])
                                elif term == 'konsole':
                                    subprocess.Popen([term, '-e', wrapper])
                                else:
                                    subprocess.Popen([term, '-e', wrapper])
                                break
                            except FileNotFoundError:
                                continue
                        else:
                            self._toast('No terminal found')
                            return
                    else:
                        # Windows: use cmd (shouldn't reach here on Mac/Linux)
                        subprocess.Popen(['cmd', '/c', 'start', 'cmd', '/k', wrapper])

                    self._toast('Started ' + os.path.basename(rel_path))
                    # Close the desktop window so the terminal can run unblocked
                    try:
                        window.destroy()
                    except Exception:
                        pass
                except Exception as e:
                    self._toast('Failed: ' + str(e))
            threading.Thread(target=_run, daemon=True).start()
            return json.dumps({"ok": True})

        def confirm_close(self):
            """Called from JS confirm-close dialog — destroy the window."""
            self._confirm_close = True
            try:
                window.destroy()
            except Exception:
                pass

        def cancel_close(self):
            """Called from JS confirm-close dialog — dismiss and keep open."""
            self._confirm_close = False

        def set_title(self, suffix: str = ""):
            """Set the window title, optionally with a status suffix."""
            if not self._window:
                return
            try:
                t = f"EZi Desktop  v{EZI_VERSION}"
                self._window.set_title(t + (f" - {suffix}" if suffix else ""))
            except Exception:
                pass

        def ui_shown(self):
            """Called from JS when the ComfyUI UI becomes visible."""
            self._ui_shown = True

        def ezi_storage_save(self, ls_json, settled=0):
            """Called from JS when localStorage is flushed."""
            try:
                save_comfy_storage(json.loads(ls_json or "{}") if isinstance(ls_json, str) else dict(ls_json or {}))
            except Exception:
                _log_error('ezi_storage_save')

        def ezi_comfy_ready(self):
            """Called from JS when the first status WebSocket message arrives."""
            try:
                self._ws_lost.clear()
            except Exception:
                _log_error('ezi_comfy_ready')

        def ezi_ws_lost(self):
            """Called from JS when the ComfyUI WebSocket drops unexpectedly."""
            try:
                self._ws_lost.set()
            except Exception:
                _log_error('ezi_ws_lost')

        def _restore_storage_from_disk(self):
            """Push persisted localStorage back into the webview after ComfyUI loads."""
            state = load_window_state()
            data = state.get("comfy_storage", {})
            if not isinstance(data, dict) or not data:
                return
            js = (
                "(function(){"
                "  try {"
                "    var data = " + json.dumps(data) + ";"
                "    if (data && !sessionStorage.getItem('__ezi_restored')) {"
                "      Object.keys(data).forEach(function(k){"
                "        try { if (localStorage.getItem(k) === null) localStorage.setItem(k, data[k]); } catch(e){}"
                "      });"
                "    }"
                "    sessionStorage.setItem('__ezi_restored', '1');"
                "  } catch(e) {}"
                "})();"
            )
            try:
                window.evaluate_js(js)
            except Exception:
                _log_error('_restore_storage_from_disk')

        def _graceful_close(self):
            """Flush storage to disk then destroy the window."""
            self._flush_state_to_disk()
            try:
                window.destroy()
            except Exception:
                pass

        def _flush_state_to_disk(self):
            """Backup ComfyUI localStorage with draft-filtering and 2 MB cap.

            Only localStorage is persisted; sessionStorage is intentionally ignored
            to match the Windows v3.18+ behavior.
            """
            try:
                result = window.evaluate_js("""
                    (function() {
                        try {
                            var out = {};
                            try {
                                var ls = window.localStorage;
                                for (var i = 0; i < ls.length; i++) {
                                    var k = ls.key(i);
                                    if (k) out[k] = ls.getItem(k);
                                }
                            } catch(e) {}
                            return JSON.stringify(out);
                        } catch(e) { return null; }
                    })();
                """)
                if result:
                    save_comfy_storage(json.loads(result))
            except Exception:
                _log_error('_flush_state_to_disk')

        def _toast(self, msg):
            """Show a toast message in the webview."""
            safe = msg.replace("'", "\\'")
            try:
                window.evaluate_js(
                    f"(function(){{var t=document.getElementById('_comfy_toast');"
                    f"if(t){{t.textContent='{safe}';t.classList.add('show');"
                    f"setTimeout(function(){{t.classList.remove('show')}},3000)}}}})();"
                )
            except Exception:
                pass

    api = Api()
    api._window = None
    api._confirm_close = False
    api._ui_shown = False
    api._ws_lost = threading.Event()

    # Restore saved geometry (falls back to defaults if no state saved)
    _state = load_window_state()
    _win_w = _state.get("width",  WINDOW_WIDTH)
    _win_h = _state.get("height", WINDOW_HEIGHT)
    _win_x = _state.get("x")
    _win_y = _state.get("y")

    # Show window IMMEDIATELY with loading splash — no waiting
    _create_kwargs = dict(
        title=WINDOW_TITLE,
        html=LOADING_HTML,
        width=_win_w,
        height=_win_h,
        resizable=True,
        zoomable=True,
        min_size=(800, 600),
        js_api=api,
    )
    if _win_x is not None and _win_y is not None:
        _create_kwargs["x"] = _win_x
        _create_kwargs["y"] = _win_y
    window = webview.create_window(**_create_kwargs)

    def poll_and_navigate():
        """Background: poll server, then navigate once ready."""
        timeout = 10 if COMFYUI_REMOTE else 120
        if wait_for_server(COMFYUI_HOST, COMFYUI_PORT, timeout=timeout):
            print("ComfyUI server is ready!")
            try:
                window.load_url(comfyui_url())
            except Exception:
                pass
            # After server is up, check for EZi Desktop updates in background
            try:
                api._check_ezi_update()
            except Exception:
                pass
        else:
            # Server unreachable — show error in the splash
            try:
                window.evaluate_js(
                    "document.getElementById('status').textContent="
                    "'Could not reach server. Press Cmd+B to open in browser.';"
                    "document.getElementById('status').style.color='#ff6b6b';"
                )
            except Exception:
                pass

    _navigated = [False]

    def on_loaded():
        """After each page load, inject performance JS (only on ComfyUI page)."""
        if not _navigated[0]:
            # First load is the splash — start background poll
            _navigated[0] = True
            t = threading.Thread(target=poll_and_navigate, daemon=True)
            t.start()
            return
        # Subsequent loads = ComfyUI page — inject JS and restore persisted localStorage
        try:
            window.evaluate_js(f"const EZI_VERSION={repr(EZI_VERSION)};\n" + INJECTED_JS)
        except Exception:
            pass
        try:
            api._restore_storage_from_disk()
        except Exception:
            _log_error('on_loaded/restore_storage')

    def on_closing():
        """Intercept window close — show native confirm dialog if ComfyUI is running.

        IMPORTANT: on_closing runs on the Cocoa main thread on macOS.
        evaluate_js() also needs the main thread (callAfter + semaphore) so
        calling it here deadlocks. Use a native OS dialog on a background
        thread instead, then call window.destroy() if the user confirms.
        """
        if api._confirm_close or COMFYUI_REMOTE:
            return True
        if not is_port_in_use(COMFYUI_PORT):
            return True

        def _ask_and_close():
            confirmed = False
            if sys.platform == "darwin":
                try:
                    r = subprocess.run(
                        [
                            "osascript", "-e",
                            'button returned of (display dialog '
                            '"Stop ComfyUI and close?" '
                            'buttons {"Cancel", "Stop & Close"} '
                            'default button "Stop & Close" '
                            'with title "EZi Desktop" '
                            'with icon caution)',
                        ],
                        capture_output=True, text=True, timeout=60,
                    )
                    confirmed = r.stdout.strip() == "Stop & Close"
                except Exception:
                    confirmed = True
            else:
                try:
                    import tkinter as tk
                    from tkinter import messagebox
                    root = tk.Tk()
                    root.withdraw()
                    confirmed = messagebox.askyesno(
                        "EZi Desktop",
                        "Stop ComfyUI and close?",
                    )
                    root.destroy()
                except Exception:
                    confirmed = True

            if confirmed:
                api._confirm_close = True
                try:
                    window.destroy()
                except Exception:
                    pass

        threading.Thread(target=_ask_and_close, daemon=True).start()
        # Return False to block this close attempt; _ask_and_close will call
        # window.destroy() → on_closing again with _confirm_close=True → True.
        return False

    def on_closed():
        """When the window is closed, save state, backup ComfyUI storage, and signal the server process."""
        api._flush_state_to_disk()
        save_window_state(window)
        if COMFYUI_REMOTE:
            return
        pid_file = os.path.join(SCRIPT_DIR, ".comfyui_server.pid")
        if os.path.isfile(pid_file):
            try:
                with open(pid_file, "r") as f:
                    pid = int(f.read().strip())
                os.kill(pid, signal.SIGTERM)
            except (ValueError, OSError):
                pass

    def _http_alive(port, timeout=5):
        """Return True if ComfyUI responds on /system_stats."""
        try:
            req = urllib.request.Request(
                f"{comfyui_url()}/system_stats",
                headers={"User-Agent": "EZiDesktop"},
            )
            with _comfy_urlopen(req, timeout=timeout) as r:
                return r.status == 200
        except Exception:
            return False

    def port_monitor():
        """Background: detect ComfyUI restart and reload the webview.

        Uses WebSocket-lost signal (Windows v3.19+) for faster detection and
        falls back to HTTP /system_stats probe when reconnecting.
        """
        _was_up = False
        _down_since = 0
        restart_start_time = 0
        _SOCK_DOWN_SECONDS = 12.0
        ws_lost_at = -1e9
        gave_up = False
        while True:
            if api._ws_lost.wait(0.5):
                api._ws_lost.clear()
                ws_lost_at = time.monotonic()
            if COMFYUI_REMOTE:
                break
            up = is_port_in_use(COMFYUI_PORT)
            if up:
                _down_since = 0
                if _was_up:
                    if restart_start_time and not gave_up:
                        print(f"ComfyUI back online after {int(time.time() - restart_start_time)}s.")
                        restart_start_time = 0
                        try:
                            window.load_url(comfyui_url())
                        except Exception:
                            _log_error('port_monitor/reload')
                elif gave_up:
                    gave_up = False
                    _was_up = True
                    print("ComfyUI is back online.")
                    try:
                        window.load_url(comfyui_url())
                    except Exception:
                        _log_error('port_monitor/reload')
                else:
                    _was_up = True
                    print("ComfyUI is ready!")
            else:
                if _was_up and not restart_start_time:
                    ws_dropped = time.monotonic() - ws_lost_at < 10
                    if not _down_since:
                        _down_since = time.monotonic()
                    if ws_dropped or (time.monotonic() - _down_since) >= _SOCK_DOWN_SECONDS:
                        if ws_dropped or not _http_alive(COMFYUI_PORT, timeout=2):
                            _was_up = False
                            _down_since = 0
                            ws_lost_at = -1e9
                            restart_start_time = time.time()
                            gave_up = False
                            print("\nComfyUI is restarting...")
                            api._flush_state_to_disk()
                        else:
                            _down_since = 0
                if restart_start_time and not _was_up:
                    if time.time() - restart_start_time > 300:
                        restart_start_time = 0
                        gave_up = True
                        print("\nRestart timed out. ComfyUI did not come back online.")

    api._window = window  # now safe for Api methods to use

    window.events.closing += on_closing
    window.events.loaded  += on_loaded
    window.events.closed  += on_closed

    threading.Thread(target=port_monitor, daemon=True).start()

    print(f"  Tip: Press Cmd+B (macOS) or Ctrl+B (Linux) to open in browser for file uploads")

    def _open_settings_menu():
        try:
            w = getattr(api, '_window', None)
            if w:
                w.evaluate_js("window._comfyDesktopPanel && window._comfyDesktopPanel();")
        except Exception:
            pass

    # Add a menu bar item so macOS users can open settings even if Cmd+Shift+I is intercepted
    try:
        from webview.menu import Menu, MenuAction
        _menu = [
            Menu("EZi Desktop", [MenuAction("Settings", _open_settings_menu)])
        ]
    except Exception:
        _menu = None

    # Start pywebview — private_mode=False may fix file upload dialogs on macOS
    if _menu:
        webview.start(menu=_menu, icon=icon, private_mode=False, debug=False)
    else:
        webview.start(icon=icon, private_mode=False, debug=False)


def main():
    settings = _load_settings()
    _ensure_ezi_aurora_palette(settings)

    # In local mode, warn if port is already bound (another instance running)
    if not COMFYUI_REMOTE and is_port_in_use(COMFYUI_PORT):
        print(
            f"WARNING: Port {COMFYUI_PORT} is already in use. "
            "Another ComfyUI instance may already be running. "
            "Connecting to it instead of starting a new server."
        )

    # Enforce pinned packages before starting
    enforce_pinned_packages()

    # Check for display server
    has_display = (
        sys.platform == "darwin"
        or os.environ.get("DISPLAY")
        or os.environ.get("WAYLAND_DISPLAY")
    )

    if has_display:
        # Window opens instantly — server polling happens in background
        print(f"Launching EZi Desktop → {comfyui_url()}")
        open_in_webview()
    else:
        # Headless: must wait for server before opening browser
        timeout = 10 if COMFYUI_REMOTE else 120
        print(f"Waiting for ComfyUI server at {comfyui_url()}...")
        if not wait_for_server(COMFYUI_HOST, COMFYUI_PORT, timeout=timeout):
            print(f"ERROR: Cannot reach ComfyUI at {comfyui_url()}")
            sys.exit(1)
        open_in_browser()


if __name__ == "__main__":
    main()
