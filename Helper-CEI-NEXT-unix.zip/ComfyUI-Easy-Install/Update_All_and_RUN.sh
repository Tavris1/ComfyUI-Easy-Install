#!/bin/bash

cd "$(dirname "$0")"

# Set colors (re-define for standalone execution if needed, or assume sourced)
WARNING='\033[33m'
RED='\033[91m'
GREEN='\033[92m'
YELLOW='\033[93m'
BOLD='\033[1m'
RESET='\033[0m'

# Set arguments (re-define for standalone execution if needed, or assume sourced)
UV_ARGS="--link-mode=copy"

# Detect embedded Python
echo -e "${GREEN}🔍 Detecting Python environment...${RESET}"
PYTHON_BIN=""

if [ -f "python_embeded/python" ]; then
    PYTHON_BIN="./python_embeded/python"
    echo -e "${GREEN}   ✓ Found Python (embedded)${RESET}"
elif [ -f "python_embeded/bin/python3" ]; then
    PYTHON_BIN="./python_embeded/bin/python3"
    echo -e "${GREEN}   ✓ Found Python 3 (embedded)${RESET}"
elif [ -f "python_embeded/bin/python" ]; then
    PYTHON_BIN="./python_embeded/bin/python"
    echo -e "${GREEN}   ✓ Found Python (embedded)${RESET}"
fi

if [ -z "$PYTHON_BIN" ]; then
    echo -e "${RED}Error: Embedded Python not found!${RESET}"
    echo -e "${YELLOW}Expected: python_embeded/python${RESET}"
    exit 1
fi

echo -e "${GREEN}🐍 Using: ${YELLOW}${PYTHON_BIN}${RESET}"
echo ""

echo -e "${GREEN}::::::::::::::: Updating ComfyUI :::::::::::::::${RESET}"
echo ""
cd ./update && bash update_comfyui.sh nopause && cd ..
echo ""

# Git pull can land new ComfyUI Python deps (frontend, av, kitchen, ...).
# Do not upgrade torch/torchvision/torchaudio here: this installer pins those
# via Torch-Pack (CUDA on Linux, MPS on Mac).
echo -e "${GREEN}::::::::::::::: Updating ComfyUI Python dependencies :::::::::::::::${RESET}"
echo ""
PYTHON_BIN="$PYTHON_BIN" UV_ARGS="$UV_ARGS" bash ./update/sync_comfyui_python_deps.sh
echo ""

# Erasing ~* folders in the current venv's site-packages
VENV_SITE_PACKAGES=$("$PYTHON_BIN" -c "import site; print(site.getsitepackages()[0])")
if [ -d "$VENV_SITE_PACKAGES" ]; then
    find "$VENV_SITE_PACKAGES" -maxdepth 1 -type d -name '~*' -exec rm -rf {} + 2>/dev/null
fi

echo -e "${GREEN}::::::::::::::: Updating All Nodes :::::::::::::::${RESET}"
echo ""
# Linux filesystems are case-sensitive; macOS usually is not.
# ComfyUI-Manager may be installed as comfyui-manager.
CM_CLI="$(find ComfyUI/custom_nodes -maxdepth 2 -iname 'cm-cli.py' 2>/dev/null | head -n 1)"
if [ -z "$CM_CLI" ]; then
    echo -e "${RED}Error: ComfyUI-Manager cm-cli.py not found under ComfyUI/custom_nodes.${RESET}"
    exit 1
fi
echo -e "${GREEN}   ✓ Manager CLI: ${YELLOW}${CM_CLI}${RESET}"
"$PYTHON_BIN" "$CM_CLI" update all
echo ""

# Restoring Numpy 1.26.4
echo -e "${GREEN}::::::::::::::: Restoring${YELLOW} Numpy 1.26.4 ${GREEN}:::::::::::::::${RESET}"
echo ""
"$PYTHON_BIN" -m uv pip install --force-reinstall numpy==1.26.4 --no-deps $UV_ARGS
echo ""

echo -e "${GREEN}::::::::::::::: Done. Starting ComfyUI :::::::::::::::${RESET}"
echo ""

# run_nvidia_gpu.sh is Linux/NVIDIA. On macOS use the matching Mac launcher.
if [ "$(uname -s)" = "Darwin" ]; then
    if [ "$(uname -m)" = "arm64" ] && [ -f "run_mac_mps.sh" ]; then
        bash run_mac_mps.sh
    elif [ -f "run_mac_intel.sh" ]; then
        bash run_mac_intel.sh
    else
        bash run_mac_mps.sh
    fi
else
    bash run_nvidia_gpu.sh
fi
