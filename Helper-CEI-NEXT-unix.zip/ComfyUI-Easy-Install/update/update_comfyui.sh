#!/bin/bash

cd "$(dirname "$0")"

# Locate embedded Python
PYTHON=""
if [ -f "../python_embeded/python" ]; then
  PYTHON="../python_embeded/python"
elif [ -f "../python_embeded/bin/python3" ]; then
  PYTHON="../python_embeded/bin/python3"
elif [ -f "../python_embeded/bin/python" ]; then
  PYTHON="../python_embeded/bin/python"
else
  echo "ERROR: Embedded Python not found!"
  exit 1
fi

"$PYTHON" update.py ../ComfyUI/

if [ -f "update_new.py" ]; then
  mv -f update_new.py update.py
  echo "Running updater again since it got updated."
  "$PYTHON" update.py ../ComfyUI/ --skip_self_update
fi

if [ -z "$1" ]; then
  read -p "Press any key to continue..."
fi
