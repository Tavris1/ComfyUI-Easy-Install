#!/bin/bash
# Sync ComfyUI/requirements.txt without replacing the Torch-Pack stack.
#
# Must be run from the ComfyUI-Easy-Install root.
# Uses PYTHON_BIN and UV_ARGS from the caller.

set -e

if [ -z "${PYTHON_BIN:-}" ]; then
    echo "ERROR: PYTHON_BIN is not set" >&2
    exit 1
fi

UV_ARGS="${UV_ARGS:---link-mode=copy}"

if [ ! -f "ComfyUI/requirements.txt" ]; then
    echo "ERROR: ComfyUI/requirements.txt not found" >&2
    exit 1
fi

REQ_NO_TORCH="$(mktemp)"
CONSTRAINTS="$(mktemp)"
cleanup_tmp() {
    rm -f "$REQ_NO_TORCH" "$CONSTRAINTS"
}
trap cleanup_tmp EXIT

# Keep torch / vision / audio on whatever Torch-Pack installed.
# torchsde is a separate package and must stay in the requirements file.
grep -Ev '^(torch|torchvision|torchaudio)([<>=!~]|[[:space:]]|$)' \
    ComfyUI/requirements.txt > "$REQ_NO_TORCH"

"$PYTHON_BIN" - "$CONSTRAINTS" <<'PY'
import importlib.metadata as metadata
import sys

path = sys.argv[1]
# Pin the CUDA/MPS stack so other packages cannot pull a new torch.
packages = (
    "torch",
    "torchvision",
    "torchaudio",
    "triton",
    "nvidia-cublas",
    "nvidia-cudnn-cu13",
    "nvidia-nccl-cu13",
    "nvidia-cusparselt-cu13",
    "nvidia-nvjitlink",
    "cuda-toolkit",
    "cuda-pathfinder",
)
with open(path, "w", encoding="utf-8") as handle:
    for name in packages:
        try:
            handle.write(f"{name}=={metadata.version(name)}\n")
        except metadata.PackageNotFoundError:
            pass
PY

echo "Keeping this torch stack pinned:"
sed 's/^/  /' "$CONSTRAINTS"
echo ""

# No --upgrade: == pins still apply, ranges do not jump to latest
# (that is what upgraded torch via kornia/torchsde, and transformers 4 -> 5).
"$PYTHON_BIN" -m uv pip install \
    -r "$REQ_NO_TORCH" \
    -c "$CONSTRAINTS" \
    $UV_ARGS

# ComfyUI currently imports ColorPrimaries, which is not in av 16.0.x,
# even though requirements.txt only says av>=16.0.0.
if ! "$PYTHON_BIN" -c "from av.video.reformatter import ColorPrimaries" >/dev/null 2>&1; then
    echo ""
    echo "Upgrading PyAV only (ColorPrimaries is missing from the installed av)."
    "$PYTHON_BIN" -m uv pip install --upgrade "av>=16.1.0" -c "$CONSTRAINTS" $UV_ARGS
fi
