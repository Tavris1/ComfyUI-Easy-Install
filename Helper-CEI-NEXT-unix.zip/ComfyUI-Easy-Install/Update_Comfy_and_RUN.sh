#!/bin/bash

cd "$(dirname "$0")"

# Set colors (re-define for standalone execution if needed, or assume sourced)
RED='\033[91m'
GREEN='\033[92m'
YELLOW='\033[93m'
RESET='\033[0m'

# Prevent git credential prompts during unattended ComfyUI update
export GIT_TERMINAL_PROMPT=0
export GIT_ASKPASS=echo
export GCM_INTERACTIVE=never

# Detect embedded Python
echo -e "${GREEN}🔍 Detecting Python environment...${RESET}"
PYTHON_BIN=""

if [ -f "python_embeded/python" ]; then
    PYTHON_BIN="./python_embeded/python"
    echo -e "${GREEN}   ✓ Found Python (embedded)${RESET}"
elif [ -f "python_embeded/bin/python3" ]; then
    PYTHON_BIN="./python_embeded/bin/python3"
    echo -e "${GREEN}   ✓ Found Python 3 (embedded)${RESET}"
elif [ -f "python_embeded/bin/python" ]; then
    PYTHON_BIN="./python_embeded/bin/python"
    echo -e "${GREEN}   ✓ Found Python (embedded)${RESET}"
fi

if [ -z "$PYTHON_BIN" ]; then
    echo -e "${RED}Error: Embedded Python not found!${RESET}"
    echo -e "${YELLOW}Expected: python_embeded/python${RESET}"
    exit 1
fi

echo -e "${GREEN}🐍 Using: ${YELLOW}${PYTHON_BIN}${RESET}"
echo ""

echo -e "${GREEN}::::::::::::::: Updating ComfyUI :::::::::::::::${RESET}"
echo ""
cd ./update && bash update_comfyui.sh nopause && cd ..
echo ""

# Reinstall ComfyUI requirements (torch/torchvision/torchaudio filtered to keep the pinned build)
if [ -f "ComfyUI/requirements.txt" ]; then
    echo -e "${GREEN}::::::::::::::: Installing ComfyUI requirements :::::::::::::::${RESET}"
    echo ""
    REQ_FILTERED="$(mktemp "${TMPDIR:-/tmp}/comfyui_req.XXXXXX")"
    grep -viE "^(torch|torchvision|torchaudio)([<>=!~]|$)" ComfyUI/requirements.txt > "$REQ_FILTERED" || true
    if [ -s "$REQ_FILTERED" ]; then
        "$PYTHON_BIN" -m uv pip install --python "$PYTHON_BIN" -r "$REQ_FILTERED" --link-mode=copy \
            || echo -e "${YELLOW}Warning: some ComfyUI requirements could not be installed.${RESET}"
    fi
    rm -f "$REQ_FILTERED"
    echo ""
fi

echo -e "${GREEN}::::::::::::::: Done. Starting ComfyUI :::::::::::::::${RESET}"
echo ""
# Repair a half-installed av (dist-info without RECORD) and reinstall av==18.0.0
VENV_SITE_PACKAGES=$("$PYTHON_BIN" -c "import site; print(site.getsitepackages()[0])")
for av_dist in "$VENV_SITE_PACKAGES"/av-*.dist-info; do
    if [ -d "$av_dist" ] && [ ! -f "$av_dist/RECORD" ]; then
        echo -e "${YELLOW}Repairing a half-installed av...${RESET}"
        rm -rf "$VENV_SITE_PACKAGES"/av "$VENV_SITE_PACKAGES"/av.libs "$av_dist" 2>/dev/null || true
    fi
done
"$PYTHON_BIN" -m uv pip install av==18.0.0 --no-deps --no-warn-script-location \
    || echo -e "${RED}Could not install av 18.0.0. Close every ComfyUI window and run this update again.${RESET}"
echo ""

# Patch rgthree-comfy: disable recursive execution to avoid workflow loops
if [ -d "ComfyUI/custom_nodes/rgthree-comfy" ]; then
    mkdir -p ComfyUI/custom_nodes/rgthree-comfy
    echo '{"patch_recursive_execution": false}' > ComfyUI/custom_nodes/rgthree-comfy/rgthree_config.json
fi

bash run_nvidia_gpu.sh
