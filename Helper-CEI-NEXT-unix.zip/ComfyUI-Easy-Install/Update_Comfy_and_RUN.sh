#!/bin/bash

cd "$(dirname "$0")"

# Set colors (re-define for standalone execution if needed, or assume sourced)
RED='\033[91m'
GREEN='\033[92m'
YELLOW='\033[93m'
RESET='\033[0m'

# Detect and activate Python environment
echo -e "${GREEN}🔍 Detecting Python environment...${RESET}"
if [ -d "python_embeded_3.12/bin" ]; then
    PYTHON_PATH="python_embeded_3.12/bin"
    echo -e "${GREEN}   ✓ Found Python 3.12${RESET}"
elif [ -d "python_embeded_3.11/bin" ]; then
    PYTHON_PATH="python_embeded_3.11/bin"
    echo -e "${GREEN}   ✓ Found Python 3.11${RESET}"
elif [ -d "python_embeded/bin" ]; then
    PYTHON_PATH="python_embeded/bin"
    echo -e "${GREEN}   ✓ Found Python (embedded)${RESET}"
else
    echo -e "${YELLOW}   ⚠ No embedded Python found, checking system Python${RESET}"
    PYTHON_PATH=""
fi

# Activate virtual environment if found
if [ -n "$PYTHON_PATH" ]; then
    echo -e "${GREEN}🐍 Activating Python environment...${RESET}"
    source "$PYTHON_PATH/activate" 2>/dev/null && echo -e "${GREEN}   ✓ Environment activated${RESET}" || echo -e "${YELLOW}   ⚠ Using system Python${RESET}"
fi

# Final check for Python availability
if ! command -v python &> /dev/null; then
    echo -e "${RED}Error: Python not found even after attempting venv activation.${RESET}"
    echo -e "Please check your ComfyUI installation."
    exit 1
fi
echo ""

echo -e "${GREEN}::::::::::::::: Updating ComfyUI :::::::::::::::${RESET}"
echo ""
cd ./update && bash update_comfyui.sh nopause && cd ..
echo ""

echo -e "${GREEN}::::::::::::::: Done. Starting ComfyUI :::::::::::::::${RESET}"
echo ""
bash run_nvidia_gpu.sh
