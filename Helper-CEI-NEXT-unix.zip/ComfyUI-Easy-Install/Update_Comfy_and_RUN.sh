#!/bin/bash

cd "$(dirname "$0")"

# Set colors (re-define for standalone execution if needed, or assume sourced)
RED='\033[91m'
GREEN='\033[92m'
YELLOW='\033[93m'
RESET='\033[0m'

# Detect embedded Python
echo -e "${GREEN}🔍 Detecting Python environment...${RESET}"
PYTHON_BIN=""

if [ -f "python_embeded/python" ]; then
    PYTHON_BIN="./python_embeded/python"
    echo -e "${GREEN}   ✓ Found Python (embedded)${RESET}"
elif [ -f "python_embeded/bin/python3" ]; then
    PYTHON_BIN="./python_embeded/bin/python3"
    echo -e "${GREEN}   ✓ Found Python 3 (embedded)${RESET}"
elif [ -f "python_embeded/bin/python" ]; then
    PYTHON_BIN="./python_embeded/bin/python"
    echo -e "${GREEN}   ✓ Found Python (embedded)${RESET}"
fi

if [ -z "$PYTHON_BIN" ]; then
    echo -e "${RED}Error: Embedded Python not found!${RESET}"
    echo -e "${YELLOW}Expected: python_embeded/python${RESET}"
    exit 1
fi

echo -e "${GREEN}🐍 Using: ${YELLOW}${PYTHON_BIN}${RESET}"
echo ""

echo -e "${GREEN}::::::::::::::: Updating ComfyUI :::::::::::::::${RESET}"
echo ""
cd ./update && bash update_comfyui.sh nopause && cd ..
echo ""

echo -e "${GREEN}::::::::::::::: Done. Starting ComfyUI :::::::::::::::${RESET}"
echo ""
bash run_nvidia_gpu.sh
