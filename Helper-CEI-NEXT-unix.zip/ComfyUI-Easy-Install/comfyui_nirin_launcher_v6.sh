#!/usr/bin/env bash

# ============================================================
# ComfyUI Easy Install Launcher
# ============================================================
#
# Refactored launcher for ComfyUI Easy Install
#
# Features:
#
# - Single configuration file
# - Embedded Python detection
# - Attention backend selection
# - VRAM selection / auto-detection
# - Network/listen address configuration
# - Output directory configuration
# - Custom ComfyUI flags
# - Port selection via --port
# - Browser selection
# - Default browser via open (macOS) or xdg-open (Linux)
# - Google Chrome / Brave / Edge / Chromium web app launchers
# - Brave-Origin web app launcher
# - macOS .app bundle detection
# - Browser GPU acceleration disabled for ComfyUI only
# - Browser / ComfyUI linked lifecycle
# - Dedicated browser profiles
# - Optional debug output via --debug
# - ComfyUI update
# - Full node update
#
# Configuration:
#
# .comfy-nirin-config
#
# Main menu:
#
# 1 / Enter  Launch ComfyUI
# 2          Update ComfyUI only
# 3          Update All
# 4          Alter Attention type
# 5          Alter VRAM type
# 6          Alter Output folder
# 7          Alter Custom arguments
# 8          Alter Network/listen address
# 9          Select Browser
# 10         Install App Launcher Shortcut
#
# ============================================================

set -u

# Associative arrays (declare -A) need Bash 4+. macOS /bin/bash is 3.2.
if ((BASH_VERSINFO[0] < 4)); then
    echo "ERROR: This launcher requires Bash 4 or newer." >&2
    echo "Found: $BASH_VERSION ($BASH)" >&2
    echo "On macOS, install Homebrew bash and rerun this script:" >&2
    echo "  brew install bash" >&2
    echo "The shebang uses /usr/bin/env bash so PATH bash is used." >&2
    exit 1
fi

cd "$(dirname "$0")" || exit 1

# ============================================================
# Colours
# ============================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
BOLD='\033[1m'
RESET='\033[0m'

# ============================================================
# Installation check
# ============================================================

if [ ! -d "ComfyUI" ] || [ ! -d "python_embeded" ]; then

    echo -e "${RED}ERROR: This script must be run from the ComfyUI-Easy-Install directory.${RESET}"
    echo -e "${YELLOW}Please run this script from inside the 'ComfyUI-Easy-Install' folder.${RESET}"
    echo -e "${CYAN}Current directory: $(pwd)${RESET}"
    echo -e "${CYAN}Expected to find: ComfyUI folder and python_embeded folder${RESET}"
    echo ""
    echo -e "${GREEN}Press any key to exit...${RESET}"

    read -n 1 -s

    exit 1

fi

# ============================================================
# Configuration
# ============================================================

CONFIG_FILE=".comfy-nirin-config"

# Runtime defaults.

custom_output_dir=""
LISTEN_ADDRESS="0.0.0.0"

VRAM_MODE="normal"
ATTENTION_MODE="default"
CUSTOM_FLAGS=""

# Browser mode.
#
# Browser-specific definitions are contained entirely in the
# Browser Registry section below.
#
# "default" is reserved for the system default browser.

BROWSER_MODE="default"

# ============================================================
# Runtime variables
# ============================================================

PORT=8188

VRAM_FLAG=""
ATTENTION_FLAG=""

PYTHON_EXEC=""
PYTHON_PATH=""

GPU_NAME=""
GPU_VRAM_MB=""

# Browser runtime variables.

BROWSER_EXEC=""
BROWSER_PID=""
BROWSER_PROFILE=""
BROWSER_DISPLAY_NAME=""

COMFY_PID=""

DEBUG_MODE=0

# Command-line arguments passed through to ComfyUI.

EXTRA_ARGS=()

# ============================================================
# Header
# ============================================================

print_header() {

    clear

    echo -e "${MAGENTA}╔═══════════════════════════════════════════════════════════╗${RESET}"
    echo -e "${MAGENTA}║${CYAN}                                                           ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}        ╔═╗╔═╗╔╦╗╔═╗╦ ╦╦ ╦╦  ${YELLOW}╔═╗╔═╗╔═╗╦ ╦              ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}        ║  ║ ║║║║╠╣ ╚╦╝║ ║║  ${YELLOW}║╣ ╠═╣╚═╗╚╦╝              ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}        ╚═╝╚═╝╩ ╩╚   ╩ ╚═╝╩  ${YELLOW}╚═╝╩ ╩╚═╝ ╩               ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}                                                           ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${GREEN}              🎨 Easy Install by VenimK 🚀                ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}                                                           ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}               🎨 Pixaroma Soldier 🚀                      ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}                                                           ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}               Updated Launcher by Nirin                   ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}                                                           ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}╚═══════════════════════════════════════════════════════════╝${RESET}"
    echo ""

}

# ============================================================
# GPU detection
# ============================================================

detect_gpu() {

    GPU_NAME=""
    GPU_VRAM_MB=""

    if ! command -v nvidia-smi >/dev/null 2>&1; then
        return
    fi

    local gpu_info

    gpu_info=$(
        nvidia-smi \
            --query-gpu=name,memory.total \
            --format=csv,noheader,nounits \
            2>/dev/null |
        head -n 1
    )

    if [ -z "$gpu_info" ]; then
        return
    fi

    GPU_NAME="${gpu_info%,*}"
    GPU_VRAM_MB="${gpu_info##*,}"

    GPU_NAME="${GPU_NAME#"${GPU_NAME%%[![:space:]]*}"}"
    GPU_NAME="${GPU_NAME%"${GPU_NAME##*[![:space:]]}"}"

    GPU_VRAM_MB="${GPU_VRAM_MB//[[:space:]]/}"

}

# ============================================================
# VRAM flag
# ============================================================

get_vram_flag() {

    case "$1" in

        low)
            echo "--lowvram"
            ;;

        high)
            echo "--highvram"
            ;;

        *)
            echo ""
            ;;

    esac

}

# ============================================================
# Attention flag
# ============================================================

get_attention_flag() {

    case "$1" in

        sage)
            echo "--use-sage-attention"
            ;;

        flash)
            echo "--use-flash-attention"
            ;;

        *)
            echo ""
            ;;

    esac

}

# ============================================================
# Browser Registry
# ============================================================
#
# THIS IS THE ONLY SECTION THAT SHOULD NEED CHANGING WHEN
# ADDING ANOTHER BROWSER.
#
# Each browser is defined by:
#
#   BROWSER_DISPLAY[name]
#       Name shown to the user.
#
#   BROWSER_COMMANDS[name]
#       Executable candidates, separated by "|".
#       Candidates may be:
#         - absolute paths to binaries
#         - commands in PATH
#         - macOS .app paths
#         - macOS application names (e.g. "Google Chrome")
#       They are tried from left to right.
#
#   BROWSER_PROFILES[name]
#       Directory used for the dedicated browser profile.
#
#   BROWSER_MENU_DESCRIPTION[name]
#       Description shown in the browser selection menu.
#
# "default" is handled separately and should NOT be added here.
#
# ------------------------------------------------------------
# Adding a browser
# ------------------------------------------------------------
#
# For example, to add Chromium:
#
#   BROWSER_DISPLAY["chromium"]="Chromium"
#   BROWSER_COMMANDS["chromium"]="Chromium|chromium|chromium-browser"
#   BROWSER_PROFILES["chromium"]="$PWD/.comfyui_chromium_profile"
#   BROWSER_MENU_DESCRIPTION["chromium"]="Launch ComfyUI as a dedicated Chromium web app"
#
# That's it.
#
# The browser will automatically:
#
# - appear in the browser selection menu
# - be saved to the configuration
# - be detected
# - receive its own profile
# - launch as an app
# - have GPU acceleration disabled
# - participate in the browser/ComfyUI lifecycle
# - appear in the current settings
# - appear in the launch information
#
# ============================================================

declare -a BROWSER_ORDER=()

declare -A BROWSER_DISPLAY
declare -A BROWSER_COMMANDS
declare -A BROWSER_PROFILES
declare -A BROWSER_MENU_DESCRIPTION

# ------------------------------------------------------------
# Google Chrome
# ------------------------------------------------------------

BROWSER_ORDER+=("chrome")

BROWSER_DISPLAY["chrome"]="Google Chrome"

BROWSER_COMMANDS["chrome"]="Google Chrome|google-chrome|google-chrome-stable|google-chrome-beta|chrome"

BROWSER_PROFILES["chrome"]="$PWD/.comfyui_chrome_profile"

BROWSER_MENU_DESCRIPTION["chrome"]="Launch ComfyUI as a dedicated Google Chrome web app"

# ------------------------------------------------------------
# Brave
# ------------------------------------------------------------

BROWSER_ORDER+=("brave")

BROWSER_DISPLAY["brave"]="Brave"

BROWSER_COMMANDS["brave"]="Brave Browser|/opt/brave-origin-bin/brave|brave|brave-browser|brave-browser-stable"

BROWSER_PROFILES["brave"]="$PWD/.comfyui_brave_profile"

BROWSER_MENU_DESCRIPTION["brave"]="Launch ComfyUI as a dedicated Brave web app"

# ------------------------------------------------------------
# Microsoft Edge
# ------------------------------------------------------------

BROWSER_ORDER+=("edge")

BROWSER_DISPLAY["edge"]="Microsoft Edge"

BROWSER_COMMANDS["edge"]="Microsoft Edge|microsoft-edge|microsoft-edge-stable|microsoft-edge-beta|microsoft-edge-dev"

BROWSER_PROFILES["edge"]="$PWD/.comfyui_edge_profile"

BROWSER_MENU_DESCRIPTION["edge"]="Launch ComfyUI as a dedicated Microsoft Edge web app"

# ------------------------------------------------------------
# Chromium
# ------------------------------------------------------------

BROWSER_ORDER+=("chromium")

BROWSER_DISPLAY["chromium"]="Chromium"

BROWSER_COMMANDS["chromium"]="Chromium|chromium|chromium-browser"

BROWSER_PROFILES["chromium"]="$PWD/.comfyui_chromium_profile"

BROWSER_MENU_DESCRIPTION["chromium"]="Launch ComfyUI as a dedicated Chromium web app"

# ------------------------------------------------------------
# Brave-Origin
# ------------------------------------------------------------

BROWSER_ORDER+=("brave-origin")

BROWSER_DISPLAY["brave-origin"]="Brave-Origin"

BROWSER_COMMANDS["brave-origin"]="/opt/brave-origin-bin/brave|brave|brave-browser|Brave Browser"

BROWSER_PROFILES["brave-origin"]="$PWD/.comfyui_brave_origin_profile"

BROWSER_MENU_DESCRIPTION["brave-origin"]="Launch ComfyUI as a dedicated Brave-Origin web app"

# ============================================================
# Browser Registry Functions
# ============================================================

is_macos() {

    [ "$(uname -s)" = Darwin ]

}

browser_is_valid() {

    local mode="$1"

    if [ "$mode" = "default" ]; then
        return 0
    fi

    [[ -n "${BROWSER_DISPLAY[$mode]+x}" ]]

}

browser_is_default() {

    [ "$BROWSER_MODE" = "default" ]

}

browser_get_display_name() {

    local mode="$1"

    if [ "$mode" = "default" ]; then
        echo "Default Browser"
        return
    fi

    if browser_is_valid "$mode"; then
        echo "${BROWSER_DISPLAY[$mode]}"
        return
    fi

    echo "Default Browser"

}

browser_get_profile() {

    local mode="$1"

    if browser_is_valid "$mode" && [ "$mode" != "default" ]; then
        echo "${BROWSER_PROFILES[$mode]}"
    else
        echo ""
    fi

}

# Resolve a single candidate to an executable.
# Accepts binaries, PATH commands, .app bundles, and macOS app names.

resolve_browser_command() {

    local candidate="$1"
    local app_path=""
    local macos_dir=""
    local app_name=""
    local exe=""

    if [ -z "$candidate" ]; then
        return 1
    fi

    if [ -x "$candidate" ] && [ ! -d "$candidate" ]; then
        printf '%s\n' "$candidate"
        return 0
    fi

    if [[ "$candidate" == *.app ]]; then

        if [ -d "$candidate" ]; then
            app_path="$candidate"
        elif [ -d "/Applications/$candidate" ]; then
            app_path="/Applications/$candidate"
        elif [ -d "$HOME/Applications/$candidate" ]; then
            app_path="$HOME/Applications/$candidate"
        fi

    elif is_macos; then

        if [ -d "/Applications/${candidate}.app" ]; then
            app_path="/Applications/${candidate}.app"
        elif [ -d "$HOME/Applications/${candidate}.app" ]; then
            app_path="$HOME/Applications/${candidate}.app"
        fi

    fi

    if [ -n "$app_path" ]; then

        macos_dir="$app_path/Contents/MacOS"
        app_name="$(basename "$app_path" .app)"

        if [ -x "$macos_dir/$app_name" ]; then
            printf '%s\n' "$macos_dir/$app_name"
            return 0
        fi

        for exe in "$macos_dir"/*; do

            if [ -f "$exe" ] && [ -x "$exe" ]; then
                printf '%s\n' "$exe"
                return 0
            fi

        done

    fi

    if command -v "$candidate" >/dev/null 2>&1; then
        command -v "$candidate"
        return 0
    fi

    return 1

}

# Print the first working executable for a registered browser id.

resolve_browser_exec() {

    local mode="$1"
    local command_list
    local browser_command
    local resolved

    if ! browser_is_valid "$mode" || [ "$mode" = "default" ]; then
        return 1
    fi

    command_list="${BROWSER_COMMANDS[$mode]}"

    IFS='|' read -r -a browser_commands_array <<< "$command_list"

    for browser_command in "${browser_commands_array[@]}"; do

        resolved="$(resolve_browser_command "$browser_command" || true)"

        if [ -n "$resolved" ]; then
            printf '%s\n' "$resolved"
            return 0
        fi

    done

    return 1

}

browser_is_detected() {

    local mode="$1"

    resolve_browser_exec "$mode" >/dev/null 2>&1

}

open_default_browser() {

    local url="$1"

    if is_macos; then

        open "$url" >/dev/null 2>&1
        return $?

    fi

    if command -v xdg-open >/dev/null 2>&1; then

        xdg-open "$url" >/dev/null 2>&1 &
        return 0

    fi

    return 1

}

# ============================================================
# Browser detection
# ============================================================

find_browser() {

    BROWSER_EXEC=""
    BROWSER_PROFILE=""
    BROWSER_DISPLAY_NAME=""

    BROWSER_DISPLAY_NAME="$(browser_get_display_name "$BROWSER_MODE")"

    if [ "$BROWSER_MODE" = "default" ]; then
        return
    fi

    if ! browser_is_valid "$BROWSER_MODE"; then

        BROWSER_MODE="default"
        BROWSER_DISPLAY_NAME="Default Browser"

        return

    fi

    BROWSER_PROFILE="${BROWSER_PROFILES[$BROWSER_MODE]}"
    BROWSER_EXEC="$(resolve_browser_exec "$BROWSER_MODE" || true)"

}

# ============================================================
# Configuration file
# ============================================================

create_default_config() {

    cat > "$CONFIG_FILE" <<EOF

# ComfyUI Nirin Launcher Configuration

#

# This file is managed automatically by the launcher.

# Do not add shell commands here.

output_dir=
listen_address=0.0.0.0
vram_mode=normal
attention_mode=default
custom_flags=
browser=default
EOF

}

# ============================================================
# Load configuration
# ============================================================

load_configuration() {

    # Create the configuration file if it does not exist.

    if [ ! -f "$CONFIG_FILE" ]; then
        create_default_config
    fi

    # Reset to safe defaults before reading.

    custom_output_dir=""
    LISTEN_ADDRESS="0.0.0.0"
    VRAM_MODE="normal"
    ATTENTION_MODE="default"
    CUSTOM_FLAGS=""
    BROWSER_MODE="default"

    local line
    local key
    local value

    while IFS= read -r line || [ -n "$line" ]; do

        # Ignore comments.

        case "$line" in
            ""|\#*)
                continue
                ;;
        esac

        key="${line%%=*}"
        value="${line#*=}"

        case "$key" in

            output_dir)
                custom_output_dir="$value"
                ;;

            listen_address)

                if [ -n "$value" ]; then
                    LISTEN_ADDRESS="$value"
                fi

                ;;

            vram_mode)

                case "$value" in
                    low|normal|high)
                        VRAM_MODE="$value"
                        ;;
                esac

                ;;

            attention_mode)

                case "$value" in
                    default|sage|flash)
                        ATTENTION_MODE="$value"
                        ;;
                esac

                ;;

            custom_flags)
                CUSTOM_FLAGS="$value"
                ;;

            browser)

                if browser_is_valid "$value"; then
                    BROWSER_MODE="$value"
                fi

                ;;

        esac

    done < "$CONFIG_FILE"

}

# ============================================================
# Save configuration
# ============================================================

save_configuration() {

    cat > "$CONFIG_FILE" <<EOF

# ComfyUI Nirin Launcher Configuration

#

# This file is managed automatically by the launcher.

# Do not add shell commands here.

output_dir=$custom_output_dir
listen_address=$LISTEN_ADDRESS
vram_mode=$VRAM_MODE
attention_mode=$ATTENTION_MODE
custom_flags=$CUSTOM_FLAGS
browser=$BROWSER_MODE
EOF

}

# ============================================================
# Python detection
# ============================================================

detect_python() {

    echo -e "${CYAN}🔍 Detecting Python environment...${RESET}"

    PYTHON_EXEC=""
    PYTHON_PATH=""

    # Current embedded structure.

    if [ -x "python_embeded/python" ]; then

        PYTHON_EXEC="./python_embeded/python"

        echo -e "${GREEN}   ✓ Found embedded Python${RESET}"
        echo -e "${GREEN}   ✓ Using direct embedded Python${RESET}"

    # Older Python 3.12 structure.

    elif [ -x "python_embeded_3.12/bin/python3" ]; then

        PYTHON_PATH="python_embeded_3.12/bin"
        PYTHON_EXEC="./python_embeded_3.12/bin/python3"

        echo -e "${GREEN}   ✓ Found Python 3.12${RESET}"

    # Older Python 3.11 structure.

    elif [ -x "python_embeded_3.11/bin/python3" ]; then

        PYTHON_PATH="python_embeded_3.11/bin"
        PYTHON_EXEC="./python_embeded_3.11/bin/python3"

        echo -e "${GREEN}   ✓ Found Python 3.11${RESET}"

    # Older embedded structure.

    elif [ -x "python_embeded/bin/python3" ]; then

        PYTHON_PATH="python_embeded/bin"
        PYTHON_EXEC="./python_embeded/bin/python3"

        echo -e "${GREEN}   ✓ Found embedded Python${RESET}"

    # System fallback.

    elif command -v python3 >/dev/null 2>&1; then

        PYTHON_EXEC="python3"

        echo -e "${YELLOW}   ⚠ No embedded Python found${RESET}"
        echo -e "${YELLOW}   ⚠ Falling back to system Python${RESET}"

    else

        echo -e "${RED}   ✗ No Python installation found${RESET}"

        exit 1

    fi

    echo ""

}

# ============================================================
# ComfyUI update
# ============================================================

update_comfyui_only() {

    clear
    print_header

    echo -e "${CYAN}🔄 Updating ComfyUI${RESET}"
    echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo ""

    echo -e "${GREEN}::::::::::::::: Updating ComfyUI :::::::::::::::${RESET}"
    echo ""

    (
        cd ./update &&
        bash update_comfyui.sh nopause
    )

    local update_status=$?

    echo ""

    if [ "$update_status" -eq 0 ]; then

        echo -e "${GREEN}✓ ComfyUI update completed successfully.${RESET}"

    else

        echo -e "${RED}✗ ComfyUI update reported an error.${RESET}"
        echo -e "${YELLOW}The launcher will return to the main menu.${RESET}"

    fi

    echo ""
    echo -e "${CYAN}Returning to main menu...${RESET}"
    sleep 2

    return 0

}

# ============================================================
# Update All
# ============================================================

update_all() {

    clear
    print_header

    echo -e "${CYAN}🔄 Updating ComfyUI and all installed nodes${RESET}"
    echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo ""

    # --------------------------------------------------------
    # Update ComfyUI
    # --------------------------------------------------------

    echo -e "${GREEN}::::::::::::::: Updating ComfyUI :::::::::::::::${RESET}"
    echo ""

    (
        cd ./update &&
        bash update_comfyui.sh nopause
    )

    local comfy_update_status=$?

    echo ""

    if [ "$comfy_update_status" -eq 0 ]; then

        echo -e "${GREEN}✓ ComfyUI update completed.${RESET}"

    else

        echo -e "${RED}✗ ComfyUI update reported an error.${RESET}"
        echo -e "${YELLOW}Continuing with the remaining Update All operations.${RESET}"

    fi

    echo ""

    # --------------------------------------------------------
    # Remove temporary ~* directories
    # --------------------------------------------------------

    echo -e "${GREEN}::::::::::::::: Cleaning temporary package folders :::::::::::::::${RESET}"
    echo ""

    local VENV_SITE_PACKAGES=""

    VENV_SITE_PACKAGES=$(
        "$PYTHON_EXEC" -c \
        "import site; print(site.getsitepackages()[0])" \
        2>/dev/null
    )

    if [ -d "$VENV_SITE_PACKAGES" ]; then

        echo -e "${CYAN}Cleaning:${RESET} ${YELLOW}$VENV_SITE_PACKAGES${RESET}"

        find "$VENV_SITE_PACKAGES" \
            -maxdepth 1 \
            -type d \
            -name '~*' \
            -exec rm -rf {} + \
            2>/dev/null

        echo -e "${GREEN}✓ Temporary package folders cleaned.${RESET}"

    else

        echo -e "${YELLOW}⚠ Could not locate Python site-packages.${RESET}"

    fi

    echo ""

    # --------------------------------------------------------
    # Update all nodes
    # --------------------------------------------------------

    echo -e "${GREEN}::::::::::::::: Updating All Nodes :::::::::::::::${RESET}"
    echo ""

    "$PYTHON_EXEC" \
        ComfyUI/custom_nodes/ComfyUI-Manager/cm-cli.py \
        update all

    local nodes_update_status=$?

    echo ""

    if [ "$nodes_update_status" -eq 0 ]; then

        echo -e "${GREEN}✓ All nodes updated successfully.${RESET}"

    else

        echo -e "${RED}✗ Node update reported an error.${RESET}"

    fi

    echo ""

    # --------------------------------------------------------
    # Restore NumPy 1.26.4
    # --------------------------------------------------------

    echo -e "${GREEN}::::::::::::::: Restoring${YELLOW} Numpy 1.26.4 ${GREEN}:::::::::::::::${RESET}"
    echo ""

    "$PYTHON_EXEC" \
        -m uv pip install \
        --force-reinstall \
        numpy==1.26.4 \
        --no-deps \
        --link-mode=copy

    local numpy_status=$?

    echo ""

    if [ "$numpy_status" -eq 0 ]; then

        echo -e "${GREEN}✓ NumPy 1.26.4 restored.${RESET}"

    else

        echo -e "${RED}✗ NumPy restore reported an error.${RESET}"

    fi

    echo ""
    echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo ""

    if [ "$comfy_update_status" -eq 0 ] &&
       [ "$nodes_update_status" -eq 0 ] &&
       [ "$numpy_status" -eq 0 ]; then

        echo -e "${GREEN}✓ Update All completed successfully.${RESET}"

    else

        echo -e "${YELLOW}⚠ Update All completed with one or more reported errors.${RESET}"
        echo -e "${YELLOW}Review the output above if necessary.${RESET}"

    fi

    echo ""
    echo -e "${CYAN}No application was launched.${RESET}"
    echo -e "${CYAN}Returning to the main menu...${RESET}"

    sleep 3

    return 0

}

# ============================================================
# Browser configuration
# ============================================================

configure_browser() {

    while true; do

        clear
        print_header

        echo -e "${CYAN}🌐 Desktop Web App Setup${RESET}"
        echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
        echo ""

        echo -e "${GREEN}Current:${RESET} ${YELLOW}$(browser_get_display_name "$BROWSER_MODE")${RESET}"

        echo ""
        echo -e "${CYAN}1)${RESET} No Web App - Launch in Default Browser"
        echo -e "   Opens ComfyUI using your normal system default browser"
        echo ""

        local browser_number=2
        local browser_id
        local browser_status

        for browser_id in "${BROWSER_ORDER[@]}"; do

            if browser_is_detected "$browser_id"; then
                browser_status="${GREEN}installed${RESET}"
            else
                browser_status="${YELLOW}not found${RESET}"
            fi

            echo -e "${CYAN}${browser_number})${RESET} ${BROWSER_DISPLAY[$browser_id]}  (${browser_status})"
            echo -e "   ${BROWSER_MENU_DESCRIPTION[$browser_id]}"
            echo ""

            ((browser_number++))

        done

        echo -e "${YELLOW}Press Enter to return to the main menu.${RESET}"
        echo ""

        read -r -p "Choice: " browser_choice

        case "$browser_choice" in

            "")

                return
                ;;

            1)

                BROWSER_MODE="default"

                save_configuration

                echo ""
                echo -e "${GREEN}✓ Web App disabled.${RESET}"
                echo -e "${CYAN}ComfyUI will launch in your default browser.${RESET}"
                sleep 1

                return
                ;;

            *)

                local selected_index=$((browser_choice - 2))

                if [[ "$browser_choice" =~ ^[0-9]+$ ]] &&
                   [ "$selected_index" -ge 0 ] &&
                   [ "$selected_index" -lt "${#BROWSER_ORDER[@]}" ]; then

                    BROWSER_MODE="${BROWSER_ORDER[$selected_index]}"

                    save_configuration

                    echo ""
                    echo -e "${GREEN}✓ $(browser_get_display_name "$BROWSER_MODE") Web App selected.${RESET}"
                    sleep 1

                    return

                fi

                echo ""
                echo -e "${RED}Invalid choice.${RESET}"
                sleep 1
                ;;

        esac

    done

}

# ============================================================
# Display current settings
# ============================================================

display_current_settings() {

    local display_vram
    local display_attention
    local display_output
    local display_custom
    local display_browser

    # ------------------------------
    # Attention
    # ------------------------------

    case "$ATTENTION_MODE" in

        sage)
            display_attention="SageAttention"
            ;;

        flash)
            display_attention="Flash Attention"
            ;;

        *)
            display_attention="Default"
            ;;

    esac

    # ------------------------------
    # VRAM
    # ------------------------------

    case "$VRAM_MODE" in

        low)
            display_vram="Low VRAM (--lowvram)"
            ;;

        high)
            display_vram="High VRAM (--highvram)"
            ;;

        *)
            display_vram="Normal VRAM"
            ;;

    esac

    # ------------------------------
    # Output
    # ------------------------------

    if [ -n "$custom_output_dir" ]; then
        display_output="$custom_output_dir"
    else
        display_output="Default ComfyUI output"
    fi

    # ------------------------------
    # Custom arguments
    # ------------------------------

    if [ -n "$CUSTOM_FLAGS" ]; then
        display_custom="$CUSTOM_FLAGS"
    else
        display_custom="None"
    fi

    # ------------------------------
    # Browser
    # ------------------------------

    display_browser="$(browser_get_display_name "$BROWSER_MODE")"

    if [ "$BROWSER_MODE" = "default" ]; then
        display_browser="No Web App - Default Browser"
    elif browser_is_detected "$BROWSER_MODE"; then
        display_browser="${display_browser} Web App"
    else
        display_browser="${display_browser} Web App (not found — default browser will be used)"
    fi

    echo -e "${CYAN}Current launch settings:${RESET}"
    echo ""

    echo -e "  ${GREEN}Attention:${RESET} ${YELLOW}${display_attention}${RESET}"
    echo -e "  ${GREEN}VRAM:${RESET}      ${YELLOW}${display_vram}${RESET}"
    echo -e "  ${GREEN}Output:${RESET}    ${YELLOW}${display_output}${RESET}"
    echo -e "  ${GREEN}Arguments:${RESET} ${YELLOW}${display_custom}${RESET}"
    echo -e "  ${GREEN}Network:${RESET}   ${YELLOW}${LISTEN_ADDRESS}${RESET}"
    echo -e "  ${GREEN}Browser:${RESET}   ${YELLOW}${display_browser}${RESET}"
    echo ""

}

# ============================================================
# Install / update app shortcut
# ============================================================

install_app_shortcut() {

    clear
    print_header

    echo -e "${CYAN}🚀  App Shortcut Installation${RESET}"
    echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo ""

    local launcher_script
    local launcher_dir
    local launcher_name
    local desktop_dir
    local desktop_file

    launcher_script="${BASH_SOURCE[0]}"

    if command -v realpath >/dev/null 2>&1; then
        launcher_script="$(realpath "$launcher_script")"
    else
        launcher_script="$(cd "$(dirname "$launcher_script")" && pwd)/$(basename "$launcher_script")"
    fi

    launcher_dir="$(dirname "$launcher_script")"
    launcher_name="$(basename "$launcher_script")"

    echo -e "${CYAN}Launcher detected:${RESET}"
    echo -e "  ${YELLOW}$launcher_script${RESET}"
    echo ""

    if chmod +x "$launcher_script"; then
        echo -e "${GREEN}✓ Launcher is executable.${RESET}"
    else
        echo -e "${RED}✗ Could not make launcher executable.${RESET}"
        echo ""
        echo -e "${YELLOW}Press any key to return...${RESET}"
        read -n 1 -s
        return
    fi

    echo ""

    desktop_dir="$HOME/.local/share/applications"
    desktop_file="$desktop_dir/comfyui-nirin-launcher.desktop"

    mkdir -p "$desktop_dir"

    cat > "$desktop_file" <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=ComfyUI Nirin Launcher
Comment=Launch ComfyUI Easy Install
Exec=$launcher_script
Path=$launcher_dir
Terminal=true
StartupNotify=true
Categories=AI;
EOF

    if [ $? -ne 0 ]; then

        echo -e "${RED}✗ Failed to create app shortcut.${RESET}"
        echo ""
        echo -e "${YELLOW}Press any key to return...${RESET}"
        read -n 1 -s
        return

    fi

    chmod +x "$desktop_file"

    if command -v update-desktop-database >/dev/null 2>&1; then
        update-desktop-database "$desktop_dir" >/dev/null 2>&1 || true
    fi

    echo -e "${GREEN}✓ App shortcut installed successfully.${RESET}"
    echo ""
    echo -e "${CYAN}Application:${RESET} ${YELLOW}ComfyUI Nirin Launcher${RESET}"
    echo -e "${CYAN}Script:${RESET}      ${YELLOW}$launcher_script${RESET}"
    echo -e "${CYAN}App shortcut:${RESET} ${YELLOW}$desktop_file${RESET}"
    echo ""
    echo -e "${GREEN}You should now be able to find it in the KDE application menu.${RESET}"
    echo -e "${CYAN}You can also pin it to the taskbar/favourites.${RESET}"
    echo ""

    echo -e "${YELLOW}Press any key to return to the main menu...${RESET}"
    read -n 1 -s

}

# ============================================================
# Main menu
# ============================================================

main_menu() {

    while true; do

        clear
        print_header

        echo -e "${CYAN}🚀 Launch ComfyUI or alter launch settings${RESET}"
        echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
        echo ""

        echo -e "${GREEN}1)${RESET} Launch ComfyUI"
        echo ""

        echo -e "${CYAN}2)${RESET} Update ComfyUI only"
        echo -e "${CYAN}3)${RESET} Update All"
        echo ""

        echo -e "${CYAN}4)${RESET} Alter Attention type"
        echo -e "${CYAN}5)${RESET} Alter VRAM type"
        echo -e "${CYAN}6)${RESET} Alter Output folder"
        echo -e "${CYAN}7)${RESET} Alter Custom arguments"
        echo -e "${CYAN}8)${RESET} Alter Network/listen address"
        echo -e "${CYAN}9)${RESET} Select Browser"
        echo -e "${CYAN}10)${RESET} Install App Launcher Shortcut"
        echo ""

        display_current_settings

        echo -e "${YELLOW}Press Enter to launch, or select an option:${RESET}"

        read -r -p "> " menu_choice

        case "$menu_choice" in

            ""|1)

                return 0
                ;;

            2)

                update_comfyui_only
                ;;

            3)

                update_all
                ;;

            4)

                configure_attention
                ;;

            5)

                configure_vram
                ;;

            6)

                configure_output_directory
                ;;

            7)

                configure_custom_flags
                ;;

            8)

                configure_network
                ;;

            9)

                configure_browser
                ;;

            10)

                install_app_shortcut
                ;;

            *)

                echo ""
                echo -e "${RED}Invalid choice.${RESET}"
                sleep 1
                ;;

        esac

    done

}

# ============================================================
# Attention configuration
# ============================================================

configure_attention() {

    while true; do

        clear
        print_header

        echo -e "${CYAN}⚡ Attention Backend Configuration${RESET}"
        echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
        echo ""

        case "$ATTENTION_MODE" in

            sage)
                echo -e "${GREEN}Current:${RESET} ${YELLOW}SageAttention${RESET}"
                ;;

            flash)
                echo -e "${GREEN}Current:${RESET} ${YELLOW}Flash Attention${RESET}"
                ;;

            *)
                echo -e "${GREEN}Current:${RESET} ${YELLOW}Default Attention${RESET}"
                ;;

        esac

        echo ""
        echo -e "${CYAN}1)${RESET} Default attention"
        echo -e "   No additional flag"
        echo ""

        echo -e "${CYAN}2)${RESET} SageAttention"
        echo -e "   --use-sage-attention"
        echo ""

        echo -e "${CYAN}3)${RESET} Flash Attention"
        echo -e "   --use-flash-attention"
        echo ""

        echo -e "${YELLOW}Press Enter to return to the main menu.${RESET}"
        echo ""

        read -r -p "Choice: " attention_choice

        case "$attention_choice" in

            "")

                return
                ;;

            1)

                ATTENTION_MODE="default"
                save_configuration
                return
                ;;

            2)

                ATTENTION_MODE="sage"
                save_configuration
                return
                ;;

            3)

                ATTENTION_MODE="flash"
                save_configuration
                return
                ;;

            *)

                echo ""
                echo -e "${RED}Invalid choice.${RESET}"
                sleep 1
                ;;

        esac

    done

}

# ============================================================
# VRAM configuration
# ============================================================

configure_vram() {

    while true; do

        clear
        print_header

        echo -e "${CYAN}🎮 GPU VRAM Configuration${RESET}"
        echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
        echo ""

        if [ -n "$GPU_NAME" ]; then

            echo -e "${GREEN}Detected GPU:${RESET} ${YELLOW}$GPU_NAME${RESET}"

            if [ -n "$GPU_VRAM_MB" ]; then

                local detected_gb
                detected_gb=$((GPU_VRAM_MB / 1024))

                echo -e "${GREEN}Detected VRAM:${RESET} ${YELLOW}${detected_gb} GB${RESET}"

            fi

            echo ""

        fi

        case "$VRAM_MODE" in

            low)
                echo -e "${GREEN}Current:${RESET} ${YELLOW}Low VRAM${RESET}"
                ;;

            high)
                echo -e "${GREEN}Current:${RESET} ${YELLOW}High VRAM${RESET}"
                ;;

            *)
                echo -e "${GREEN}Current:${RESET} ${YELLOW}Normal VRAM${RESET}"
                ;;

        esac

        echo ""
        echo -e "${CYAN}1)${RESET} Low VRAM (--lowvram)"
        echo -e "${CYAN}2)${RESET} Normal VRAM"
        echo -e "${CYAN}3)${RESET} High VRAM (--highvram)"
        echo ""
        echo -e "${YELLOW}Press Enter to return to the main menu.${RESET}"
        echo ""

        read -r -p "Choice: " mode_choice

        case "$mode_choice" in

            "")

                return
                ;;

            1)

                VRAM_MODE="low"
                save_configuration
                return
                ;;

            2)

                VRAM_MODE="normal"
                save_configuration
                return
                ;;

            3)

                VRAM_MODE="high"
                save_configuration
                return
                ;;

            *)

                echo ""
                echo -e "${RED}Invalid choice.${RESET}"
                sleep 1
                ;;

        esac

    done

}

# ============================================================
# Output directory configuration
# ============================================================

configure_output_directory() {

    clear
    print_header

    echo -e "${CYAN}📁 Output Directory Configuration${RESET}"
    echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo ""

    if [ -n "$custom_output_dir" ]; then

        echo -e "${GREEN}Current:${RESET} ${YELLOW}$custom_output_dir${RESET}"

    else

        echo -e "${GREEN}Current:${RESET} ${YELLOW}Default ComfyUI output directory${RESET}"

    fi

    echo ""
    echo -e "${CYAN}1)${RESET} Set custom output directory"
    echo -e "${CYAN}2)${RESET} Use default ComfyUI output directory"
    echo ""
    echo -e "${YELLOW}Press Enter to return to the main menu.${RESET}"
    echo ""

    read -r -p "Choice: " output_choice

    case "$output_choice" in

        "")

            return
            ;;

        1)

            echo ""
            echo -e "${YELLOW}Enter the output directory path:${RESET}"
            echo -e "${CYAN}You can use spaces in the path.${RESET}"
            echo ""

            read -r -p "Path: " new_output_dir

            if [ -n "$new_output_dir" ]; then

                custom_output_dir="$new_output_dir"

                save_configuration

                echo ""
                echo -e "${GREEN}✓ Output directory updated.${RESET}"
                sleep 1

            fi

            ;;

        2)

            custom_output_dir=""

            save_configuration

            echo ""
            echo -e "${GREEN}✓ Output directory reset to ComfyUI default.${RESET}"
            sleep 1

            ;;

        *)

            echo ""
            echo -e "${RED}Invalid choice.${RESET}"
            sleep 1
            ;;

    esac

}

# ============================================================
# Custom flags configuration
# ============================================================

configure_custom_flags() {

    clear
    print_header

    echo -e "${CYAN}⚙️  Custom ComfyUI Arguments${RESET}"
    echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo ""

    if [ -n "$CUSTOM_FLAGS" ]; then

        echo -e "${GREEN}Current arguments:${RESET}"
        echo -e "${YELLOW}$CUSTOM_FLAGS${RESET}"

    else

        echo -e "${GREEN}Current:${RESET} ${YELLOW}No custom arguments${RESET}"

    fi

    echo ""
    echo -e "${CYAN}1)${RESET} Replace custom arguments"
    echo -e "${CYAN}2)${RESET} Clear custom arguments"
    echo ""
    echo -e "${YELLOW}Press Enter to return to the main menu.${RESET}"
    echo ""

    read -r -p "Choice: " flags_choice

    case "$flags_choice" in

        "")

            return
            ;;

        1)

            echo ""
            echo -e "${YELLOW}Enter custom arguments for ComfyUI:${RESET}"
            echo ""
            echo -e "${CYAN}Example:${RESET}"
            echo -e "  --force-fp16 --preview-method auto"
            echo ""
            echo -e "${YELLOW}Arguments are entered exactly as they should be passed to ComfyUI.${RESET}"
            echo ""

            read -r -p "> " CUSTOM_FLAGS

            save_configuration

            echo ""
            echo -e "${GREEN}✓ Custom arguments updated.${RESET}"
            sleep 1

            ;;

        2)

            CUSTOM_FLAGS=""

            save_configuration

            echo ""
            echo -e "${GREEN}✓ Custom arguments cleared.${RESET}"
            sleep 1

            ;;

        *)

            echo ""
            echo -e "${RED}Invalid choice.${RESET}"
            sleep 1
            ;;

    esac

}

# ============================================================
# Network configuration
# ============================================================

configure_network() {

    clear
    print_header

    echo -e "${CYAN}🌐 Network Configuration${RESET}"
    echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo ""

    if [ "$LISTEN_ADDRESS" = "0.0.0.0" ]; then

        echo -e "${GREEN}Current:${RESET} ${YELLOW}LAN Access (0.0.0.0)${RESET}"
        echo -e "${CYAN}Accessible from other devices on your network.${RESET}"

    elif [ "$LISTEN_ADDRESS" = "127.0.0.1" ]; then

        echo -e "${GREEN}Current:${RESET} ${YELLOW}Local Only (127.0.0.1)${RESET}"
        echo -e "${CYAN}Accessible only from this computer.${RESET}"

    else

        echo -e "${GREEN}Current:${RESET} ${YELLOW}Custom IP ($LISTEN_ADDRESS)${RESET}"

    fi

    echo ""
    echo -e "${CYAN}1)${RESET} LAN Access (0.0.0.0)"
    echo -e "${CYAN}2)${RESET} Local Only (127.0.0.1)"
    echo -e "${CYAN}3)${RESET} Custom IP address"
    echo ""
    echo -e "${YELLOW}Press Enter to return to the main menu.${RESET}"
    echo ""

    read -r -p "Choice: " listen_choice

    case "$listen_choice" in

        "")

            return
            ;;

        1)

            LISTEN_ADDRESS="0.0.0.0"

            save_configuration

            echo ""
            echo -e "${GREEN}✓ Network setting updated.${RESET}"
            sleep 1

            ;;

        2)

            LISTEN_ADDRESS="127.0.0.1"

            save_configuration

            echo ""
            echo -e "${GREEN}✓ Network setting updated.${RESET}"
            sleep 1

            ;;

        3)

            echo ""
            read -r -p "Enter IP address: " custom_ip

            if [ -n "$custom_ip" ]; then

                LISTEN_ADDRESS="$custom_ip"

                save_configuration

                echo ""
                echo -e "${GREEN}✓ Network setting updated.${RESET}"
                sleep 1

            fi

            ;;

        *)

            echo ""
            echo -e "${RED}Invalid choice.${RESET}"
            sleep 1
            ;;

    esac

}

# ============================================================
# Build ComfyUI arguments
# ============================================================

build_comfy_args() {

    COMFY_ARGS=()

    PYTHON_ARGS=(
        -W "ignore::FutureWarning"
        -W "ignore::UserWarning:pydantic._internal._fields"
    )

    COMFY_ARGS+=(
        "ComfyUI/main.py"
        --listen "$LISTEN_ADDRESS"
        --port "$PORT"
    )

    if [ -n "$custom_output_dir" ]; then

        COMFY_ARGS+=(
            --output-directory "$custom_output_dir"
        )

    fi

    # Determine VRAM flag.

    VRAM_FLAG=$(get_vram_flag "$VRAM_MODE")

    # Determine attention flag.

    ATTENTION_FLAG=$(get_attention_flag "$ATTENTION_MODE")

    if [ -n "$VRAM_FLAG" ]; then

        COMFY_ARGS+=(
            "$VRAM_FLAG"
        )

    fi

    if [ -n "$ATTENTION_FLAG" ]; then

        COMFY_ARGS+=(
            "$ATTENTION_FLAG"
        )

    fi

    # Custom flags.

    if [ -n "$CUSTOM_FLAGS" ]; then

        read -r -a CUSTOM_FLAGS_ARRAY <<< "$CUSTOM_FLAGS"

        COMFY_ARGS+=(
            "${CUSTOM_FLAGS_ARRAY[@]}"
        )

    fi

    # Additional arguments supplied directly to this launcher.

    if [ "${#EXTRA_ARGS[@]}" -gt 0 ]; then

        COMFY_ARGS+=(
            "${EXTRA_ARGS[@]}"
        )

    fi

}

# ============================================================
# Start ComfyUI
# ============================================================

start_comfyui() {

    echo -e "${GREEN}Starting ComfyUI server...${RESET}"
    echo ""

    "$PYTHON_EXEC" \
        "${PYTHON_ARGS[@]}" \
        "${COMFY_ARGS[@]}" &

    COMFY_PID=$!

    echo -e "${CYAN}ComfyUI process started (PID ${COMFY_PID}).${RESET}"
    echo ""

}

# ============================================================
# Determine local URL
# ============================================================

get_comfy_url() {

    if [ "$LISTEN_ADDRESS" = "0.0.0.0" ]; then

        echo "http://127.0.0.1:${PORT}"

    elif [ "$LISTEN_ADDRESS" = "::" ]; then

        echo "http://[::1]:${PORT}"

    else

        echo "http://${LISTEN_ADDRESS}:${PORT}"

    fi

}

# ============================================================
# Wait for ComfyUI
# ============================================================

wait_for_comfyui() {

    local url="$1"

    echo -e "${CYAN}Waiting for ComfyUI web server...${RESET}"

    for ((i=1; i<=60; i++)); do

        # Check whether ComfyUI is still alive.

        if ! kill -0 "$COMFY_PID" 2>/dev/null; then

            echo ""
            echo -e "${RED}✗ ComfyUI exited before the web server became ready.${RESET}"

            wait "$COMFY_PID" 2>/dev/null || true

            return 1

        fi

        # Check HTTP response.

        if curl -fsS --max-time 1 "$url" >/dev/null 2>&1; then

            echo ""
            echo -e "${GREEN}✓ ComfyUI web server is ready!${RESET}"
            echo ""

            return 0

        fi

        printf "."
        sleep 1

    done

    echo ""
    echo -e "${RED}✗ Timed out waiting for ComfyUI to start.${RESET}"
    echo ""

    return 1

}

# ============================================================
# Start browser web app
# ============================================================

start_browser_app() {

    local url="$1"

    # ========================================================
    # Default browser
    # ========================================================

    if [ "$BROWSER_MODE" = "default" ]; then

        BROWSER_DISPLAY_NAME="Default Browser"

        echo -e "${CYAN}Launching ComfyUI in your default browser...${RESET}"
        echo ""

        if ! open_default_browser "$url"; then

            echo -e "${RED}✗ Could not open the default browser.${RESET}"
            echo -e "${CYAN}Open ComfyUI manually at:${RESET}"
            echo -e "${YELLOW}$url${RESET}"
            echo ""

            return 1

        fi

        # There is deliberately no BROWSER_PID here.
        #
        # The default browser is not considered part of the
        # ComfyUI launcher lifecycle.

        echo -e "${GREEN}✓ ComfyUI opened in the default browser.${RESET}"
        echo -e "${CYAN}URL:${RESET} ${YELLOW}$url${RESET}"
        echo ""

        return 0

    fi

    # ========================================================
    # Dedicated Web App
    # ========================================================

    find_browser

    if [ -z "$BROWSER_EXEC" ]; then

        echo -e "${YELLOW}${BROWSER_DISPLAY_NAME} was not found.${RESET}"
        echo -e "${CYAN}Opening the default browser instead...${RESET}"
        echo ""

        if open_default_browser "$url"; then

            BROWSER_MODE="default"
            BROWSER_DISPLAY_NAME="Default Browser"
            BROWSER_PID=""

            echo -e "${GREEN}✓ ComfyUI opened in the default browser.${RESET}"
            echo -e "${CYAN}URL:${RESET} ${YELLOW}$url${RESET}"
            echo ""

            return 0

        fi

        echo -e "${CYAN}Open ComfyUI manually at:${RESET}"
        echo -e "${YELLOW}$url${RESET}"
        echo ""

        return 1

    fi

    echo -e "${CYAN}Launching ComfyUI as a ${BROWSER_DISPLAY_NAME} web app...${RESET}"
    echo -e "${CYAN}GPU acceleration disabled for this app.${RESET}"
    echo ""

    mkdir -p "$BROWSER_PROFILE"

    if command -v setsid >/dev/null 2>&1; then

        setsid \
            "$BROWSER_EXEC" \
            --app="$url" \
            --user-data-dir="$BROWSER_PROFILE" \
            --no-first-run \
            --disable-gpu \
            >/dev/null 2>&1 &

    else

        "$BROWSER_EXEC" \
            --app="$url" \
            --user-data-dir="$BROWSER_PROFILE" \
            --no-first-run \
            --disable-gpu \
            >/dev/null 2>&1 &

    fi

    BROWSER_PID=$!

    sleep 1

    if ! kill -0 "$BROWSER_PID" 2>/dev/null; then

        echo -e "${RED}✗ Failed to start ${BROWSER_DISPLAY_NAME} web app.${RESET}"

        BROWSER_PID=""

        return 1

    fi

    echo -e "${GREEN}✓ ComfyUI web app launched.${RESET}"
    echo -e "${CYAN}Browser:${RESET} ${YELLOW}${BROWSER_DISPLAY_NAME}${RESET}"
    echo -e "${CYAN}Executable:${RESET} ${YELLOW}${BROWSER_EXEC}${RESET}"
    echo -e "${CYAN}URL:${RESET} ${YELLOW}$url${RESET}"
    echo ""

    return 0

}

# ============================================================
# Terminate process group / session
# ============================================================

kill_process_tree() {

    local pid="$1"

    if [ -z "$pid" ]; then
        return
    fi

    if ! kill -0 "$pid" 2>/dev/null; then
        return
    fi

    echo -e "${CYAN}Stopping process ${pid}...${RESET}"

    kill -TERM "$pid" 2>/dev/null || true

    sleep 2

    if kill -0 "$pid" 2>/dev/null; then
        kill -KILL "$pid" 2>/dev/null || true
    fi

}

# ============================================================
# Cleanup
# ============================================================

CLEANUP_DONE=0

cleanup_session() {

    if [ "$CLEANUP_DONE" -eq 1 ]; then
        return
    fi

    CLEANUP_DONE=1

    echo ""
    echo -e "${CYAN}Shutting down ComfyUI session...${RESET}"

    # --------------------------------------------------------
    # Stop browser
    # --------------------------------------------------------

    if [ -n "$BROWSER_PID" ]; then

        echo -e "${CYAN}Closing ${BROWSER_DISPLAY_NAME} web app...${RESET}"

        kill_process_tree "$BROWSER_PID"

        BROWSER_PID=""

    fi

    # --------------------------------------------------------
    # Stop ComfyUI
    # --------------------------------------------------------

    if [ -n "$COMFY_PID" ]; then

        echo -e "${CYAN}Stopping ComfyUI...${RESET}"

        kill_process_tree "$COMFY_PID"

        COMFY_PID=""

    fi

    echo -e "${GREEN}✓ ComfyUI session stopped.${RESET}"

}

# ============================================================
# Signal handling
# ============================================================

handle_signal() {

    echo ""
    echo -e "${YELLOW}Launcher interrupted.${RESET}"

    exit 0

}

# ============================================================
# Traps
# ============================================================

trap handle_signal INT TERM HUP
trap cleanup_session EXIT

# ============================================================
# Parse command-line arguments
# ============================================================

while [[ $# -gt 0 ]]; do

    case "$1" in

        --port)

            if [ -z "${2:-}" ] || [[ "$2" == --* ]]; then

                echo -e "${RED}ERROR: --port requires a port number.${RESET}"

                exit 1

            fi

            PORT="$2"

            shift 2
            ;;

        --debug)

            DEBUG_MODE=1

            shift
            ;;

        *)

            EXTRA_ARGS+=("$1")

            shift

            ;;

    esac

done

# ============================================================
# Initial detection
# ============================================================

print_header

detect_python
detect_gpu
load_configuration

# ============================================================
# Main configuration menu
# ============================================================

main_menu

# ============================================================
# Build final ComfyUI command
# ============================================================

build_comfy_args

# ============================================================
# Final launch information
# ============================================================

clear
print_header

echo -e "${CYAN}🚀 Launching ComfyUI...${RESET}"
echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo ""

# ------------------------------------------------------------
# Output
# ------------------------------------------------------------

if [ -n "$custom_output_dir" ]; then

    echo -e "${GREEN}   ✓ Output:${RESET} ${YELLOW}$custom_output_dir${RESET}"

else

    echo -e "${GREEN}   ✓ Output:${RESET} ${YELLOW}Default ComfyUI output directory${RESET}"

fi

# ------------------------------------------------------------
# Network
# ------------------------------------------------------------

echo -e "${GREEN}   ✓ Listening:${RESET} ${YELLOW}${LISTEN_ADDRESS}:${PORT}${RESET}"

# ------------------------------------------------------------
# Python
# ------------------------------------------------------------

echo -e "${GREEN}   ✓ Python:${RESET} ${YELLOW}${PYTHON_EXEC}${RESET}"

# ------------------------------------------------------------
# Attention
# ------------------------------------------------------------

case "$ATTENTION_MODE" in

    sage)

        echo -e "${GREEN}   ✓ Attention:${RESET} ${YELLOW}SageAttention${RESET}"
        ;;

    flash)

        echo -e "${GREEN}   ✓ Attention:${RESET} ${YELLOW}Flash Attention${RESET}"
        ;;

    *)

        echo -e "${GREEN}   ✓ Attention:${RESET} ${YELLOW}Default${RESET}"
        ;;

esac

# ------------------------------------------------------------
# VRAM
# ------------------------------------------------------------

case "$VRAM_MODE" in

    low)

        echo -e "${GREEN}   ✓ VRAM:${RESET} ${YELLOW}Low VRAM (--lowvram)${RESET}"
        ;;

    high)

        echo -e "${GREEN}   ✓ VRAM:${RESET} ${YELLOW}High VRAM (--highvram)${RESET}"
        ;;

    *)

        echo -e "${GREEN}   ✓ VRAM:${RESET} ${YELLOW}Normal${RESET}"
        ;;

esac

# ------------------------------------------------------------
# Browser
# ------------------------------------------------------------

find_browser

echo -e "${GREEN}   ✓ Browser:${RESET} ${YELLOW}${BROWSER_DISPLAY_NAME}${RESET}"

if [ -n "$BROWSER_EXEC" ]; then

    echo -e "${GREEN}   ✓ Browser executable:${RESET} ${YELLOW}${BROWSER_EXEC}${RESET}"

fi

# ------------------------------------------------------------
# Custom flags
# ------------------------------------------------------------

if [ -n "$CUSTOM_FLAGS" ]; then

    echo -e "${GREEN}   ✓ Custom flags:${RESET} ${YELLOW}$CUSTOM_FLAGS${RESET}"

fi

# ------------------------------------------------------------
# GPU
# ------------------------------------------------------------

if [ -n "$GPU_NAME" ]; then

    echo -e "${GREEN}   ✓ GPU:${RESET} ${YELLOW}$GPU_NAME${RESET}"

fi

echo ""

# ============================================================
# Debug information
# ============================================================

if [ "$DEBUG_MODE" -eq 1 ]; then

    echo "========== ACTUAL COMFYUI COMMAND =========="

    printf '%q ' \
        "$PYTHON_EXEC" \
        "${PYTHON_ARGS[@]}" \
        "${COMFY_ARGS[@]}"

    echo ""
    echo "============================================="
    echo ""

    echo "========== GPU ENVIRONMENT =========="
    echo "CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-}"
    echo "CUDA_DEVICE_ORDER=${CUDA_DEVICE_ORDER:-}"
    echo "PYTORCH_CUDA_ALLOC_CONF=${PYTORCH_CUDA_ALLOC_CONF:-}"
    echo "CUDA_HOME=${CUDA_HOME:-}"
    echo "LD_LIBRARY_PATH=${LD_LIBRARY_PATH:-}"
    echo "PATH=${PATH}"
    echo ""
    echo "PYTHON_EXEC=${PYTHON_EXEC}"

    if [ -x "$PYTHON_EXEC" ]; then

        echo "PYTHON_VERSION=$("$PYTHON_EXEC" --version 2>&1)"

    fi

    echo ""

    echo "BROWSER_MODE=${BROWSER_MODE}"
    echo "BROWSER_EXEC=${BROWSER_EXEC}"
    echo "BROWSER_PROFILE=${BROWSER_PROFILE}"

    if command -v nvcc >/dev/null 2>&1; then

        echo ""
        echo "NVCC:"
        nvcc --version

    fi

    echo ""

    if command -v nvidia-smi >/dev/null 2>&1; then

        echo "NVIDIA-SMI:"
        nvidia-smi

    fi

    echo "======================================"
    echo ""

fi

# ============================================================
# Start ComfyUI
# ============================================================

start_comfyui

# ============================================================
# Determine local URL
# ============================================================

COMFY_URL=$(get_comfy_url)

# ============================================================
# Wait for server
# ============================================================

if ! wait_for_comfyui "$COMFY_URL"; then

    echo -e "${RED}ComfyUI failed to start.${RESET}"

    exit 1

fi

# ============================================================
# Start browser
# ============================================================

if ! start_browser_app "$COMFY_URL"; then

    echo -e "${YELLOW}${BROWSER_DISPLAY_NAME} could not be started.${RESET}"
    echo -e "${CYAN}ComfyUI will remain running in the terminal.${RESET}"
    echo ""

    wait "$COMFY_PID" 2>/dev/null || true

    exit 0

fi

# ============================================================
# Session handling
# ============================================================

if browser_is_default; then

    echo -e "${GREEN}✓ ComfyUI launched in the default browser.${RESET}"
    echo -e "${CYAN}The browser is not linked to the ComfyUI process.${RESET}"
    echo ""

    # --------------------------------------------------------
    # Default browser mode
    #
    # We simply keep ComfyUI running in this terminal.
    # Closing the browser does not stop ComfyUI because there
    # is no reliable browser process belonging exclusively to
    # this launcher.
    # --------------------------------------------------------

    wait "$COMFY_PID" 2>/dev/null || true

else

    echo -e "${GREEN}✓ ComfyUI and ${BROWSER_DISPLAY_NAME} are linked.${RESET}"
    echo -e "${CYAN}Closing either one will close the other.${RESET}"
    echo ""
    echo -e "${CYAN}Browser GPU acceleration:${RESET} ${YELLOW}Disabled${RESET}"
    echo -e "${CYAN}Browser profile:${RESET} ${YELLOW}$BROWSER_PROFILE${RESET}"
    echo ""

    # --------------------------------------------------------
    # Monitor both processes
    # --------------------------------------------------------

    while true; do

        # ----------------------------------------------------
        # Check ComfyUI
        # ----------------------------------------------------

        if ! kill -0 "$COMFY_PID" 2>/dev/null; then

            echo ""
            echo -e "${YELLOW}ComfyUI has exited.${RESET}"

            cleanup_session

            break

        fi

        # ----------------------------------------------------
        # Check browser
        # ----------------------------------------------------

        if ! kill -0 "$BROWSER_PID" 2>/dev/null; then

            echo ""
            echo -e "${YELLOW}${BROWSER_DISPLAY_NAME} web app has been closed.${RESET}"

            cleanup_session

            break

        fi

        sleep 1

    done

fi

# ============================================================
# Wait for processes to finish
# ============================================================

if [ -n "$BROWSER_PID" ]; then
    wait "$BROWSER_PID" 2>/dev/null || true
fi

if [ -n "$COMFY_PID" ]; then
    wait "$COMFY_PID" 2>/dev/null || true
fi

# ============================================================
# Session ended
# ============================================================

echo ""

echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${YELLOW}✨ ComfyUI session ended ✨${RESET}"
echo ""

echo -e "${GREEN}Press any key to exit...${RESET}"

read -n 1 -s

echo ""
