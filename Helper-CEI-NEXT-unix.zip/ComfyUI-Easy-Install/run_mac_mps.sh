#!/bin/bash

cd "$(dirname "$0")"

# Check if we're in the correct directory
if [ ! -d "ComfyUI" ] || [ ! -d "python_embeded" ]; then
    echo -e "${RED}ERROR: This script must be run from the ComfyUI-Easy-Install directory.${RESET}"
    echo -e "${YELLOW}Please run this script from inside the 'ComfyUI-Easy-Install' folder.${RESET}"
    echo -e "${CYAN}Current directory: $(pwd)${RESET}"
    echo -e "${CYAN}Expected to find: ComfyUI folder and python_embeded folder${RESET}"
    echo ""
    echo -e "${GREEN}Press any key to exit...${RESET}"
    read -n 1 -s
    exit 1
fi

# Clear RAM before starting ComfyUI
echo "Clearing RAM cache to free up memory..."
# Try non-sudo memory clearing techniques first
# Force macOS to drop disk caches and buffer caches
echo 3 > /dev/null 2>&1 || true
# Alternative approach without sudo
python3 -c 'import ctypes; ctypes.CDLL(None).malloc_zone_pressure_relief(0, 0)' 2>/dev/null || true

# Kill any lingering Python processes that might be using memory
echo "Stopping any running Python processes..."
pkill -f "python.*main.py" 2>/dev/null || true

# Give the system a moment to release memory
sleep 1

# Set environment variables for M1 GPU optimization
export PYTORCH_ENABLE_MPS_FALLBACK=1

# Memory optimization settings
export PYTORCH_MPS_HIGH_WATERMARK_RATIO=0.0  # Allow using more GPU memory
export PYTORCH_MPS_LOW_WATERMARK_RATIO=0.7   # Higher threshold for better stability
export PYTORCH_MPS_MINIMUM_MEMORY_WARNINGS=0  # Reduce warning spam
export PYTORCH_MPS_ALLOCATOR_POLICY=garbage_collection  # Enable aggressive GC

# Additional memory optimizations
export PYTORCH_MPS_ALLOCATOR_BLOCK_SIZE=1073741824  # 1GB blocks for better memory management

# Additional performance optimizations
export TORCH_MPS_PLEASE_CACHE_DESCRIPTORS=1   # Improve descriptor caching
export PYTORCH_MPS_ENABLE_GRAPH_MODE=1       # Enable graph mode for better performance

# Enable unified memory for better memory management
export PYTORCH_MPS_ENABLE_UNIFIED_MEMORY=1
export PYTORCH_MPS_ENABLE_GUARD_IMPLEMENTATION=1

# ComfyUI specific optimizations
export COMFYUI_USE_MPS=1    
export COMFYUI_VRAM_OPTIMIZATIONS=MPS
export COMFYUI_FORCE_MPS=1

# Data type compatibility fixes
export PYTORCH_MPS_USE_FP32_ACCUM=1  # Use FP32 for accumulation to improve precision
export PYTORCH_CUDA_ALLOC_CONF=max_split_size_mb:32  # Limit memory splits
export PYTORCH_FLOAT8_DISABLED=1  # Disable Float8 which is not supported on MPS
export PYTORCH_PREFER_FLOAT32=1  # Prefer float32 over unsupported types

# Fix for tensor view errors in upscalers (Ultimate SD Upscale)
export PYTORCH_MPS_CONTIGUOUS_FORMAT=1  # Force contiguous memory format for tensors

# Force Python garbage collection before activating environment
echo "Running Python garbage collection..."
python3 -c "import gc; gc.collect()" 2>/dev/null || true


# Detect Python environment
echo -e "${CYAN}🔍 Detecting Python environment...${RESET}"
PYTHON_EXEC=""
PYTHON_PATH=""

# Check for new installer structure (direct Python installation)
if [ -f "python_embeded/python" ]; then
    PYTHON_EXEC="./python_embeded/python"
    echo -e "${GREEN}   ✓ Found Python (embedded)${RESET}"
    echo -e "${GREEN}   ✓ Using direct embedded Python (no venv activation needed)${RESET}"
# Check for old virtual environment structure
elif [ -d "python_embeded_3.12/bin" ]; then
    PYTHON_PATH="python_embeded_3.12/bin"
    PYTHON_EXEC="./python_embeded_3.12/bin/python3"
    echo -e "${GREEN}   ✓ Found Python 3.12${RESET}"
elif [ -d "python_embeded_3.11/bin" ]; then
    PYTHON_PATH="python_embeded_3.11/bin"
    PYTHON_EXEC="./python_embeded_3.11/bin/python3"
    echo -e "${GREEN}   ✓ Found Python 3.11${RESET}"
elif [ -d "python_embeded/bin" ]; then
    PYTHON_PATH="python_embeded/bin"
    PYTHON_EXEC="./python_embeded/bin/python3"
    echo -e "${GREEN}   ✓ Found Python (embedded)${RESET}"
else
    echo -e "${RED}   ✗ No embedded Python found, using system Python${RESET}"
    PYTHON_EXEC="python3"
fi
echo ""

# Activate virtual environment if we have one (old installer structure)
if [ -n "$PYTHON_PATH" ]; then
    echo -e "${CYAN}🐍 Activating Python environment...${RESET}"
    sleep 0.5
    source "$PYTHON_PATH/activate" 2>/dev/null && echo -e "${GREEN}   ✓ Environment activated${RESET}" || echo -e "${YELLOW}   ⚠ Using direct Python${RESET}"
    echo ""
else
    # New installer structure - no activation needed
    echo -e "${CYAN}🐍 Python environment ready...${RESET}"
    echo ""
fi

# Ask for listening address
LISTEN_CONFIG_FILE=".listen_address_config"
LISTEN_ADDRESS=""

# Check if config file exists
if [ -f "$LISTEN_CONFIG_FILE" ]; then
    LISTEN_ADDRESS=$(cat "$LISTEN_CONFIG_FILE")
    clear
    echo -e "${CYAN}🌐 Network Configuration${RESET}"
    echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo ""
    if [ -n "$LISTEN_ADDRESS" ]; then
        if [ "$LISTEN_ADDRESS" = "0.0.0.0" ]; then
            echo -e "${GREEN}   ✓ Saved setting: ${YELLOW}LAN Access (0.0.0.0)${RESET}"
            echo -e "${CYAN}     Accessible from other devices on your network${RESET}"
        elif [ "$LISTEN_ADDRESS" = "127.0.0.1" ]; then
            echo -e "${GREEN}   ✓ Saved setting: ${YELLOW}Local Only (127.0.0.1)${RESET}"
            echo -e "${CYAN}     Accessible only from this computer${RESET}"
        else
            echo -e "${GREEN}   ✓ Saved setting: ${YELLOW}Custom IP (${LISTEN_ADDRESS})${RESET}"
        fi
    else
        echo -e "${GREEN}   ✓ Using default: ${YELLOW}LAN Access (0.0.0.0)${RESET}"
        LISTEN_ADDRESS="0.0.0.0"
    fi
    echo ""
    echo -e "${YELLOW}Press Enter to keep current, or 'c' to change:${RESET}"
    read -p "> " change_choice
    
    if [ "$change_choice" = "c" ] || [ "$change_choice" = "C" ]; then
        clear
        echo -e "${CYAN}🌐 Network Configuration${RESET}"
        echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
        echo ""
        echo -e "${YELLOW}Choose listening address:${RESET}"
        echo -e "${CYAN}1) LAN Access (0.0.0.0) - For Network access${RESET}"
        echo -e "${CYAN}2) Local Only (127.0.0.1) - For security${RESET}"
        echo -e "${CYAN}3) Custom IP address${RESET}"
        echo -e "${CYAN}Choose 1-3:${RESET}"
        read -p "Choice: " listen_choice
        
        case $listen_choice in
            1)
                LISTEN_ADDRESS="0.0.0.0"
                echo "$LISTEN_ADDRESS" > "$LISTEN_CONFIG_FILE"
                ;;
            2)
                LISTEN_ADDRESS="127.0.0.1"
                echo "$LISTEN_ADDRESS" > "$LISTEN_CONFIG_FILE"
                ;;
            3)
                read -p "Enter IP address: " custom_ip
                if [ -n "$custom_ip" ]; then
                    LISTEN_ADDRESS="$custom_ip"
                    echo "$LISTEN_ADDRESS" > "$LISTEN_CONFIG_FILE"
                fi
                ;;
            *)
                echo -e "${YELLOW}Keeping current setting${RESET}"
                ;;
        esac
        echo ""
    fi
else
    clear
    echo -e "${CYAN}🌐 Network Configuration${RESET}"
    echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo ""
    echo -e "${YELLOW}Choose ComfyUI listening address:${RESET}"
    echo -e "${CYAN}1) LAN Access (0.0.0.0) - For Network access${RESET}"
    echo -e "${CYAN}2) Local Only (127.0.0.1) - For security${RESET}"
    echo -e "${CYAN}3) Custom IP address${RESET}"
    echo -e "${CYAN}Press Enter for LAN Access (default), or choose 1-3:${RESET}"
    read -p "Choice: " listen_choice
    
    case $listen_choice in
        1|"")
            LISTEN_ADDRESS="0.0.0.0"
            ;;
        2)
            LISTEN_ADDRESS="127.0.0.1"
            ;;
        3)
            read -p "Enter IP address: " custom_ip
            if [ -n "$custom_ip" ]; then
                LISTEN_ADDRESS="$custom_ip"
            else
                LISTEN_ADDRESS="0.0.0.0"
            fi
            ;;
        *)
            LISTEN_ADDRESS="0.0.0.0"
            ;;
    esac
    echo "$LISTEN_ADDRESS" > "$LISTEN_CONFIG_FILE"
    echo ""
fi


# PYTHON_EXEC already set above in detection section

# Launch ComfyUI
clear
echo -e "${CYAN}🚀 Launching ComfyUI...${RESET}"
echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo ""
echo -e "${GREEN}   ✓ Listening on: ${YELLOW}${LISTEN_ADDRESS}${RESET}"
echo -e "${GREEN}   ✓ Using Python: ${YELLOW}$PYTHON_EXEC${RESET}"
echo ""
sleep 0.5

$PYTHON_EXEC -W ignore::FutureWarning ComfyUI/main.py --listen "$LISTEN_ADDRESS" --force-upcast-attention
    
echo ""
echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${YELLOW}✨ ComfyUI session ended ✨${RESET}"
echo ""
echo -e "${GREEN}Press any key to exit...${RESET}"
read -n 1 -s
