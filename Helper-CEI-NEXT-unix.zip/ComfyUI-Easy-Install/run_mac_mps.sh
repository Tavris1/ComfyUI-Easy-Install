#!/bin/bash
cd "$(dirname "$0")"

# Clear RAM before starting ComfyUI
echo "Clearing RAM cache to free up memory..."
# Try non-sudo memory clearing techniques first
# Force macOS to drop disk caches and buffer caches
echo 3 > /dev/null 2>&1 || true
# Alternative approach without sudo
python3 -c 'import ctypes; ctypes.CDLL(None).malloc_zone_pressure_relief(0, 0)' 2>/dev/null || true

# Kill any lingering Python processes that might be using memory
echo "Stopping any running Python processes..."
pkill -f "python.*main.py" 2>/dev/null || true

# Give the system a moment to release memory
sleep 1

# Set environment variables for M1 GPU optimization
export PYTORCH_ENABLE_MPS_FALLBACK=1

# Memory optimization settings
export PYTORCH_MPS_HIGH_WATERMARK_RATIO=0.0  # Allow using more GPU memory
export PYTORCH_MPS_LOW_WATERMARK_RATIO=0.7   # Higher threshold for better stability
export PYTORCH_MPS_MINIMUM_MEMORY_WARNINGS=0  # Reduce warning spam
export PYTORCH_MPS_ALLOCATOR_POLICY=garbage_collection  # Enable aggressive GC

# Additional memory optimizations
export PYTORCH_MPS_ALLOCATOR_BLOCK_SIZE=1073741824  # 1GB blocks for better memory management

# Additional performance optimizations
export TORCH_MPS_PLEASE_CACHE_DESCRIPTORS=1   # Improve descriptor caching
export PYTORCH_MPS_ENABLE_GRAPH_MODE=1       # Enable graph mode for better performance

# Enable unified memory for better memory management
export PYTORCH_MPS_ENABLE_UNIFIED_MEMORY=1
export PYTORCH_MPS_ENABLE_GUARD_IMPLEMENTATION=1

# ComfyUI specific optimizations
export COMFYUI_USE_MPS=1    
export COMFYUI_VRAM_OPTIMIZATIONS=MPS
export COMFYUI_FORCE_MPS=1

# Data type compatibility fixes
export PYTORCH_MPS_USE_FP32_ACCUM=1  # Use FP32 for accumulation to improve precision
export PYTORCH_CUDA_ALLOC_CONF=max_split_size_mb:32  # Limit memory splits
export PYTORCH_FLOAT8_DISABLED=1  # Disable Float8 which is not supported on MPS
export PYTORCH_PREFER_FLOAT32=1  # Prefer float32 over unsupported types

# Fix for tensor view errors in upscalers (Ultimate SD Upscale)
export PYTORCH_MPS_CONTIGUOUS_FORMAT=1  # Force contiguous memory format for tensors

# Force Python garbage collection before activating environment
echo "Running Python garbage collection..."
python3 -c "import gc; gc.collect()" 2>/dev/null || true


# Detect Python environment
PYTHON_BIN=""
if [ -x "python_embeded/venv/bin/python" ]; then
    PYTHON_BIN="python_embeded/venv/bin/python"
elif [ -x "python_embeded/python" ]; then
    PYTHON_BIN="python_embeded/python"
elif [ -x "python_embeded/bin/python3" ]; then
    PYTHON_BIN="python_embeded/bin/python3"
elif [ -x "python_embeded_3.12/bin/python3" ]; then
    PYTHON_BIN="python_embeded_3.12/bin/python3"
elif [ -x "python_embeded_3.11/bin/python3" ]; then
    PYTHON_BIN="python_embeded_3.11/bin/python3"
else
    PYTHON_BIN="python3"
fi

# Show Python being used
if [ -n "$PYTHON_BIN" ]; then
    echo -e "${CYAN}🐍 Activating Python environment...${RESET}"
    sleep 0.5
    echo -e "${GREEN}   ✓ Using: ${YELLOW}${PYTHON_BIN}${RESET}"
    echo ""
fi


# Launch ComfyUI
clear
echo -e "${CYAN}🚀 Launching ComfyUI...${RESET}"
echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo ""
sleep 0.5

ARCH="$(uname -m)"
EXTRA_ARGS=""
if [ "$ARCH" = "x86_64" ]; then
    EXTRA_ARGS="--cpu"
fi

"$PYTHON_BIN" -W ignore::FutureWarning ComfyUI/main.py --listen 0.0.0.0 --force-upcast-attention $EXTRA_ARGS
    
echo ""
echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${YELLOW}✨ ComfyUI session ended ✨${RESET}"
echo ""
echo -e "${GREEN}Press any key to exit...${RESET}"
read -n 1 -s
