#!/bin/bash

# Title: Torch 2.9.1 (cu130) for 'ComfyUI Easy Install' by ivo
# Pixaroma Community Edition

set -euo pipefail
cd "$(dirname "$0")"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
RESET='\033[0m'

# PIP args
PIPargs=(--no-cache-dir --no-warn-script-location --timeout=1000 --retries 200)

echo -e "${GREEN}::::::::::::::: Torch 2.9.1 (cu130) installer for Linux :::::::::::::::${RESET}"

# Locate embedded Python
# Note: Script runs from Add-Ons/Torch-Pack, so need to go up two levels
PYTHON=""

# Try different possible locations for embedded Python (matching main installer)
if [ -f "../../python_embeded/python" ]; then
  PYTHON="../../python_embeded/python"
  echo -e "${GREEN}✓${RESET} Using embedded Python"
elif [ -f "../../python_embeded/bin/python3" ]; then
  PYTHON="../../python_embeded/bin/python3"
  echo -e "${GREEN}✓${RESET} Using embedded Python 3"
elif [ -f "../../python_embeded/bin/python" ]; then
  PYTHON="../../python_embeded/bin/python"
  echo -e "${GREEN}✓${RESET} Using embedded Python"
elif [ -f "../../python_embeded/python3" ]; then
  PYTHON="../../python_embeded/python3"
  echo -e "${GREEN}✓${RESET} Using embedded Python 3"
fi

if [ -z "$PYTHON" ]; then
  echo -e "${RED}✗ Embedded Python not found!${RESET}"
  echo -e "${YELLOW}Expected locations:${RESET}"
  echo -e "    ../../python_embeded/python"
  echo -e "    ../../python_embeded/bin/python3"
  echo -e "${YELLOW}Run this from the 'ComfyUI-Easy-Install/Add-Ons/Torch-Pack' folder.${RESET}"
  exit 1
fi

echo -e "${GREEN}✓${RESET} Python path: ${YELLOW}$PYTHON${RESET}"

# Check currently installed versions
echo -e "\n${CYAN}::::::::::::::: Currently Installed Versions :::::::::::::::${RESET}"
CURRENT_TORCH=$("$PYTHON" -c "import torch; print(torch.__version__)" 2>/dev/null || echo "Not installed")
CURRENT_TORCHVISION=$("$PYTHON" -c "import torchvision; print(torchvision.__version__)" 2>/dev/null || echo "Not installed")
CURRENT_TORCHAUDIO=$("$PYTHON" -c "import torchaudio; print(torchaudio.__version__)" 2>/dev/null || echo "Not installed")
CURRENT_CUDA=$("$PYTHON" -c "import torch; print(torch.version.cuda if torch.cuda.is_available() else 'N/A')" 2>/dev/null || echo "N/A")

echo -e "    ${YELLOW}torch:${RESET}       $CURRENT_TORCH"
echo -e "    ${YELLOW}torchvision:${RESET} $CURRENT_TORCHVISION"
echo -e "    ${YELLOW}torchaudio:${RESET}  $CURRENT_TORCHAUDIO"
echo -e "    ${YELLOW}CUDA:${RESET}        $CURRENT_CUDA"
echo -e "${CYAN}::::::::::::::: Target Versions :::::::::::::::${RESET}"
echo -e "    ${GREEN}torch:${RESET}       2.9.1"
echo -e "    ${GREEN}torchvision:${RESET} 0.24.1"
echo -e "    ${GREEN}torchaudio:${RESET}  2.9.1"
echo -e "    ${GREEN}CUDA:${RESET}        13.0"
echo ""

# Clear pip cache
CACHE_DIR="${XDG_CACHE_HOME:-$HOME/.cache}/pip/cache"
if [ -d "$CACHE_DIR" ]; then
  rm -rf "$CACHE_DIR" || true
fi
mkdir -p "$CACHE_DIR"
echo -e "${GREEN}::::::::::::::: Clearing Pip Cache ${YELLOW}Done${GREEN} :::::::::::::::${RESET}\n"

# Uninstall existing torch packages
echo -e "${CYAN}Uninstalling existing torch packages...${RESET}"
"$PYTHON" -I -m pip uninstall torch torchvision torchaudio -y || true

# Install target versions
echo -e "${GREEN}::::::::::::::: Updating${YELLOW} Torch 2.9.1 ${GREEN}:::::::::::::::${RESET}\n"
"$PYTHON" -I -m pip install torch==2.9.1 torchvision==0.24.1 torchaudio==2.9.1 --index-url https://download.pytorch.org/whl/cu130 "${PIPargs[@]}"

# Disable Searge_LLM custom node if present
CUSTOM_NODES_DIR="../ComfyUI/custom_nodes"
DISABLED_DIR="$CUSTOM_NODES_DIR/.disabled"
SEARGE_DIR="$CUSTOM_NODES_DIR/ComfyUI_Searge_LLM"

mkdir -p "$DISABLED_DIR"
if [ -d "$SEARGE_DIR" ]; then
  echo -e "\n${GREEN}::::::::::::::: Disabling${YELLOW} Searge_LLM ${GREEN}:::::::::::::::${RESET}"
  mv "$SEARGE_DIR" "$DISABLED_DIR/ComfyUI_Searge_LLM" || true
  echo -e "${GREEN}::::::::: ${YELLOW}Searge_LLM ${GREEN}disabled successfully :::::::::${RESET}"
fi

# Final messages
echo
echo -e "${GREEN}::::::::::::::::::::::: Installation Complete ::::::::::::::::::::::${RESET}"
echo -e "    ${RED}!!! Make sure to reinstall SageAttention and Nunchaku !!!${RESET}"
