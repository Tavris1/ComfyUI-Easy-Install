#!/bin/bash

# Title: Torch 2.13.0 for 'ComfyUI Easy Install' by ivo
# Pixaroma Community Edition
# macOS version (CPU/MPS - no CUDA)

set -euo pipefail
cd "$(dirname "$0")"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
RESET='\033[0m'

# PIP args
PIPargs=(--no-cache-dir --no-warn-script-location --timeout=1000 --retries 200)

echo -e "${GREEN}::::::::::::::: Torch 2.13.0 installer for macOS :::::::::::::::::${RESET}"

# Locate embedded Python
PYTHON=""
if [ -x ../python_embeded_3.12/bin/python ]; then
  PYTHON=../python_embeded_3.12/bin/python
  echo -e "${GREEN}✓${RESET} Using embedded Python 3.12"
elif [ -x ../python_embeded_3.11/bin/python ]; then
  PYTHON=../python_embeded_3.11/bin/python
  echo -e "${GREEN}✓${RESET} Using embedded Python 3.11"
elif [ -x ../python_embeded/bin/python ]; then
  PYTHON=../python_embeded/bin/python
  echo -e "${GREEN}✓${RESET} Using embedded Python"
fi

if [ -z "$PYTHON" ]; then
  echo -e "${YELLOW}⚠ Could not find embedded Python. Falling back to system 'python'.${RESET}"
  if command -v python3 >/dev/null 2>&1; then
    PYTHON=python3
  elif command -v python >/dev/null 2>&1; then
    PYTHON=python
  else
    echo -e "${RED}✗ No Python interpreter found. Aborting.${RESET}"
    exit 1
  fi
fi

# Clear pip cache
CACHE_DIR="${XDG_CACHE_HOME:-$HOME/.cache}/pip/cache"
if [ -d "$CACHE_DIR" ]; then
  rm -rf "$CACHE_DIR" || true
fi
mkdir -p "$CACHE_DIR"
echo -e "${GREEN}::::::::::::::: Clearing Pip Cache ${YELLOW}Done${GREEN} :::::::::::::::::${RESET}\n"

# Uninstall existing torch packages
echo -e "${CYAN}Uninstalling existing torch packages...${RESET}"
"$PYTHON" -I -m pip uninstall torch torchvision torchaudio -y || true

# Install target versions for macOS (CPU + MPS support, no CUDA)
echo -e "${GREEN}::::::::::::::: Updating${YELLOW} Torch 2.13.0 ${GREEN}:::::::::::::::${RESET}\n"
"$PYTHON" -I -m pip install torch==2.13.0 torchvision==0.28.0 torchaudio==2.11.0 "${PIPargs[@]}"

# Verify MPS is available
echo -e "${CYAN}Verifying MPS (Metal Performance Shaders) availability...${RESET}"
"$PYTHON" -I -c "import torch; print(f'PyTorch {torch.__version__}'); print(f'MPS available: {torch.backends.mps.is_available()}')"

# Disable Searge_LLM custom node if present
CUSTOM_NODES_DIR="../ComfyUI/custom_nodes"
DISABLED_DIR="$CUSTOM_NODES_DIR/.disabled"
SEARGE_DIR="$CUSTOM_NODES_DIR/ComfyUI_Searge_LLM"

mkdir -p "$DISABLED_DIR"
if [ -d "$SEARGE_DIR" ]; then
  echo -e "\n${GREEN}::::::::::::::: Disabling${YELLOW} Searge_LLM ${GREEN}:::::::::::::::${RESET}"
  mv "$SEARGE_DIR" "$DISABLED_DIR/ComfyUI_Searge_LLM" || true
  echo -e "${GREEN}::::::::: ${YELLOW}Searge_LLM ${GREEN}disabled successfully :::::::::${RESET}"
fi

# Final messages
echo
echo -e "${GREEN}::::::::::::::::::::::: Installation Complete ::::::::::::::::::::::${RESET}"
echo -e "    ${YELLOW}Torch 2.13.0 installed for macOS (CPU + MPS)${RESET}"
echo
echo -e "${CYAN}Note: For Apple Silicon Macs (M1/M2/M3/M4), MPS acceleration${RESET}"
echo -e "${CYAN}      will be used automatically when available.${RESET}"
echo
