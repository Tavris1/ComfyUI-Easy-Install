#!/bin/bash

# Title: Torch 2.10.0 (cu130) for 'ComfyUI Easy Install' by ivo
# Pixaroma Community Edition

set -euo pipefail
cd "$(dirname "$0")"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
RESET='\033[0m'

# PIP args
FLAG_DIR="$(pwd)"
PIP_NC="--no-cache-dir"
if [ -f "$FLAG_DIR/../Tools/Helper-CEI/keep_cache.flag" ]; then PIP_NC=""; fi
PIPargs=($PIP_NC --no-warn-script-location --timeout=1000 --retries 200)

echo -e "${GREEN}::::::::::::::: Torch 2.10.0 (cu130) installer for Linux :::::::::::::::${RESET}"

# Locate embedded Python
PYTHON=""
if [ -x ../python_embeded_3.12/bin/python ]; then
  PYTHON=../python_embeded_3.12/bin/python
  echo -e "${GREEN}✓${RESET} Using embedded Python 3.12"
elif [ -x ../python_embeded_3.11/bin/python ]; then
  PYTHON=../python_embeded_3.11/bin/python
  echo -e "${GREEN}✓${RESET} Using embedded Python 3.11"
elif [ -x ../python_embeded/bin/python ]; then
  PYTHON=../python_embeded/bin/python
  echo -e "${GREEN}✓${RESET} Using embedded Python"
fi

if [ -z "$PYTHON" ]; then
  echo -e "${YELLOW}⚠ Could not find embedded Python. Falling back to system 'python'.${RESET}"
  if command -v python3 >/dev/null 2>&1; then
    PYTHON=python3
  elif command -v python >/dev/null 2>&1; then
    PYTHON=python
  else
    echo -e "${RED}✗ No Python interpreter found. Aborting.${RESET}"
    exit 1
  fi
fi

# Clear pip cache
CACHE_DIR="${XDG_CACHE_HOME:-$HOME/.cache}/pip/cache"
if [ -d "$CACHE_DIR" ]; then
  rm -rf "$CACHE_DIR" || true
fi
mkdir -p "$CACHE_DIR"
echo -e "${GREEN}::::::::::::::: Clearing Pip Cache ${YELLOW}Done${GREEN} :::::::::::::::${RESET}\n"

# Uninstall existing torch packages
echo -e "${CYAN}Uninstalling existing torch packages...${RESET}"
"$PYTHON" -I -m pip uninstall torch torchvision torchaudio -y || true

# Install target versions
echo -e "${GREEN}::::::::::::::: Installing${YELLOW} Torch 2.10.0 ${GREEN}:::::::::::::::${RESET}\n"
"$PYTHON" -I -m pip install torch==2.10.0 torchvision==0.25.0 torchaudio==2.10.0 --index-url https://download.pytorch.org/whl/cu130 "${PIPargs[@]}"

# Disable Searge_LLM custom node if present
CUSTOM_NODES_DIR="../ComfyUI/custom_nodes"
DISABLED_DIR="$CUSTOM_NODES_DIR/.disabled"
SEARGE_DIR="$CUSTOM_NODES_DIR/ComfyUI_Searge_LLM"

mkdir -p "$DISABLED_DIR"
if [ -d "$SEARGE_DIR" ]; then
  echo -e "\n${GREEN}::::::::::::::: Disabling${YELLOW} Searge_LLM ${GREEN}:::::::::::::::${RESET}"
  mv "$SEARGE_DIR" "$DISABLED_DIR/ComfyUI_Searge_LLM" || true
  echo -e "${GREEN}::::::::: ${YELLOW}Searge_LLM ${GREEN}disabled successfully :::::::::${RESET}"
fi

# Final messages
echo
echo -e "${GREEN}::::::::::::::::::::::: Installation Complete ::::::::::::::::::::::${RESET}"
echo -e "    ${RED}!!! Make sure to reinstall SageAttention and Nunchaku !!!${RESET}"
