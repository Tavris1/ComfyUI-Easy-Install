#!/bin/bash

# TRELLIS.2 Build Script based on Batuhan's Guide
# Adapted for RTX 3060 (SM_86) and embedded Python

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'
RESET='\033[0m'

# Get script directory and Python path
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_PATH="$SCRIPT_DIR/../python_embeded/python"
BUILD_DIR="$SCRIPT_DIR/trellis2_build"

echo -e "${GREEN}::::::::::::::: TRELLIS.2 Build Script${RESET}"
echo -e "${GREEN}::::::::::::::: Python: ${YELLOW}$PYTHON_PATH${RESET}"
echo -e "${GREEN}::::::::::::::: Build Dir: ${YELLOW}$BUILD_DIR${RESET}"
echo

# Check CUDA toolkit
if [ ! -d "/usr/local/cuda" ]; then
    echo -e "${RED}ERROR: CUDA toolkit not found at /usr/local/cuda${RESET}"
    exit 1
fi

CUDA_HOME="/usr/local/cuda"
echo -e "${GREEN}✓ CUDA Home: ${YELLOW}$CUDA_HOME${RESET}"

# Get versions
PYTHON_VERSION=$("$PYTHON_PATH" --version 2>&1 | cut -d' ' -f2 | cut -d'.' -f1,2)
TORCH_VERSION=$("$PYTHON_PATH" -c "import torch; print(torch.__version__)" 2>/dev/null | cut -d'.' -f1,2)
CUDA_TORCH_VERSION=$("$PYTHON_PATH" -c "import torch; print(torch.version.cuda if torch.cuda.is_available() else 'Not available')" 2>/dev/null | cut -d'.' -f1,2)

echo -e "${GREEN}✓ Python: ${YELLOW}$PYTHON_VERSION${RESET}"
echo -e "${GREEN}✓ Torch: ${YELLOW}$TORCH_VERSION${RESET}"
echo -e "${GREEN}✓ Torch CUDA: ${YELLOW}$CUDA_TORCH_VERSION${RESET}"
echo

# Set CUDA flags for RTX 3060 (SM_86)
export CUDA_HOME="$CUDA_HOME"
export TORCH_CUDA_ARCH_LIST="8.6"
export PATH="$CUDA_HOME/bin:$PATH"
export LD_LIBRARY_PATH="$CUDA_HOME/lib64:$LD_LIBRARY_PATH"

echo -e "${GREEN}✓ CUDA Arch List: ${YELLOW}$TORCH_CUDA_ARCH_LIST${RESET}"
echo

# Create build directory
mkdir -p "$BUILD_DIR"
cd "$BUILD_DIR"

# Install build dependencies
echo -e "${GREEN}::::::::::::::: Installing Build Dependencies${RESET}"
"$PYTHON_PATH" -m pip install wheel ninja --no-cache-dir

# 1. FlashAttention
echo -e "${GREEN}::::::::::::::: Building FlashAttention${RESET}"
MAX_JOBS=8 "$PYTHON_PATH" -m pip install flash-attn --no-build-isolation --no-cache-dir || {
    echo -e "${YELLOW}FlashAttention failed, trying older version...${RESET}"
    "$PYTHON_PATH" -m pip install flash-attn==2.3.6 --no-build-isolation --no-cache-dir
}

# 2. CuMesh (patched)
echo -e "${GREEN}::::::::::::::: Building CuMesh${RESET}"
if [ -d "CuMesh" ]; then
    rm -rf CuMesh
fi
git clone https://github.com/JeffreyXiang/CuMesh.git
cd CuMesh

# Apply patch for cub::Sum -> thrust::plus if needed
# This is a common fix for newer CUDA versions
echo "Applying CuMesh patches if needed..."
# Add any patch commands here if needed

"$PYTHON_PATH" -m pip install . --no-build-isolation --no-cache-dir
cd ..

# 3. FlexGEMM
echo -e "${GREEN}::::::::::::::: Building FlexGEMM${RESET}"
if [ -d "FlexGEMM" ]; then
    rm -rf FlexGEMM
fi
git clone https://github.com/JeffreyXiang/FlexGEMM.git
cd FlexGEMM
"$PYTHON_PATH" -m pip install . --no-build-isolation --no-cache-dir
cd ..

# 4. nvdiffrast
echo -e "${GREEN}::::::::::::::: Building nvdiffrast${RESET}"
if [ -d "nvdiffrast" ]; then
    rm -rf nvdiffrast
fi
git clone https://github.com/NVlabs/nvdiffrast.git
cd nvdiffrast
"$PYTHON_PATH" -m pip install . --no-build-isolation --no-cache-dir
cd ..

# 5. nvdiffrec (renderutils branch)
echo -e "${GREEN}::::::::::::::: Building nvdiffrec (renderutils)${RESET}"
if [ -d "nvdiffrec" ]; then
    rm -rf nvdiffrec
fi
git clone -b renderutils https://github.com/JeffreyXiang/nvdiffrec.git
cd nvdiffrec
"$PYTHON_PATH" -m pip install . --no-build-isolation --no-cache-dir
export PYTHONPATH="$PYTHONPATH:$(pwd)"
cd ..

# 6. o-voxel (from TRELLIS.2)
echo -e "${GREEN}::::::::::::::: Building o-voxel${RESET}"
if [ -d "TRELLIS.2" ]; then
    rm -rf TRELLIS.2
fi
git clone https://github.com/microsoft/TRELLIS.2.git --recursive
cd TRELLIS.2/o-voxel

# Install dependencies
"$PYTHON_PATH" -m pip install plyfile zstandard --no-cache-dir

# Setup Eigen (using system if available, otherwise submodule)
if [ -d "/usr/include/eigen3" ]; then
    echo "Using system Eigen3..."
    rm -rf third_party/eigen
    ln -sf /usr/include/eigen3 third_party/eigen
else
    echo "Using submodule Eigen..."
    git submodule update --init --recursive
fi

# Clean and build
rm -rf build dist *.egg-info
bash setup.sh --o-voxel
cd ../..

# Verification
echo -e "${GREEN}::::::::::::::: Verification${RESET}"
echo

packages=("flash_attn" "cumesh" "flexgemm" "nvdiffrast" "render" "o_voxel")
for package in "${packages[@]}"; do
    if "$PYTHON_PATH" -c "import $package; print(f'✓ {package} imported successfully')" 2>/dev/null; then
        echo -e "${GREEN}✓ $package${RESET}"
    else
        echo -e "${RED}✗ $package failed${RESET}"
    fi
done

echo
echo -e "${GREEN}::::::::::::::: Build Complete!${RESET}"
echo -e "${YELLOW}Note: This builds directly into the environment, not creating wheels${RESET}"
echo -e "${YELLOW}To create wheels, use the Trellis2-Build-Wheels.sh script${RESET}"

if [ -z "$1" ]; then
    echo -e "${GREEN}::::::::::::::: ${YELLOW}Press any key to exit${RESET}"
    read -n 1 -s
fi
