#!/bin/bash

# Title: 'Nunchaku110' for 'ComfyUI Easy Install' by ivo
# Pixaroma Community Edition
# Linux conversion

# Set colors
WARNING='\033[33m'
RED='\033[91m'
GREEN='\033[92m'
YELLOW='\033[93m'
BOLD='\033[1m'
RESET='\033[0m'

NODE_NAME="Nunchaku120"

# Set arguments
PIP_ARGS="--no-cache-dir --no-warn-script-location --timeout=1000 --retries 200 --use-pep517"

# Check Add-ons folder and find embedded Python
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PYTHON_PATH=""

# Try different possible locations for embedded Python
if [ -f "../python_embeded/python" ]; then
    PYTHON_PATH="../python_embeded/python"
elif [ -f "../python_embeded/bin/python3" ]; then
    PYTHON_PATH="../python_embeded/bin/python3"
elif [ -f "../python_embeded/bin/python" ]; then
    PYTHON_PATH="../python_embeded/bin/python"
elif [ -f "../python_embeded/python3" ]; then
    PYTHON_PATH="../python_embeded/python3"
fi

if [ -z "$PYTHON_PATH" ] || [ ! -f "$PYTHON_PATH" ]; then
    clear
    echo -e "${RED}::::::::::::::: ERROR: Embedded Python not found!${RESET}"
    echo -e "${GREEN}::::::::::::::: Expected locations:${RESET}"
    echo -e "${YELLOW}    ../python_embeded/python${RESET}"
    echo -e "${YELLOW}    ../python_embeded/bin/python3${RESET}"
    echo
    echo -e "${GREEN}::::::::::::::: Run this file from the ${RED}'ComfyUI-Easy-Install/Add-Ons'${GREEN} folder.${RESET}"
    echo -e "${GREEN}::::::::::::::: Press any key to exit...${RESET}"
    read -n 1 -s
    exit 1
fi

echo -e "${GREEN}::::::::::::::: Using Python:${YELLOW} $PYTHON_PATH${RESET}"
echo

# Clear Pip Cache
if [ -d "$HOME/.cache/pip" ]; then
    rm -rf "$HOME/.cache/pip" && mkdir -p "$HOME/.cache/pip"
fi
echo -e "${GREEN}::::::::::::::: Clearing Pip Cache ${YELLOW}Done${GREEN}${RESET}"
echo

# Get versions
get_versions() {
    echo -e "${GREEN}::::::::::::::: Checking ${YELLOW}Python, Torch and CUDA ${GREEN}versions${RESET}"
    echo

    PYTHON_VERSION=$("$PYTHON_PATH" --version 2>&1 | cut -d' ' -f2 | cut -d'.' -f1,2)
    TORCH_VERSION=$("$PYTHON_PATH" -c "import torch; print(torch.__version__)" 2>/dev/null | cut -d'.' -f1,2)
    CUDA_VERSION=$("$PYTHON_PATH" -c "import torch; print(torch.version.cuda if torch.cuda.is_available() else 'Not available')" 2>/dev/null | cut -d'.' -f1,2)

    echo -e "${GREEN}::::::::::::::: Python Version:${YELLOW} $PYTHON_VERSION${RESET}"
    echo -e "${GREEN}::::::::::::::: Torch Version:${YELLOW} $TORCH_VERSION${RESET}"
    echo -e "${GREEN}::::::::::::::: CUDA Version:${YELLOW} $CUDA_VERSION${RESET}"
    echo

    WARNINGS=0

    if [ "$PYTHON_VERSION" != "3.11" ] && [ "$PYTHON_VERSION" != "3.12" ]; then
        echo -e "${WARNING}WARNING: ${RED}Python $PYTHON_VERSION is not supported. ${GREEN}Supported versions: 3.11, 3.12${RESET}"
        WARNINGS=1
    fi
    if [ "$TORCH_VERSION" != "2.7" ] && [ "$TORCH_VERSION" != "2.8" ] && [ "$TORCH_VERSION" != "2.9" ]; then
        echo -e "${WARNING}WARNING: ${RED}Torch $TORCH_VERSION is not supported. ${GREEN}Supported versions: 2.7, 2.8, 2.9 (requires CUDA 13.0 for 2.9.1+)${RESET}"
        WARNINGS=1
    fi
    if [ "$CUDA_VERSION" != "12.8" ] && [ "$CUDA_VERSION" != "13.0" ]; then
        echo -e "${WARNING}WARNING: ${RED}CUDA $CUDA_VERSION is not supported. ${GREEN}Supported versions: 12.8, 13.0${RESET}"
        WARNINGS=1
    fi
    if [ "$TORCH_VERSION" == "2.9" ] && [ "$CUDA_VERSION" != "13.0" ]; then
        echo -e "${WARNING}WARNING: ${RED}Torch 2.9 requires CUDA 13.0${RESET}"
        WARNINGS=1
    fi

    if [ $WARNINGS -eq 0 ]; then
        echo -e "${GREEN}::::::::::::::: ${RESET}${BOLD}All versions are supported! ${RESET}"
        echo
    else
        echo
        echo -e "${RED}::::::::::::::: Press any key to exit${RESET}"
        read -n 1 -s
        exit
    fi
}

get_versions

# Erasing ~* folders
if [ -d "../python_embeded/Lib/site-packages" ]; then
    find "../python_embeded/Lib/site-packages" -maxdepth 1 -type d -name '~*' -exec rm -rf {} + 2>/dev/null
fi

# Installing Nunchaku
echo -e "${GREEN}::::::::::::::: Installing${YELLOW} $NODE_NAME${RESET}"
echo
if [ -d "../ComfyUI/custom_nodes/ComfyUI-nunchaku" ]; then
    rm -rf "../ComfyUI/custom_nodes/ComfyUI-nunchaku"
fi
git clone https://github.com/nunchaku-ai/ComfyUI-nunchaku ../ComfyUI/custom_nodes/ComfyUI-nunchaku

# Remove existing nunchaku packages
if [ -d "../python_embeded/lib/site-packages" ]; then
    find "../python_embeded/lib/site-packages" -maxdepth 1 -type d -name 'nunchaku*' -exec rm -rf {} + 2>/dev/null
fi

# Install Nunchaku wheel
NUNCHAKU_WHL=""
if [ "$PYTHON_VERSION" == "3.11" ] && [ "$TORCH_VERSION" == "2.7" ]; then
    NUNCHAKU_WHL="v1.0.2/nunchaku-1.0.2+torch2.7-cp311-cp311-linux_x86_64.whl"
elif [ "$PYTHON_VERSION" == "3.11" ] && [ "$TORCH_VERSION" == "2.8" ]; then
    NUNCHAKU_WHL="v1.0.2/nunchaku-1.0.2+torch2.8-cp311-cp311-linux_x86_64.whl"
elif [ "$PYTHON_VERSION" == "3.11" ] && [ "$TORCH_VERSION" == "2.9" ]; then
    NUNCHAKU_WHL="v1.2.1/nunchaku-1.2.1+torch2.9-cp311-cp311-linux_x86_64.whl"
elif [ "$PYTHON_VERSION" == "3.12" ] && [ "$TORCH_VERSION" == "2.7" ]; then
    NUNCHAKU_WHL="v1.0.2/nunchaku-1.0.2+torch2.7-cp312-cp312-linux_x86_64.whl"
elif [ "$PYTHON_VERSION" == "3.12" ] && [ "$TORCH_VERSION" == "2.8" ]; then
    if [ "$CUDA_VERSION" == "12.8" ]; then
        NUNCHAKU_WHL="v1.2.1/nunchaku-1.2.1+cu12.8torch2.8-cp312-cp312-linux_x86_64.whl"
    else
        NUNCHAKU_WHL="v1.2.0/nunchaku-1.2.0+torch2.8-cp312-cp312-linux_x86_64.whl"
    fi
elif [ "$PYTHON_VERSION" == "3.12" ] && [ "$TORCH_VERSION" == "2.9" ]; then
    if [ "$CUDA_VERSION" == "13.0" ]; then
        NUNCHAKU_WHL="v1.2.1/nunchaku-1.2.1+cu13.0torch2.9-cp312-cp312-linux_x86_64.whl"
    elif [ "$CUDA_VERSION" == "12.8" ]; then
        NUNCHAKU_WHL="v1.2.1/nunchaku-1.2.1+cu12.8torch2.9-cp312-cp312-linux_x86_64.whl"
    else
        NUNCHAKU_WHL="v1.2.0/nunchaku-1.2.0+torch2.9-cp312-cp312-linux_x86_64.whl"
    fi
fi

"$PYTHON_PATH" -m pip install "https://github.com/nunchaku-ai/nunchaku/releases/download/$NUNCHAKU_WHL" $PIP_ARGS

if [ -f "../ComfyUI/custom_nodes/ComfyUI-nunchaku/utils.py" ]; then
    sed -i 's/v1\.0\.0/v1.0.2/g' "../ComfyUI/custom_nodes/ComfyUI-nunchaku/utils.py"
fi

# Download nunchaku_versions.json
curl -L -o "../ComfyUI/custom_nodes/ComfyUI-nunchaku/nunchaku_versions.json" "https://nunchaku.tech/cdn/nunchaku_versions.json"

# Install compatible transformers version
"$PYTHON_PATH" -m pip uninstall transformers -y
"$PYTHON_PATH" -m pip install "transformers>=4.54,<4.57" $PIP_ARGS

# Fix flash_attn compatibility - install version matching Torch/CUDA
"$PYTHON_PATH" -m pip uninstall flash-attn -y

# Install compatible flash_attn wheel based on Torch and CUDA version
PYTHON_MINOR=${PYTHON_VERSION#*.}
FLASH_WHL=""
if [ "$TORCH_VERSION" == "2.9" ] && [ "$CUDA_VERSION" == "13.0" ]; then
    FLASH_WHL="https://github.com/mjun0812/flash-attention-prebuild-wheels/releases/download/v0.5.4/flash_attn-2.8.3%2Bcu130torch2.9-cp3${PYTHON_MINOR}-cp3${PYTHON_MINOR}-linux_x86_64.whl"
elif [ "$TORCH_VERSION" == "2.8" ] && [ "$CUDA_VERSION" == "12.8" ]; then
    FLASH_WHL="https://github.com/mjun0812/flash-attention-prebuild-wheels/releases/download/v0.5.4/flash_attn-2.8.3%2Bcu128torch2.8-cp3${PYTHON_MINOR}-cp3${PYTHON_MINOR}-linux_x86_64.whl"
elif [ "$TORCH_VERSION" == "2.7" ] && [ "$CUDA_VERSION" == "12.8" ]; then
    FLASH_WHL="https://github.com/mjun0812/flash-attention-prebuild-wheels/releases/download/v0.5.4/flash_attn-2.8.3%2Bcu128torch2.7-cp3${PYTHON_MINOR}-cp3${PYTHON_MINOR}-linux_x86_64.whl"
fi

if [ -n "$FLASH_WHL" ]; then
    "$PYTHON_PATH" -m pip install "$FLASH_WHL" $PIP_ARGS
else
    echo -e "${WARNING}WARNING: No compatible flash_attn wheel found for Torch $TORCH_VERSION + CUDA $CUDA_VERSION${RESET}"
fi


"$PYTHON_PATH" -m pip install --force-reinstall numpy==1.26.4 $PIP_ARGS

# Final Messages
echo
echo -e "${GREEN}:::::::::::::::${YELLOW} $NODE_NAME ${GREEN}Installation Complete${RESET}"
echo
if [ -z "$1" ]; then
    echo -e "${GREEN}::::::::::::::: ${YELLOW}Press any key to exit${RESET}"
    read -n 1 -s
    exit
fi
