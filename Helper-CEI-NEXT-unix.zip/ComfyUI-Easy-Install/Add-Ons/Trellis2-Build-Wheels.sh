#!/bin/bash

# Build and save Trellis2 wheels for Linux LXC
# Creates reusable wheels for your specific environment

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'
RESET='\033[0m'

# Get script directory and Python path
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_PATH="$SCRIPT_DIR/../python_embeded/python"

echo -e "${GREEN}::::::::::::::: Trellis2 Wheel Builder${RESET}"
echo -e "${GREEN}::::::::::::::: Python: ${YELLOW}$PYTHON_PATH${RESET}"
echo

# Check CUDA toolkit
if [ ! -d "/usr/local/cuda" ]; then
    echo -e "${RED}ERROR: CUDA toolkit not found at /usr/local/cuda${RESET}"
    exit 1
fi

CUDA_HOME="/usr/local/cuda"
echo -e "${GREEN}✓ CUDA Home: ${YELLOW}$CUDA_HOME${RESET}"

# Get versions with detailed checks
PYTHON_VERSION=$("$PYTHON_PATH" --version 2>&1 | cut -d' ' -f2 | cut -d'.' -f1,2)
TORCH_VERSION=$("$PYTHON_PATH" -c "import torch; print(torch.__version__)" 2>/dev/null | cut -d'.' -f1,2)
CUDA_TORCH_VERSION=$("$PYTHON_PATH" -c "import torch; print(torch.version.cuda if torch.cuda.is_available() else 'Not available')" 2>/dev/null | cut -d'.' -f1,2)
# Try multiple methods to detect system CUDA version
CUDA_SYSTEM_VERSION=""
# Method 1: version.txt (older CUDA)
if [ -z "$CUDA_SYSTEM_VERSION" ] && [ -f "$CUDA_HOME/version.txt" ]; then
    CUDA_SYSTEM_VERSION=$(cat "$CUDA_HOME/version.txt" 2>/dev/null | grep -oP 'CUDA Version \K[0-9]+\.[0-9]+')
fi
# Method 2: version.json (CUDA 12.8+)
if [ -z "$CUDA_SYSTEM_VERSION" ] && [ -f "$CUDA_HOME/version.json" ]; then
    CUDA_SYSTEM_VERSION=$(grep -oP '"cuda"\s*:\s*"\K[0-9]+\.[0-9]+' "$CUDA_HOME/version.json" 2>/dev/null)
fi
# Method 3: nvcc in CUDA_HOME/bin
if [ -z "$CUDA_SYSTEM_VERSION" ] && [ -x "$CUDA_HOME/bin/nvcc" ]; then
    CUDA_SYSTEM_VERSION=$("$CUDA_HOME/bin/nvcc" --version 2>/dev/null | grep -oP 'release \K[0-9]+\.[0-9]+')
fi
# Method 4: nvcc in PATH
if [ -z "$CUDA_SYSTEM_VERSION" ]; then
    CUDA_SYSTEM_VERSION=$(nvcc --version 2>/dev/null | grep -oP 'release \K[0-9]+\.[0-9]+')
fi

echo -e "${GREEN}✓ Python: ${YELLOW}$PYTHON_VERSION${RESET}"
echo -e "${GREEN}✓ Torch: ${YELLOW}$TORCH_VERSION${RESET}"
echo -e "${GREEN}✓ Torch CUDA: ${YELLOW}$CUDA_TORCH_VERSION${RESET}"
echo -e "${GREEN}✓ System CUDA: ${YELLOW}$CUDA_SYSTEM_VERSION${RESET}"

# Check CUDA version compatibility (critical issue from GitHub)
if [ "$CUDA_TORCH_VERSION" != "$CUDA_SYSTEM_VERSION" ]; then
    echo -e "${YELLOW}⚠ CUDA Version Mismatch Detected${RESET}"
    echo -e "${YELLOW}  PyTorch compiled with CUDA: $CUDA_TORCH_VERSION${RESET}"
    echo -e "${YELLOW}  System CUDA version: $CUDA_SYSTEM_VERSION${RESET}"
    echo -e "${YELLOW}  This may cause build issues (see microsoft/TRELLIS.2#19)${RESET}"
    echo
    if [ -z "$ALLOW_CUDA_MISMATCH" ]; then
        echo -e "${YELLOW}Recommended fix:${RESET}"
        echo -e "${YELLOW}  - Install CUDA Toolkit $CUDA_TORCH_VERSION to match PyTorch${RESET}"
        echo -e "${YELLOW}  - OR install a PyTorch build that matches CUDA $CUDA_SYSTEM_VERSION${RESET}"
        echo -e "${YELLOW}    (example: torch+cu${CUDA_SYSTEM_VERSION//./} if available)${RESET}"
        echo
        echo -e "${RED}ERROR: CUDA mismatch will break builds. Install matching PyTorch or set ALLOW_CUDA_MISMATCH=1 to continue.${RESET}"
        exit 1
    fi
    echo -e "${YELLOW}Continuing because ALLOW_CUDA_MISMATCH=1 was set.${RESET}"
else
    echo -e "${GREEN}✓ CUDA versions match perfectly${RESET}"
fi

# Build dynamic wheels directory name based on detected versions
# Format: Torch{major}{minor}_cu{cuda_major}{cuda_minor}
TORCH_VER_CLEAN=$(echo "$TORCH_VERSION" | tr -d '.')
CUDA_VER_CLEAN=$(echo "$CUDA_TORCH_VERSION" | tr -d '.')
WHEELS_DIR="$SCRIPT_DIR/wheels/Linux/Torch${TORCH_VER_CLEAN}_cu${CUDA_VER_CLEAN}"

echo -e "${GREEN}::::::::::::::: Wheels Dir: ${YELLOW}$WHEELS_DIR${RESET}"
echo

# Create wheels directory
mkdir -p "$WHEELS_DIR"

# Detect GPU and set optimal CUDA architecture
echo -e "${GREEN}::::::::::::::: Detecting GPU${RESET}"
if "$PYTHON_PATH" -c "import torch; print(torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'No GPU')" 2>/dev/null; then
    GPU_NAME=$("$PYTHON_PATH" -c "import torch; print(torch.cuda.get_device_name(0))" 2>/dev/null)
    GPU_ARCH=$("$PYTHON_PATH" -c "import torch; print(torch.cuda.get_device_capability(0)[0]*10 + torch.cuda.get_device_capability(0)[1])" 2>/dev/null)
    
    echo -e "${GREEN}✓ GPU: ${YELLOW}$GPU_NAME${RESET}"
    echo -e "${GREEN}✓ Architecture: ${YELLOW}SM_$GPU_ARCH${RESET}"
    
    case "$GPU_ARCH" in
        "86") export TORCH_CUDA_ARCH_LIST="8.0;8.6" ;;
        "89") export TORCH_CUDA_ARCH_LIST="8.0;8.6;8.9" ;;
        "80") export TORCH_CUDA_ARCH_LIST="8.0;8.6" ;;
        *) export TORCH_CUDA_ARCH_LIST="8.0;8.6;8.9;9.0;10.0;12.0" ;;
    esac
    echo -e "${GREEN}✓ CUDA List: ${YELLOW}$TORCH_CUDA_ARCH_LIST${RESET}"
else
    echo -e "${YELLOW}⚠ No GPU detected${RESET}"
    export TORCH_CUDA_ARCH_LIST="8.0;8.6;8.9;9.0;10.0;12.0"
fi
echo

# Set environment variables
export CUDA_HOME="$CUDA_HOME"
export PATH="$CUDA_HOME/bin:$PATH"
export LD_LIBRARY_PATH="$CUDA_HOME/lib64:$LD_LIBRARY_PATH"

# Create build directory
BUILD_DIR="$HOME/trellis2_wheel_build"
mkdir -p "$BUILD_DIR"
cd "$BUILD_DIR"

# Function to build and save wheel with enhanced error handling
build_wheel() {
    local package_name="$1"
    local repo_url="$2"
    local import_name="$3"
    
    echo -e "${GREEN}::::::::::::::: Building ${YELLOW}$package_name${RESET}"
    
    # Validate environment before building
    echo "Validating build environment..."
    if ! "$PYTHON_PATH" -c "import torch; assert torch.cuda.is_available()" 2>/dev/null; then
        echo -e "${RED}✗ CUDA not available in PyTorch - cannot build $package_name${RESET}"
        return 1
    fi
    
    # Clone repository
    if [ -d "$package_name" ]; then
        echo "Removing existing $package_name directory..."
        rm -rf "$package_name"
    fi
    
    echo "Cloning $package_name repository..."
    git clone "$repo_url" "$package_name" --recursive || {
        echo -e "${RED}✗ Failed to clone $package_name${RESET}"
        return 1
    }
    
    cd "$package_name"
    
    # Check for setup.py or pyproject.toml
    if [ ! -f "setup.py" ] && [ ! -f "pyproject.toml" ]; then
        echo -e "${YELLOW}⚠ No setup.py or pyproject.toml found in $package_name${RESET}"
        echo -e "${YELLOW}  This package may not be buildable as a wheel${RESET}"
        cd ..
        return 1
    fi
    
    # Build wheel with proper environment
    echo "Building wheel for $package_name..."
    echo "  CUDA_ARCH_LIST: $TORCH_CUDA_ARCH_LIST"
    echo "  CUDA_HOME: $CUDA_HOME"
    echo "  Python: $PYTHON_PATH"
    
    export TORCH_CUDA_ARCH_LIST="$TORCH_CUDA_ARCH_LIST"
    export CUDA_HOME="$CUDA_HOME"
    export PATH="$CUDA_HOME/bin:$PATH"
    export LD_LIBRARY_PATH="$CUDA_HOME/lib64:$LD_LIBRARY_PATH"
    
    # Try building with verbose output for debugging
    "$PYTHON_PATH" -m pip wheel . --no-build-isolation --no-deps --wheel-dir="$WHEELS_DIR" --verbose || {
        echo -e "${RED}✗ Failed to build wheel for $package_name${RESET}"
        echo -e "${YELLOW}  Common issues:${RESET}"
        echo -e "${YELLOW}  - CUDA version mismatch (see microsoft/TRELLIS.2#19)${RESET}"
        echo -e "${YELLOW}  - Missing build dependencies (gcc, git)${RESET}"
        echo -e "${YELLOW}  - Incompatible GPU architecture${RESET}"
        cd ..
        return 1
    }
    
    echo -e "${GREEN}✓ $package_name wheel built successfully${RESET}"
    cd ..
    return 0
}

# Function to build wheel from a specific branch
build_wheel_branch() {
    local package_name="$1"
    local repo_url="$2"
    local branch="$3"
    local import_name="$4"
    
    echo -e "${GREEN}::::::::::::::: Building ${YELLOW}$package_name${RESET} (branch: $branch)"
    
    # Validate environment before building
    echo "Validating build environment..."
    if ! "$PYTHON_PATH" -c "import torch; assert torch.cuda.is_available()" 2>/dev/null; then
        echo -e "${RED}✗ CUDA not available in PyTorch - cannot build $package_name${RESET}"
        return 1
    fi
    
    # Clone repository with specific branch
    if [ -d "$package_name" ]; then
        echo "Removing existing $package_name directory..."
        rm -rf "$package_name"
    fi
    
    echo "Cloning $package_name repository (branch: $branch)..."
    git clone -b "$branch" "$repo_url" "$package_name" --recursive || {
        echo -e "${RED}✗ Failed to clone $package_name (branch: $branch)${RESET}"
        return 1
    }
    
    cd "$package_name"
    
    # Check for setup.py or pyproject.toml
    if [ ! -f "setup.py" ] && [ ! -f "pyproject.toml" ]; then
        echo -e "${YELLOW}⚠ No setup.py or pyproject.toml found in $package_name${RESET}"
        cd ..
        return 1
    fi
    
    # Build wheel
    echo "Building wheel for $package_name..."
    export TORCH_CUDA_ARCH_LIST="$TORCH_CUDA_ARCH_LIST"
    export CUDA_HOME="$CUDA_HOME"
    export PATH="$CUDA_HOME/bin:$PATH"
    export LD_LIBRARY_PATH="$CUDA_HOME/lib64:$LD_LIBRARY_PATH"
    
    "$PYTHON_PATH" -m pip wheel . --no-build-isolation --no-deps --wheel-dir="$WHEELS_DIR" --verbose || {
        echo -e "${RED}✗ Failed to build wheel for $package_name${RESET}"
        cd ..
        return 1
    }
    
    echo -e "${GREEN}✓ $package_name wheel built successfully${RESET}"
    cd ..
    return 0
}

# Build wheels
echo -e "${GREEN}::::::::::::::: Building Wheels${RESET}"
echo

# nvdiffrast
build_wheel "nvdiffrast" "https://github.com/NVlabs/nvdiffrast" "nvdiffrast"

# cumesh (with submodules)
build_wheel "cumesh" "https://github.com/JeffreyXiang/CuMesh" "cumesh"

# flex_gemm  
build_wheel "flex_gemm" "https://github.com/JeffreyXiang/FlexGEMM" "flex_gemm"

# nvdiffrec_render (from JeffreyXiang's renderutils branch)
build_wheel_branch "nvdiffrec_render" "https://github.com/JeffreyXiang/nvdiffrec" "renderutils" "nvdiffrec_render"

# o_voxel (from Microsoft's TRELLIS.2 repo - bundled source)
build_ovoxel() {
    echo -e "${GREEN}::::::::::::::: Building ${YELLOW}o_voxel${RESET} (from TRELLIS.2 repo)"
    
    if ! "$PYTHON_PATH" -c "import torch; assert torch.cuda.is_available()" 2>/dev/null; then
        echo -e "${RED}✗ CUDA not available in PyTorch - cannot build o_voxel${RESET}"
        return 1
    fi
    
    # Clone TRELLIS.2 repo to get o-voxel source
    if [ -d "TRELLIS.2" ]; then
        echo "Removing existing TRELLIS.2 directory..."
        rm -rf "TRELLIS.2"
    fi
    
    echo "Cloning Microsoft TRELLIS.2 repository with submodules..."
    git clone https://github.com/microsoft/TRELLIS.2 TRELLIS.2 --depth 1 --recursive || {
        echo -e "${RED}✗ Failed to clone TRELLIS.2${RESET}"
        return 1
    }
    
    cd TRELLIS.2
    git submodule update --init --recursive
    
    if [ ! -d "o-voxel" ]; then
        echo -e "${RED}✗ o-voxel folder not found in TRELLIS.2 repo${RESET}"
        cd ..
        return 1
    fi
    
    # Check eigen submodule
    if [ ! -d "o-voxel/third_party/eigen/Eigen" ]; then
        echo -e "${YELLOW}Eigen submodule missing, cloning manually...${RESET}"
        rm -rf o-voxel/third_party/eigen
        git clone https://gitlab.com/libeigen/eigen.git o-voxel/third_party/eigen --depth 1
    fi
    
    cd "o-voxel"
    
    # Install dependencies BEFORE building
    echo "Installing o_voxel dependencies..."
    "$PYTHON_PATH" -m pip install plyfile zstandard
    
    echo "Building wheel for o_voxel..."
    export TORCH_CUDA_ARCH_LIST="$TORCH_CUDA_ARCH_LIST"
    export CUDA_HOME="$CUDA_HOME"
    export PATH="$CUDA_HOME/bin:$PATH"
    export LD_LIBRARY_PATH="$CUDA_HOME/lib64:$LD_LIBRARY_PATH"
    
    "$PYTHON_PATH" -m pip wheel . --no-build-isolation --no-deps --wheel-dir="$WHEELS_DIR" --verbose || {
        echo -e "${RED}✗ Failed to build wheel for o_voxel${RESET}"
        cd "$BUILD_DIR"
        return 1
    }
    
    echo -e "${GREEN}✓ o_voxel wheel built successfully${RESET}"
    cd "$BUILD_DIR"
    return 0
}
build_ovoxel

# List built wheels
echo
echo -e "${GREEN}::::::::::::::: Built Wheels${RESET}"
echo
ls -la "$WHEELS_DIR"/*.whl 2>/dev/null || echo "No wheels found"

# Test wheels with comprehensive validation
echo
echo -e "${GREEN}::::::::::::::: Testing Wheels${RESET}"
echo

successful_wheels=()
failed_wheels=()
core_packages=("cumesh" "nvdiffrast" "flex_gemm" "nvdiffrec_render" "o_voxel")

for wheel in "$WHEELS_DIR"/*.whl; do
    if [ -f "$wheel" ]; then
        wheel_name=$(basename "$wheel")
        package_name=$(basename "$wheel" | cut -d'-' -f1)
        if [[ ! " ${core_packages[*]} " =~ " ${package_name} " ]]; then
            continue
        fi
        
        echo -e "${YELLOW}Testing: $wheel_name${RESET}"
        
        # Check wheel file size
        wheel_size=$(stat -c%s "$wheel" 2>/dev/null || stat -f%z "$wheel" 2>/dev/null)
        if [ "$wheel_size" -lt 1000 ]; then
            echo -e "${RED}✗ Wheel too small (${wheel_size} bytes) - likely corrupted${RESET}"
            failed_wheels+=("$wheel_name")
            continue
        fi
        
        # Test wheel installation
        echo "  Installing wheel..."
        if ! "$PYTHON_PATH" -m pip install "$wheel" --force-reinstall --no-deps 2>/dev/null; then
            echo -e "${RED}✗ Failed to install $wheel_name${RESET}"
            failed_wheels+=("$wheel_name")
            continue
        fi
        
        # Test import with detailed error checking
        echo "  Testing import..."
        if "$PYTHON_PATH" -c "import $package_name; print('✓ Import successful')" 2>/dev/null; then
            # Get version if available
            version=$("$PYTHON_PATH" -c "import $package_name; print(getattr($package_name, '__version__', 'unknown'))" 2>/dev/null || echo "unknown")
            echo -e "${GREEN}✓ $package_name imports successfully (version: $version)${RESET}"
            successful_wheels+=("$wheel_name")
            
            # Test CUDA functionality if available
            if "$PYTHON_PATH" -c "import torch; import $package_name; print('CUDA available:', torch.cuda.is_available())" 2>/dev/null; then
                echo -e "${GREEN}  ✓ CUDA functionality verified${RESET}"
            fi
        else
            echo -e "${RED}✗ $package_name import failed${RESET}"
            failed_wheels+=("$wheel_name")
        fi
        echo
    fi
done

# Summary report
echo -e "${GREEN}::::::::::::::: Build Summary${RESET}"
echo
echo -e "${GREEN}✅ Successful wheels (${#successful_wheels[@]}):${RESET}"
for wheel in "${successful_wheels[@]}"; do
    echo -e "${GREEN}  ✓ $wheel${RESET}"
done

if [ ${#failed_wheels[@]} -gt 0 ]; then
    echo
    echo -e "${RED}❌ Failed wheels (${#failed_wheels[@]}):${RESET}"
    for wheel in "${failed_wheels[@]}"; do
        echo -e "${RED}  ✗ $wheel${RESET}"
    done
fi

echo
echo -e "${GREEN}::::::::::::::: Build Complete${RESET}"
echo -e "${YELLOW}Wheels saved in: $WHEELS_DIR${RESET}"
echo -e "${YELLOW}You can now install these wheels anytime with:${RESET}"
echo -e "${BLUE}cd $WHEELS_DIR && $PYTHON_PATH -m pip install *.whl${RESET}"
echo

if [ -z "$1" ]; then
    echo -e "${GREEN}::::::::::::::: ${YELLOW}Press any key to exit${RESET}"
    read -n 1 -s
fi
