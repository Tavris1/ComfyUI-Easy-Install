#!/bin/bash
echo -ne "\033]0;model2GGUF by ivo v0.2.1\007"
cd "$(dirname "$0")"

# Set colors
green='\033[0;92m'
red='\033[0;91m'
yellow='\033[0;93m'
reset='\033[0m'

# GUI Mode Selection - Set to 1 for GUI, 0 for text mode
GUI_MODE=1

# Check python_embeded folder
PYTHON_PATH="../../python_embeded/python"
if [ ! -f "$PYTHON_PATH" ]; then
    clear
    echo -e "${green}::::::::::::::: Run this file from the ${red}'ComfyUI-Easy-Install/Add-ons/Tools'${green} folder"
    echo -e "${green}::::::::::::::: Press any key to exit...${reset}"
    read -n 1
    exit 1
fi

# Check llama.cpp
if [ ! -f "llama.cpp/llama-quantize" ]; then
    clear
    echo -e "${green}::::::::::::::: ${yellow}llama.cpp${green} bin pack is not in the ${yellow}Add-ons/Tools/llama.cpp/${green} folder"
    echo -e "${green}::::::::::::::: Press any key to exit...${reset}"
    read -n 1
    exit 1
fi

echo
echo -e "${yellow}model2GGUF${green} is a tool that converts ${yellow}safetensors/ckpt${green} models to ${yellow}FP16/BF16 GGUF${green}"
echo
echo -e "${green}More info: ${yellow}https://github.com/city96/ComfyUI-GGUF/blob/main/tools/README.md${reset}"
echo

start=$(date +%s)

# Install ComfyUI-GGUF if not exist
if [ ! -d "../../ComfyUI/custom_nodes/ComfyUI-GGUF" ]; then
    echo -e "${green}::::::::::::::: Installing${yellow} ComfyUI-GGUF${reset}"
    echo
    git clone "https://github.com/city96/ComfyUI-GGUF" ../../ComfyUI/custom_nodes/ComfyUI-GGUF
    $PYTHON_PATH -m pip install -r ../../ComfyUI/custom_nodes/ComfyUI-GGUF/requirements.txt
fi

# Switch ComfyUI-GGUF to the auto_convert branch
pushd ../../ComfyUI/custom_nodes/ComfyUI-GGUF
git checkout -q auto_convert
popd

# File select dialog
echo -e "${green}::::::::::::::: Select input model file${reset}"
input_file=""
if [ "$GUI_MODE" -eq 1 ] && command -v zenity >/dev/null; then
    input_file=$(zenity --file-selection --title="Select input model file" --file-filter="Model files | *.safetensors *.pth *.pt")
else
    read -p "Enter path to input model file: " input_file
fi

if [ -z "$input_file" ]; then
    echo -e "${red}::::::::::::::: No input file selected. Exiting.${reset}"
    echo -e "${green}::::::::::::::: Press any key to exit...${reset}"
    read -n 1
    exit 1
fi

echo
echo -e "${green}::::::::::::::: Selected input file: ${yellow}${input_file}${reset}"

# Quantization selection
quant_method=""
if [ "$GUI_MODE" -eq 1 ] && command -v zenity >/dev/null; then
    quant_method=$(zenity --list --radiolist --title="Select Quantization Method" \
        --column="Pick" --column="Method" \
        TRUE "Q8_0" FALSE "Q6_K" FALSE "Q5_K_M" FALSE "Q5_K_S" FALSE "Q5_1" FALSE "Q5_0" \
        FALSE "Q4_K_M" FALSE "Q4_K_S" FALSE "Q4_1" FALSE "Q4_0" FALSE "Q3_K_M" FALSE "Q3_K_S" FALSE "Q2_K")
else
    echo
    echo -e "${green}::::::::::::::: Select quantization method (ordered by quality)${reset}"
    echo "1 - Q8_0    (highest quality, largest size)"
    echo "2 - Q6_K    (very high quality)"
    echo "3 - Q5_K_M  (high quality)"
    echo "4 - Q5_K_S  (high quality)"
    echo "5 - Q5_1    (high quality)"
    echo "6 - Q5_0    (high quality)"
    echo "7 - Q4_K_M  (medium-high quality)"
    echo "8 - Q4_K_S  (medium-high quality)"
    echo "9 - Q4_1    (medium quality)"
    echo "A - Q4_0    (medium quality)"
    echo "B - Q3_K_M  (low-medium quality)"
    echo "C - Q3_K_S  (low quality)"
    echo "D - Q2_K    (lowest quality, smallest size)"
    echo
    read -p "Enter your choice (1-9, A-D): " choice
    case "$choice" in
        1) quant_method="Q8_0" ;;
        2) quant_method="Q6_K" ;;
        3) quant_method="Q5_K_M" ;;
        4) quant_method="Q5_K_S" ;;
        5) quant_method="Q5_1" ;;
        6) quant_method="Q5_0" ;;
        7) quant_method="Q4_K_M" ;;
        8) quant_method="Q4_K_S" ;;
        9) quant_method="Q4_1" ;;
        A|a) quant_method="Q4_0" ;;
        B|b) quant_method="Q3_K_M" ;;
        C|c) quant_method="Q3_K_S" ;;
        D|d) quant_method="Q2_K" ;;
        *) quant_method="" ;;
    esac
fi

if [ -z "$quant_method" ]; then
    echo -e "${red}::::::::::::::: No quantization method selected. Exiting.${reset}"
    echo -e "${green}::::::::::::::: Press any key to exit...${reset}"
    read -n 1
    exit 1
fi

echo -e "${green}::::::::::::::: Selected quantization: ${yellow}${quant_method}${reset}"

# Generate output file names based on input file
input_dir=$(dirname "$input_file")/
input_name=$(basename "$input_file")
input_name="${input_name%.*}"

fp16_gguf="${input_dir}${input_name}-FP16.gguf"
bf16_gguf="${input_dir}${input_name}-BF16.gguf"
quant_gguf="${input_dir}${input_name}-${quant_method}.gguf"

echo -e "${green}::::::::::::::: Expected GGUF files:${reset}"
echo -e "${yellow}FP16: ${fp16_gguf}${reset}"
echo -e "${yellow}BF16: ${bf16_gguf}${reset}"

# Converting initial model to FP16/BF16 GGUF
echo -e "${green}::::::::::::::: Converting model to GGUF format${reset}"
$PYTHON_PATH ../../ComfyUI/custom_nodes/ComfyUI-GGUF/tools/convert.py --src "$input_file"

# Check which GGUF file was created
intermediate_gguf=""
if [ -f "$bf16_gguf" ]; then
    intermediate_gguf="$bf16_gguf"
    echo -e "${green}::::::::::::::: Found BF16 GGUF file${reset}"
elif [ -f "$fp16_gguf" ]; then
    intermediate_gguf="$fp16_gguf"
    echo -e "${green}::::::::::::::: Found FP16 GGUF file${reset}"
else
    echo -e "${red}::::::::::::::: GGUF conversion failed. Checking for any GGUF files in directory...${reset}"
    ls "${input_dir}"*.gguf
    echo -e "${green}::::::::::::::: Press any key to exit...${reset}"
    read -n 1
    exit 1
fi

# Quantize the model
echo -e "${green}::::::::::::::: Quantizing model to ${quant_method}${reset}"
echo -e "${green}::::::::::::::: Input: ${yellow}${intermediate_gguf}${reset}"
echo -e "${green}::::::::::::::: Output: ${yellow}${quant_gguf}${reset}"
./llama.cpp/llama-quantize "$intermediate_gguf" "$quant_gguf" "$quant_method"

# Check for fix_5d_tensors file and apply fix if found
fix_file=$(ls "${input_dir}"fix_5d_tensors_*.safetensors 2>/dev/null | head -n 1)
if [ -n "$fix_file" ]; then
    echo -e "${green}::::::::::::::: Found fix file: ${yellow}${fix_file}${reset}"
    echo -e "${green}::::::::::::::: Moving fix file to script directory${reset}"
    mv "$fix_file" "./"

    echo -e "${green}::::::::::::::: Applying 5D tensors fix${reset}"
    fixed_gguf="${input_dir}${input_name}-${quant_method}-fixed.gguf"

    echo -e "${green}::::::::::::::: Source: ${yellow}${quant_gguf}${reset}"
    echo -e "${green}::::::::::::::: Destination: ${yellow}${fixed_gguf}${reset}"

    $PYTHON_PATH ../../ComfyUI/custom_nodes/ComfyUI-GGUF/tools/fix_5d_tensors.py --src "$quant_gguf" --dst "$fixed_gguf" --overwrite

    if [ -f "$fixed_gguf" ]; then
        echo -e "${green}::::::::::::::: Fixed GGUF file created successfully: ${yellow}${fixed_gguf}${reset}"
        echo -e "${green}::::::::::::::: Removing original quantized file: ${yellow}${quant_gguf}${reset}"
        rm "$quant_gguf"

        echo -e "${green}::::::::::::::: Renaming fixed file to original quant name${reset}"
        mv "$fixed_gguf" "$quant_gguf"

        echo -e "${green}::::::::::::::: Cleaning up fix files${reset}"
        rm "./$(basename "$fix_file")"

        echo -e "${green}::::::::::::::: Final output file: ${yellow}${quant_gguf}${reset}"
    else
        echo -e "${red}::::::::::::::: Failed to create fixed GGUF file, keeping original${reset}"
    fi
fi

# Switch to ComfyUI-GGUF main branch
echo -e "${green}::::::::::::::: Switch ComfyUI-GGUF to the ${yellow}main branch${reset}"
pushd ../../ComfyUI/custom_nodes/ComfyUI-GGUF
git checkout -q main
popd

end=$(date +%s)
diff=$((end-start))

# Final Messages
echo
echo -e "${green}::::::::::::::: Conversion Complete${reset}"
echo -e "${green}::::::::::::::: Input: ${yellow}${input_file}${reset}"
echo -e "${green}::::::::::::::: Intermediate: ${yellow}${intermediate_gguf}${reset}"
echo -e "${green}::::::::::::::: Output: ${yellow}${quant_gguf}${reset}"
echo -e "${green}::::::::::::::: Quantization: ${yellow}${quant_method}${reset}"
echo
echo -e "${green}::::::::::::::: Total Running Time:${red} ${diff} ${green}seconds${reset}"
echo -e "${green}::::::::::::::: Press any key to exit${reset}"
read -n 1
exit 0
