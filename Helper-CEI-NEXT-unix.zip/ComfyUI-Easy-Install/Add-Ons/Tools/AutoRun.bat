@Echo off&&cd /D %~dp0
Title 'Update Add-ons' v0.1.0 by ivo
:: Pixaroma Community Edition ::

:: Set colors ::
call :set_colors

echo.
echo %green%::: Copying the images into the %yellow%ComfyUI\input%green% folder :::%reset%
echo.

if exist ".\Helper-CEI\*.jpeg" move ".\Helper-CEI\*.jpeg" "..\..\ComfyUI\input\" >nul 2>&1
if exist ".\Helper-CEI\*.jpg" move ".\Helper-CEI\*.jpg" "..\..\ComfyUI\input\" >nul 2>&1
if exist ".\Helper-CEI\*.png" move ".\Helper-CEI\*.png" "..\..\ComfyUI\input\" >nul 2>&1

echo %green%:::::::::::::::: Updating the bat files ::::::::::::::::%reset%
echo.
if exist ".\Helper-CEI\*.bat" move ".\Helper-CEI\*.bat" "..\..\" >nul 2>&1

:set_colors
set warning=[33m
set     red=[91m
set   green=[92m
set  yellow=[93m
set    bold=[97m
set   reset=[0m
goto :eof
