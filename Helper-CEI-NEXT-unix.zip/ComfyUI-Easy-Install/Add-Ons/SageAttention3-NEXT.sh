#!/bin/bash
cd "$(dirname "$0")"

node_name="SageAttention3"
echo -e "\033]0;'$node_name' for 'ComfyUI Easy Install' by ivo\007"

# Pixaroma Community Edition

# Set colors
warning='\033[93m'
red='\033[91m'
green='\033[92m'
yellow='\033[93m'
bold='\033[1m'
reset='\033[0m'

# Set arguments
PIPargs="--no-cache-dir --no-warn-script-location --timeout=1000 --retries 200 --use-pep517"

# Check Add-ons folder
PYTHON_PATH="../python_embeded/python"
if [ ! -f "$PYTHON_PATH" ]; then
    # Check for old virtual environment structure
    if [ -f "../python_embeded/bin/python3" ]; then
        PYTHON_PATH="../python_embeded/bin/python3"
    elif [ -f "../python_embeded_3.12/bin/python3" ]; then
        PYTHON_PATH="../python_embeded_3.12/bin/python3"
    elif [ -f "../python_embeded_3.11/bin/python3" ]; then
        PYTHON_PATH="../python_embeded_3.11/bin/python3"
    # Fallback to python3 if not in the expected embedded path
    elif command -v python3 &> /dev/null; then
        PYTHON_PATH=$(command -v python3)
    else
        clear
        echo -e "${green}::::::::::::::: Run this file from the ${red}'ComfyUI-Easy-Install/Add-ons'${green} folder, or ensure python3 is in your PATH.${reset}"
        echo -e "${green}::::::::::::::: Press any key to exit...${reset}"
        read -n 1 -s
        exit
    fi
fi

# Clear Pip Cache
echo -e "${green}::::::::::::::: Clearing Pip Cache ${yellow}Done${green}${reset}"
echo

# Function to get versions
get_versions() {
    WARNINGS=0
    
    echo -e "${green}::::::::::::::: Checking ${yellow}Python, Torch, CUDA ${green}versions${reset}"
    echo

    PYTHON_VERSION=$("$PYTHON_PATH" --version 2>&1 | cut -d' ' -f2 | cut -d'.' -f1,2)
    TORCH_VERSION=$("$PYTHON_PATH" -c "import torch; print(torch.__version__)" 2>/dev/null | cut -d'.' -f1,2)
    CUDA_VERSION=$("$PYTHON_PATH" -c "import torch; print(torch.version.cuda if torch.cuda.is_available() else 'Not available')" 2>/dev/null | cut -d'.' -f1,2)

    echo -e "${green}::::::::::::::: Python Version:${yellow} $PYTHON_VERSION${reset}"
    echo -e "${green}::::::::::::::: Torch Version:${yellow} $TORCH_VERSION${reset}"
    echo -e "${green}::::::::::::::: CUDA Version:${yellow} $CUDA_VERSION${reset}"
    echo

    # Check Python version requirement (>=3.11)
    if [[ "$PYTHON_VERSION" < "3.11" ]]; then
        echo -e "${warning}WARNING: ${red}Python $PYTHON_VERSION is not supported. ${green}SageAttention3 requires Python >=3.11${reset}"
        WARNINGS=1
    fi

    # Check Torch version requirement (>=2.8)
    if [[ "$TORCH_VERSION" < "2.8" ]]; then
        echo -e "${warning}WARNING: ${red}Torch $TORCH_VERSION is not supported. ${green}SageAttention3 requires Torch >=2.8${reset}"
        WARNINGS=1
    fi

    # Check CUDA version requirement (>=12.8)
    if [[ "$CUDA_VERSION" < "12.8" ]]; then
        echo -e "${warning}WARNING: ${red}CUDA $CUDA_VERSION is not supported. ${green}SageAttention3 requires CUDA >=12.8${reset}"
        WARNINGS=1
    fi

    if [ $WARNINGS -eq 0 ]; then
        echo -e "${green}::::::::::::::: ${bold}All versions are supported! ${reset}"
        echo
    else
        echo
        echo -e "${red}::::::::::::::: Press any key to exit${reset}"
        read -n 1 -s
        exit
    fi
}

get_versions

# Check for Python development headers
echo -e "${green}::::::::::::::: Checking ${yellow}Python development headers${reset}"
echo

if ! "$PYTHON_PATH" -c "import sysconfig; import os; print(os.path.exists(os.path.join(sysconfig.get_path('include'), 'Python.h')))" 2>/dev/null | grep -q "True"; then
    echo -e "${warning}WARNING: ${red}Python development headers (Python.h) not found.${reset}"
    echo
    echo -e "${yellow}SageAttention3 requires Python development headers to compile C++ extensions.${reset}"
    echo -e "${yellow}Please install them using one of these methods:${reset}"
    echo
    echo -e "${green}Ubuntu/Debian:${reset}"
    echo -e "  ${bold}sudo apt-get update && sudo apt-get install -y python3.11-dev${reset} (for Python 3.11)"
    echo -e "  ${bold}sudo apt-get update && sudo apt-get install -y python3.12-dev${reset} (for Python 3.12)"
    echo -e "  ${bold}sudo apt-get update && sudo apt-get install -y python3.13-dev${reset} (for Python 3.13)"
    echo
    echo -e "${green}RHEL/CentOS/Fedora:${reset}"
    echo -e "  ${bold}sudo yum install -y python3.11-devel${reset} (for Python 3.11)"
    echo -e "  ${bold}sudo yum install -y python3.12-devel${reset} (for Python 3.12)"
    echo -e "  ${bold}sudo yum install -y python3.13-devel${reset} (for Python 3.13)"
    echo
    echo -e "${green}Arch Linux:${reset}"
    echo -e "  ${bold}sudo pacman -S python${reset}"
    echo
    echo -e "${red}::::::::::::::: Press any key to exit${reset}"
    read -n 1 -s
    exit 1
fi

echo -e "${green}::::::::::::::: Python development headers ${yellow}found!${reset}"
echo

# Erasing ~* folders
find "../python_embeded/lib/" -type d -name "~*" -exec rm -rf {} + 2>/dev/null

# Installing build dependencies
echo -e "${green}::::::::::::::: Installing${yellow} build dependencies${reset}"
echo
"$PYTHON_PATH" -m pip install --upgrade wheel setuptools $PIPargs
echo

# Installing SageAttention3
echo -e "${green}::::::::::::::: Installing${yellow} $node_name${reset}"
echo

# Create wheels directory for saving built wheels
WHEELS_DIR="../wheels"
mkdir -p "$WHEELS_DIR"
echo -e "${yellow}   ✓ Created wheels directory: $WHEELS_DIR${RESET}"

# Install and save the built wheel
echo -e "${cyan}   Building and installing SageAttention3...${RESET}"
"$PYTHON_PATH" -m pip install --upgrade --no-build-isolation git+https://github.com/thu-ml/SageAttention.git $PIPargs

# Find and copy the built wheel to wheels directory
echo -e "${cyan}   Saving built wheel...${RESET}"
sleep 2  # Give pip time to finish

# Search for the wheel in common locations
WHEEL_FOUND=""
for cache_dir in ~/.cache/pip/wheels /tmp/pip-ephem-wheel-cache-*; do
    if [ -d "$cache_dir" ]; then
        WHEEL_PATH=$(find "$cache_dir" -name "*sageattention-*.whl" 2>/dev/null | head -1)
        if [ -n "$WHEEL_PATH" ]; then
            cp "$WHEEL_PATH" "$WHEELS_DIR/"
            WHEEL_FOUND=$(basename "$WHEEL_PATH")
            echo -e "${green}   ✓ Saved wheel: $WHEEL_FOUND${RESET}"
            echo -e "${yellow}   Location: $WHEELS_DIR/$WHEEL_FOUND${RESET}"
            break
        fi
    fi
done

# If not found in cache, try to find in /tmp
if [ -z "$WHEEL_FOUND" ]; then
    WHEEL_PATH=$(find /tmp -name "*sageattention-*.whl" 2>/dev/null | head -1)
    if [ -n "$WHEEL_PATH" ]; then
        cp "$WHEEL_PATH" "$WHEELS_DIR/"
        WHEEL_FOUND=$(basename "$WHEEL_PATH")
        echo -e "${green}   ✓ Saved wheel: $WHEEL_FOUND${RESET}"
        echo -e "${yellow}   Location: $WHEELS_DIR/$WHEEL_FOUND${RESET}"
    fi
fi

if [ -z "$WHEEL_FOUND" ]; then
    echo -e "${yellow}   ⚠ Wheel not found in cache (may have been cleaned)${RESET}"
    echo -e "${yellow}   To build manually: git clone https://github.com/thu-ml/SageAttention.git && cd SageAttention && python -m build --wheel${RESET}"
fi

echo

# Installing Triton (version based on Torch version)
echo -e "${green}::::::::::::::: Installing${yellow} Triton${reset}"
echo
if [ "$TORCH_VERSION" = "2.9" ]; then
    "$PYTHON_PATH" -I -m pip install --upgrade --force-reinstall triton==3.5.1 $PIPargs
elif [ "$TORCH_VERSION" = "2.8" ]; then
    "$PYTHON_PATH" -I -m pip install --upgrade --force-reinstall triton==3.4.0 $PIPargs
elif [ "$TORCH_VERSION" = "2.7" ]; then
    "$PYTHON_PATH" -I -m pip install --upgrade --force-reinstall triton==3.3.1 $PIPargs
fi
echo

# Clone SageAttention repository if not exists
echo -e "${green}::::::::::::::: Cloning${yellow} SageAttention repository${reset}"
echo
if [ ! -d "../SageAttention" ]; then
    git clone https://github.com/thu-ml/SageAttention ../SageAttention
else
    echo -e "${yellow}SageAttention repository already exists, updating...${reset}"
    cd ../SageAttention
    git pull
    cd ../Add-Ons
fi
echo

# Installing SageAttention3 from source
echo -e "${green}::::::::::::::: Installing${yellow} $node_name${reset}"
echo

# Store absolute path to Python before changing directories
PYTHON_ABS_PATH=$(realpath "$PYTHON_PATH")

# Check for CUDA toolkit and set CUDA_HOME
echo -e "${green}::::::::::::::: Checking${yellow} CUDA toolkit${reset}"
echo

# Add CUDA to PATH if not already there
if [ -d "/usr/local/cuda/bin" ] && [ ":$PATH:" != *":/usr/local/cuda/bin:"* ]; then
    export PATH="/usr/local/cuda/bin:$PATH"
    echo -e "${yellow}   Added CUDA to PATH${RESET}"
fi

CUDA_HOME=""
if command -v nvcc &> /dev/null; then
    CUDA_PATH=$(which nvcc)
    CUDA_HOME=$(dirname "$CUDA_PATH")
    echo -e "${green}   ✓ Found CUDA at: ${YELLOW}$CUDA_PATH${RESET}"
    echo -e "${green}   ✓ CUDA_HOME set to: ${YELLOW}$CUDA_HOME${RESET}"
    
    # Check GPU compatibility for SageAttention3
    echo -e "${green}::::::::::::::: Checking${yellow} GPU compatibility${reset}"
    echo
    
    # Get GPU information
    if command -v nvidia-smi &> /dev/null; then
        GPU_NAME=$(nvidia-smi --query-gpu=name --format=csv,noheader,nounits | head -1)
        GPU_ARCH=$(nvidia-smi --query-gpu=compute_cap --format=csv,noheader,nounits | head -1)
        echo -e "${green}   ✓ GPU detected: ${YELLOW}$GPU_NAME${RESET}"
        echo -e "${green}   ✓ Compute Capability: ${YELLOW}$GPU_ARCH${RESET}"
        echo
        
        # Check if GPU is supported (SageAttention3 requires SM_120 - RTX 50x series only)
        case "$GPU_NAME" in
            *"RTX 5090"*|*"RTX 5080"*|*"RTX 5070"*|*"RTX 5060"*)
                echo -e "${green}   ✓ GPU is supported by SageAttention3 (SM_120 architecture)${RESET}"
                ;;
            *"RTX 40"*|*"RTX 30"*|*"RTX 20"*|*"GTX"*|*"Tesla"*)
                echo -e "${red}   ✗ GPU is NOT supported by SageAttention3${reset}"
                echo -e "${yellow}SageAttention3 requires SM_120 architecture (RTX 50x series only)${reset}"
                echo -e "${yellow}Your GPU ($GPU_NAME) has SM_$GPU_ARCH architecture${reset}"
                echo
                echo -e "${green}Recommended alternatives:${reset}"
                echo -e "${yellow}  - Use SageAttention2 v2.2.0 for RTX 40xx/30xx/20xx series${reset}"
                echo -e "${yellow}  - Use SageAttention2++ for better compatibility${reset}"
                echo
                echo -e "${red}::::::::::::::: Press any key to exit${reset}"
                read -n 1 -s
                exit 1
                ;;
            *)
                echo -e "${warning}WARNING: ${red}Unknown GPU compatibility${reset}"
                echo -e "${yellow}SageAttention3 requires SM_120 (RTX 50x series)${reset}"
                echo -e "${yellow}Your GPU: $GPU_NAME (SM_$GPU_ARCH)${reset}"
                echo
                echo -e "${yellow}Continue anyway? Not recommended (y/N)${RESET}"
                read -r continue_anyway
                if [[ ! "$continue_anyway" =~ ^[Yy]$ ]]; then
                    echo -e "${red}::::::::::::::: Installation cancelled${reset}"
                    exit 1
                fi
                ;;
        esac
    else
        echo -e "${warning}WARNING: ${red}nvidia-smi not found, cannot verify GPU${reset}"
    fi
    echo
else
    echo -e "${warning}WARNING: ${red}CUDA toolkit (nvcc) not found in PATH${reset}"
    echo -e "${yellow}Trying to locate CUDA installation...${reset}"
    
    # Common CUDA installation paths
    CUDA_PATHS=(
        "/usr/local/cuda"
        "/usr/cuda"
        "/opt/cuda"
        "$HOME/cuda"
    )
    
    for path in "${CUDA_PATHS[@]}"; do
        if [ -f "$path/bin/nvcc" ]; then
            CUDA_HOME="$path"
            export PATH="$CUDA_HOME/bin:$PATH"
            echo -e "${green}   ✓ Found CUDA at: ${YELLOW}$CUDA_HOME/bin/nvcc${RESET}"
            break
        fi
    done
    
    if [ -z "$CUDA_HOME" ]; then
        echo -e "${red}   ✗ CUDA toolkit not found. Please install CUDA development toolkit.${reset}"
        echo
        echo -e "${yellow}To install CUDA development toolkit:${reset}"
        echo
        echo -e "${green}Option 1: Add NVIDIA repository (recommended):${reset}"
        echo -e "  ${bold}wget https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_64/cuda-keyring_1.1-1_all.deb${reset}"
        echo -e "  ${bold}sudo dpkg -i cuda-keyring_1.1-1_all.deb${reset}"
        echo -e "  ${bold}sudo apt-get update${reset}"
        echo -e "  ${bold}sudo apt-get install -y cuda-toolkit-${reset}"
        echo
        echo -e "${green}Option 2: Download from NVIDIA:${reset}"
        echo -e "  ${bold}https://developer.nvidia.com/cuda-downloads${reset}"
        echo
        echo -e "${green}Option 3: Use conda (if available):${reset}"
        echo -e "  ${bold}conda install -c nvidia cuda-toolkit${reset}"
        echo
        echo -e "${yellow}Note: In LXC containers, you may need to:${reset}"
        echo -e "  - Install from NVIDIA's official repository"
        echo -e "  - Use host CUDA by mounting /usr/local/cuda"
        echo -e "  - Install CUDA in a compatible location"
        echo
        echo -e "${red}::::::::::::::: Press any key to exit${reset}"
        read -n 1 -s
        exit 1
    fi
fi
echo

cd ../SageAttention/sageattention3_blackwell
export CUDA_HOME="$CUDA_HOME"
"$PYTHON_ABS_PATH" setup.py install $PIPargs
cd ../Add-Ons
echo

# Creating run_nvidia_gpu_SageAttention3.sh file
echo
echo -e "${green}::::::::::::::: Creating${yellow} run_nvidia_gpu_SageAttention3.sh${reset}"
echo
echo "#!/bin/bash" > ../run_nvidia_gpu_SageAttention3.sh
echo "cd \"\$(dirname \"\$0\")\"" >> ../run_nvidia_gpu_SageAttention3.sh
echo "echo \"Title ComfyUI-Easy-Install\"" >> ../run_nvidia_gpu_SageAttention3.sh

# Add listening address configuration
echo "" >> ../run_nvidia_gpu_SageAttention3.sh
echo "# Set listening address (configurable)" >> ../run_nvidia_gpu_SageAttention3.sh
echo "LISTEN_CONFIG_FILE=\".listen_address_config\"" >> ../run_nvidia_gpu_SageAttention3.sh
echo "LISTEN_ADDRESS=\"\${LISTEN_ADDRESS:-0.0.0.0}\"" >> ../run_nvidia_gpu_SageAttention3.sh
echo "" >> ../run_nvidia_gpu_SageAttention3.sh
echo "# Load saved setting if exists" >> ../run_nvidia_gpu_SageAttention3.sh
echo "if [ -f \"\$LISTEN_CONFIG_FILE\" ]; then" >> ../run_nvidia_gpu_SageAttention3.sh
echo "    LISTEN_ADDRESS=\$(cat \"\$LISTEN_CONFIG_FILE\")" >> ../run_nvidia_gpu_SageAttention3.sh
echo "fi" >> ../run_nvidia_gpu_SageAttention3.sh
echo "" >> ../run_nvidia_gpu_SageAttention3.sh
echo "echo \"Listening on: \$LISTEN_ADDRESS\"" >> ../run_nvidia_gpu_SageAttention3.sh

# Detect Python executable for the run script
echo "# Detect Python executable" >> ../run_nvidia_gpu_SageAttention3.sh
echo "PYTHON_EXEC=\"\"" >> ../run_nvidia_gpu_SageAttention3.sh
echo "if [ -f \"python_embeded/python\" ]; then" >> ../run_nvidia_gpu_SageAttention3.sh
echo "    PYTHON_EXEC=\"./python_embeded/python\"" >> ../run_nvidia_gpu_SageAttention3.sh
echo "elif [ -d \"python_embeded_3.12/bin\" ]; then" >> ../run_nvidia_gpu_SageAttention3.sh
echo "    PYTHON_EXEC=\"./python_embeded_3.12/bin/python3\"" >> ../run_nvidia_gpu_SageAttention3.sh
echo "elif [ -d \"python_embeded_3.11/bin\" ]; then" >> ../run_nvidia_gpu_SageAttention3.sh
echo "    PYTHON_EXEC=\"./python_embeded_3.11/bin/python3\"" >> ../run_nvidia_gpu_SageAttention3.sh
echo "elif [ -d \"python_embeded/bin\" ]; then" >> ../run_nvidia_gpu_SageAttention3.sh
echo "    PYTHON_EXEC=\"./python_embeded/bin/python3\"" >> ../run_nvidia_gpu_SageAttention3.sh
echo "else" >> ../run_nvidia_gpu_SageAttention3.sh
echo "    PYTHON_EXEC=\"python3\"" >> ../run_nvidia_gpu_SageAttention3.sh
echo "fi" >> ../run_nvidia_gpu_SageAttention3.sh
echo "" >> ../run_nvidia_gpu_SageAttention3.sh
echo "\$PYTHON_EXEC -W ignore::FutureWarning ComfyUI/main.py --use-sage-attention3 --listen \"\$LISTEN_ADDRESS\"" >> ../run_nvidia_gpu_SageAttention3.sh

chmod +x ../run_nvidia_gpu_SageAttention3.sh

# Final Messages
echo
echo -e "${GREEN}:::::::::::::::${YELLOW} ${node_name} ${GREEN}Installation Complete${reset}"
echo
echo -e "${yellow}Note: SageAttention3 works best for:${reset}"
echo -e "${yellow}  - Video generation models: CogVideoX-2B, HunyuanVideo, Mochi${reset}"
echo -e "${yellow}  - Image generation models: Flux, Stable-Diffusion3.5${reset}"
echo
echo -e "${yellow}For other models, consider using SageAttention2++ at first/last timesteps${reset}"
echo
if [ -z "$1" ]; then
    echo -e "${green}::::::::::::::: ${yellow}Press any key to exit${reset}"
    read -n 1 -s
    exit
fi
