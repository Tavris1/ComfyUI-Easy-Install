#!/bin/bash

# Fixed Trellis2 build script - installs packages properly
# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color
RESET='\033[0m'

# Get script directory and Python path
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_PATH="$SCRIPT_DIR/../python_embeded/python"
PIPargs="--upgrade --no-cache-dir"

echo -e "${GREEN}::::::::::::::: Trellis2 Fixed Build Script${RESET}"
echo -e "${GREEN}::::::::::::::: Using Python: ${YELLOW}$PYTHON_PATH${RESET}"
echo

# Check CUDA toolkit
if [ ! -d "/usr/local/cuda" ]; then
    echo -e "${RED}ERROR: CUDA toolkit not found at /usr/local/cuda${RESET}"
    exit 1
fi

CUDA_HOME="/usr/local/cuda"
echo -e "${GREEN}✓ CUDA Home: ${YELLOW}$CUDA_HOME${RESET}"

# Get CUDA version
CUDA_VERSION=$("$PYTHON_PATH" -c "import torch; print(torch.version.cuda if torch.cuda.is_available() else 'Not available')" 2>/dev/null)
echo -e "${GREEN}✓ CUDA Version: ${YELLOW}$CUDA_VERSION${RESET}"

# Detect GPU and set optimal CUDA architecture
echo -e "${GREEN}::::::::::::::: Detecting GPU${RESET}"
if "$PYTHON_PATH" -c "import torch; print(torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'No GPU')" 2>/dev/null; then
    GPU_NAME=$("$PYTHON_PATH" -c "import torch; print(torch.cuda.get_device_name(0))" 2>/dev/null)
    GPU_ARCH=$("$PYTHON_PATH" -c "import torch; print(torch.cuda.get_device_capability(0)[0]*10 + torch.cuda.get_device_capability(0)[1])" 2>/dev/null)
    
    echo -e "${GREEN}✓ GPU Detected: ${YELLOW}$GPU_NAME${RESET}"
    echo -e "${GREEN}✓ GPU Architecture: ${YELLOW}SM_$GPU_ARCH${RESET}"
    
    # Set optimal CUDA architecture based on detected GPU
    case "$GPU_ARCH" in
        "86")  # RTX 30xx series (Ampere)
            export TORCH_CUDA_ARCH_LIST="8.0;8.6"
            echo -e "${GREEN}✓ CUDA Architecture: ${YELLOW}Optimized for RTX 30xx (Ampere)${RESET}"
            ;;
        "89")  # RTX 40xx series (Ada Lovelace)
            export TORCH_CUDA_ARCH_LIST="8.0;8.6;8.9"
            echo -e "${GREEN}✓ CUDA Architecture: ${YELLOW}Optimized for RTX 40xx (Ada Lovelace)${RESET}"
            ;;
        "80")  # RTX 20xx series (Turing)
            export TORCH_CUDA_ARCH_LIST="8.0;8.6"
            echo -e "${GREEN}✓ CUDA Architecture: ${YELLOW}Optimized for RTX 20xx (Turing)${RESET}"
            ;;
        *)
            export TORCH_CUDA_ARCH_LIST="8.0;8.6;8.9;9.0;10.0;12.0"
            echo -e "${YELLOW}✓ CUDA Architecture: ${YELLOW}Using universal compatibility mode${RESET}"
            ;;
    esac
else
    echo -e "${YELLOW}⚠ No GPU detected, using universal CUDA architecture${RESET}"
    export TORCH_CUDA_ARCH_LIST="8.0;8.6;8.9;9.0;10.0;12.0"
fi
echo

# Set environment variables
export CUDA_HOME="$CUDA_HOME"
export PATH="$CUDA_HOME/bin:$PATH"
export LD_LIBRARY_PATH="$CUDA_HOME/lib64:$LD_LIBRARY_PATH"

# Create persistent build directory
BUILD_DIR="$HOME/trellis2_build_persistent"
mkdir -p "$BUILD_DIR"
cd "$BUILD_DIR"

echo -e "${GREEN}::::::::::::::: Building Trellis2 Dependencies (Fixed)${RESET}"
echo

# Function to build package properly
build_package_fixed() {
    local package_name="$1"
    local repo_url="$2"
    
    echo -e "${GREEN}::::::::::::::: Building ${YELLOW}$package_name${RESET}"
    
    # Clone or update repository
    if [ -d "$package_name" ]; then
        echo "Updating existing $package_name repository..."
        cd "$package_name"
        git pull origin main 2>/dev/null || git pull origin master 2>/dev/null || echo "Using existing repository"
        # Update submodules if they exist
        if [ -f ".gitmodules" ]; then
            echo "Updating submodules..."
            git submodule update --init --recursive 2>/dev/null || echo "Submodule update failed"
        fi
    else
        echo "Cloning $package_name repository..."
        git clone "$repo_url" "$package_name" --recursive || {
            echo -e "${RED}✗ Failed to clone $package_name repository${RESET}"
            return 1
        }
        cd "$package_name"
    fi
    
    # Build and install normally (not editable)
    echo "Building and installing $package_name..."
    export TORCH_CUDA_ARCH_LIST="$TORCH_CUDA_ARCH_LIST"
    export CUDA_HOME="$CUDA_HOME"
    
    "$PYTHON_PATH" -m pip install . --no-build-isolation $PIPargs || {
        echo -e "${RED}✗ Failed to build/install $package_name${RESET}"
        cd ..
        return 1
    }
    
    echo -e "${GREEN}✓ $package_name built and installed successfully${RESET}"
    cd ..
    return 0
}

# Build nvdiffrast
build_package_fixed "nvdiffrast" "https://github.com/NVlabs/nvdiffrast"

# Build cumesh (requires submodules)
echo -e "${YELLOW}Note: cumesh requires submodules (cubvh dependency)${RESET}"
build_package_fixed "cumesh" "https://github.com/JeffreyXiang/CuMesh" || {
    echo -e "${YELLOW}✗ cumesh failed (missing submodules or build issue)${RESET}"
}

# Build flex_gemm
build_package_fixed "flex_gemm" "https://github.com/JeffreyXiang/FlexGEMM"

# Try nvdiffrec (may fail due to package structure)
echo -e "${YELLOW}Note: nvdiffrec may fail due to package structure issues${RESET}"
build_package_fixed "nvdiffrec" "https://github.com/NVlabs/nvdiffrec" || {
    echo -e "${YELLOW}✗ nvdiffrec failed (expected - package structure issue)${RESET}"
}

# Skip o_voxel (Microsoft internal package)
echo -e "${YELLOW}✗ o_voxel skipped (Microsoft internal package, not publicly available)${RESET}"

# Verify installations
echo
echo -e "${GREEN}::::::::::::::: Verifying Installations${RESET}"
echo

# Clear Pip Cache - DISABLED to avoid slow connection issues
# echo -e "${green}::::::::::::::: Clearing Pip Cache ${yellow}Done${green}${reset}"
# echo

packages=("nvdiffrast" "flex_gemm" "cumesh" "nvdiffrec")
for package in "${packages[@]}"; do
    if "$PYTHON_PATH" -c "import $package" 2>/dev/null; then
        version=$("$PYTHON_PATH" -c "import $package; print($package.__version__)" 2>/dev/null || echo "unknown")
        echo -e "${GREEN}✓ $package installed successfully (version: $version)${RESET}"
    else
        case "$package" in
            "cumesh")
                echo -e "${YELLOW}✗ cumesh not available (submodule issue or build problem)${RESET}"
                ;;
            "nvdiffrec")
                echo -e "${YELLOW}✗ nvdiffrec not available (package structure issue)${RESET}"
                ;;
            *)
                echo -e "${RED}✗ $package installation failed${RESET}"
                ;;
        esac
    fi
done

echo -e "${YELLOW}Note: o_voxel is a Microsoft internal package and not publicly available${RESET}"

echo
echo -e "${GREEN}::::::::::::::: Build Complete${RESET}"
echo -e "${YELLOW}Note: Build directory kept at $BUILD_DIR for reference${RESET}"
echo

if [ -z "$1" ]; then
    echo -e "${GREEN}::::::::::::::: ${YELLOW}Press any key to exit${RESET}"
    read -n 1 -s
fi
