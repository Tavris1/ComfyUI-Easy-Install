#!/bin/bash
cd "$(dirname "$0")"

node_name="SageAttention2 v2.2.0"
echo -e "\033]0;'$node_name' for 'ComfyUI Easy Install' by ivo\007"

# Pixaroma Community Edition

# Set colors
warning='\033[93m'
red='\033[91m'
green='\033[92m'
yellow='\033[93m'
bold='\033[1m'
reset='\033[0m'

# Set arguments
PIPargs="--no-cache-dir --no-warn-script-location --timeout=1000 --retries 200 --use-pep517"

# Check Add-ons folder
PYTHON_PATH="../python_embeded/python"
if [ ! -f "$PYTHON_PATH" ]; then
    # Check for old virtual environment structure
    if [ -f "../python_embeded/bin/python3" ]; then
        PYTHON_PATH="../python_embeded/bin/python3"
    elif [ -f "../python_embeded_3.12/bin/python3" ]; then
        PYTHON_PATH="../python_embeded_3.12/bin/python3"
    elif [ -f "../python_embeded_3.11/bin/python3" ]; then
        PYTHON_PATH="../python_embeded_3.11/bin/python3"
    # Fallback to python3 if not in the expected embedded path
    elif command -v python3 &> /dev/null; then
        PYTHON_PATH=$(command -v python3)
    else
        clear
        echo -e "${green}::::::::::::::: Run this file from the ${red}'ComfyUI-Easy-Install/Add-ons'${green} folder, or ensure python3 is in your PATH.${reset}"
        echo -e "${green}::::::::::::::: Press any key to exit...${reset}"
        read -n 1 -s
        exit
    fi
fi

# Clear Pip Cache
echo -e "${green}::::::::::::::: Clearing Pip Cache ${yellow}Done${green}${reset}"
echo

# Function to get versions
get_versions() {
    WARNINGS=0
    
    echo -e "${green}::::::::::::::: Checking ${yellow}Python, Torch, CUDA ${green}versions${reset}"
    echo

    PYTHON_VERSION=$("$PYTHON_PATH" --version 2>&1 | cut -d' ' -f2 | cut -d'.' -f1,2)
    TORCH_VERSION=$("$PYTHON_PATH" -c "import torch; print(torch.__version__)" 2>/dev/null | cut -d'.' -f1,2)
    CUDA_VERSION=$("$PYTHON_PATH" -c "import torch; print(torch.version.cuda if torch.cuda.is_available() else 'Not available')" 2>/dev/null | cut -d'.' -f1,2)

    echo -e "${green}::::::::::::::: Python Version:${yellow} $PYTHON_VERSION${reset}"
    echo -e "${green}::::::::::::::: Torch Version:${yellow} $TORCH_VERSION${reset}"
    echo -e "${green}::::::::::::::: CUDA Version:${yellow} $CUDA_VERSION${reset}"
    echo

    # Check Python version requirement (>=3.8)
    if [[ "$(echo "$PYTHON_VERSION" | cut -d'.' -f1)" -lt 3 ]] || [[ "$(echo "$PYTHON_VERSION" | cut -d'.' -f1)" -eq 3 && "$(echo "$PYTHON_VERSION" | cut -d'.' -f2)" -lt 8 ]]; then
        echo -e "${warning}WARNING: ${red}Python $PYTHON_VERSION is not supported. ${green}SageAttention2 requires Python >=3.8${reset}"
        WARNINGS=1
    fi

    # Check Torch version requirement (>=2.0)
    if [[ "$(echo "$TORCH_VERSION" | cut -d'.' -f1)" -lt 2 ]]; then
        echo -e "${warning}WARNING: ${red}Torch $TORCH_VERSION is not supported. ${green}SageAttention2 requires Torch >=2.0${reset}"
        WARNINGS=1
    fi

    # Check CUDA version requirement (>=11.8)
    if [[ "$CUDA_VERSION" != "Not available" ]] && [[ "$CUDA_VERSION" < "11.8" ]]; then
        echo -e "${warning}WARNING: ${red}CUDA $CUDA_VERSION may not be fully supported. ${green}SageAttention2 recommends CUDA >=11.8${reset}"
        WARNINGS=1
    fi

    if [ $WARNINGS -eq 0 ]; then
        echo -e "${green}::::::::::::::: ${bold}All versions are supported! ${reset}"
        echo
    else
        echo
        echo -e "${yellow}Note: SageAttention2 has broader GPU compatibility than SageAttention3${reset}"
        echo -e "${yellow}Supports RTX 20xx/30xx/40xx series and GTX series${reset}"
        echo
        echo -e "${red}::::::::::::::: Press any key to exit${reset}"
        read -n 1 -s
        exit
    fi
}

get_versions

# Check for Python development headers
echo -e "${green}::::::::::::::: Checking ${yellow}Python development headers${reset}"
echo

if ! "$PYTHON_PATH" -c "import sysconfig; import os; print(os.path.exists(os.path.join(sysconfig.get_path('include'), 'Python.h')))" 2>/dev/null | grep -q "True"; then
    echo -e "${warning}WARNING: ${red}Python development headers (Python.h) not found.${reset}"
    echo
    echo -e "${yellow}SageAttention2 requires Python development headers to compile C++ extensions.${reset}"
    echo -e "${yellow}Please install them using one of these methods:${reset}"
    echo
    echo -e "${green}Ubuntu/Debian:${reset}"
    echo -e "  ${bold}sudo apt-get update && sudo apt-get install -y python3.11-dev${reset} (for Python 3.11)"
    echo -e "  ${bold}sudo apt-get update && sudo apt-get install -y python3.12-dev${reset} (for Python 3.12)"
    echo -e "  ${bold}sudo apt-get update && sudo apt-get install -y python3.13-dev${reset} (for Python 3.13)"
    echo
    echo -e "${green}RHEL/CentOS/Fedora:${reset}"
    echo -e "  ${bold}sudo yum install -y python3.11-devel${reset} (for Python 3.11)"
    echo -e "  ${bold}sudo yum install -y python3.12-devel${reset} (for Python 3.12)"
    echo -e "  ${bold}sudo yum install -y python3.13-devel${reset} (for Python 3.13)"
    echo
    echo -e "${green}Arch Linux:${reset}"
    echo -e "  ${bold}sudo pacman -S python${reset}"
    echo
    echo -e "${red}::::::::::::::: Press any key to exit${reset}"
    read -n 1 -s
    exit 1
fi

echo -e "${green}::::::::::::::: Python development headers ${yellow}found!${reset}"
echo

# Erasing ~* folders
find "../python_embeded/lib/" -type d -name "~*" -exec rm -rf {} + 2>/dev/null

# Installing build dependencies
echo -e "${green}::::::::::::::: Installing${yellow} build dependencies${reset}"
echo
"$PYTHON_PATH" -m pip install --upgrade wheel setuptools $PIPargs
echo

# Installing Triton (version based on Torch version)
echo -e "${green}::::::::::::::: Installing${yellow} Triton${reset}"
echo
if [ "$TORCH_VERSION" = "2.9" ]; then
    "$PYTHON_PATH" -I -m pip install --upgrade --force-reinstall triton==3.5.1 $PIPargs
elif [ "$TORCH_VERSION" = "2.8" ]; then
    "$PYTHON_PATH" -I -m pip install --upgrade --force-reinstall triton==3.4.0 $PIPargs
elif [ "$TORCH_VERSION" = "2.7" ]; then
    "$PYTHON_PATH" -I -m pip install --upgrade --force-reinstall triton==3.3.1 $PIPargs
elif [ "$TORCH_VERSION" = "2.6" ]; then
    "$PYTHON_PATH" -I -m pip install --upgrade --force-reinstall triton==3.2.0 $PIPargs
else
    "$PYTHON_PATH" -I -m pip install --upgrade --force-reinstall triton $PIPargs
fi
echo

# Installing SageAttention2 v2.2.0
echo -e "${green}::::::::::::::: Installing${yellow} $node_name${reset}"
echo
"$PYTHON_PATH" -m pip install --upgrade --no-build-isolation git+https://github.com/thu-ml/SageAttention@v2.2.0 $PIPargs
echo

# Creating run_nvidia_gpu_SageAttention2.sh file
echo
echo -e "${green}::::::::::::::: Creating${yellow} run_nvidia_gpu_SageAttention2.sh${reset}"
echo
echo "#!/bin/bash" > ../run_nvidia_gpu_SageAttention2.sh
echo "cd \"\$(dirname \"\$0\")\"" >> ../run_nvidia_gpu_SageAttention2.sh
echo "echo \"Title ComfyUI-Easy-Install\"" >> ../run_nvidia_gpu_SageAttention2.sh

# Add listening address configuration
echo "" >> ../run_nvidia_gpu_SageAttention2.sh
echo "# Set listening address (configurable)" >> ../run_nvidia_gpu_SageAttention2.sh
echo "LISTEN_CONFIG_FILE=\".listen_address_config\"" >> ../run_nvidia_gpu_SageAttention2.sh
echo "LISTEN_ADDRESS=\"\${LISTEN_ADDRESS:-0.0.0.0}\"" >> ../run_nvidia_gpu_SageAttention2.sh
echo "" >> ../run_nvidia_gpu_SageAttention2.sh
echo "# Load saved setting if exists" >> ../run_nvidia_gpu_SageAttention2.sh
echo "if [ -f \"\$LISTEN_CONFIG_FILE\" ]; then" >> ../run_nvidia_gpu_SageAttention2.sh
echo "    LISTEN_ADDRESS=\$(cat \"\$LISTEN_CONFIG_FILE\")" >> ../run_nvidia_gpu_SageAttention2.sh
echo "fi" >> ../run_nvidia_gpu_SageAttention2.sh
echo "" >> ../run_nvidia_gpu_SageAttention2.sh
echo "echo \"Listening on: \$LISTEN_ADDRESS\"" >> ../run_nvidia_gpu_SageAttention2.sh

# Detect Python executable for the run script
echo "# Detect Python executable" >> ../run_nvidia_gpu_SageAttention2.sh
echo "PYTHON_EXEC=\"\"" >> ../run_nvidia_gpu_SageAttention2.sh
echo "if [ -f \"python_embeded/python\" ]; then" >> ../run_nvidia_gpu_SageAttention2.sh
echo "    PYTHON_EXEC=\"./python_embeded/python\"" >> ../run_nvidia_gpu_SageAttention2.sh
echo "elif [ -d \"python_embeded_3.12/bin\" ]; then" >> ../run_nvidia_gpu_SageAttention2.sh
echo "    PYTHON_EXEC=\"./python_embeded_3.12/bin/python3\"" >> ../run_nvidia_gpu_SageAttention2.sh
echo "elif [ -d \"python_embeded_3.11/bin\" ]; then" >> ../run_nvidia_gpu_SageAttention2.sh
echo "    PYTHON_EXEC=\"./python_embeded_3.11/bin/python3\"" >> ../run_nvidia_gpu_SageAttention2.sh
echo "elif [ -d \"python_embeded/bin\" ]; then" >> ../run_nvidia_gpu_SageAttention2.sh
echo "    PYTHON_EXEC=\"./python_embeded/bin/python3\"" >> ../run_nvidia_gpu_SageAttention2.sh
echo "else" >> ../run_nvidia_gpu_SageAttention2.sh
echo "    PYTHON_EXEC=\"python3\"" >> ../run_nvidia_gpu_SageAttention2.sh
echo "fi" >> ../run_nvidia_gpu_SageAttention2.sh
echo "" >> ../run_nvidia_gpu_SageAttention2.sh
echo "\$PYTHON_EXEC -W ignore::FutureWarning ComfyUI/main.py --use-sage-attention --listen \"\$LISTEN_ADDRESS\"" >> ../run_nvidia_gpu_SageAttention2.sh

chmod +x ../run_nvidia_gpu_SageAttention2.sh

# Final Messages
echo
echo -e "${GREEN}:::::::::::::::${YELLOW} ${node_name} ${GREEN}Installation Complete${reset}"
echo
echo -e "${yellow}SageAttention2 v2.2.0 Features:${reset}"
echo -e "${yellow}  - Broad GPU compatibility (RTX 20xx/30xx/40xx, GTX series)${reset}"
echo -e "${yellow}  - 2-5x speedup compared to FlashAttention${reset}"
echo -e "${yellow}  - Lossless acceleration for most models${reset}"
echo
echo -e "${yellow}For newer RTX 40xx/50xx GPUs, consider SageAttention3${reset}"
echo
if [ -z "$1" ]; then
    echo -e "${green}::::::::::::::: ${yellow}Press any key to exit${reset}"
    read -n 1 -s
    exit
fi
