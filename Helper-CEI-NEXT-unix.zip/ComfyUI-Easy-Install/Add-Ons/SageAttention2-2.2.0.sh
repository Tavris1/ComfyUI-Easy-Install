#!/bin/bash
cd "$(dirname "$0")"

node_name="SageAttention Build"
echo -e "\033]0;'$node_name' for 'ComfyUI Easy Install' by ivo\007"

# Pixaroma Community Edition

# Set colors
warning='\033[93m'
red='\033[91m'
green='\033[92m'
yellow='\033[93m'
bold='\033[1m'
reset='\033[0m'

# Set arguments
PIPargs="--no-cache-dir --no-warn-script-location --timeout=1000 --retries 200 --use-pep517"

# Check Add-ons folder
PYTHON_PATH="../python_embeded/python"
if [ ! -f "$PYTHON_PATH" ]; then
    # Check for old virtual environment structure
    if [ -f "../python_embeded/bin/python3" ]; then
        PYTHON_PATH="../python_embeded/bin/python3"
    elif [ -f "../python_embeded_3.12/bin/python3" ]; then
        PYTHON_PATH="../python_embeded_3.12/bin/python3"
    elif [ -f "../python_embeded_3.11/bin/python3" ]; then
        PYTHON_PATH="../python_embeded_3.11/bin/python3"
    # Fallback to python3 if not in the expected embedded path
    elif command -v python3 &> /dev/null; then
        PYTHON_PATH=$(command -v python3)
    else
        clear
        echo -e "${green}::::::::::::::: Run this file from the ${red}'ComfyUI-Easy-Install/Add-ons'${green} folder, or ensure python3 is in your PATH.${reset}"
        echo -e "${green}::::::::::::::: Press any key to exit...${reset}"
        read -n 1 -s
        exit
    fi
fi

# Convert to absolute path for use in subdirectories
PYTHON_ABS_PATH=$(cd "$(dirname "$PYTHON_PATH")" && pwd)/$(basename "$PYTHON_PATH")

# Function to get versions
get_versions() {
    WARNINGS=0

    echo -e "${green}::::::::::::::: Checking ${yellow}Python, Torch, CUDA ${green}versions${reset}"
    echo

    PYTHON_VERSION=$("$PYTHON_PATH" --version 2>&1 | cut -d' ' -f2 | cut -d'.' -f1,2)
    TORCH_VERSION=$("$PYTHON_PATH" -c "import torch; print(torch.__version__)" 2>/dev/null | cut -d'.' -f1,2)
    CUDA_VERSION=$("$PYTHON_PATH" -c "import torch; print(torch.version.cuda if torch.cuda.is_available() else 'Not available')" 2>/dev/null | cut -d'.' -f1,2)

    echo -e "${green}::::::::::::::: Python Version:${yellow} $PYTHON_VERSION${reset}"
    echo -e "${green}::::::::::::::: Torch Version:${yellow} $TORCH_VERSION${reset}"
    echo -e "${green}::::::::::::::: CUDA Version:${yellow} $CUDA_VERSION${reset}"
    echo

    # Check Python version requirement (>=3.8)
    if [[ "$(echo "$PYTHON_VERSION" | cut -d'.' -f1)" -lt 3 ]] || [[ "$(echo "$PYTHON_VERSION" | cut -d'.' -f1)" -eq 3 && "$(echo "$PYTHON_VERSION" | cut -d'.' -f2)" -lt 8 ]]; then
        echo -e "${warning}WARNING: ${red}Python $PYTHON_VERSION is not supported. ${green}SageAttention requires Python >=3.8${reset}"
        WARNINGS=1
    fi

    # Check Torch version requirement (>=2.0)
    if [[ "$(echo "$TORCH_VERSION" | cut -d'.' -f1)" -lt 2 ]]; then
        echo -e "${warning}WARNING: ${red}Torch $TORCH_VERSION is not supported. ${green}SageAttention requires Torch >=2.0${reset}"
        WARNINGS=1
    fi

    # Check CUDA availability
    if [[ "$CUDA_VERSION" == "Not available" ]]; then
        echo -e "${warning}WARNING: ${red}CUDA not available. ${green}SageAttention requires CUDA for compilation${reset}"
        WARNINGS=1
    fi

    if [ $WARNINGS -eq 0 ]; then
        echo -e "${green}::::::::::::::: ${bold}All versions are supported! ${reset}"
        echo
    else
        echo
        echo -e "${red}::::::::::::::: Press any key to exit${reset}"
        read -n 1 -s
        exit
    fi
}

get_versions

# Check for Python development headers
echo -e "${green}::::::::::::::: Checking ${yellow}Python development headers${reset}"
echo

if ! "$PYTHON_PATH" -c "import sysconfig; import os; print(os.path.exists(os.path.join(sysconfig.get_path('include'), 'Python.h')))" 2>/dev/null | grep -q "True"; then
    echo -e "${warning}WARNING: ${red}Python development headers (Python.h) not found.${reset}"
    echo
    echo -e "${yellow}SageAttention requires Python development headers to compile C++ extensions.${reset}"
    echo -e "${yellow}Please install them using one of these methods:${reset}"
    echo
    echo -e "${green}Ubuntu/Debian:${reset}"
    echo -e "  ${bold}sudo apt-get update && sudo apt-get install -y python3.11-dev${reset} (for Python 3.11)"
    echo -e "  ${bold}sudo apt-get update && sudo apt-get install -y python3.12-dev${reset} (for Python 3.12)"
    echo -e "  ${bold}sudo apt-get update && sudo apt-get install -y python3.13-dev${reset} (for Python 3.13)"
    echo
    echo -e "${green}RHEL/CentOS/Fedora:${reset}"
    echo -e "  ${bold}sudo yum install -y python3.11-devel${reset} (for Python 3.11)"
    echo -e "  ${bold}sudo yum install -y python3.12-devel${reset} (for Python 3.12)"
    echo -e "  ${bold}sudo yum install -y python3.13-devel${reset} (for Python 3.13)"
    echo
    echo -e "${green}Arch Linux:${reset}"
    echo -e "  ${bold}sudo pacman -S python${reset}"
    echo
    echo -e "${red}::::::::::::::: Press any key to exit${reset}"
    read -n 1 -s
    exit 1
fi

echo -e "${green}::::::::::::::: Python development headers ${yellow}found!${reset}"
echo

# Erasing ~* folders
find "../python_embeded/lib/" -type d -name "~*" -exec rm -rf {} + 2>/dev/null

# Installing build dependencies
echo -e "${green}::::::::::::::: Installing${yellow} build dependencies${reset}"
echo
# Pin setuptools to <82 for torch 2.11.0+cu130 compatibility
"$PYTHON_PATH" -m pip install --upgrade wheel "setuptools<82" $PIPargs
echo

# Set CUDA_HOME for SageAttention compilation
echo -e "${green}::::::::::::::: Setting${yellow} CUDA_HOME${reset}"
echo

# Get PyTorch's CUDA runtime (e.g. 13.0). That is NOT an nvcc package name.
# Any toolkit in the same major (13.1 / 13.3) is fine for compiling extensions.
PYTORCH_CUDA_VERSION=$("$PYTHON_PATH" -c "import torch; print(torch.version.cuda)" 2>/dev/null)
PYTORCH_CUDA_MAJOR="${PYTORCH_CUDA_VERSION%%.*}"

nvcc_release_of() {
    "$1" --version 2>/dev/null | grep "release" | sed -n 's/.*release \([0-9]\+\.[0-9]\+\).*/\1/p'
}

pick_nvcc() {
    local candidate ver
    for candidate in \
        "/usr/local/cuda-${PYTORCH_CUDA_VERSION}/bin/nvcc" \
        /opt/cuda/bin/nvcc \
        /usr/local/cuda/bin/nvcc \
        /usr/local/cuda-*/bin/nvcc \
        /opt/cuda-*/bin/nvcc
    do
        if [ -x "$candidate" ]; then
            echo "$candidate"
            return 0
        fi
    done
    if command -v nvcc >/dev/null 2>&1; then
        command -v nvcc
        return 0
    fi
    return 1
}

CUDA_HOME=""
MATCHING_CUDA_FOUND=false
NVCC_BIN=""
NVCC_VERSION=""

if NVCC_BIN=$(pick_nvcc); then
    NVCC_VERSION=$(nvcc_release_of "$NVCC_BIN")
    CUDA_HOME=$(cd "$(dirname "$NVCC_BIN")/.." && pwd)
    if [ -n "$NVCC_VERSION" ] && [ "${NVCC_VERSION%%.*}" = "$PYTORCH_CUDA_MAJOR" ]; then
        MATCHING_CUDA_FOUND=true
    fi
fi

if [ "$MATCHING_CUDA_FOUND" = true ]; then
    if [ "$NVCC_VERSION" = "$PYTORCH_CUDA_VERSION" ]; then
        echo -e "${green}nvcc ${NVCC_VERSION} matches PyTorch CUDA ${PYTORCH_CUDA_VERSION}${reset}"
    else
        echo -e "${green}nvcc ${NVCC_VERSION} is compatible with PyTorch CUDA ${PYTORCH_CUDA_VERSION}${reset}"
        echo -e "${yellow}(same CUDA ${PYTORCH_CUDA_MAJOR}.x series — PyTorch uses its own ${PYTORCH_CUDA_VERSION} runtime libraries)${reset}"
    fi
else
    echo -e "${warning}WARNING: ${red}No CUDA ${PYTORCH_CUDA_MAJOR}.x toolkit found for PyTorch ${PYTORCH_CUDA_VERSION}.${reset}"
    echo
    echo -e "${green}Available CUDA installations:${reset}"
    for cuda_dir in /usr/local/cuda*; do
        if [ -d "$cuda_dir" ]; then
            echo -e "  ${yellow}$cuda_dir${reset}"
        fi
    done
    echo
    if [ -n "$CUDA_HOME" ]; then
        echo -e "${yellow}Using ${CUDA_HOME} (nvcc ${NVCC_VERSION:-unknown}) anyway.${reset}"
        echo -e "${yellow}This may work — the compiled extension uses pip-installed nvidia runtime libraries.${reset}"
        echo
    else
        echo -e "${red}No CUDA toolkit (nvcc) found at all.${reset}"
        echo -e "${green}Please install a CUDA ${PYTORCH_CUDA_MAJOR}.x toolkit (see Add-Ons/cuda-toolkit-installer.sh).${reset}"
        echo
        echo -e "${red}::::::::::::::: Press any key to exit${reset}"
        read -n 1 -s
        exit 1
    fi
fi

export CUDA_HOME="$CUDA_HOME"
export PATH="$CUDA_HOME/bin:$PATH"
export LD_LIBRARY_PATH="$CUDA_HOME/lib64:$LD_LIBRARY_PATH"

echo -e "${green}::::::::::::::: CUDA_HOME set to:${yellow} $CUDA_HOME${reset}"
echo -e "${green}::::::::::::::: PyTorch CUDA version:${yellow} $PYTORCH_CUDA_VERSION${reset}"
echo

# Clone SageAttention repository
echo -e "${green}::::::::::::::: Cloning${yellow} SageAttention repository${reset}"
echo

if [ -d "SageAttention" ]; then
    echo -e "${yellow}SageAttention directory already exists. Removing...${reset}"
    rm -rf SageAttention
fi

git clone https://github.com/thu-ml/SageAttention.git
if [ $? -ne 0 ]; then
    echo -e "${red}Failed to clone SageAttention repository${reset}"
    exit 1
fi

cd SageAttention

# Create build script
echo -e "${green}::::::::::::::: Creating${yellow} build script${reset}"
echo

cat > build_sage.py << 'EOF'
# SageAttention build patcher
import os
import subprocess
import sys

# Apply patches
print("Applying patches...")
files = ['csrc/fused/fused.cu', 'csrc/qattn/qk_int_sv_f16_cuda_sm80.cu']

for f in files:
    if os.path.exists(f):
        with open(f, 'r') as file:
            content = file.read()
        if '#include <vector>' not in content:
            content = '#include <vector>\n#include <typeindex>\n' + content
            with open(f, 'w') as file:
                file.write(content)
            print(f"✓ Patched {f}")

# Patch setup.py
with open('setup.py', 'r') as f:
    setup_content = f.read()

setup_content = setup_content.replace(
    'CXX_FLAGS = ["/O2", "/openmp"]',
    'CXX_FLAGS = ["/O2", "/openmp", "/std:c++20", "/DENABLE_BF16"]'
)
setup_content = setup_content.replace('"-std=c++17"', '"-std=c++20"')

with open('setup.py', 'w') as f:
    f.write(setup_content)

print("✓ Patches applied successfully")

# Set environment variables
os.environ['EXT_PARALLEL'] = '4'
os.environ['NVCC_APPEND_FLAGS'] = '--threads 8'
os.environ['MAX_JOBS'] = os.environ.get('MAX_JOBS', '4')

# Uninstall old version first
subprocess.run([sys.executable, '-m', 'pip', 'uninstall', 'sageattention', '-y'])

# Build and install with pip
print("\nBuilding with pip...")
subprocess.run([sys.executable, '-m', 'pip', 'install', '.', '--no-build-isolation'], check=True)
print("\n✓ Build complete!")
EOF

# Run build script
echo -e "${green}::::::::::::::: Running${yellow} build script${reset}"
echo

"$PYTHON_ABS_PATH" build_sage.py
if [ $? -ne 0 ]; then
    echo -e "${red}Build failed${reset}"
    cd ..
    exit 1
fi

cd ..

# Creating run_nvidia_gpu_SageAttention.sh file
echo
echo -e "${green}::::::::::::::: Creating${yellow} run_nvidia_gpu_SageAttention.sh${reset}"
echo

echo "#!/bin/bash" > ../run_nvidia_gpu_SageAttention.sh
echo "cd \"\$(dirname \"\$0\")\"" >> ../run_nvidia_gpu_SageAttention.sh
echo "echo \"Title ComfyUI-Easy-Install\"" >> ../run_nvidia_gpu_SageAttention.sh

# Add listening address configuration
echo "" >> ../run_nvidia_gpu_SageAttention.sh
echo "# Set listening address (configurable)" >> ../run_nvidia_gpu_SageAttention.sh
echo "LISTEN_CONFIG_FILE=\".listen_address_config\"" >> ../run_nvidia_gpu_SageAttention.sh
echo "LISTEN_ADDRESS=\"\${LISTEN_ADDRESS:-0.0.0.0}\"" >> ../run_nvidia_gpu_SageAttention.sh
echo "" >> ../run_nvidia_gpu_SageAttention.sh
echo "# Load saved setting if exists" >> ../run_nvidia_gpu_SageAttention.sh
echo "if [ -f \"\$LISTEN_CONFIG_FILE\" ]; then" >> ../run_nvidia_gpu_SageAttention.sh
echo "    LISTEN_ADDRESS=\$(cat \"\$LISTEN_CONFIG_FILE\")" >> ../run_nvidia_gpu_SageAttention.sh
echo "fi" >> ../run_nvidia_gpu_SageAttention.sh
echo "" >> ../run_nvidia_gpu_SageAttention.sh
echo "echo \"Listening on: \$LISTEN_ADDRESS\"" >> ../run_nvidia_gpu_SageAttention.sh

# Detect Python executable for the run script
echo "# Detect Python executable" >> ../run_nvidia_gpu_SageAttention.sh
echo "PYTHON_EXEC=\"\"" >> ../run_nvidia_gpu_SageAttention.sh
echo "if [ -f \"python_embeded/python\" ]; then" >> ../run_nvidia_gpu_SageAttention.sh
echo "    PYTHON_EXEC=\"./python_embeded/python\"" >> ../run_nvidia_gpu_SageAttention.sh
echo "elif [ -d \"python_embeded_3.12/bin\" ]; then" >> ../run_nvidia_gpu_SageAttention.sh
echo "    PYTHON_EXEC=\"./python_embeded_3.12/bin/python3\"" >> ../run_nvidia_gpu_SageAttention.sh
echo "elif [ -d \"python_embeded_3.11/bin\" ]; then" >> ../run_nvidia_gpu_SageAttention.sh
echo "    PYTHON_EXEC=\"./python_embeded_3.11/bin/python3\"" >> ../run_nvidia_gpu_SageAttention.sh
echo "elif [ -d \"python_embeded/bin\" ]; then" >> ../run_nvidia_gpu_SageAttention.sh
echo "    PYTHON_EXEC=\"./python_embeded/bin/python3\"" >> ../run_nvidia_gpu_SageAttention.sh
echo "else" >> ../run_nvidia_gpu_SageAttention.sh
echo "    PYTHON_EXEC=\"python3\"" >> ../run_nvidia_gpu_SageAttention.sh
echo "fi" >> ../run_nvidia_gpu_SageAttention.sh
echo "" >> ../run_nvidia_gpu_SageAttention.sh
echo "\$PYTHON_EXEC -W ignore::FutureWarning ComfyUI/main.py --use-sage-attention --listen \"\$LISTEN_ADDRESS\"" >> ../run_nvidia_gpu_SageAttention.sh

chmod +x ../run_nvidia_gpu_SageAttention.sh

# Final Messages
echo
echo -e "${green}:::::::::::::::${yellow} ${node_name} ${green}Installation Complete${reset}"
echo
echo -e "${yellow}SageAttention Features:${reset}"
echo -e "${yellow}  - Broad GPU compatibility (RTX 20xx/30xx/40xx/50xx, GTX series)${reset}"
echo -e "${yellow}  - 2-5x speedup compared to FlashAttention${reset}"
echo -e "${yellow}  - Lossless acceleration for most models${reset}"
echo -e "${yellow}  - Custom build with optimized compilation flags${reset}"
echo
if [ -z "$1" ]; then
    echo -e "${green}::::::::::::::: ${yellow}Press any key to exit${reset}"
    read -n 1 -s
    exit
fi
