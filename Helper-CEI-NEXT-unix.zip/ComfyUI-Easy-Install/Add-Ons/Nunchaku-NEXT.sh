#!/bin/bash

# Title: 'Nunchaku' for 'ComfyUI Easy Install' by ivo
# Pixaroma Community Edition
# macOS and Linux conversion

# Set colors
WARNING='\033[33m'
RED='\033[91m'
GREEN='\033[92m'
YELLOW='\033[93m'
BOLD='\033[1m'
RESET='\033[0m'

NODE_NAME="Nunchaku"

# Set arguments
PIP_ARGS="--no-cache-dir --no-warn-script-location --timeout=1000 --retries 200 --use-pep517"
UV_ARGS="--no-cache --link-mode=copy"

# Check Add-ons folder
# Assuming the main script has activated the venv, so 'python' is available
if ! command -v python &> /dev/null; then
    clear
    echo -e "${GREEN}::::::::::::::: Run this file from the ${RED}'ComfyUI-Easy-Install/Add-ons'${GREEN} folder or ensure python venv is active"
    echo -e "${GREEN}::::::::::::::: Press any key to exit...${RESET}"
    read -p ""
    exit 1
fi

# Clear Pip Cache
clear_pip_cache() {
    if [ -d "$HOME/.cache/pip" ]; then
        rm -rf "$HOME/.cache/pip" && mkdir -p "$HOME/.cache/pip"
    fi
    echo -e "${GREEN}::::::::::::::: Clearing Pip Cache ${YELLOW}Done${GREEN}${RESET}"
    echo ""
}

# Get Python, Torch, CUDA versions
get_versions() {
    echo -e "${GREEN}::::::::::::::: Checking ${YELLOW}Python, Torch and CUDA ${GREEN}versions${RESET}"
    echo ""

    PYTHON_FULL_VERSION=$(python -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}')")
    PYTHON_MAJOR_MINOR=$(python -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")

    TORCH_VERSION=$(python -c "import torch; print(torch.__version__)" 2>/dev/null || echo "Not installed")
    CUDA_VERSION=$(python -c "import torch; print(torch.version.cuda if torch.cuda.is_available() else 'Not available')" 2>/dev/null || echo "Not available")

    echo -e "${GREEN}::::::::::::::: Python Version:${YELLOW} ${PYTHON_FULL_VERSION}${RESET}"
    echo -e "${GREEN}::::::::::::::: Torch Version:${YELLOW} ${TORCH_VERSION}${RESET}"
    echo -e "${GREEN}::::::::::::::: CUDA Version:${YELLOW} ${CUDA_VERSION}${RESET}"
    echo ""

    local WARNINGS=0

    if [ "$PYTHON_MAJOR_MINOR" != "3.11" ] && [ "$PYTHON_MAJOR_MINOR" != "3.12" ]; then
        echo -e "${WARNING}WARNING: ${RED}Python ${PYTHON_MAJOR_MINOR} is not supported. ${GREEN}Supported versions: 3.11, 3.12${RESET}"
        WARNINGS=1
    fi

    # Simplified Torch/CUDA version checks for generic installation
    # The original script checked for specific minor versions (2.7, 2.8) and CUDA 12.8
    # For cross-platform, we'll assume pip will handle compatible versions.
    # If specific versions are critical, this section would need more sophisticated checks.
    if [[ "$TORCH_VERSION" == "Not installed" ]]; then
        echo -e "${WARNING}WARNING: ${RED}Torch is not installed. Please ensure it's installed correctly.${RESET}"
        WARNINGS=1
    fi

    if [ "$WARNINGS" -eq 0 ]; then
        echo -e "${GREEN}::::::::::::::: ${RESET}${BOLD}All versions are supported! ${RESET}"
        echo ""
    else
        echo ""
        echo -e "${RED}::::::::::::::: Press any key to exit${RESET}"
        read -p ""
        exit 1
    fi
}

# Main script execution
cd "$(dirname "$0")"
clear_pip_cache
get_versions

# Erasing ~* folders in the current venv's site-packages
VENV_SITE_PACKAGES=$(python -c "import site; print(site.getsitepackages()[0])")
if [ -d "$VENV_SITE_PACKAGES" ]; then
    find "$VENV_SITE_PACKAGES" -maxdepth 1 -type d -name '~*' -exec rm -rf {} + 2>/dev/null
fi

echo -e "${GREEN}::::::::::::::: Installing${YELLOW} ${NODE_NAME}${RESET}"
echo ""

# Remove existing Nunchaku installation if it exists
if [ -d "../ComfyUI/custom_nodes/ComfyUI-nunchaku" ]; then
    rm -rf "../ComfyUI/custom_nodes/ComfyUI-nunchaku"
fi

git clone https://github.com/mit-han-lab/ComfyUI-nunchaku ../ComfyUI/custom_nodes/ComfyUI-nunchaku

# Remove existing nunchaku wheel installations
if [ -d "$VENV_SITE_PACKAGES" ]; then
    find "$VENV_SITE_PACKAGES" -maxdepth 1 -type d -name 'nunchaku*' -exec rm -rf {} + 2>/dev/null
fi

# Install Nunchaku from pre-compiled wheel
echo -e "${GREEN}::::::::::::::: Installing Nunchaku from pre-compiled wheel${RESET}"

PYTHON_VERSION_MINOR=$(python -c "import sys; print(f'{sys.version_info.minor}')")
TORCH_VERSION_MAJOR_MINOR=$(python -c "import torch; print('.'.join(torch.__version__.split('.')[:2]))")

NUNCHAKU_WHL=""
if [[ "$PYTHON_VERSION_MINOR" == "11" && "$TORCH_VERSION_MAJOR_MINOR" == "2.9" ]]; then
    NUNCHAKU_WHL="nunchaku-1.0.2+torch2.9-cp311-cp311-linux_x86_64.whl"
elif [[ "$PYTHON_VERSION_MINOR" == "12" && "$TORCH_VERSION_MAJOR_MINOR" == "2.9" ]]; then
    NUNCHAKU_WHL="nunchaku-1.0.2+torch2.9-cp312-cp312-linux_x86_64.whl"
elif [[ "$PYTHON_VERSION_MINOR" == "11" && "$TORCH_VERSION_MAJOR_MINOR" == "2.7" ]]; then
    NUNCHAKU_WHL="nunchaku-1.0.2+torch2.7-cp311-cp311-linux_x86_64.whl"
elif [[ "$PYTHON_VERSION_MINOR" == "11" && "$TORCH_VERSION_MAJOR_MINOR" == "2.8" ]]; then
    NUNCHAKU_WHL="nunchaku-1.0.2+torch2.8-cp311-cp311-linux_x86_64.whl"
elif [[ "$PYTHON_VERSION_MINOR" == "12" && "$TORCH_VERSION_MAJOR_MINOR" == "2.7" ]]; then
    NUNCHAKU_WHL="nunchaku-1.0.2+torch2.7-cp312-cp312-linux_x86_64.whl"
elif [[ "$PYTHON_VERSION_MINOR" == "12" && "$TORCH_VERSION_MAJOR_MINOR" == "2.8" ]]; then
    NUNCHAKU_WHL="nunchaku-1.0.2+torch2.8-cp312-cp312-linux_x86_64.whl"
fi

if [ -z "$NUNCHAKU_WHL" ]; then
    echo -e "${RED}::::::::::::::: No compatible Nunchaku wheel found for your Python/Torch version.${RESET}"
    echo -e "${RED}Attempting generic installation from PyPI, which may fail.${RESET}"
    python -m uv pip install nunchaku $UV_ARGS
else
    echo -e "${GREEN}::::::::::::::: Installing wheel: $NUNCHAKU_WHL${RESET}"
    python -m uv pip install "https://github.com/nunchaku-tech/nunchaku/releases/download/v1.0.2/$NUNCHAKU_WHL" $UV_ARGS
fi


# Write nunchaku_versions.json
echo '{"versions":["1.0.2","1.0.1","1.0.0","0.3.2","0.3.1","0.3.0","0.2.0","0.1.4","0.1.3","0.1.2"],"dev_versions":["1.0.1.dev20250930","1.0.1.dev20250929","1.0.1.dev20250926","1.0.1.dev20250924","1.0.1.dev20250923","1.0.1.dev20250921","1.0.1.dev20250920","1.0.1.dev20250912","1.0.0.dev20250904","1.0.0.dev20250903","1.0.0.dev20250902","1.0.0.dev20250830","1.0.0.dev20250823","1.0.0.dev20250820","1.0.0.dev20250816"],"supported_torch":["torch2.5","torch2.6","torch2.7","torch2.8","torch2.9"],"supported_python":["cp310","cp311","cp312","cp313"],"filename_template":"nunchaku-{version}+{torch_version}-{python_version}-{python_version}-{platform}.whl","url_templates":{"github":"https://github.com/nunchaku-tech/nunchaku/releases/download/{version_tag}/{filename}","huggingface":"https://huggingface.co/nunchaku-tech/nunchaku/resolve/main/{filename}","modelscope":"https://modelscope.cn/models/nunchaku-tech/nunchaku/resolve/master/{filename}"}}' > "../ComfyUI/custom_nodes/ComfyUI-nunchaku/nunchaku_versions.json"

python -m uv pip install --force-reinstall numpy $UV_ARGS

echo ""
echo -e "${GREEN}:::::::::::::::${YELLOW} ${NODE_NAME} ${GREEN}Installation Complete${RESET}"
echo ""

if [ -z "$1" ]; then
    echo -e "${GREEN}::::::::::::::: ${YELLOW}Press any key to exit${RESET}"
    read -p ""
    exit 0
fi
