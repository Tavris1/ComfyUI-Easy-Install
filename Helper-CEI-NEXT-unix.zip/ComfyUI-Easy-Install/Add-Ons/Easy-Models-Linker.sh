#!/bin/bash

# Title: Easy-Models-Linker by ivo v1.67.0
# Pixaroma Community Edition
# macOS and Linux conversion by Gemini

# Set colors
WARNING='\033[33m'
RED='\033[91m'
GREEN='\033[92m'
YELLOW='\033[93m'
BOLD='\033[1m'
RESET='\033[0m'

start_script() {
    cd "$(dirname "$0")"

    local main_folder
    main_folder=$(cd .. && pwd)
    local yaml="${main_folder}/ComfyUI/extra_model_paths.yaml"
    local yaml_backup="extra_model_paths_Backup.yaml"

    if [ ! -d "${main_folder}/ComfyUI/models" ]; then
        echo ""
        echo -e "${WARNING}WARNING: ${GREEN}Start this file from ${YELLOW}Add-ons${GREEN} folder${RESET}"
        echo ""
        read -p "${YELLOW}Press any key to Exit...${RESET}"
        exit 1
    fi

    echo -e "${YELLOW}extra_model_paths.yaml${GREEN} will be created in the ${YELLOW}${main_folder}/ComfyUI${GREEN} folder.${RESET}"
    echo -e "${GREEN}This way, you can use your ${YELLOW}EXISTING 'MODELS'${GREEN} folders without downloading them again.${RESET}"
    echo ""

    local models
    while true; do
        echo -e "${GREEN}Enter the absolute path to your ${YELLOW}EXISTING 'MODELS'${GREEN} folder:"
        read -r models

        if [ -z "$models" ]; then
            echo "Cancelled."
            exit
        fi

        if [ ! -d "${models}/diffusion_models" ]; then
            echo ""
            echo -e "${WARNING}WARNING: ${GREEN}This is ${RED}NOT a MODELS${GREEN} folder.${RESET}"
            echo ""
            read -p "${YELLOW}Press any key to Select again...${RESET}"
            clear
        elif [ "$models" == "${main_folder}/ComfyUI/models" ]; then
            echo ""
            echo -e "${WARNING}WARNING: ${GREEN}This is ${RED}YOUR NEW MODELS${GREEN} folder.${RESET}"
            echo -e "${GREEN}Select the location of your ${YELLOW}EXISTING MODELS${GREEN} folder."
            echo ""
            read -p "${YELLOW}Press any key to Select again...${RESET}"
            clear
        else
            break
        fi
    done

    echo -e "${GREEN}Selected: ${YELLOW}${models}${RESET}"

    if [ -f "${main_folder}/ComfyUI/${yaml_backup}" ]; then
        rm "${main_folder}/ComfyUI/${yaml_backup}"
    fi

    local backup_msg=""
    if [ -f "${yaml}" ]; then
        mv "${yaml}" "${main_folder}/ComfyUI/${yaml_backup}"
        echo ""
        backup_msg="${GREEN}::::: Backup file${YELLOW} ${yaml_backup} ${GREEN}has been created${RESET}"
    fi

    echo "# Powered by Easy-Models-Linker, developed by Ivo" > "${yaml}"
    echo "# Pixaroma Community Edition" >> "${yaml}"
    echo "" >> "${yaml}"

    local modelsname
    modelsname=$(basename "${models}")

    echo "comfyui:" >> "${yaml}"
    echo "    base_path: ${main_folder}/ComfyUI/" >> "${yaml}"
    
    # Iterate through subdirectories of the selected models folder
    for f in "${models}"/*/; do
        if [ -d "$f" ]; then
            echo "    $(basename "$f"): ${modelsname}/$(basename "$f")" >> "${yaml}"
        fi
    done

    echo ""
    cat "${yaml}"
    if [ -n "$backup_msg" ]; then
        echo ""
        echo -e "$backup_msg"
    fi
    echo ""
    echo -e "${GREEN}::::: ${YELLOW}extra_model_paths.yaml${GREEN} has been created in ${YELLOW}${main_folder}/ComfyUI${RESET}"
    echo ""
    read -p "${GREEN}::::: ${YELLOW}Press any key to exit${RESET}"
    exit 0
}

start_script
