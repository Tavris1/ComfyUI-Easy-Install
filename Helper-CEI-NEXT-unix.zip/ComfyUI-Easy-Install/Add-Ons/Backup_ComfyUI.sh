#!/bin/bash

# Set the ComfyUI directories
COMFYUI_DIR="$(dirname "$0")/ComfyUI"
BACKUP_ROOT_DIR="$HOME/ComfyUI_Backups"

# Create backup directory with timestamp
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_DIR="${BACKUP_ROOT_DIR}/ComfyUI_backup_${TIMESTAMP}"

# Create the backup root directory if it doesn't exist
mkdir -p "$BACKUP_ROOT_DIR"

# Create the backup directory
mkdir -p "$BACKUP_DIR"

# Directories to back up
DIRS=("user" "input" "output")

# Copy each directory if it exists
for dir in "${DIRS[@]}"; do
    if [ -d "${COMFYUI_DIR}/${dir}" ]; then
        echo "Backing up ${dir}..."
        cp -r "${COMFYUI_DIR}/${dir}" "${BACKUP_DIR}/"
    else
        echo "Warning: ${dir} directory not found, skipping..."
    fi
done

echo "Backup completed! Files saved to: $BACKUP_DIR"

# Optional: Create a zip archive
read -p "Do you want to create a zip archive of the backup? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "Creating zip archive..."
    zip -r "${BACKUP_DIR}.zip" "$BACKUP_DIR"
    echo "Zip archive created: ${BACKUP_DIR}.zip"
fi
