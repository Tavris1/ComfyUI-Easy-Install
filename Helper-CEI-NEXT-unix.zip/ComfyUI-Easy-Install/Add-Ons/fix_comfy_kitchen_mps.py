#!/usr/bin/env python3
"""Apply the comfy-kitchen INT8/ConvRoT fallback for Apple MPS.

Run this after installing or upgrading comfy-kitchen on macOS.  The patch keeps
weights stored as INT8 and dequantizes only a bounded group of output channels
for each native floating-point MPS matrix multiplication, avoiding the
unsupported torch.int8_mm / torch._int_mm ops on Apple Silicon.

Usage:
    python3 fix_comfy_kitchen_mps.py              # auto-detect
    python3 fix_comfy_kitchen_mps.py /path/to/ComfyUI-Easy-Install  # specify root
"""

from __future__ import annotations

import py_compile
import subprocess
import sys
from pathlib import Path

MARKER = "# MPS has no native implementation of torch.int8_mm/torch._int_mm."

ANCHOR = """    orig_shape = x.shape
        x_2d = x.reshape(-1, x.shape[-1])

        # Quantize input per-row
"""

PATCHED = """    orig_shape = x.shape
        x_2d = x.reshape(-1, x.shape[-1])

        # MPS has no native implementation of torch.int8_mm/torch._int_mm.  Keep
        # the checkpoint weights in INT8, but dequantize one group of output
        # channels at a time and use the native floating-point MPS matmul.  This is
        # slower than a hardware INT8 kernel, but avoids both the unsupported op
        # and materializing the entire model at its floating-point size.
        if x.device.type == "mps":
            compute_dtype = x.dtype
            if compute_dtype not in (torch.float16, torch.bfloat16, torch.float32):
                compute_dtype = out_dtype
            if compute_dtype not in (torch.float16, torch.bfloat16, torch.float32):
                compute_dtype = torch.float16

            x_2d = x_2d.to(dtype=compute_dtype)
            # Limit each temporary dequantized weight block to roughly 64 MiB.
            bytes_per_element = torch.empty((), dtype=compute_dtype).element_size()
            rows_per_chunk = max(
                1,
                min(
                    weight.shape[0],
                    (64 * 1024 * 1024) // max(1, weight.shape[1] * bytes_per_element),
                ),
            )
            output_parts = []
            for start in range(0, weight.shape[0], rows_per_chunk):
                end = min(start + rows_per_chunk, weight.shape[0])
                weight_chunk = weight[start:end].to(dtype=compute_dtype)
                scale_chunk = (
                    weight_scale
                    if weight_scale.numel() == 1
                    else weight_scale[start:end]
                )
                weight_chunk.mul_(
                    scale_chunk.to(device=x.device, dtype=compute_dtype).reshape(-1, 1)
                )
                output_parts.append(torch.mm(x_2d, weight_chunk.t()))

            result = torch.cat(output_parts, dim=-1).to(dtype=out_dtype)
            if bias is not None:
                result = result + bias.to(
                    device=result.device, dtype=result.dtype
                ).reshape(1, -1)
            return result.reshape(*orig_shape[:-1], weight.shape[0])

        # Quantize input per-row
"""


def find_target() -> Path | None:
    """Locate comfy_kitchen/backends/eager/quantization.py by trying several strategies."""
    rel = Path("comfy_kitchen") / "backends" / "eager" / "quantization.py"

    # 1. Explicit argument
    if len(sys.argv) > 1:
        root = Path(sys.argv[1]).resolve()
        for candidate in [
            root / "python_embeded" / "lib" / "python3.12" / "site-packages" / rel,
            root / "python_embeded" / "lib" / "python3.11" / "site-packages" / rel,
            root / "venv" / "lib" / "python3.12" / "site-packages" / rel,
            root / "venv" / "lib" / "python3.11" / "site-packages" / rel,
            root / rel,
        ]:
            if candidate.is_file():
                return candidate

    # 2. Search beneath common ComfyUI-Easy-Install roots
    search_roots = []
    if len(sys.argv) > 1:
        search_roots.append(Path(sys.argv[1]).resolve())
    search_roots.append(Path.cwd())
    search_roots.append(Path.home() / "ComfyUI-Easy-Install")
    search_roots.append(Path.home() / "Downloads" / "TEMP" / "ComfyUI-Easy-Install")

    for root in search_roots:
        if root.is_dir():
            for hit in root.rglob("quantization.py"):
                if hit.parent.parts[-3:] == ("eager", "backends", "comfy_kitchen") or (
                    "comfy_kitchen" in hit.parts
                    and "backends" in hit.parts
                    and "eager" in hit.parts
                ):
                    return hit

    # 3. Ask the active Python where comfy_kitchen lives
    for py in [sys.executable, "python3", sys.executable.replace("python3.12", "python3")]:
        try:
            result = subprocess.run(
                [py, "-c", "import comfy_kitchen, os; print(os.path.dirname(comfy_kitchen.__file__))"],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0 and result.stdout.strip():
                candidate = Path(result.stdout.strip()) / "backends" / "eager" / "quantization.py"
                if candidate.is_file():
                    return candidate
        except Exception:
            continue

    # 4. pip show
    try:
        result = subprocess.run(
            ["pip3", "show", "-f", "comfy-kitchen"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            for line in result.stdout.splitlines():
                if line.startswith("Location:"):
                    loc = Path(line.split(":", 1)[1].strip())
                    candidate = loc / rel
                    if candidate.is_file():
                        return candidate
    except Exception:
        pass

    return None


def main() -> int:
    if sys.platform != "darwin":
        print("This fix is only intended for macOS.")
        return 2

    target = find_target()
    if target is None:
        print("Could not find comfy_kitchen/backends/eager/quantization.py")
        print()
        print("Usage:  python3 fix_comfy_kitchen_mps.py [path-to-ComfyUI-Easy-Install]")
        print()
        print("The script searches automatically, but you can pass the install root explicitly.")
        return 1

    source = target.read_text(encoding="utf-8")
    if MARKER in source:
        print(f"Already patched: {target}")
    elif ANCHOR not in source:
        print("The installed comfy-kitchen version has changed; no files were modified.")
        print(f"Expected patch location was not found in: {target}")
        return 1
    else:
        target.write_text(source.replace(ANCHOR, PATCHED, 1), encoding="utf-8")
        print(f"Patched: {target}")

    py_compile.compile(str(target), doraise=True)
    print("Syntax check passed. Restart ComfyUI to use INT8 ConvRoT on MPS.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
