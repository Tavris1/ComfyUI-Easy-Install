#!/bin/bash
cd "$(dirname "$0")"

# Title: CUDA Toolkit Installer for ComfyUI Easy Install
# Adds the NVIDIA CUDA repository and installs the toolkit

set -euo pipefail

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
RESET='\033[0m'

echo -e "${GREEN}::::::::::::::: Universal CUDA Toolkit Installer :::::::::::::::${RESET}"
echo

# Detect distro
DISTRO=""
ID_LIKE=""
if [ -f /etc/os-release ]; then
    . /etc/os-release
    DISTRO="$ID"
    DISTRO_VERSION="${VERSION_ID:-rolling}"
    DISTRO_NAME="$NAME"
    ID_LIKE="${ID_LIKE:-}"
else
    echo -e "${RED}Cannot detect Linux distribution. /etc/os-release not found.${RESET}"
    exit 1
fi

is_arch_family() {
    case "$DISTRO" in
        arch|cachyos|manjaro|endeavouros|garuda|artix|archlinux) return 0 ;;
    esac
    case " $ID_LIKE " in
        *" arch "*) return 0 ;;
    esac
    return 1
}

echo -e "${GREEN}Detected:${YELLOW} ${DISTRO_NAME} (${DISTRO} ${DISTRO_VERSION})${RESET}"
echo

sudo_if_needed() {
    if [ "$(id -u)" -ne 0 ]; then
        echo sudo
    fi
}

# 13.3 >= 13.0 ?
ver_ge() {
    local have="$1" need="$2"
    [ "$(printf '%s\n%s\n' "$need" "$have" | sort -V | head -1)" = "$need" ]
}

find_working_nvcc() {
    local candidate
    if command -v nvcc >/dev/null 2>&1; then
        command -v nvcc
        return 0
    fi
    # Arch/CachyOS: /opt/cuda. Debian/Ubuntu: /usr/local/cuda*
    for candidate in \
        /opt/cuda/bin/nvcc \
        /usr/local/cuda/bin/nvcc \
        /usr/local/cuda-*/bin/nvcc \
        /opt/cuda-*/bin/nvcc
    do
        if [ -x "$candidate" ]; then
            echo "$candidate"
            return 0
        fi
    done
    return 1
}

nvcc_release() {
    "$1" --version 2>/dev/null | grep "release" | sed -n 's/.*release \([0-9]\+\.[0-9]\+\).*/\1/p'
}

# Newest available toolkit in the same major as $1, preferring >= $1
resolve_toolkit_version() {
    local wanted="$1"
    local avail="$2"
    local major="${wanted%%.*}"
    local exact="" newest_ge="" newest_same=""
    local v
    while IFS= read -r v; do
        [ -z "$v" ] && continue
        [ "$v" = "$wanted" ] && exact="$v"
        if [ "${v%%.*}" = "$major" ]; then
            newest_same="$v"
            if ver_ge "$v" "$wanted"; then
                newest_ge="$v"
            fi
        fi
    done <<< "$avail"
    if [ -n "$exact" ]; then
        echo "$exact"
        return 0
    fi
    if [ -n "$newest_ge" ]; then
        echo "$newest_ge"
        return 0
    fi
    if [ -n "$newest_same" ]; then
        echo "$newest_same"
        return 0
    fi
    return 1
}

list_apt_toolkit_versions() {
    apt-cache search --names-only '^cuda-toolkit-[0-9]+-[0-9]+$' 2>/dev/null \
        | awk '{print $1}' \
        | sed -n 's/^cuda-toolkit-\([0-9][0-9]*\)-\([0-9][0-9]*\)$/\1.\2/p' \
        | sort -u -V
}

# Arch extra/cuda version, e.g. "13.0.2-1" -> "13.0"
arch_cuda_pkg_version() {
    local raw
    raw=$(pacman -Si cuda 2>/dev/null | awk -F': *' '/^Version/{print $2; exit}')
    if [ -z "$raw" ]; then
        return 1
    fi
    echo "$raw" | sed -n 's/^\([0-9][0-9]*\.[0-9][0-9]*\).*/\1/p'
}

# Locate embedded Python for version checks
find_embedded_python() {
    for base in ".." "../.."; do
        for ver in "_3.12" "_3.11" ""; do
            for sub in "/python" "/bin/python"; do
                local candidate="${base}/python_embeded${ver}${sub}"
                if [ -x "$candidate" ]; then
                    echo "$candidate"
                    return 0
                fi
            done
        done
    done
    return 1
}

PYTHON=$(find_embedded_python || true)
if [ -z "$PYTHON" ]; then
    if command -v python3 >/dev/null 2>&1; then
        PYTHON=python3
    elif command -v python >/dev/null 2>&1; then
        PYTHON=python
    fi
fi

# Preflight check
echo -e "${GREEN}::::::::::::::: Preflight check ${YELLOW}(before installation)${GREEN} :::::::::::::::${RESET}"

NVCC_PATH=""
NVCC_VER=""
if NVCC_PATH=$(find_working_nvcc); then
    NVCC_VER=$(nvcc_release "$NVCC_PATH")
    echo -e "${GREEN}nvcc found:${YELLOW} ${NVCC_PATH} (v${NVCC_VER})${RESET}"
else
    NVCC_PATH=""
    echo -e "${YELLOW}WARNING: nvcc not found on current PATH/known locations${RESET}"
fi

TORCH_VER="not installed"
TORCH_CUDA="N/A"
if [ -n "$PYTHON" ]; then
    PY_VER=$("$PYTHON" --version 2>&1 | cut -d' ' -f2)
    TORCH_VER=$("$PYTHON" -c "import torch; print(torch.__version__)" 2>/dev/null || echo "not installed")
    TORCH_CUDA=$("$PYTHON" -c "import torch; print(torch.version.cuda or 'N/A')" 2>/dev/null || echo "N/A")
    echo -e "${GREEN}Embedded python:${YELLOW} ${PYTHON}${RESET}"
    echo -e "${GREEN}Python version:${YELLOW} ${PY_VER}${RESET}"
    echo -e "${GREEN}Torch version:${YELLOW} ${TORCH_VER}${RESET}"
    echo -e "${GREEN}Torch CUDA runtime (torch.version.cuda):${YELLOW} ${TORCH_CUDA}${RESET}"
    echo -e "${YELLOW}Note: torch.version.cuda is the PyTorch runtime, not an nvcc package name.${RESET}"

    if "$PYTHON" -c "import sysconfig, os; print(os.path.exists(os.path.join(sysconfig.get_path('include'), 'Python.h')))" 2>/dev/null | grep -q "True"; then
        echo -e "${GREEN}Python development headers:${YELLOW} found${RESET}"
    else
        echo -e "${YELLOW}Python development headers: NOT found${RESET}"
    fi
else
    echo -e "${YELLOW}No Python found for version checks${RESET}"
fi

echo -e "${GREEN}Preflight summary: all core checks look good${RESET}"
echo

# Distro bits needed to talk to the NVIDIA apt repo before showing a plan
APT_DISTRO=""
APT_CODENAME=""
NVIDIA_REPO_DISTRO=""
CUDA_REPO_URL=""
case "$DISTRO" in
    debian|ubuntu|linuxmint)
        APT_DISTRO="$DISTRO"
        if [ "$DISTRO" = "debian" ]; then
            case "$DISTRO_VERSION" in
                12*) APT_CODENAME="bookworm" ;;
                13*) APT_CODENAME="trixie" ;;
                *) APT_CODENAME=$(lsb_release -cs 2>/dev/null || echo "trixie") ;;
            esac
        elif [ "$DISTRO" = "ubuntu" ]; then
            APT_CODENAME=$(lsb_release -cs 2>/dev/null || echo "jammy")
        elif [ "$DISTRO" = "linuxmint" ]; then
            case "$DISTRO_VERSION" in
                22*) DISTRO_VERSION="2404"; APT_CODENAME="noble" ;;
                21*) DISTRO_VERSION="2204"; APT_CODENAME="jammy" ;;
                20*) DISTRO_VERSION="2004"; APT_CODENAME="focal" ;;
                *) DISTRO_VERSION="2404"; APT_CODENAME="noble" ;;
            esac
            APT_DISTRO="ubuntu"
        fi
        REPO_VERSION=$(echo "$DISTRO_VERSION" | sed 's/[^0-9]//g')
        NVIDIA_REPO_DISTRO="${APT_DISTRO}${REPO_VERSION}"
        CUDA_REPO_URL="https://developer.download.nvidia.com/compute/cuda/repos/${NVIDIA_REPO_DISTRO}/x86_64"
        ;;
esac

ensure_cuda_apt_repo() {
    local SUDO_CMD
    SUDO_CMD=$(sudo_if_needed)
    local CUDA_KEYRING_URL="${CUDA_REPO_URL}/cuda-keyring_1.1-1_all.deb"
    local APT_SOURCE_FILE="/etc/apt/sources.list.d/cuda-${NVIDIA_REPO_DISTRO}.list"

    local already
    already=$(list_apt_toolkit_versions || true)
    if [ -n "$already" ]; then
        echo -e "${GREEN}NVIDIA CUDA repository already configured${RESET}"
        return 0
    fi

    $SUDO_CMD apt-get update -qq
    $SUDO_CMD apt-get install -y -qq wget gnupg ca-certificates

    echo -e "${GREEN}Adding NVIDIA CUDA repository:${YELLOW} ${CUDA_REPO_URL}${RESET}"
    TMP_KEYRING=$(mktemp /tmp/cuda-keyring.XXXXXX.deb)
    if ! wget -q -O "$TMP_KEYRING" "$CUDA_KEYRING_URL"; then
        echo -e "${YELLOW}Failed to download cuda-keyring from ${CUDA_KEYRING_URL}${RESET}"
        echo -e "${YELLOW}Trying alternate repo paths...${RESET}"
        local alt_distro alt_url
        for alt_distro in "${APT_DISTRO}${REPO_VERSION}" "${APT_CODENAME}" "${APT_DISTRO}12" "${APT_DISTRO}11"; do
            alt_url="https://developer.download.nvidia.com/compute/cuda/repos/${alt_distro}/x86_64/cuda-keyring_1.1-1_all.deb"
            echo -e "${YELLOW}  Trying: ${alt_url}${RESET}"
            if wget -q -O "$TMP_KEYRING" "$alt_url"; then
                NVIDIA_REPO_DISTRO="$alt_distro"
                CUDA_REPO_URL="https://developer.download.nvidia.com/compute/cuda/repos/${alt_distro}/x86_64"
                APT_SOURCE_FILE="/etc/apt/sources.list.d/cuda-${NVIDIA_REPO_DISTRO}.list"
                echo -e "${GREEN}✓${RESET} Found repo at ${alt_distro}"
                break
            fi
        done
        if [ ! -s "$TMP_KEYRING" ]; then
            echo -e "${RED}Failed to download cuda-keyring from all attempted URLs.${RESET}"
            rm -f "$TMP_KEYRING"
            exit 1
        fi
    fi
    $SUDO_CMD dpkg -i "$TMP_KEYRING"
    rm -f "$TMP_KEYRING"

    $SUDO_CMD rm -f /etc/apt/sources.list.d/cuda-${NVIDIA_REPO_DISTRO}*.list
    echo "deb [signed-by=/usr/share/keyrings/cuda-archive-keyring.gpg] ${CUDA_REPO_URL} /" | $SUDO_CMD tee "$APT_SOURCE_FILE" >/dev/null
    $SUDO_CMD apt-get update -qq
}

AVAILABLE_VERS=""
if [ -n "$NVIDIA_REPO_DISTRO" ]; then
    ensure_cuda_apt_repo
    AVAILABLE_VERS=$(list_apt_toolkit_versions || true)
    if [ -n "$AVAILABLE_VERS" ]; then
        echo -e "${GREEN}Toolkit packages in repo:${YELLOW} $(echo "$AVAILABLE_VERS" | tr '\n' ' ')${RESET}"
    else
        echo -e "${YELLOW}Could not list versioned cuda-toolkit packages from the repo.${RESET}"
    fi
    echo
fi

# torch.version.cuda (e.g. 13.0) is the runtime ABI, not an nvcc package name.
AUTO_CUDA=""
if [ -n "$PYTHON" ] && [ "$TORCH_CUDA" != "N/A" ] && [ -n "$TORCH_CUDA" ]; then
    AUTO_CUDA="$TORCH_CUDA"
fi

RECOMMENDED=""
RESOLVE_NOTE=""
PKG_NAME=""
CUDA_VER=""
CUDA_MAJOR=""
CUDA_MINOR=""

if is_arch_family; then
    # Arch/CachyOS/Manjaro: one package named "cuda", files live in /opt/cuda.
    # There are no cuda-toolkit-13-0 style packages.
    echo -e "${GREEN}Arch-family distro:${YELLOW} a single ${BOLD}cuda${RESET}${GREEN} package (not versioned like cuda-toolkit-13-0)${RESET}"
    ARCH_CUDA_VER=$(arch_cuda_pkg_version || true)
    if [ -z "$ARCH_CUDA_VER" ]; then
        echo -e "${YELLOW}Could not query ${BOLD}pacman -Si cuda${RESET}${YELLOW}. The extra repo may be disabled.${RESET}"
        ARCH_CUDA_VER="${AUTO_CUDA:-unknown}"
    fi
    CUDA_VER="$ARCH_CUDA_VER"
    CUDA_MAJOR="${CUDA_VER%%.*}"
    CUDA_MINOR="${CUDA_VER#*.}"
    CUDA_MINOR="${CUDA_MINOR%%.*}"
    PKG_NAME="cuda"
    RECOMMENDED="$CUDA_VER"
    if [ -n "$AUTO_CUDA" ]; then
        echo -e "${GREEN}PyTorch CUDA runtime:${YELLOW} ${AUTO_CUDA}${RESET}"
        if [ "$CUDA_VER" != "$AUTO_CUDA" ] && [ "$CUDA_VER" != "unknown" ]; then
            echo -e "${YELLOW}Repo cuda package is ${CUDA_VER}. Same ${CUDA_MAJOR}.x series is compatible with PyTorch ${AUTO_CUDA}.${RESET}"
        fi
    fi
    echo
    echo -e "${GREEN}Install plan:${YELLOW} CUDA ${CUDA_VER}${RESET}"
    echo -e "  - Repo package: ${BOLD}cuda${RESET} (pacman extra)"
    echo -e "  - Install prefix: ${BOLD}/opt/cuda${RESET}"
    if [ -n "$AUTO_CUDA" ]; then
        echo -e "  - PyTorch runtime: CUDA ${AUTO_CUDA} (torch.version.cuda)"
    fi
    echo -e "  - Mode: toolkit only (recommended)"
else
    if [ -n "$AUTO_CUDA" ] && [ -n "$AVAILABLE_VERS" ]; then
        if echo "$AVAILABLE_VERS" | grep -qx "$AUTO_CUDA"; then
            RECOMMENDED="$AUTO_CUDA"
        elif RECOMMENDED=$(resolve_toolkit_version "$AUTO_CUDA" "$AVAILABLE_VERS"); then
            RESOLVE_NOTE="Repo has no cuda-toolkit-${AUTO_CUDA%%.*}-${AUTO_CUDA#*.}. Using ${RECOMMENDED} (newest CUDA ${AUTO_CUDA%%.*}.x, compatible with PyTorch ${AUTO_CUDA})."
        fi
    elif [ -n "$AUTO_CUDA" ]; then
        RECOMMENDED="$AUTO_CUDA"
    fi

    # Menu: recommended first, then remaining versions newest-first.
    MENU_VERS=()
    if [ -n "$RECOMMENDED" ]; then
        MENU_VERS+=("$RECOMMENDED")
    fi
    if [ -n "$AVAILABLE_VERS" ]; then
        while IFS= read -r v; do
            [ -z "$v" ] && continue
            [ -n "$RECOMMENDED" ] && [ "$v" = "$RECOMMENDED" ] && continue
            MENU_VERS+=("$v")
        done <<< "$(printf '%s\n' "$AVAILABLE_VERS" | sort -Vr)"
    elif [ ${#MENU_VERS[@]} -eq 0 ]; then
        MENU_VERS=("13.3" "13.1" "12.8")
    fi

    if [ -n "$AUTO_CUDA" ]; then
        echo -e "${GREEN}PyTorch CUDA runtime:${YELLOW} ${AUTO_CUDA}${RESET}"
        if [ -n "$RESOLVE_NOTE" ]; then
            echo -e "${YELLOW}${RESOLVE_NOTE}${RESET}"
        elif [ -n "$RECOMMENDED" ]; then
            echo -e "${GREEN}Repo has an exact match:${YELLOW} CUDA ${RECOMMENDED}${RESET}"
        fi
        echo
    fi

    echo -e "${GREEN}Select CUDA toolkit version to install:${RESET}"
    i=1
    for v in "${MENU_VERS[@]}"; do
        label="  ${i}) CUDA ${v}"
        extra=()
        if [ -n "$RECOMMENDED" ] && [ "$v" = "$RECOMMENDED" ]; then
            extra+=("recommended")
        fi
        if [ -n "$NVCC_VER" ] && [ "$v" = "$NVCC_VER" ]; then
            extra+=("already installed")
        fi
        if [ ${#extra[@]} -gt 0 ]; then
            IFS=', '
            label+=" (${extra[*]})"
            unset IFS
        fi
        echo "$label"
        i=$((i + 1))
    done

    DEFAULT_CHOICE=1
    if [ -n "$RECOMMENDED" ]; then
        idx=1
        for v in "${MENU_VERS[@]}"; do
            if [ "$v" = "$RECOMMENDED" ]; then
                DEFAULT_CHOICE=$idx
                break
            fi
            idx=$((idx + 1))
        done
    fi

    read -r -p "Choice [1-${#MENU_VERS[@]}, default=${DEFAULT_CHOICE}]: " CUDA_CHOICE || true
    CUDA_CHOICE="${CUDA_CHOICE:-$DEFAULT_CHOICE}"
    if ! [[ "$CUDA_CHOICE" =~ ^[0-9]+$ ]] || [ "$CUDA_CHOICE" -lt 1 ] || [ "$CUDA_CHOICE" -gt ${#MENU_VERS[@]} ]; then
        echo -e "${RED}Invalid choice${RESET}"
        exit 1
    fi

    CUDA_VER="${MENU_VERS[$((CUDA_CHOICE - 1))]}"
    CUDA_MAJOR="${CUDA_VER%%.*}"
    CUDA_MINOR="${CUDA_VER#*.}"
    PKG_NAME="cuda-toolkit-${CUDA_MAJOR}-${CUDA_MINOR}"
fi

if ! is_arch_family; then
    echo
    echo -e "${GREEN}Install plan:${YELLOW} CUDA ${CUDA_VER}${RESET}"
    echo -e "  - Repo package: ${BOLD}${PKG_NAME}${RESET}"
    if [ -n "$AUTO_CUDA" ]; then
        echo -e "  - PyTorch runtime: CUDA ${AUTO_CUDA} (torch.version.cuda)"
        if [ "$CUDA_VER" != "$AUTO_CUDA" ]; then
            echo -e "  - ${YELLOW}${PKG_NAME} is the toolkit used to compile extensions; PyTorch keeps its own ${AUTO_CUDA} runtime libraries.${RESET}"
        fi
    fi
    echo -e "  - Mode: toolkit only (recommended)"
    if [ -n "$NVCC_VER" ] && [ "$CUDA_VER" != "$NVCC_VER" ] && ! ver_ge "$CUDA_VER" "$NVCC_VER"; then
        echo -e "  - ${RED}DOWNGRADE: this will purge working CUDA ${NVCC_VER} and install older ${CUDA_VER}.${RESET}"
        echo -e "  - ${YELLOW}PyTorch ${AUTO_CUDA:-runtime} does not need this. Prefer ${RECOMMENDED:-$NVCC_VER}.${RESET}"
    fi
fi

SKIP_INSTALL=false
if [ -n "$NVCC_VER" ] && [ -n "$NVCC_PATH" ] && [ -x "$NVCC_PATH" ]; then
    if [ "$NVCC_VER" = "$CUDA_VER" ] || { is_arch_family && [ "${NVCC_VER%%.*}" = "${CUDA_VER%%.*}" ]; }; then
        echo -e "  - ${GREEN}Working nvcc ${NVCC_VER} already matches this plan — nothing will be removed or reinstalled.${RESET}"
        SKIP_INSTALL=true
    fi
fi

if [ "$SKIP_INSTALL" = true ]; then
    echo
    echo -e "${GREEN}Skipping install: CUDA ${NVCC_VER:-$CUDA_VER} toolkit is already present.${RESET}"
else
    read -r -p "Proceed with installation? [y/N]: " CONFIRM || true
    if [[ ! "$CONFIRM" =~ ^[Yy]$ ]]; then
        echo -e "${YELLOW}Aborted.${RESET}"
        exit 0
    fi
fi

# Installation by distro
install_debian_ubuntu() {
    local SUDO_CMD
    SUDO_CMD=$(sudo_if_needed)

    echo -e "${GREEN}::::::::::::::: Installing CUDA toolkit ${CUDA_VER} via apt :::::::::::::::${RESET}"
    echo -e "${GREEN}Package:${YELLOW} ${PKG_NAME}${RESET}"
    echo -e "${GREEN}NVIDIA repo URL: ${CUDA_REPO_URL}${RESET}"

    # Only wipe when we must: broken files, or switching to a different version.
    local need_purge=false
    if [ -n "$NVCC_VER" ] && [ "$NVCC_VER" != "$CUDA_VER" ]; then
        need_purge=true
        echo -e "${YELLOW}Switching toolkit ${NVCC_VER} → ${CUDA_VER}, removing the old toolkit...${RESET}"
    elif [ -z "$NVCC_PATH" ] || [ ! -x "$NVCC_PATH" ]; then
        local cuda_pkg_count
        cuda_pkg_count=$(dpkg-query -W -f='${Package} ${Status}\n' \
            'cuda-*' 'cccl-*' 'nsight-compute-*' 'nsight-systems-*' 2>/dev/null \
            | awk '!/not-installed/ && $1 != "cuda-keyring" {print $1}' | wc -l || true)
        if [ "${cuda_pkg_count:-0}" -gt 0 ] || ls -d /usr/local/cuda* >/dev/null 2>&1; then
            need_purge=true
            echo -e "${YELLOW}CUDA packages are registered but nvcc is missing — clean reinstall...${RESET}"
        fi
    fi

    if [ "$need_purge" = true ]; then
        mapfile -t cuda_pkgs < <(dpkg-query -W -f='${Package} ${Status}\n' \
            'cuda-*' 'cccl-*' 'nsight-compute-*' 'nsight-systems-*' 2>/dev/null \
            | awk '!/not-installed/ && $1 != "cuda-keyring" {print $1}' || true)
        if [ ${#cuda_pkgs[@]} -gt 0 ]; then
            echo -e "${YELLOW}Purging ${#cuda_pkgs[@]} packages...${RESET}"
            $SUDO_CMD apt-get purge -y "${cuda_pkgs[@]}" || true
        fi
        $SUDO_CMD apt-get autoremove --purge -y || true
        $SUDO_CMD rm -rf /usr/local/cuda*
        $SUDO_CMD dpkg --configure -a || true
        echo -e "${GREEN}✓${RESET} Clean state ready"
    fi

    echo -e "${GREEN}Installing ${PKG_NAME}...${RESET}"
    if ! $SUDO_CMD apt-get install -y "$PKG_NAME"; then
        echo -e "${RED}Failed to install ${PKG_NAME}.${RESET}"
        echo -e "${YELLOW}Available CUDA packages:${RESET}"
        $SUDO_CMD apt-cache search --names-only '^cuda-toolkit-[0-9]' | head -20
        exit 1
    fi

    # apt can report "already the newest version" while files were deleted
    if ! ls /usr/local/cuda*/bin/nvcc >/dev/null 2>&1; then
        echo -e "${YELLOW}nvcc missing after apt install — force-reinstalling compiler packages...${RESET}"
        $SUDO_CMD apt-get install --reinstall -y \
            "cuda-nvcc-${CUDA_MAJOR}-${CUDA_MINOR}" \
            "cuda-compiler-${CUDA_MAJOR}-${CUDA_MINOR}" \
            "cuda-cudart-dev-${CUDA_MAJOR}-${CUDA_MINOR}" \
            "$PKG_NAME" || true
    fi
    echo -e "${GREEN}✓${RESET} CUDA toolkit installed via apt"
}

install_opensuse() {
    echo -e "${GREEN}::::::::::::::: Installing CUDA toolkit ${CUDA_VER} via zypper :::::::::::::::${RESET}"

    local OPENSUSE_VER=""
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        OPENSUSE_VER="${VERSION_ID:-}"
    fi

    local CUDA_REPO="https://developer.download.nvidia.com/compute/cuda/repos/opensuse15/x86_64"
    local SUDO_CMD
    SUDO_CMD=$(sudo_if_needed)

    echo -e "${GREEN}NVIDIA repo URL: ${CUDA_REPO}${RESET}"

    if $SUDO_CMD zypper repos --uri 2>/dev/null | grep -q "$CUDA_REPO"; then
        echo -e "${GREEN}NVIDIA CUDA repository already exists, skipping.${RESET}"
    else
        echo -e "${GREEN}Adding NVIDIA CUDA repository...${RESET}"
        $SUDO_CMD zypper ar -f -G "$CUDA_REPO" nvidia-cuda
    fi
    $SUDO_CMD zypper --gpg-auto-import-keys refresh

    echo -e "${GREEN}Installing ${PKG_NAME}...${RESET}"
    if ! $SUDO_CMD zypper install -y "$PKG_NAME"; then
        echo -e "${YELLOW}Versioned package ${PKG_NAME} not found, searching for available versions...${RESET}"
        local FOUND_PKG
        FOUND_PKG=$($SUDO_CMD zypper search "cuda-toolkit-${CUDA_MAJOR}-" 2>/dev/null | grep -oP 'cuda-toolkit-\d+-\d+' | sort -V | tail -1)
        if [ -n "$FOUND_PKG" ]; then
            echo -e "${GREEN}Found ${FOUND_PKG}, installing...${RESET}"
            if ! $SUDO_CMD zypper install -y "$FOUND_PKG"; then
                echo -e "${YELLOW}Falling back to generic cuda-toolkit...${RESET}"
                $SUDO_CMD zypper install -y cuda-toolkit || { echo -e "${RED}Failed to install CUDA toolkit.${RESET}"; exit 1; }
            fi
        else
            echo -e "${YELLOW}No versioned package found, trying generic cuda-toolkit...${RESET}"
            if ! $SUDO_CMD zypper install -y cuda-toolkit; then
                echo -e "${RED}Failed to install CUDA toolkit.${RESET}"
                $SUDO_CMD zypper search cuda 2>/dev/null | head -30
                exit 1
            fi
        fi
    fi
    echo -e "${GREEN}✓${RESET} CUDA toolkit installed via zypper"
}

install_arch() {
    echo -e "${GREEN}::::::::::::::: Installing CUDA toolkit via pacman :::::::::::::::${RESET}"
    local SUDO_CMD
    SUDO_CMD=$(sudo_if_needed)

    if ! command -v pacman >/dev/null 2>&1; then
        echo -e "${RED}pacman not found.${RESET}"
        exit 1
    fi

    echo -e "${GREEN}Installing ${BOLD}cuda${RESET}${GREEN} (Arch/CachyOS extra — lands in /opt/cuda)...${RESET}"
    if ! $SUDO_CMD pacman -S --noconfirm --needed cuda; then
        echo -e "${RED}Failed to install cuda via pacman.${RESET}"
        echo -e "${YELLOW}Enable the extra repo, or install manually:${RESET}"
        echo -e "  ${BOLD}sudo pacman -S cuda${RESET}"
        echo -e "  ${BOLD}https://developer.nvidia.com/cuda-downloads${RESET}"
        exit 1
    fi

    if [ ! -x /opt/cuda/bin/nvcc ]; then
        echo -e "${YELLOW}cuda package installed but /opt/cuda/bin/nvcc is missing.${RESET}"
        pacman -Ql cuda 2>/dev/null | grep -E 'nvcc$' || true
    fi
    echo -e "${GREEN}✓${RESET} CUDA toolkit installed via pacman"
}

install_rhel_fedora() {
    echo -e "${GREEN}::::::::::::::: Installing CUDA toolkit ${CUDA_VER} via dnf :::::::::::::::${RESET}"

    local DISTRO_VER=""
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        DISTRO_VER="${VERSION_ID:-}"
    fi

    local CUDA_REPO=""
    if [ "$DISTRO" = "fedora" ]; then
        CUDA_REPO="https://developer.download.nvidia.com/compute/cuda/repos/fedora${DISTRO_VER}/x86_64"
    else
        CUDA_REPO="https://developer.download.nvidia.com/compute/cuda/repos/rhel${DISTRO_VER}/x86_64"
    fi

    echo -e "${GREEN}Adding NVIDIA CUDA repository...${RESET}"
    cat > /etc/yum.repos.d/cuda.repo << REPOEOF
[cuda]
name=NVIDIA CUDA Repository
baseurl=${CUDA_REPO}
enabled=1
gpgcheck=1
gpgkey=${CUDA_REPO}/D42D0685.pub
REPOEOF

    dnf clean all
    dnf makecache

    echo -e "${GREEN}Installing ${PKG_NAME}...${RESET}"
    if ! dnf install -y "$PKG_NAME"; then
        echo -e "${YELLOW}Versioned package failed, trying generic cuda-toolkit...${RESET}"
        if ! dnf install -y cuda-toolkit; then
            echo -e "${RED}Failed to install CUDA toolkit.${RESET}"
            exit 1
        fi
    fi
    echo -e "${GREEN}✓${RESET} CUDA toolkit installed via dnf"
}

if [ "$SKIP_INSTALL" != true ]; then
    if is_arch_family; then
        install_arch
    else
        case "$DISTRO" in
            debian|ubuntu|linuxmint)
                install_debian_ubuntu
                ;;
            opensuse|opensuse-tumbleweed|opensuse-leap)
                install_opensuse
                ;;
            fedora|rhel|centos|rocky|alma)
                install_rhel_fedora
                ;;
            *)
                echo -e "${RED}Unsupported distribution: ${DISTRO}${RESET}"
                echo -e "${YELLOW}Please install CUDA ${CUDA_VER} manually from:${RESET}"
                echo -e "  ${BOLD}https://developer.nvidia.com/cuda-downloads${RESET}"
                exit 1
                ;;
        esac
    fi
fi

# Post-install: verify and set up paths
echo
echo -e "${GREEN}::::::::::::::: Running CUDA checks :::::::::::::::${RESET}"

CUDA_HOME=""
if [ -x "/opt/cuda/bin/nvcc" ]; then
    CUDA_HOME="/opt/cuda"
elif [ -n "${CUDA_VER:-}" ] && [ -x "/usr/local/cuda-${CUDA_VER}/bin/nvcc" ]; then
    CUDA_HOME="/usr/local/cuda-${CUDA_VER}"
elif [ -x "/usr/local/cuda/bin/nvcc" ]; then
    CUDA_HOME="/usr/local/cuda"
elif command -v nvcc &> /dev/null; then
    CUDA_HOME=$(cd "$(dirname "$(command -v nvcc)")/.." && pwd)
fi

if [ -z "$CUDA_HOME" ] || [ ! -x "$CUDA_HOME/bin/nvcc" ]; then
    for dir in /opt/cuda /opt/cuda-* /usr/local/cuda /usr/local/cuda-*; do
        if [ -x "$dir/bin/nvcc" ]; then
            CUDA_HOME="$dir"
            break
        fi
    done
fi

if [ -n "$CUDA_HOME" ] && [ -x "$CUDA_HOME/bin/nvcc" ] && [ ! -e "/usr/local/cuda" ]; then
    $(sudo_if_needed) ln -sfn "$CUDA_HOME" /usr/local/cuda
    echo -e "${GREEN}✓${RESET} Created /usr/local/cuda symlink → ${CUDA_HOME}"
fi

if [ -n "$CUDA_HOME" ] && [ -x "$CUDA_HOME/bin/nvcc" ]; then
    NVCC_VER=$("$CUDA_HOME/bin/nvcc" --version 2>/dev/null | grep "release" | sed -n 's/.*release \([0-9]\+\.[0-9]\+\).*/\1/p')
    echo -e "${GREEN}✓${RESET} nvcc found: ${CUDA_HOME}/bin/nvcc (v${NVCC_VER})"
    echo -e "${GREEN}✓${RESET} CUDA_HOME: ${CUDA_HOME}"

    CUDA_MARKER="# >>> CUDA toolkit >>>"
    CUDA_END="# <<< CUDA toolkit <<<"
    CUDA_BLOCK="${CUDA_MARKER}
export CUDA_HOME=${CUDA_HOME}
export PATH=\$CUDA_HOME/bin:\$PATH
export LD_LIBRARY_PATH=\$CUDA_HOME/lib64:\$LD_LIBRARY_PATH
${CUDA_END}"
    for rc in "${HOME}/.bashrc" "${HOME}/.zshrc"; do
        if [ -f "$rc" ] || [ "$rc" = "${HOME}/.bashrc" ]; then
            if [ -f "$rc" ] && grep -q "$CUDA_MARKER" "$rc" 2>/dev/null; then
                sed -i "/${CUDA_MARKER}/,/${CUDA_END}/d" "$rc"
            fi
            printf '%s\n' "$CUDA_BLOCK" >> "$rc"
            echo -e "${GREEN}✓${RESET} CUDA paths added to ${rc}"
        fi
    done
    export CUDA_HOME
    export PATH="$CUDA_HOME/bin:$PATH"
    export LD_LIBRARY_PATH="$CUDA_HOME/lib64:${LD_LIBRARY_PATH:-}"
else
    echo -e "${RED}ERROR: nvcc not found${RESET}"
    echo -e "${YELLOW}CUDA toolkit may have been installed but is not on PATH.${RESET}"
    echo -e "${YELLOW}Looked in /opt/cuda and /usr/local/cuda*:${RESET}"
    ls -d /opt/cuda /opt/cuda-* /usr/local/cuda* 2>/dev/null || echo "  (no cuda directories found)"
    exit 1
fi

echo
echo -e "${GREEN}::::::::::::::: Done :::::::::::::::${RESET}"
echo -e "${YELLOW}Current shell exports (if needed):${RESET}"
echo "  export CUDA_HOME=${CUDA_HOME:-/usr/local/cuda}"
echo "  export PATH=\$CUDA_HOME/bin:\$PATH"
echo "  export LD_LIBRARY_PATH=\$CUDA_HOME/lib64:\$LD_LIBRARY_PATH"
echo

if [ -n "$CUDA_HOME" ] && [ "$CUDA_HOME" != "/usr/local/cuda" ]; then
    if [ ! -L "/usr/local/cuda" ]; then
        ln -sfn "$CUDA_HOME" /usr/local/cuda 2>/dev/null || true
        echo -e "${GREEN}✓${RESET} Created symlink /usr/local/cuda -> ${CUDA_HOME}"
    fi
fi

echo -e "${GREEN}::::::::::::::: CUDA ${CUDA_VER} toolkit ready :::::::::::::::${RESET}"
echo
echo -e "${YELLOW}Note: You may need to open a new shell or run:${RESET}"
echo -e "  ${BOLD}export CUDA_HOME=${CUDA_HOME}${RESET}"
echo -e "  ${BOLD}export PATH=\$CUDA_HOME/bin:\$PATH${RESET}"
echo -e "  ${BOLD}export LD_LIBRARY_PATH=\$CUDA_HOME/lib64:\$LD_LIBRARY_PATH${RESET}"
echo
echo -e "${YELLOW}Now re-run the SageAttention installer.${RESET}"
