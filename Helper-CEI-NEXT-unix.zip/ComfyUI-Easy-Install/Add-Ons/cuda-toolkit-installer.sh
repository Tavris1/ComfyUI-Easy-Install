#!/bin/bash
cd "$(dirname "$0")"

# Title: CUDA Toolkit Installer for ComfyUI Easy Install
# Adds the NVIDIA CUDA repository and installs the toolkit

set -euo pipefail

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
RESET='\033[0m'

echo -e "${GREEN}::::::::::::::: Universal CUDA Toolkit Installer :::::::::::::::${RESET}"
echo

# Detect distro
DISTRO=""
if [ -f /etc/os-release ]; then
    . /etc/os-release
    DISTRO="$ID"
    DISTRO_VERSION="$VERSION_ID"
    DISTRO_NAME="$NAME"
else
    echo -e "${RED}Cannot detect Linux distribution. /etc/os-release not found.${RESET}"
    exit 1
fi

echo -e "${GREEN}Detected:${YELLOW} ${DISTRO_NAME} (${DISTRO} ${DISTRO_VERSION})${RESET}"
echo

# Locate embedded Python for version checks
find_embedded_python() {
    for base in ".." "../.."; do
        for ver in "_3.12" "_3.11" ""; do
            for sub in "/python" "/bin/python"; do
                local candidate="${base}/python_embeded${ver}${sub}"
                if [ -x "$candidate" ]; then
                    echo "$candidate"
                    return 0
                fi
            done
        done
    done
    return 1
}

PYTHON=$(find_embedded_python || true)
if [ -z "$PYTHON" ]; then
    if command -v python3 >/dev/null 2>&1; then
        PYTHON=python3
    elif command -v python >/dev/null 2>&1; then
        PYTHON=python
    fi
fi

# Preflight check
echo -e "${GREEN}::::::::::::::: Preflight check ${YELLOW}(before installation)${GREEN} :::::::::::::::${RESET}"

if command -v nvcc &> /dev/null; then
    NVCC_PATH=$(which nvcc)
    NVCC_VER=$(nvcc --version 2>/dev/null | grep "release" | sed -n 's/.*release \([0-9]\+\.[0-9]\+\).*/\1/p')
    echo -e "${GREEN}nvcc found:${YELLOW} ${NVCC_PATH} (v${NVCC_VER})${RESET}"
else
    echo -e "${YELLOW}WARNING: nvcc not found on current PATH/known locations${RESET}"
fi

if [ -n "$PYTHON" ]; then
    PY_VER=$("$PYTHON" --version 2>&1 | cut -d' ' -f2)
    TORCH_VER=$("$PYTHON" -c "import torch; print(torch.__version__)" 2>/dev/null || echo "not installed")
    TORCH_CUDA=$("$PYTHON" -c "import torch; print(torch.version.cuda if torch.cuda.is_available() else 'N/A')" 2>/dev/null || echo "N/A")
    echo -e "${GREEN}Embedded python:${YELLOW} ${PYTHON}${RESET}"
    echo -e "${GREEN}Python version:${YELLOW} ${PY_VER}${RESET}"
    echo -e "${GREEN}Torch version:${YELLOW} ${TORCH_VER}${RESET}"
    echo -e "${GREEN}Torch CUDA available:${YELLOW} ${TORCH_CUDA}${RESET}"
    echo -e "${GREEN}Current torch.version.cuda:${YELLOW} ${TORCH_CUDA}${RESET}"

    if "$PYTHON" -c "import sysconfig, os; print(os.path.exists(os.path.join(sysconfig.get_path('include'), 'Python.h')))" 2>/dev/null | grep -q "True"; then
        echo -e "${GREEN}Python development headers:${YELLOW} found${RESET}"
    else
        echo -e "${YELLOW}Python development headers: NOT found${RESET}"
    fi
else
    echo -e "${YELLOW}No Python found for version checks${RESET}"
fi

echo -e "${GREEN}Preflight summary: all core checks look good${RESET}"
echo

# Select CUDA version
echo -e "${GREEN}Select CUDA toolkit version:${RESET}"
echo "  1) CUDA 12.8"
echo "  2) CUDA 13.0"
echo "  3) CUDA 13.1"
read -p "Choice [1-3]: " CUDA_CHOICE

case "$CUDA_CHOICE" in
    1) CUDA_VER="12.8"; CUDA_MAJOR="12"; CUDA_MINOR="8" ;;
    2) CUDA_VER="13.0"; CUDA_MAJOR="13"; CUDA_MINOR="0" ;;
    3) CUDA_VER="13.1"; CUDA_MAJOR="13"; CUDA_MINOR="1" ;;
    *) echo -e "${RED}Invalid choice${RESET}"; exit 1 ;;
esac

echo
echo -e "${GREEN}Install plan:${YELLOW} CUDA ${CUDA_VER}${RESET}"
echo -e "  - Mode: toolkit only (recommended)"
read -p "Proceed with installation? [y/N]: " CONFIRM
if [[ ! "$CONFIRM" =~ ^[Yy]$ ]]; then
    echo -e "${YELLOW}Aborted.${RESET}"
    exit 0
fi

# Installation by distro
install_debian_ubuntu() {
    local APT_DISTRO="$1"
    local APT_CODENAME="$2"
    # Use sudo if not root
    local SUDO_CMD=""
    if [ "$(id -u)" -ne 0 ]; then
        SUDO_CMD="sudo"
    fi
    local CUDA_KEYRING_PKG="cuda-keyring"
    # NVIDIA uses debian<version> not debian/codename for repo paths
    # Normalize version: remove dots so "24.04" becomes "2404"
    local REPO_VERSION=$(echo "$DISTRO_VERSION" | sed 's/[^0-9]//g')
    local NVIDIA_REPO_DISTRO="${APT_DISTRO}${REPO_VERSION}"
    local CUDA_REPO_URL="https://developer.download.nvidia.com/compute/cuda/repos/${NVIDIA_REPO_DISTRO}/x86_64"
    local CUDA_KEYRING_URL="${CUDA_REPO_URL}/cuda-keyring_1.1-1_all.deb"

    echo -e "${GREEN}::::::::::::::: Installing CUDA toolkit ${CUDA_VER} via apt :::::::::::::::${RESET}"
    echo -e "${GREEN}NVIDIA repo URL: ${CUDA_REPO_URL}${RESET}"

    # Install prerequisites
    $SUDO_CMD apt-get update -qq
    $SUDO_CMD apt-get install -y -qq wget gnupg ca-certificates

    # Download and install cuda-keyring
    echo -e "${GREEN}Adding NVIDIA CUDA repository...${RESET}"
    TMP_KEYRING=$(mktemp /tmp/cuda-keyring.XXXXXX.deb)
    wget -q -O "$TMP_KEYRING" "$CUDA_KEYRING_URL" || {
        echo -e "${YELLOW}Failed to download cuda-keyring from ${CUDA_KEYRING_URL}${RESET}"
        echo -e "${YELLOW}Trying alternate repo paths...${RESET}"
        # Try common alternate patterns
        for alt_distro in "${APT_DISTRO}${REPO_VERSION}" "${APT_DISTRO}$(echo $APT_CODENAME | sed 's/[^a-z]//g')" "${APT_CODENAME}" "${APT_DISTRO}12" "${APT_DISTRO}11"; do
            alt_url="https://developer.download.nvidia.com/compute/cuda/repos/${alt_distro}/x86_64/cuda-keyring_1.1-1_all.deb"
            echo -e "${YELLOW}  Trying: ${alt_url}${RESET}"
            if wget -q -O "$TMP_KEYRING" "$alt_url"; then
                CUDA_REPO_URL="https://developer.download.nvidia.com/compute/cuda/repos/${alt_distro}/x86_64"
                echo -e "${GREEN}✓${RESET} Found repo at ${alt_distro}"
                break
            fi
        done
        if [ ! -s "$TMP_KEYRING" ]; then
            echo -e "${RED}Failed to download cuda-keyring from all attempted URLs.${RESET}"
            echo -e "${YELLOW}Check network connectivity to developer.download.nvidia.com${RESET}"
            echo -e "${YELLOW}Or install CUDA manually from: https://developer.nvidia.com/cuda-downloads${RESET}"
            rm -f "$TMP_KEYRING"
            exit 1
        fi
    }
    $SUDO_CMD dpkg -i "$TMP_KEYRING"
    rm -f "$TMP_KEYRING"

    # Add repository if not already present
    APT_SOURCE_FILE="/etc/apt/sources.list.d/cuda-${NVIDIA_REPO_DISTRO}.list"
    if [ ! -f "$APT_SOURCE_FILE" ]; then
        echo "deb [signed-by=/usr/share/keyrings/cuda-archive-keyring.gpg] ${CUDA_REPO_URL} /" | $SUDO_CMD tee "$APT_SOURCE_FILE" >/dev/null
    fi

    $SUDO_CMD apt-get update -qq

    # Install the toolkit
    # NVIDIA names packages by the latest minor version in the series, e.g. cuda-toolkit-13-3
    # Try the requested version, then the latest available in that major series
    local PKG_NAME="cuda-toolkit-${CUDA_MAJOR}-${CUDA_MINOR}"
    echo -e "${GREEN}Installing ${PKG_NAME}...${RESET}"
    if ! $SUDO_CMD apt-get install -y "$PKG_NAME"; then
        echo -e "${YELLOW}Versioned package ${PKG_NAME} not found, searching for available versions...${RESET}"
        # Search for any cuda-toolkit-<major>-* package
        local FOUND_PKG=$($SUDO_CMD apt-cache search "cuda-toolkit-${CUDA_MAJOR}-" | grep "^cuda-toolkit-${CUDA_MAJOR}-" | head -1 | awk '{print $1}')
        if [ -n "$FOUND_PKG" ]; then
            echo -e "${GREEN}Found ${FOUND_PKG}, installing...${RESET}"
            if ! $SUDO_CMD apt-get install -y "$FOUND_PKG"; then
                echo -e "${YELLOW}Falling back to generic cuda-toolkit...${RESET}"
                $SUDO_CMD apt-get install -y cuda-toolkit || { echo -e "${RED}Failed to install CUDA toolkit.${RESET}"; exit 1; }
            fi
        else
            echo -e "${YELLOW}No versioned package found, trying generic cuda-toolkit...${RESET}"
            if ! $SUDO_CMD apt-get install -y cuda-toolkit; then
                echo -e "${RED}Failed to install CUDA toolkit.${RESET}"
                echo -e "${YELLOW}Available CUDA packages:${RESET}"
                $SUDO_CMD apt-cache search cuda-toolkit | head -20
                exit 1
            fi
        fi
    fi
    echo -e "${GREEN}✓${RESET} CUDA toolkit installed via apt"
}

install_opensuse() {
    echo -e "${GREEN}::::::::::::::: Installing CUDA toolkit ${CUDA_VER} via zypper :::::::::::::::${RESET}"

    # Add NVIDIA CUDA repository for openSUSE
    local OPENSUSE_VER=""
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        OPENSUSE_VER="$VERSION_ID"
    fi

    # NVIDIA only provides opensuse15 repo for all openSUSE versions (including Tumbleweed)
    local CUDA_REPO="https://developer.download.nvidia.com/compute/cuda/repos/opensuse15/x86_64"

    # Use sudo if not root
    local SUDO_CMD=""
    if [ "$(id -u)" -ne 0 ]; then
        SUDO_CMD="sudo"
    fi

    echo -e "${GREEN}NVIDIA repo URL: ${CUDA_REPO}${RESET}"

    # Check if repo already exists before adding
    if $SUDO_CMD zypper repos --uri 2>/dev/null | grep -q "$CUDA_REPO"; then
        echo -e "${GREEN}NVIDIA CUDA repository already exists, skipping.${RESET}"
    else
        echo -e "${GREEN}Adding NVIDIA CUDA repository...${RESET}"
        $SUDO_CMD zypper ar -f -G "$CUDA_REPO" nvidia-cuda
    fi
    $SUDO_CMD zypper --gpg-auto-import-keys refresh

    # NVIDIA names packages by latest minor version, e.g. cuda-toolkit-13-3
    local PKG_NAME="cuda-toolkit-${CUDA_MAJOR}-${CUDA_MINOR}"
    echo -e "${GREEN}Installing ${PKG_NAME}...${RESET}"
    if ! $SUDO_CMD zypper install -y "$PKG_NAME"; then
        echo -e "${YELLOW}Versioned package ${PKG_NAME} not found, searching for available versions...${RESET}"
        # Search for any cuda-toolkit-<major>-* package and extract the actual package name
        local FOUND_PKG=$($SUDO_CMD zypper search "cuda-toolkit-${CUDA_MAJOR}-" 2>/dev/null | grep -oP 'cuda-toolkit-\d+-\d+' | sort -V | head -1)
        if [ -n "$FOUND_PKG" ]; then
            echo -e "${GREEN}Found ${FOUND_PKG}, installing...${RESET}"
            if ! $SUDO_CMD zypper install -y "$FOUND_PKG"; then
                echo -e "${YELLOW}Falling back to generic cuda-toolkit...${RESET}"
                $SUDO_CMD zypper install -y cuda-toolkit || { echo -e "${RED}Failed to install CUDA toolkit.${RESET}"; exit 1; }
            fi
        else
            echo -e "${YELLOW}No versioned package found, trying generic cuda-toolkit...${RESET}"
            if ! $SUDO_CMD zypper install -y cuda-toolkit; then
                echo -e "${RED}Failed to install CUDA toolkit.${RESET}"
                echo -e "${YELLOW}Searching for available CUDA packages...${RESET}"
                $SUDO_CMD zypper search cuda 2>/dev/null | head -30
                exit 1
            fi
        fi
    fi
    echo -e "${GREEN}✓${RESET} CUDA toolkit installed via zypper"
}

install_rhel_fedora() {
    echo -e "${GREEN}::::::::::::::: Installing CUDA toolkit ${CUDA_VER} via dnf :::::::::::::::${RESET}"

    # Add NVIDIA CUDA repository
    local DISTRO_VER=""
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        DISTRO_VER="$VERSION_ID"
    fi

    local CUDA_REPO=""
    if [ "$DISTRO" = "fedora" ]; then
        CUDA_REPO="https://developer.download.nvidia.com/compute/cuda/repos/fedora${DISTRO_VER}/x86_64"
    else
        CUDA_REPO="https://developer.download.nvidia.com/compute/cuda/repos/rhel${DISTRO_VER}/x86_64"
    fi

    echo -e "${GREEN}Adding NVIDIA CUDA repository...${RESET}"
    cat > /etc/yum.repos.d/cuda.repo << REPOEOF
[cuda]
name=NVIDIA CUDA Repository
baseurl=${CUDA_REPO}
enabled=1
gpgcheck=1
gpgkey=${CUDA_REPO}/D42D0685.pub
REPOEOF

    dnf clean all
    dnf makecache

    local PKG_NAME="cuda-toolkit-${CUDA_MAJOR}-${CUDA_MINOR}"
    echo -e "${GREEN}Installing ${PKG_NAME}...${RESET}"
    if ! dnf install -y "$PKG_NAME"; then
        echo -e "${YELLOW}Versioned package failed, trying generic cuda-toolkit...${RESET}"
        if ! dnf install -y cuda-toolkit; then
            echo -e "${RED}Failed to install CUDA toolkit.${RESET}"
            exit 1
        fi
    fi
    echo -e "${GREEN}✓${RESET} CUDA toolkit installed via dnf"
}

# Route to correct installer
case "$DISTRO" in
    debian|ubuntu|linuxmint)
        # Determine the codename for the CUDA repo
        APT_DISTRO="$DISTRO"
        APT_CODENAME=""

        if [ "$DISTRO" = "debian" ]; then
            # Debian version to codename mapping
            case "$DISTRO_VERSION" in
                12*) APT_CODENAME="bookworm" ;;
                13*) APT_CODENAME="trixie" ;;
                *) APT_CODENAME=$(lsb_release -cs 2>/dev/null || echo "trixie") ;;
            esac
        elif [ "$DISTRO" = "ubuntu" ]; then
            APT_CODENAME=$(lsb_release -cs 2>/dev/null || echo "jammy")
        elif [ "$DISTRO" = "linuxmint" ]; then
            # Map Linux Mint versions to their Ubuntu base for NVIDIA repo
            case "$DISTRO_VERSION" in
                22*) UBUNTU_BASE="2404"; APT_CODENAME="noble" ;;
                21*) UBUNTU_BASE="2204"; APT_CODENAME="jammy" ;;
                20*) UBUNTU_BASE="2004"; APT_CODENAME="focal" ;;
                *) UBUNTU_BASE="2404"; APT_CODENAME="noble" ;;
            esac
            APT_DISTRO="ubuntu"
            DISTRO_VERSION="$UBUNTU_BASE"
            NVIDIA_REPO_DISTRO="ubuntu${UBUNTU_BASE}"
        fi

        # For Debian Trixie, use trixie repo
        if [ "$DISTRO" = "debian" ] && [ -z "$APT_CODENAME" ]; then
            APT_CODENAME="trixie"
        fi

        install_debian_ubuntu "$APT_DISTRO" "$APT_CODENAME"
        ;;
    opensuse|opensuse-tumbleweed|opensuse-leap)
        install_opensuse
        ;;
    fedora|rhel|centos|rocky|alma)
        install_rhel_fedora
        ;;
    *)
        echo -e "${RED}Unsupported distribution: ${DISTRO}${RESET}"
        echo -e "${YELLOW}Please install CUDA ${CUDA_VER} manually from:${RESET}"
        echo -e "  ${BOLD}https://developer.nvidia.com/cuda-downloads${RESET}"
        exit 1
        ;;
esac

# Post-install: verify and set up paths
echo
echo -e "${GREEN}::::::::::::::: Running CUDA checks :::::::::::::::${RESET}"

# Find the installed CUDA — NVIDIA may install a different minor version than requested
CUDA_HOME=""
if [ -d "/usr/local/cuda-${CUDA_VER}" ]; then
    CUDA_HOME="/usr/local/cuda-${CUDA_VER}"
elif [ -d "/usr/local/cuda" ]; then
    CUDA_HOME="/usr/local/cuda"
elif command -v nvcc &> /dev/null; then
    CUDA_HOME=$(dirname $(dirname $(which nvcc)))
fi

# If still not found, search for any /usr/local/cuda-* directory (NVIDIA may install a newer minor)
if [ -z "$CUDA_HOME" ] || [ ! -x "$CUDA_HOME/bin/nvcc" ]; then
    for dir in /usr/local/cuda-*; do
        if [ -x "$dir/bin/nvcc" ]; then
            CUDA_HOME="$dir"
            break
        fi
    done
fi

if [ -n "$CUDA_HOME" ] && [ -x "$CUDA_HOME/bin/nvcc" ]; then
    NVCC_VER=$("$CUDA_HOME/bin/nvcc" --version 2>/dev/null | grep "release" | sed -n 's/.*release \([0-9]\+\.[0-9]\+\).*/\1/p')
    echo -e "${GREEN}✓${RESET} nvcc found: ${CUDA_HOME}/bin/nvcc (v${NVCC_VER})"
    echo -e "${GREEN}✓${RESET} CUDA_HOME: ${CUDA_HOME}"
else
    echo -e "${RED}ERROR: nvcc not found${RESET}"
    echo -e "${YELLOW}CUDA toolkit may have been installed but is not on PATH.${RESET}"
    echo -e "${YELLOW}Try sourcing the CUDA environment or check /usr/local/cuda*${RESET}"
fi

echo
echo -e "${GREEN}::::::::::::::: Done :::::::::::::::${RESET}"
echo -e "${YELLOW}Current shell exports (if needed):${RESET}"
echo "  export CUDA_HOME=${CUDA_HOME:-/usr/local/cuda}"
echo "  export PATH=\$CUDA_HOME/bin:\$PATH"
echo "  export LD_LIBRARY_PATH=\$CUDA_HOME/lib64:\$LD_LIBRARY_PATH"
echo

# Also create/update the /usr/local/cuda symlink if needed
if [ -n "$CUDA_HOME" ] && [ "$CUDA_HOME" != "/usr/local/cuda" ]; then
    if [ ! -L "/usr/local/cuda" ]; then
        ln -sf "$CUDA_HOME" /usr/local/cuda 2>/dev/null || true
        echo -e "${GREEN}✓${RESET} Created symlink /usr/local/cuda -> ${CUDA_HOME}"
    fi
fi

echo -e "${GREEN}::::::::::::::: CUDA ${CUDA_VER} toolkit installation complete :::::::::::::::${RESET}"
echo
echo -e "${YELLOW}Note: You may need to open a new shell or run:${RESET}"
echo -e "  ${BOLD}export PATH=/usr/local/cuda/bin:\$PATH${RESET}"
echo -e "  ${BOLD}export LD_LIBRARY_PATH=/usr/local/cuda/lib64:\$LD_LIBRARY_PATH${RESET}"
echo
echo -e "${YELLOW}Now re-run the SageAttention installer.${RESET}"
