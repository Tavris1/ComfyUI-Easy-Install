#!/bin/bash
# Title: 'SageAttention' for 'ComfyUI Easy Install' by ivo

# Set colors
WARNING='\033[33m'
RED='\033[91m'
GREEN='\033[92m'
YELLOW='\033[93m'
BOLD='\033[1m'
RESET='\033[0m'

NODE_NAME="SageAttention"

# Set arguments
PIPargs="--no-cache-dir --no-warn-script-location --timeout=1000 --retries 200 --use-pep517"

# Check Add-ons folder
PYTHON_PATH="../python_embeded/bin/python"
if [ ! -f "$PYTHON_PATH" ]; then
    clear
    echo -e "${GREEN}::::::::::::::: Run this file from the ${RED}'ComfyUI-Easy-Install/Add-ons'${GREEN} folder"
    echo -e "${GREEN}::::::::::::::: Press any key to exit...${RESET}"
    read -p ""
    exit 1
fi

cd "$(dirname "$0")"

# Clear Pip Cache
if [ -d "$HOME/.cache/pip" ]; then
    rm -rf "$HOME/.cache/pip"
    mkdir -p "$HOME/.cache/pip"
fi
echo -e "${GREEN}::::::::::::::: Clearing Pip Cache ${YELLOW}Done${GREEN}${RESET}"
echo

# Get versions
echo -e "${GREEN}::::::::::::::: Checking ${YELLOW}Python, Torch, CUDA ${GREEN}versions${RESET}"
echo

PYTHON_VERSION=$($PYTHON_PATH -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
TORCH_VERSION=$($PYTHON_PATH -c "import torch; print(torch.__version__)" | cut -d. -f1,2)
CUDA_VERSION=$($PYTHON_PATH -c "import torch; print(torch.version.cuda if torch.cuda.is_available() else 'Not available')" | cut -d. -f1,2)

echo -e "${GREEN}::::::::::::::: Python Version:${YELLOW} $PYTHON_VERSION${RESET}"
echo -e "${GREEN}::::::::::::::: Torch Version:${YELLOW} $TORCH_VERSION${RESET}"
echo -e "${GREEN}::::::::::::::: CUDA Version:${YELLOW} $CUDA_VERSION${RESET}"
echo

WARNINGS=0

if [[ "$PYTHON_VERSION" != "3.11" && "$PYTHON_VERSION" != "3.12" ]]; then
    echo -e "${WARNING}WARNING: ${RED}Python $PYTHON_VERSION is not supported. ${GREEN}Supported versions: 3.11, 3.12${RESET}"
    WARNINGS=1
fi
if [[ "$TORCH_VERSION" != "2.7" && "$TORCH_VERSION" != "2.8" ]]; then
    echo -e "${WARNING}WARNING: ${RED}Torch $TORCH_VERSION is not supported. ${GREEN}Supported versions: 2.7, 2.8${RESET}"
    WARNINGS=1
fi
if [[ "$CUDA_VERSION" != "12.8" ]]; then
    echo -e "${WARNING}WARNING: ${RED}CUDA $CUDA_VERSION is not supported. ${GREEN}Supported version: 12.8${RESET}"
    WARNINGS=1
fi

if [ $WARNINGS -eq 0 ]; then
    echo -e "${GREEN}::::::::::::::: ${RESET}${BOLD}All versions are supported! ${RESET}"
    echo
else
    echo
    echo -e "${RED}::::::::::::::: Press any key to exit${RESET}"
    read -p ""
    exit 1
fi

# Erasing ~* folders
find ../python_embeded/lib/ -type d -name "~*" -exec rm -rf {} +

# Installing Triton
echo -e "${GREEN}::::::::::::::: Installing${YELLOW} Triton${RESET}"
echo
$PYTHON_PATH -I -m pip install --upgrade --force-reinstall triton==3.4.0.post2 $PIPargs
echo

# Installing SageAttention
echo -e "${GREEN}::::::::::::::: Installing${YELLOW} $NODE_NAME${RESET}"
echo

if [ "$TORCH_VERSION" == "2.7" ] && [ "$CUDA_VERSION" == "12.8" ]; then
    SAGE_WHL="sageattention-2.2.0+cu128torch2.7.1.post3-cp311-cp311-linux_x86_64.whl"
elif [ "$TORCH_VERSION" == "2.8" ] && [ "$CUDA_VERSION" == "12.8" ]; then
    SAGE_WHL="sageattention-2.2.0+cu128torch2.8.0.post3-cp311-cp311-linux_x86_64.whl"
fi

$PYTHON_PATH -I -m pip install --upgrade --force-reinstall https://github.com/woct0rdho/SageAttention/releases/download/v2.2.0-linux.post3/$SAGE_WHL $PIPargs

# Creating run_nvidia_gpu_SageAttention.sh file
echo
echo -e "${GREEN}::::::::::::::: Creating${YELLOW} run_nvidia_gpu_SageAttention.sh${RESET}"
echo
cat << EOF > ../run_nvidia_gpu_SageAttention.sh
#!/bin/bash
cd "\$(dirname "\$0")"
echo "Starting ComfyUI with SageAttention"
./python_embeded/bin/python -I -W ignore::FutureWarning ComfyUI/main.py --windows-standalone-build --use-sage-attention
read -p "Press any key to continue..."
EOF
chmod +x ../run_nvidia_gpu_SageAttention.sh

# Final Messages
echo
echo -e "${GREEN}:::::::::::::::%YELLOW% $NODE_NAME %GREEN%Installation Complete%RESET}"
echo
if [ -z "$1" ]; then
    echo -e "${GREEN}::::::::::::::: ${YELLOW}Press any key to exit${RESET}"
    read -p ""
    exit 0
fi
