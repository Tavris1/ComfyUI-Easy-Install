#!/bin/bash
cd "$(dirname "$0")"

node_name="SageAttention"
echo -e "\033]0;'$node_name' for 'ComfyUI Easy Install' by ivo\007"

# Pixaroma Community Edition

# Set colors
warning='\033[33m'
red='\033[91m'
green='\033[92m'
yellow='\033[93m'
bold='\033[1m'
reset='\033[0m'

# Set arguments
PIPargs="--no-cache-dir --no-warn-script-location --timeout=1000 --retries 200 --use-pep517"

# Check Add-ons folder and find embedded Python
# The main installer creates python_embeded/python (wrapper) or python_embeded/bin/python3
PYTHON_PATH=""

# Try different possible locations for embedded Python
if [ -f "../python_embeded/python" ]; then
    PYTHON_PATH="../python_embeded/python"
elif [ -f "../python_embeded/bin/python3" ]; then
    PYTHON_PATH="../python_embeded/bin/python3"
elif [ -f "../python_embeded/bin/python" ]; then
    PYTHON_PATH="../python_embeded/bin/python"
elif [ -f "../python_embeded/python3" ]; then
    PYTHON_PATH="../python_embeded/python3"
fi

if [ -z "$PYTHON_PATH" ] || [ ! -f "$PYTHON_PATH" ]; then
    clear
    echo -e "${red}::::::::::::::: ERROR: Embedded Python not found!${reset}"
    echo -e "${green}::::::::::::::: Expected locations:${reset}"
    echo -e "${yellow}    ../python_embeded/python${reset}"
    echo -e "${yellow}    ../python_embeded/bin/python3${reset}"
    echo
    echo -e "${green}::::::::::::::: Run this file from the ${red}'ComfyUI-Easy-Install/Add-ons'${green} folder.${reset}"
    echo -e "${green}::::::::::::::: Press any key to exit...${reset}"
    read -n 1 -s
    exit 1
fi

echo -e "${green}::::::::::::::: Using Python:${yellow} $PYTHON_PATH${reset}"
echo


# Clear Pip Cache
if [ -d "$HOME/.cache/pip" ]; then
    rm -rf "$HOME/.cache/pip"
    mkdir -p "$HOME/.cache/pip"
fi
echo -e "${green}::::::::::::::: Clearing Pip Cache ${yellow}Done${green}${reset}"
echo

# Get versions
get_versions() {
    echo -e "${green}::::::::::::::: Checking ${yellow}Python, Torch, CUDA ${green}versions${reset}"
    echo

    PYTHON_VERSION=$("$PYTHON_PATH" --version 2>&1 | cut -d' ' -f2 | cut -d'.' -f1,2)
    TORCH_VERSION=$("$PYTHON_PATH" -c "import torch; print(torch.__version__)" 2>/dev/null | cut -d'.' -f1,2)
    CUDA_VERSION=$("$PYTHON_PATH" -c "import torch; print(torch.version.cuda if torch.cuda.is_available() else 'Not available')" 2>/dev/null | cut -d'.' -f1,2)

    echo -e "${green}::::::::::::::: Python Version:${yellow} $PYTHON_VERSION${reset}"
    echo -e "${green}::::::::::::::: Torch Version:${yellow} $TORCH_VERSION${reset}"
    echo -e "${green}::::::::::::::: CUDA Version:${yellow} $CUDA_VERSION${reset}"
    echo

    WARNINGS=0

    if [[ "$PYTHON_VERSION" != "3.11" && "$PYTHON_VERSION" != "3.12" ]]; then
        echo -e "${warning}WARNING: ${red}Python $PYTHON_VERSION is not supported. ${green}Supported versions: 3.11, 3.12${reset}"
        WARNINGS=1
    fi
    # Torch might not be installed yet, so check if TORCH_VERSION is empty
    if [ -z "$TORCH_VERSION" ]; then
        echo -e "${warning}WARNING: ${red}Torch is not installed. Please install PyTorch before running this script.${reset}"
        WARNINGS=1
    elif [[ "$TORCH_VERSION" != "2.2" && "$TORCH_VERSION" != "2.3" && "$TORCH_VERSION" != "2.4" && "$TORCH_VERSION" != "2.5" && "$TORCH_VERSION" != "2.6" && "$TORCH_VERSION" != "2.7" && "$TORCH_VERSION" != "2.8" && "$TORCH_VERSION" != "2.9" ]]; then
        echo -e "${warning}WARNING: ${red}Torch $TORCH_VERSION is not supported. ${green}Supported versions: 2.2 - 2.9${reset}"
        WARNINGS=1
    fi
    if [[ "$CUDA_VERSION" != "12.1" && "$CUDA_VERSION" != "12.4" && "$CUDA_VERSION" != "12.8" && "$CUDA_VERSION" != "13.0" ]]; then
        echo -e "${warning}WARNING: ${red}CUDA $CUDA_VERSION is not supported. ${green}Supported versions: 12.1, 12.4, 12.8, 13.0${reset}"
        WARNINGS=1
    fi

    if [ $WARNINGS -eq 0 ]; then
        echo -e "${green}::::::::::::::: ${reset}${bold}All versions are supported! ${reset}"
        echo
    else
        echo
        echo -e "${red}::::::::::::::: Press any key to exit${reset}"
        read -n 1 -s
        exit
    fi
}

get_versions

# Check for Python development headers
echo -e "${green}::::::::::::::: Checking ${yellow}Python development headers${reset}"
echo

if ! "$PYTHON_PATH" -c "import sysconfig; import os; print(os.path.exists(os.path.join(sysconfig.get_path('include'), 'Python.h')))" 2>/dev/null | grep -q "True"; then
    echo -e "${warning}WARNING: ${red}Python development headers (Python.h) not found.${reset}"
    echo
    echo -e "${yellow}SageAttention requires Python development headers to compile C++ extensions.${reset}"
    echo -e "${yellow}Please install them using one of these methods:${reset}"
    echo
    echo -e "${green}Ubuntu/Debian:${reset}"
    echo -e "  ${bold}sudo apt-get update && sudo apt-get install -y python3.11-dev${reset}"
    echo
    echo -e "${green}RHEL/CentOS/Fedora:${reset}"
    echo -e "  ${bold}sudo yum install -y python3.11-devel${reset}"
    echo
    echo -e "${green}Arch Linux:${reset}"
    echo -e "  ${bold}sudo pacman -S python${reset}"
    echo
    echo -e "${red}::::::::::::::: Press any key to exit${reset}"
    read -n 1 -s
    exit 1
fi

echo -e "${green}::::::::::::::: Python development headers ${yellow}found!${reset}"
echo

# Erasing ~* folders
find "../python_embeded/lib/" -type d -name "~*" -exec rm -rf {} + 2>/dev/null

# Installing build dependencies
echo -e "${green}::::::::::::::: Installing${yellow} build dependencies${reset}"
echo
"$PYTHON_PATH" -m pip install --upgrade wheel setuptools ninja $PIPargs
echo

# Installing Triton
echo -e "${green}::::::::::::::: Installing${yellow} Triton${reset}"
echo
"$PYTHON_PATH" -I -m pip install --upgrade --force-reinstall triton==3.5.1 $PIPargs
echo

# Detect CUDA_HOME (CUDA toolkit) for building SageAttention
echo -e "${green}::::::::::::::: Checking ${yellow}CUDA toolkit (CUDA_HOME)${reset}"
echo

CUDA_HOME_DETECTED=$(
    "$PYTHON_PATH" -c "
try:
    from torch.utils.cpp_extension import CUDA_HOME
    print(CUDA_HOME or '')
except Exception:
    print('')
" 2>/dev/null
)

if [ -z "$CUDA_HOME_DETECTED" ] && command -v nvcc &>/dev/null; then
    NVCC_PATH="$(command -v nvcc)"
    CUDA_HOME_DETECTED="$(dirname "$(dirname "$NVCC_PATH")")"
fi

if [ -z "$CUDA_HOME" ] && [ -n "$CUDA_HOME_DETECTED" ]; then
    export CUDA_HOME="$CUDA_HOME_DETECTED"
fi

if [ -z "$CUDA_HOME" ] || [ ! -d "$CUDA_HOME" ]; then
    echo -e "${warning}WARNING: ${red}CUDA_HOME not found.${reset}"
    echo
    echo -e "${yellow}SageAttention needs the NVIDIA CUDA Toolkit to compile (nvcc + headers).${reset}"
    echo -e "${yellow}PyTorch reporting CUDA support is not enough; the toolkit must be installed inside this environment.${reset}"
    echo
    echo -e "${green}Fix options:${reset}"
    echo -e "  ${bold}1) Install the CUDA Toolkit automatically${reset}"
    echo -e "  ${bold}2) Set CUDA_HOME manually (if already installed elsewhere)${reset}"
    echo -e "  ${bold}3) Exit${reset}"
    echo
    read -p "Choose an option [1/2/3]: " CUDA_CHOICE

    case "$CUDA_CHOICE" in
        1)
            echo
            echo -e "${green}::::::::::::::: Installing CUDA Toolkit...${reset}"
            echo
            # Detect distro and install CUDA toolkit
            if [ -f /etc/os-release ]; then
                . /etc/os-release
                DISTRO="$ID"
            else
                DISTRO="unknown"
            fi

            case "$DISTRO" in
                ubuntu)
                    echo -e "${yellow}Detected: $DISTRO - Adding NVIDIA CUDA repository and installing cuda-toolkit-12-8${reset}"
                    apt-get update
                    apt-get install -y wget gnupg
                    # Add NVIDIA CUDA repo for Ubuntu
                    UBUNTU_VERSION=$(lsb_release -rs | tr -d '.')
                    wget -q -O /tmp/cuda-keyring.deb "https://developer.download.nvidia.com/compute/cuda/repos/ubuntu${UBUNTU_VERSION}/x86_64/cuda-keyring_1.1-1_all.deb"
                    dpkg -i /tmp/cuda-keyring.deb
                    rm -f /tmp/cuda-keyring.deb
                    apt-get update
                    apt-get install -y cuda-toolkit-12-8
                    ;;
                debian)
                    echo -e "${yellow}Detected: $DISTRO - Adding NVIDIA CUDA repository and installing cuda-toolkit-12-8${reset}"
                    apt-get update
                    apt-get install -y wget gnupg software-properties-common
                    # Add NVIDIA CUDA repo for Debian 12 (bookworm)
                    wget -q -O /tmp/cuda-keyring.deb "https://developer.download.nvidia.com/compute/cuda/repos/debian12/x86_64/cuda-keyring_1.1-1_all.deb"
                    dpkg -i /tmp/cuda-keyring.deb
                    rm -f /tmp/cuda-keyring.deb
                    apt-get update
                    apt-get install -y cuda-toolkit-12-8
                    ;;
                fedora|rhel|centos|rocky|almalinux)
                    echo -e "${yellow}Detected: $DISTRO - Adding NVIDIA CUDA repository and installing cuda-toolkit-12-8${reset}"
                    dnf config-manager --add-repo https://developer.download.nvidia.com/compute/cuda/repos/rhel9/x86_64/cuda-rhel9.repo 2>/dev/null || \
                    yum-config-manager --add-repo https://developer.download.nvidia.com/compute/cuda/repos/rhel9/x86_64/cuda-rhel9.repo 2>/dev/null
                    dnf install -y cuda-toolkit-12-8 || yum install -y cuda-toolkit-12-8
                    ;;
                arch|manjaro)
                    echo -e "${yellow}Detected: $DISTRO - Installing cuda${reset}"
                    pacman -Sy --noconfirm cuda
                    ;;
                *)
                    echo -e "${red}Unknown distro: $DISTRO. Please install CUDA toolkit manually.${reset}"
                    echo -e "${red}::::::::::::::: Press any key to exit${reset}"
                    read -n 1 -s
                    exit 1
                    ;;
            esac

            # Set CUDA_HOME after installation
            if [ -d "/usr/local/cuda-12.8" ]; then
                export CUDA_HOME="/usr/local/cuda-12.8"
            elif [ -d "/usr/local/cuda" ]; then
                export CUDA_HOME="/usr/local/cuda"
            elif [ -d "/opt/cuda" ]; then
                export CUDA_HOME="/opt/cuda"
            else
                echo -e "${red}CUDA toolkit installed but CUDA_HOME path not found.${reset}"
                echo -e "${yellow}Please set CUDA_HOME manually and re-run.${reset}"
                echo -e "${red}::::::::::::::: Press any key to exit${reset}"
                read -n 1 -s
                exit 1
            fi
            echo
            echo -e "${green}::::::::::::::: CUDA_HOME set to:${yellow} $CUDA_HOME${reset}"
            ;;
        2)
            echo
            read -p "Enter your CUDA installation path (e.g. /usr/local/cuda): " CUDA_MANUAL_PATH
            if [ -d "$CUDA_MANUAL_PATH" ]; then
                export CUDA_HOME="$CUDA_MANUAL_PATH"
                echo -e "${green}::::::::::::::: CUDA_HOME set to:${yellow} $CUDA_HOME${reset}"
            else
                echo -e "${red}Directory not found: $CUDA_MANUAL_PATH${reset}"
                echo -e "${red}::::::::::::::: Press any key to exit${reset}"
                read -n 1 -s
                exit 1
            fi
            ;;
        *)
            echo -e "${red}::::::::::::::: Exiting${reset}"
            exit 1
            ;;
    esac
    echo
fi

echo -e "${green}::::::::::::::: CUDA_HOME:${yellow} $CUDA_HOME${reset}"
echo

# Installing SageAttention
echo -e "${green}::::::::::::::: Installing${yellow} $node_name${reset}"
echo

# Detect GPU compute capability for TORCH_CUDA_ARCH_LIST
GPU_ARCH=$(
    "$PYTHON_PATH" -c "
import torch
if torch.cuda.is_available():
    cap = torch.cuda.get_device_capability(0)
    print(f'{cap[0]}.{cap[1]}')
else:
    print('8.6')
" 2>/dev/null
)
echo -e "${green}::::::::::::::: GPU Compute Capability:${yellow} $GPU_ARCH${reset}"

export TORCH_CUDA_ARCH_LIST="$GPU_ARCH"
export NVCC_FLAGS="-allow-unsupported-compiler"

# Patch PyTorch's cpp_extension.py to skip CUDA version check
# This is needed when system CUDA differs from PyTorch's bundled CUDA
TORCH_CPP_EXT=$(
    "$PYTHON_PATH" -c "import torch.utils.cpp_extension as ext; print(ext.__file__)" 2>/dev/null
)

PATCHED_CPP_EXT=0
if [ -f "$TORCH_CPP_EXT" ]; then
    echo -e "${green}::::::::::::::: Patching PyTorch CUDA version check...${reset}"
    cp "$TORCH_CPP_EXT" "${TORCH_CPP_EXT}.bak"
    # Replace the raise statement with pass to maintain valid Python syntax
    # This handles both old and new PyTorch versions
    "$PYTHON_PATH" -c "
import re
with open('$TORCH_CPP_EXT', 'r') as f:
    content = f.read()
# Replace 'raise RuntimeError(CUDA_MISMATCH_MESSAGE' with 'pass  # '
content = re.sub(
    r'raise RuntimeError\(CUDA_MISMATCH_MESSAGE[^)]*\)',
    'pass  # CUDA version check disabled by SageAttention installer',
    content
)
with open('$TORCH_CPP_EXT', 'w') as f:
    f.write(content)
"
    PATCHED_CPP_EXT=1
    echo -e "${green}::::::::::::::: Patch applied${reset}"
fi
echo

# Clone and install SageAttention from VenimK's fork
SAGE_DIR="SageAttention"
if [ -d "$SAGE_DIR" ]; then
    echo -e "${green}::::::::::::::: Updating existing SageAttention repo${reset}"
    cd "$SAGE_DIR"
    git fetch origin
    git reset --hard origin/main
    cd ..
else
    echo -e "${green}::::::::::::::: Cloning SageAttention from VenimK's fork${reset}"
    git clone https://github.com/VenimK/SageAttention.git "$SAGE_DIR"
fi

echo -e "${green}::::::::::::::: Building SageAttention from source${reset}"
echo
# Use absolute path for Python since we're changing directories
ABS_PYTHON_PATH=$(cd "$(dirname "$PYTHON_PATH")" && pwd)/$(basename "$PYTHON_PATH")
cd "$SAGE_DIR"
"$ABS_PYTHON_PATH" -m pip install --upgrade --no-build-isolation -e . $PIPargs
cd ..

# Restore original cpp_extension.py
if [ "$PATCHED_CPP_EXT" -eq 1 ] && [ -f "${TORCH_CPP_EXT}.bak" ]; then
    echo -e "${green}::::::::::::::: Restoring PyTorch cpp_extension.py${reset}"
    mv "${TORCH_CPP_EXT}.bak" "$TORCH_CPP_EXT"
fi

# Creating run_nvidia_gpu_SageAttention.sh file
echo
echo -e "${green}::::::::::::::: Creating${yellow} run_nvidia_gpu_SageAttention.sh${reset}"
echo

cat > ../run_nvidia_gpu_SageAttention.sh << 'SAGE_SCRIPT'
#!/bin/bash

cd "$(dirname "$0")"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
BOLD='\033[1m'
RESET='\033[0m'

# Animation functions
spinner() {
    local pid=$1
    local delay=0.1
    local spinstr='⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏'
    while [ "$(ps a | awk '{print $1}' | grep $pid)" ]; do
        local temp=${spinstr#?}
        printf " ${CYAN}[%c]${RESET}  " "$spinstr"
        local spinstr=$temp${spinstr%"$temp"}
        sleep $delay
        printf "\b\b\b\b\b\b"
    done
    printf "    \b\b\b\b"
}

print_header() {
    clear
    echo -e "${MAGENTA}╔═══════════════════════════════════════════════════════════╗${RESET}"
    echo -e "${MAGENTA}║${CYAN}                                                           ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}        ╔═╗╔═╗╔╦╗╔═╗╦ ╦╦ ╦╦  ${YELLOW}╔═╗╔═╗╔═╗╦ ╦              ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}        ║  ║ ║║║║╠╣ ╚╦╝║ ║║  ${YELLOW}║╣ ╠═╣╚═╗╚╦╝              ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}        ╚═╝╚═╝╩ ╩╚   ╩ ╚═╝╩  ${YELLOW}╚═╝╩ ╩╚═╝ ╩               ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}                                                           ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${GREEN}              🎨 Easy Install by VenimK 🚀                ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}                                                           ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}               🎨 Pixaroma Soldier 🚀                       ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}                                                           ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${YELLOW}              ⚡ SageAttention Enabled ⚡                  ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}╚═══════════════════════════════════════════════════════════╝${RESET}"
    echo ""
}

loading_bar() {
    local duration=$1
    local message=$2
    local width=50
    echo -ne "${YELLOW}${message}${RESET}\n"
    for ((i = 0 ; i <= width ; i++)); do
        echo -ne "${GREEN}▓${RESET}"
        sleep $(echo "scale=4; $duration/$width" | bc)
    done
    echo -e " ${GREEN}✓${RESET}"
}

generate_ascii_art() {
    local delay=0.05
    echo -e "${CYAN}🎨 Initializing AI Image Generator...${RESET}"
    sleep 0.5
    echo ""
    
    # Frame 1 - Empty canvas
    echo -e "${YELLOW}[Generating...]${RESET} Step 1/4 - Preparing canvas"
    echo -e "${MAGENTA}┌────────────────────┐${RESET}"
    for i in {1..6}; do
        echo -e "${MAGENTA}│${RESET}                    ${MAGENTA}│${RESET}"
        sleep $delay
    done
    echo -e "${MAGENTA}└────────────────────┘${RESET}"
    sleep 0.3
    
    # Clear and redraw with noise
    clear
    print_header
    echo -e "${YELLOW}[Generating...]${RESET} Step 2/4 - Adding noise"
    echo -e "${MAGENTA}┌────────────────────┐${RESET}"
    local chars=".:░▒▓"
    for i in {1..6}; do
        echo -ne "${MAGENTA}│${RESET}"
        for j in {1..20}; do
            local rand_char=${chars:$((RANDOM % ${#chars})):1}
            echo -ne "${CYAN}${rand_char}${RESET}"
            sleep 0.002
        done
        echo -e "${MAGENTA}│${RESET}"
    done
    echo -e "${MAGENTA}└────────────────────┘${RESET}"
    sleep 0.3
    
    # Clear and redraw with pattern forming
    clear
    print_header
    echo -e "${YELLOW}[Generating...]${RESET} Step 3/4 - Forming patterns"
    echo -e "${MAGENTA}┌────────────────────┐${RESET}"
    echo -e "${MAGENTA}│${RESET}${GREEN}░░░▒▒▓▓██${YELLOW}☼☼${GREEN}██▓▓▒▒░░░${RESET}${MAGENTA}│${RESET}"
    sleep $delay
    echo -e "${MAGENTA}│${RESET}${GREEN}░░▒▒▓▓${CYAN}████${YELLOW}◉◉${CYAN}████${GREEN}▓▓▒▒░░${RESET}${MAGENTA}│${RESET}"
    sleep $delay
    echo -e "${MAGENTA}│${RESET}${GREEN}░▒▓${CYAN}██${BLUE}▓▓▓▓${YELLOW}││${BLUE}▓▓▓▓${CYAN}██${GREEN}▓▒░${RESET}${MAGENTA}│${RESET}"
    sleep $delay
    echo -e "${MAGENTA}│${RESET}${GREEN}░▒▓${CYAN}██${BLUE}▓${WHITE}◆◆◆◆${BLUE}▓${CYAN}██${GREEN}▓▒░${RESET}${MAGENTA}│${RESET}"
    sleep $delay
    echo -e "${MAGENTA}│${RESET}${GREEN}░░▒▓${CYAN}███${BLUE}▓▓▓▓${CYAN}███${GREEN}▓▒░░${RESET}${MAGENTA}│${RESET}"
    sleep $delay
    echo -e "${MAGENTA}│${RESET}${GREEN}░░░▒▓▓${CYAN}██████${GREEN}▓▓▒░░░${RESET}${MAGENTA}│${RESET}"
    echo -e "${MAGENTA}└────────────────────┘${RESET}"
    sleep 0.3
    
    # Clear and show final image
    clear
    print_header
    echo -e "${GREEN}[Complete!]${RESET} Step 4/4 - Rendering final image ✓"
    echo -e "${MAGENTA}┌────────────────────┐${RESET}"
    echo -e "${MAGENTA}│${RESET}${GREEN}░░░▒▒▓▓██${YELLOW}☼☼${GREEN}██▓▓▒▒░░░${RESET}${MAGENTA}│${RESET}"
    echo -e "${MAGENTA}│${RESET}${GREEN}░░▒▒▓▓${CYAN}████${YELLOW}◉◉${CYAN}████${GREEN}▓▓▒▒░░${RESET}${MAGENTA}│${RESET}"
    echo -e "${MAGENTA}│${RESET}${GREEN}░▒▓${CYAN}██${BLUE}▓▓▓▓${YELLOW}││${BLUE}▓▓▓▓${CYAN}██${GREEN}▓▒░${RESET}${MAGENTA}│${RESET}"
    echo -e "${MAGENTA}│${RESET}${GREEN}░▒▓${CYAN}██${BLUE}▓${WHITE}◆◆◆◆${BLUE}▓${CYAN}██${GREEN}▓▒░${RESET}${MAGENTA}│${RESET}"
    echo -e "${MAGENTA}│${RESET}${GREEN}░░▒▓${CYAN}███${BLUE}▓▓▓▓${CYAN}███${GREEN}▓▒░░${RESET}${MAGENTA}│${RESET}"
    echo -e "${MAGENTA}│${RESET}${GREEN}░░░▒▓▓${CYAN}██████${GREEN}▓▓▒░░░${RESET}${MAGENTA}│${RESET}"
    echo -e "${MAGENTA}└────────────────────┘${RESET}"
    echo ""
    
    # Stats display
    echo -e "${CYAN}╭─────────────────────────────────────╮${RESET}"
    echo -e "${CYAN}│${RESET} ${YELLOW}⚡${RESET} Seed: ${WHITE}42424242${RESET}                  ${CYAN}│${RESET}"
    echo -e "${CYAN}│${RESET} ${GREEN}✓${RESET} Steps: ${WHITE}20${RESET}                        ${CYAN}│${RESET}"
    echo -e "${CYAN}│${RESET} ${MAGENTA}🎨${RESET} Sampler: ${WHITE}DPM++ 2M Karras${RESET}      ${CYAN}│${RESET}"
    echo -e "${CYAN}│${RESET} ${BLUE}⏱${RESET}  Time: ${WHITE}0.${RANDOM:0:2}s${RESET}                   ${CYAN}│${RESET}"
    echo -e "${CYAN}╰─────────────────────────────────────╯${RESET}"
    echo ""
    sleep 1
}

print_header

# Detect Python environment
echo -e "${CYAN}🔍 Detecting Python environment...${RESET}"
PYTHON_CMD=""

# Try different possible locations for embedded Python
if [ -f "python_embeded/python" ]; then
    PYTHON_CMD="./python_embeded/python"
    echo -e "${GREEN}   ✓ Found Python (embedded)${RESET}"
elif [ -f "python_embeded/bin/python3" ]; then
    PYTHON_CMD="./python_embeded/bin/python3"
    echo -e "${GREEN}   ✓ Found Python 3 (embedded)${RESET}"
elif [ -f "python_embeded/bin/python" ]; then
    PYTHON_CMD="./python_embeded/bin/python"
    echo -e "${GREEN}   ✓ Found Python (embedded)${RESET}"
elif [ -f "python_embeded/python3" ]; then
    PYTHON_CMD="./python_embeded/python3"
    echo -e "${GREEN}   ✓ Found Python 3 (embedded)${RESET}"
else
    echo -e "${YELLOW}   ⚠ No embedded Python found, using system Python${RESET}"
    PYTHON_CMD="python3"
fi
echo ""
echo -e "${CYAN}🐍 Using: ${YELLOW}${PYTHON_CMD}${RESET}"
echo ""

# Show ASCII art generation animation
generate_ascii_art

# Ask for custom output directory
CONFIG_FILE=".output_dir_config"
custom_output_dir=""

# Check if config file exists
if [ -f "$CONFIG_FILE" ]; then
    custom_output_dir=$(cat "$CONFIG_FILE")
    clear
    print_header
    echo -e "${CYAN}📁 Output Directory Configuration${RESET}"
    echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo ""
    if [ -n "$custom_output_dir" ]; then
        echo -e "${GREEN}   ✓ Saved output directory: ${YELLOW}${custom_output_dir}${RESET}"
    else
        echo -e "${GREEN}   ✓ Using default output directory${RESET}"
    fi
    echo ""
    echo -e "${CYAN}Press Enter to continue, or type 'c' to change:${RESET}"
    read -p "> " change_choice
    
    if [ "$change_choice" = "c" ] || [ "$change_choice" = "C" ]; then
        clear
        print_header
        echo -e "${CYAN}📁 Output Directory Configuration${RESET}"
        echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
        echo ""
        echo -e "${YELLOW}Enter new output directory path:${RESET}"
        echo -e "${CYAN}Press Enter to use default, or type path:${RESET}"
        read -p "Path: " custom_output_dir
        echo "$custom_output_dir" > "$CONFIG_FILE"
        echo ""
    fi
else
    # First time setup
    clear
    print_header
    echo -e "${CYAN}📁 Output Directory Configuration${RESET}"
    echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo ""
    echo -e "${YELLOW}Do you want to use a custom output directory?${RESET}"
    echo -e "${CYAN}Press Enter to use default, or type path:${RESET}"
    read -p "Path: " custom_output_dir
    echo "$custom_output_dir" > "$CONFIG_FILE"
    echo ""
fi

# Launch ComfyUI
clear
print_header
echo -e "${CYAN}🚀 Launching ComfyUI with SageAttention...${RESET}"
echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo ""

# Build command with optional output directory
if [ -n "$custom_output_dir" ]; then
    echo -e "${GREEN}   ✓ Using custom output: ${YELLOW}${custom_output_dir}${RESET}"
    echo -e "${GREEN}   ✓ SageAttention: ${YELLOW}Enabled${RESET}"
    echo ""
    sleep 0.5
    $PYTHON_CMD -W ignore::FutureWarning ComfyUI/main.py --use-sage-attention --output-directory "$custom_output_dir" --listen 0.0.0.0
else
    echo -e "${GREEN}   ✓ Using default output directory${RESET}"
    echo -e "${GREEN}   ✓ SageAttention: ${YELLOW}Enabled${RESET}"
    echo ""
    sleep 0.5
    $PYTHON_CMD -W ignore::FutureWarning ComfyUI/main.py --use-sage-attention --listen 0.0.0.0 --disable-pinned-memory
fi

echo ""
echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${YELLOW}✨ ComfyUI session ended ✨${RESET}"
echo ""
echo -e "${GREEN}Press any key to exit...${RESET}"
read -n 1 -s
SAGE_SCRIPT

chmod +x ../run_nvidia_gpu_SageAttention.sh


# Final Messages
echo
echo -e "${GREEN}:::::::::::::::${YELLOW} ${NODE_NAME} ${GREEN}Installation Complete${reset}"
echo
if [ -z "$1" ]; then
    echo -e "${green}::::::::::::::: ${yellow}Press any key to exit${reset}"
    read -n 1 -s
    exit
fi
