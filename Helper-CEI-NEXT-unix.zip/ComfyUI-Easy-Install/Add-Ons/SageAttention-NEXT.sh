#!/bin/bash
cd "$(dirname "$0")"

node_name="SageAttention"
echo -e "\033]0;'$node_name' for 'ComfyUI Easy Install' by ivo\007"

# Pixaroma Community Edition

# Set colors
warning='\033[33m'
red='\033[91m'
green='\033[92m'
yellow='\033[93m'
bold='\033[1m'
reset='\033[0m'

# Set arguments
PIPargs="--no-cache-dir --no-warn-script-location --timeout=1000 --retries 200 --use-pep517"

# Check Add-ons folder
PYTHON_PATH="../python_embeded/bin/python"
if [ ! -f "$PYTHON_PATH" ]; then
    # Fallback to python3 if not in the expected embedded path
    if command -v python3 &> /dev/null; then
        PYTHON_PATH=$(command -v python3)
    else
        clear
        echo -e "${green}::::::::::::::: Run this file from the ${red}'ComfyUI-Easy-Install/Add-ons'${green} folder, or ensure python3 is in your PATH.${reset}"
        echo -e "${green}::::::::::::::: Press any key to exit...${reset}"
        read -n 1 -s
        exit
    fi
fi


# Clear Pip Cache
if [ -d "$HOME/.cache/pip" ]; then
    rm -rf "$HOME/.cache/pip"
    mkdir -p "$HOME/.cache/pip"
fi
echo -e "${green}::::::::::::::: Clearing Pip Cache ${yellow}Done${green}${reset}"
echo

# Get versions
get_versions() {
    echo -e "${green}::::::::::::::: Checking ${yellow}Python, Torch, CUDA ${green}versions${reset}"
    echo

    PYTHON_VERSION=$("$PYTHON_PATH" --version 2>&1 | cut -d' ' -f2 | cut -d'.' -f1,2)
    TORCH_VERSION=$("$PYTHON_PATH" -c "import torch; print(torch.__version__)" 2>/dev/null | cut -d'.' -f1,2)
    CUDA_VERSION=$("$PYTHON_PATH" -c "import torch; print(torch.version.cuda if torch.cuda.is_available() else 'Not available')" 2>/dev/null | cut -d'.' -f1,2)

    echo -e "${green}::::::::::::::: Python Version:${yellow} $PYTHON_VERSION${reset}"
    echo -e "${green}::::::::::::::: Torch Version:${yellow} $TORCH_VERSION${reset}"
    echo -e "${green}::::::::::::::: CUDA Version:${yellow} $CUDA_VERSION${reset}"
    echo

    WARNINGS=0

    if [[ "$PYTHON_VERSION" != "3.11" && "$PYTHON_VERSION" != "3.12" ]]; then
        echo -e "${warning}WARNING: ${red}Python $PYTHON_VERSION is not supported. ${green}Supported versions: 3.11, 3.12${reset}"
        WARNINGS=1
    fi
    # Torch might not be installed yet, so check if TORCH_VERSION is empty
    if [ -z "$TORCH_VERSION" ]; then
        echo -e "${warning}WARNING: ${red}Torch is not installed. Please install PyTorch before running this script.${reset}"
        WARNINGS=1
    elif [[ "$TORCH_VERSION" != "2.7" && "$TORCH_VERSION" != "2.8" && "$TORCH_VERSION" != "2.9" ]]; then
        echo -e "${warning}WARNING: ${red}Torch $TORCH_VERSION is not supported. ${green}Supported versions: 2.7, 2.8, 2.9${reset}"
        WARNINGS=1
    fi
    if [[ "$CUDA_VERSION" != "12.8" ]]; then
        echo -e "${warning}WARNING: ${red}CUDA $CUDA_VERSION is not supported. ${green}Supported version: 12.8${reset}"
        WARNINGS=1
    fi

    if [ $WARNINGS -eq 0 ]; then
        echo -e "${green}::::::::::::::: ${reset}${bold}All versions are supported! ${reset}"
        echo
    else
        echo
        echo -e "${red}::::::::::::::: Press any key to exit${reset}"
        read -n 1 -s
        exit
    fi
}

get_versions

# Check for Python development headers
echo -e "${green}::::::::::::::: Checking ${yellow}Python development headers${reset}"
echo

if ! "$PYTHON_PATH" -c "import sysconfig; import os; print(os.path.exists(os.path.join(sysconfig.get_path('include'), 'Python.h')))" 2>/dev/null | grep -q "True"; then
    echo -e "${warning}WARNING: ${red}Python development headers (Python.h) not found.${reset}"
    echo
    echo -e "${yellow}SageAttention requires Python development headers to compile C++ extensions.${reset}"
    echo -e "${yellow}Please install them using one of these methods:${reset}"
    echo
    echo -e "${green}Ubuntu/Debian:${reset}"
    echo -e "  ${bold}sudo apt-get update && sudo apt-get install -y python3.11-dev${reset}"
    echo
    echo -e "${green}RHEL/CentOS/Fedora:${reset}"
    echo -e "  ${bold}sudo yum install -y python3.11-devel${reset}"
    echo
    echo -e "${green}Arch Linux:${reset}"
    echo -e "  ${bold}sudo pacman -S python${reset}"
    echo
    echo -e "${red}::::::::::::::: Press any key to exit${reset}"
    read -n 1 -s
    exit 1
fi

echo -e "${green}::::::::::::::: Python development headers ${yellow}found!${reset}"
echo

# Erasing ~* folders
find "../python_embeded/lib/" -type d -name "~*" -exec rm -rf {} + 2>/dev/null

# Installing build dependencies
echo -e "${green}::::::::::::::: Installing${yellow} build dependencies${reset}"
echo
"$PYTHON_PATH" -m pip install --upgrade wheel setuptools $PIPargs
echo

# Installing Triton
echo -e "${green}::::::::::::::: Installing${yellow} Triton${reset}"
echo
"$PYTHON_PATH" -I -m pip install --upgrade --force-reinstall triton==3.5.0 $PIPargs
echo

# Detect CUDA_HOME (CUDA toolkit) for building SageAttention
echo -e "${green}::::::::::::::: Checking ${yellow}CUDA toolkit (CUDA_HOME)${reset}"
echo

CUDA_HOME_DETECTED=$(
    "$PYTHON_PATH" -c "
try:
    from torch.utils.cpp_extension import CUDA_HOME
    print(CUDA_HOME or '')
except Exception:
    print('')
" 2>/dev/null
)

if [ -z "$CUDA_HOME_DETECTED" ] && command -v nvcc &>/dev/null; then
    NVCC_PATH="$(command -v nvcc)"
    CUDA_HOME_DETECTED="$(dirname "$(dirname "$NVCC_PATH")")"
fi

if [ -z "$CUDA_HOME" ] && [ -n "$CUDA_HOME_DETECTED" ]; then
    export CUDA_HOME="$CUDA_HOME_DETECTED"
fi

if [ -z "$CUDA_HOME" ] || [ ! -d "$CUDA_HOME" ]; then
    echo -e "${warning}WARNING: ${red}CUDA_HOME not found.${reset}"
    echo
    echo -e "${yellow}SageAttention needs the NVIDIA CUDA Toolkit to compile (nvcc + headers).${reset}"
    echo -e "${yellow}PyTorch reporting CUDA support is not enough; the toolkit must be installed inside this environment.${reset}"
    echo
    echo -e "${green}Fix options:${reset}"
    echo -e "  ${bold}1) Install the CUDA Toolkit automatically${reset}"
    echo -e "  ${bold}2) Set CUDA_HOME manually (if already installed elsewhere)${reset}"
    echo -e "  ${bold}3) Exit${reset}"
    echo
    read -p "Choose an option [1/2/3]: " CUDA_CHOICE

    case "$CUDA_CHOICE" in
        1)
            echo
            echo -e "${green}::::::::::::::: Installing CUDA Toolkit...${reset}"
            echo
            # Detect distro and install CUDA toolkit
            if [ -f /etc/os-release ]; then
                . /etc/os-release
                DISTRO="$ID"
            else
                DISTRO="unknown"
            fi

            case "$DISTRO" in
                ubuntu)
                    echo -e "${yellow}Detected: $DISTRO - Adding NVIDIA CUDA repository and installing cuda-toolkit-12-8${reset}"
                    apt-get update
                    apt-get install -y wget gnupg
                    # Add NVIDIA CUDA repo for Ubuntu
                    UBUNTU_VERSION=$(lsb_release -rs | tr -d '.')
                    wget -q -O /tmp/cuda-keyring.deb "https://developer.download.nvidia.com/compute/cuda/repos/ubuntu${UBUNTU_VERSION}/x86_64/cuda-keyring_1.1-1_all.deb"
                    dpkg -i /tmp/cuda-keyring.deb
                    rm -f /tmp/cuda-keyring.deb
                    apt-get update
                    apt-get install -y cuda-toolkit-12-8
                    ;;
                debian)
                    echo -e "${yellow}Detected: $DISTRO - Adding NVIDIA CUDA repository and installing cuda-toolkit-12-8${reset}"
                    apt-get update
                    apt-get install -y wget gnupg software-properties-common
                    # Add NVIDIA CUDA repo for Debian 12 (bookworm)
                    wget -q -O /tmp/cuda-keyring.deb "https://developer.download.nvidia.com/compute/cuda/repos/debian12/x86_64/cuda-keyring_1.1-1_all.deb"
                    dpkg -i /tmp/cuda-keyring.deb
                    rm -f /tmp/cuda-keyring.deb
                    apt-get update
                    apt-get install -y cuda-toolkit-12-8
                    ;;
                fedora|rhel|centos|rocky|almalinux)
                    echo -e "${yellow}Detected: $DISTRO - Adding NVIDIA CUDA repository and installing cuda-toolkit-12-8${reset}"
                    dnf config-manager --add-repo https://developer.download.nvidia.com/compute/cuda/repos/rhel9/x86_64/cuda-rhel9.repo 2>/dev/null || \
                    yum-config-manager --add-repo https://developer.download.nvidia.com/compute/cuda/repos/rhel9/x86_64/cuda-rhel9.repo 2>/dev/null
                    dnf install -y cuda-toolkit-12-8 || yum install -y cuda-toolkit-12-8
                    ;;
                arch|manjaro)
                    echo -e "${yellow}Detected: $DISTRO - Installing cuda${reset}"
                    pacman -Sy --noconfirm cuda
                    ;;
                *)
                    echo -e "${red}Unknown distro: $DISTRO. Please install CUDA toolkit manually.${reset}"
                    echo -e "${red}::::::::::::::: Press any key to exit${reset}"
                    read -n 1 -s
                    exit 1
                    ;;
            esac

            # Set CUDA_HOME after installation
            if [ -d "/usr/local/cuda-12.8" ]; then
                export CUDA_HOME="/usr/local/cuda-12.8"
            elif [ -d "/usr/local/cuda" ]; then
                export CUDA_HOME="/usr/local/cuda"
            elif [ -d "/opt/cuda" ]; then
                export CUDA_HOME="/opt/cuda"
            else
                echo -e "${red}CUDA toolkit installed but CUDA_HOME path not found.${reset}"
                echo -e "${yellow}Please set CUDA_HOME manually and re-run.${reset}"
                echo -e "${red}::::::::::::::: Press any key to exit${reset}"
                read -n 1 -s
                exit 1
            fi
            echo
            echo -e "${green}::::::::::::::: CUDA_HOME set to:${yellow} $CUDA_HOME${reset}"
            ;;
        2)
            echo
            read -p "Enter your CUDA installation path (e.g. /usr/local/cuda): " CUDA_MANUAL_PATH
            if [ -d "$CUDA_MANUAL_PATH" ]; then
                export CUDA_HOME="$CUDA_MANUAL_PATH"
                echo -e "${green}::::::::::::::: CUDA_HOME set to:${yellow} $CUDA_HOME${reset}"
            else
                echo -e "${red}Directory not found: $CUDA_MANUAL_PATH${reset}"
                echo -e "${red}::::::::::::::: Press any key to exit${reset}"
                read -n 1 -s
                exit 1
            fi
            ;;
        *)
            echo -e "${red}::::::::::::::: Exiting${reset}"
            exit 1
            ;;
    esac
    echo
fi

echo -e "${green}::::::::::::::: CUDA_HOME:${yellow} $CUDA_HOME${reset}"
echo

# Installing SageAttention
echo -e "${green}::::::::::::::: Installing${yellow} $node_name${reset}"
echo
"$PYTHON_PATH" -m pip install --upgrade --no-build-isolation git+https://github.com/thu-ml/SageAttention $PIPargs

# Creating run_nvidia_gpu_SageAttention.sh file
echo
echo -e "${green}::::::::::::::: Creating${yellow} run_nvidia_gpu_SageAttention.sh${reset}"
echo
echo "#!/bin/bash" > ../run_nvidia_gpu_SageAttention.sh
echo "cd \"\$(dirname \"\$0\")\"" >> ../run_nvidia_gpu_SageAttention.sh
echo "echo \"Title ComfyUI-Easy-Install\"" >> ../run_nvidia_gpu_SageAttention.sh
echo "./python_embeded/bin/python -W ignore::FutureWarning ComfyUI/main.py --use-sage-attention --listen 0.0.0.0" >> ../run_nvidia_gpu_SageAttention.sh
chmod +x ../run_nvidia_gpu_SageAttention.sh


# Final Messages
echo
echo -e "${GREEN}:::::::::::::::${YELLOW} ${NODE_NAME} ${GREEN}Installation Complete${reset}"
echo
if [ -z "$1" ]; then
    echo -e "${green}::::::::::::::: ${yellow}Press any key to exit${reset}"
    read -n 1 -s
    exit
fi
