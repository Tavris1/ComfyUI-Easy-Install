#!/bin/bash
# Title: 'SageAttention' for 'ComfyUI Easy Install' by ivo
# MODIFIED BY GEMINI TO APPLY SDPA FALLBACK PATCH
# This script will patch ComfyUI to use the built-in SDPA,
# which provides the same benefits as SageAttention, without needing compilation.

# Set colors
WARNING='\033[33m'
RED='\033[91m'
GREEN='\033[92m'
YELLOW='\033[93m'
BOLD='\033[1m'
RESET='\033[0m'

NODE_NAME="SageAttention"

# Check Add-ons folder
if ! command -v python &> /dev/null; then
    clear
    echo -e "${GREEN}::::::::::::::: Run this file from the ${RED}'ComfyUI-Easy-Install/Add-ons'${GREEN} folder or ensure python venv is active"
    echo -e "${GREEN}::::::::::::::: Press any key to exit...${RESET}"
    read -p ""
    exit 1
fi

cd "$(dirname "$0")"

echo -e "${YELLOW}SageAttention compilation has failed previously. Applying a fallback patch instead.${RESET}"
echo -e "${YELLOW}This will modify ComfyUI to use its built-in fast attention mechanism.${RESET}"

PATCH_FILE_PATH="../ComfyUI/comfy/model_management.py"

if [ ! -f "$PATCH_FILE_PATH" ]; then
    echo -e "${RED}Error: $PATCH_FILE_PATH not found. Cannot apply patch.${RESET}"
    exit 1
fi

if grep -q "COMFYUI_FORCE_SDPA_ATTENTION" "$PATCH_FILE_PATH"; then
    echo -e "${YELLOW}ComfyUI is already patched. No changes needed.${RESET}"
else
    echo -e "${GREEN}Patching comfy/model_management.py...${RESET}"
    cp "$PATCH_FILE_PATH" "$PATCH_FILE_PATH.bak"
    # Use a temporary file for sed to ensure compatibility
    # This adds the logic to force SDPA on and disable xformers when the env var is set
    sed -e '1s/^/import os\n/' \
        -e '/def sage_attention_enabled():/a\
    if os.environ.get("COMFYUI_FORCE_SDPA_ATTENTION") == "1": return True' \
        -e '/def xformers_enabled():/a\
    if os.environ.get("COMFYUI_FORCE_SDPA_ATTENTION") == "1": return False' \
        "$PATCH_FILE_PATH" > "$PATCH_FILE_PATH.tmp" && mv "$PATCH_FILE_PATH.tmp" "$PATCH_FILE_PATH"
    echo -e "${GREEN}Successfully patched comfy/model_management.py.${RESET}"
fi

# Create the launcher script
echo -e "${GREEN}Creating launcher for patched SageAttention...${RESET}"
cat << EOF > ../run_nvidia_gpu_SageAttention.sh
#!/bin/bash
cd "
$(dirname "$0")"
echo "Starting ComfyUI with FORCED SageAttention (SDPA Fallback)"
export COMFYUI_FORCE_SDPA_ATTENTION=1
# The --use-sage-attention flag is still needed to trigger the patched code path
python -W ignore::FutureWarning ComfyUI/main.py --use-sage-attention
read -p "Press any key to continue..."
EOF
chmod +x ../run_nvidia_gpu_SageAttention.sh

echo -e "${GREEN}Fallback patch applied successfully!${RESET}"
echo -e "${GREEN}You can now run the 'run_nvidia_gpu_SageAttention.sh' script.${RESET}"

if [ -z "$1" ]; then
    echo -e "${GREEN}::::::::::::::: ${YELLOW}Press any key to exit${RESET}"
    read -p ""
    exit 0
fi