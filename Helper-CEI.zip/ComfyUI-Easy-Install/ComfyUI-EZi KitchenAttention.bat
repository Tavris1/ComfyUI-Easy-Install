@Echo off&&cd /D "%~dp0"
set "PSModulePath="
Title 'ComfyUI-EZi KitchenAttention' by ivo

.\python_embeded\python.exe .\Add-Ons\Tools\Helper-CEI\ComfyUI-EZi.py "Start ComfyUI KitchenAttention.bat"
