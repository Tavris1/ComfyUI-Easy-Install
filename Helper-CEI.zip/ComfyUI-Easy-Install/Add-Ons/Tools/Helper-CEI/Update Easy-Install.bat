@Echo off&&cd /D %~dp0&&chcp 65001 >nul
Title 'Update Easy-Install Modules' v0.1.0 by ivo
:: Pixaroma Community Edition ::

:: Set colors ::
call :set_colors

:: Check for the main folder ::
if not exist "python_embeded" (
    echo %green%::::::::::::::: Run this file from the %yellow%'ComfyUI-Easy-Install main folder'%green% folder%reset%
    echo %green%::::::::::::::: Press any key to exit...%reset%&Pause>nul
	exit
)

echo %green%::::: Updating %yellow%ComfyUI-Easy-Install\Add-Ons%green% folder :::::%reset%

:: Renaming files ::
call :rename_files ".\run_nvidia_gpu.bat" 				"Start ComfyUI.bat"
call :rename_files ".\run_nvidia_gpu_SageAttention.bat"	"Start ComfyUI SageAttention.bat"
call :rename_files ".\Update All and RUN.bat" 			"Update ComfyUI and Nodes.bat"
call :rename_files ".\Update Comfy and RUN.bat" 		"Update ComfyUI.bat"
call :rename_files ".\Add-Ons\Easy-Models-Linker.bat" 	"1. Easy-Models-Linker.bat"
call :rename_files ".\Add-Ons\Insightface-NEXT.bat" 	"Insightface.bat"
call :rename_files ".\Add-Ons\Nunchaku-NEXT.bat" 		"Nunchaku.bat"
call :rename_files ".\Add-Ons\SageAttention-NEXT.bat" 	"SageAttention.bat"
call :rename_files ".\Add-Ons\Tools\model2GGUF.bat" 	"Easy-model2GGUF.bat"
echo.

:: Add a path just in case ::
for /f "delims=" %%G in ('cmd /c "where.exe git.exe 2>nul"') do (set "GIT_PATH=%%~dpG")
set "path=%GIT_PATH%;%PATH%"
if exist "%windir%\System32" set "path=%PATH%;%windir%\System32"
if exist "%windir%\System32\WindowsPowerShell\v1.0" set "path=%PATH%;%windir%\System32\WindowsPowerShell\v1.0"
if exist "%localappdata%\Microsoft\WindowsApps" set "path=%PATH%;%localappdata%\Microsoft\WindowsApps"


if not exist "Add-Ons" mkdir "Add-Ons"
set "HLPR-NAME=Helper-CEI.zip"

:: ------------------------------------------------------------------------------
for /f "tokens=*" %%a in ('powershell -command "(Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe' -ErrorAction SilentlyContinue).'(default)' | ForEach-Object { [System.Diagnostics.FileVersionInfo]::GetVersionInfo($_).FileVersion }" 2^>nul') do set "BROWSER_VER=%%a"
if "%BROWSER_VER%"=="" (for /f "tokens=*" %%a in ('powershell -command "(Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe' -ErrorAction SilentlyContinue).'(default)' | ForEach-Object { [System.Diagnostics.FileVersionInfo]::GetVersionInfo($_).FileVersion }" 2^>nul') do set "BROWSER_VER=%%a")
if "%BROWSER_VER%"=="" set "BROWSER_VER=146.0.0.0"
set "BROWSER_VER=%BROWSER_VER: =%"
set "UA=-H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/%BROWSER_VER% Safari/537.36 Edge/%BROWSER_VER%""
:: echo %green%::::: Update Engine: %yellow%Detected Browser Version %BROWSER_VER%%reset%
set "URL=https://github.com/Tavris1/ComfyUI-Easy-Install/releases/latest/download/ComfyUI-Easy-Install.zip"
if not exist "ComfyUI-Easy-Install.zip" (
    curl -L %UA% --progress-bar --ssl-no-revoke --retry 5 --retry-delay 2 -o "ComfyUI-Easy-Install.zip" "%URL%"
    if errorlevel 1 (curl -L %UA% --progress-bar --ssl-no-revoke -k --retry 5 --retry-delay 2 -o "ComfyUI-Easy-Install.zip" "%URL%")
	if errorlevel 1 (powershell -NoProfile -ExecutionPolicy Bypass -Command "$web = New-Object System.Net.WebClient; $web.Headers.Add('User-Agent','Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/%BROWSER_VER%'); $web.DownloadFile('%URL%','ComfyUI-Easy-Install.zip')")
    if not exist "ComfyUI-Easy-Install.zip" (
        echo.
        echo %red%Failed to download Updates.%reset%
        echo Press any key to Exit...&Pause>nul
        exit /b 1
    )
    echo.
)
:: ------------------------------------------------------------------------------

if not exist "ComfyUI-Easy-Install.zip" (
    echo %red%::::::::::::::: Error downloading 'ComfyUI-Easy-Install.zip'%reset%
    echo %green%::::::::::::::: Press any key to exit...%reset%&Pause>nul
	exit
)

tar.exe -xf "ComfyUI-Easy-Install.zip" "%HLPR-NAME%"
tar.exe -xf "%HLPR-NAME%" -C "Add-Ons" --strip-components=2 "ComfyUI-Easy-Install/Add-Ons"
tar.exe -xf "%HLPR-NAME%" -C "ComfyUI" --strip-components=2 "ComfyUI-Easy-Install/ComfyUI/user"

if exist "ComfyUI-Easy-Install.zip" del "ComfyUI-Easy-Install.zip"
if exist "%HLPR-NAME%" del "%HLPR-NAME%"

if not exist ".\ComfyUI\custom_nodes\.disabled" mkdir ".\ComfyUI\custom_nodes\.disabled"

if exist ".\Add-Ons\Tools\AutoRun.bat" (
	pushd %cd%
	call ".\Add-Ons\Tools\AutoRun.bat"
	popd
	del  ".\Add-Ons\Tools\AutoRun.bat"
)

exit

::::::::::::::::::::::::::::::::: END :::::::::::::::::::::::::::::::::

:set_colors
set warning=[33m
set     red=[91m
set   green=[92m
set  yellow=[93m
set    bold=[1m
set   reset=[0m
goto :eof

:rename_files
::Renaming files ::
if exist "%~1" if not exist "%~2" (
	echo %green%::::::::::::::: Renaming %yellow%%~1%green% to %yellow%%~2 %reset%
	ren "%~1" "%~2"
)
goto :eof