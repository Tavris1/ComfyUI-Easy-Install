@Echo off&&cd /D %~dp0
Title ComfyUI-Easy-Install

set "path=%windir%\System32;%windir%\System32\WindowsPowerShell\v1.0;%PATH%"

set PORT=8188
for /f %%A in ('powershell -NoProfile -ExecutionPolicy Bypass -Command "([regex]::Match((Get-Content '%~f0' -Raw), '--port\s+(\d+)')).Groups[1].Value"') do set PORT=%%A

netstat -an | find ":%PORT% " >nul 2>&1
if %errorlevel% == 0 (
    echo Hey [92m%USERNAME%[0m! ComfyUI is already running on port [92m%PORT%[0m.
	echo [93mPress any key to exit...[0m&&pause>nul&&exit
)

.\python_embeded\python.exe -I -W ignore::FutureWarning ComfyUI\main.py --windows-standalone-build

echo.
echo If you see this and ComfyUI did not start, [92mtry updating your Nvidia drivers.[0m
echo If you get a c10.dll error, [92minstall VC Redist: https://aka.ms/vc14/vc_redist.x64.exe[0m
echo.
echo Press any key to exit%reset%&Pause>nul

