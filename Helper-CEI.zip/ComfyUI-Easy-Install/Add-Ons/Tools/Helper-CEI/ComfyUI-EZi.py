APP_VERSION = "3.30.3"

import sys
import os
import ctypes

try:
    ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
except Exception:
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass

def _find_webview2_runtime_exe():
    import glob
    candidates = []
    for env_var in ("ProgramFiles(x86)", "ProgramFiles", "LocalAppData"):
        base = os.environ.get(env_var)
        if not base:
            continue
        candidates.extend(glob.glob(os.path.join(base, "Microsoft", "EdgeWebView", "Application", "*", "msedgewebview2.exe")))
    for path in candidates:
        if os.path.isfile(path):
            return path
    return None


def _check_webview2():
    registered = False
    try:
        import winreg
        keys = [
            (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"),
            (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"),
            (winreg.HKEY_CURRENT_USER,  r"SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"),
        ]
        for hive, path in keys:
            try:
                winreg.OpenKey(hive, path)
                registered = True
                break
            except OSError:
                pass
    except Exception:
        pass
    exe_path = _find_webview2_runtime_exe()
    return registered, exe_path


_ezi_wv2_registered, _ezi_wv2_exe = _check_webview2()
_ezi_wv2_registered_but_exe_missing = _ezi_wv2_registered and not _ezi_wv2_exe

if not _ezi_wv2_registered:
    url = "https://developer.microsoft.com/en-us/microsoft-edge/webview2/"
    ctypes.windll.user32.MessageBoxW(
        0,
        "WebView2 Runtime was not found on this system.\n\n"
        "ComfyUI-EZi requires the Microsoft Edge WebView2 Runtime to run.\n\n"
        "Click OK to open the download page in your browser.",
        "ComfyUI-EZi - WebView2 Runtime Missing",
        0x10
    )
    os.startfile(url)
    sys.exit(1)

def _apply_cache_env():
    keep = os.path.exists(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'keep_cache.flag'))
    for name in ('PIP_NO_CACHE_DIR', 'UV_NO_CACHE'):
        if keep:
            os.environ.pop(name, None)
        else:
            os.environ[name] = '1'

_apply_cache_env()

import subprocess as _sp
_popen_init = _sp.Popen.__init__

def _popen_init_safe(self, *args, **kwargs):
    if len(args) < 4 and kwargs.get('stdin') is None and (kwargs.get('stdout') is not None or kwargs.get('stderr') is not None):
        kwargs['stdin'] = _sp.DEVNULL
    _popen_init(self, *args, **kwargs)

_sp.Popen.__init__ = _popen_init_safe

try:
    import webview
except ImportError:
    import sys, subprocess, os
    print("pywebview not found - attempting to install...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pywebview"])
    try:
        import webview
    except ImportError:
        print("ERROR: pywebview could not be installed. Please run:")
        print("  pip install pywebview")
        sys.exit(1)

_EZI_TOP_RESIZE_GAP = 5
_ezi_bounds_fns = {}


_ezi_wv2_failure_reported = False

def _ezi_report_webview2_failure(exc):
    global _ezi_wv2_failure_reported
    if _ezi_wv2_failure_reported:
        return
    _ezi_wv2_failure_reported = True
    try:
        detail = f"\n\nDetails: {exc}" if exc else ""
        if _ezi_wv2_registered_but_exe_missing:
            reason = (
                "The Microsoft Edge WebView2 Runtime is registered as "
                "installed, but its files could not be found in any of the "
                "usual locations - most likely removed by a \"debloat\"/"
                "privacy tool, or blocked by antivirus."
            )
        else:
            reason = (
                "The Microsoft Edge WebView2 Runtime is installed, but "
                "something is preventing it from running - most commonly a "
                "Group Policy restriction, an AppLocker/Software "
                "Restriction Policy, or antivirus/endpoint-protection "
                "software blocking msedgewebview2.exe."
            )
        ctypes.windll.user32.MessageBoxW(
            0,
            "ComfyUI-EZi could not start its WebView2 window.\n\n" + reason +
            "\n\nCheck whether \"msedgewebview2.exe\" is allowed to run, and "
            "whether Microsoft Edge / Edge WebView2 is blocked for this "
            "user or on this machine." + detail,
            "ComfyUI-EZi - WebView2 Blocked",
            0x10
        )
    except Exception:
        pass
    os._exit(1)


_EZI_BAR_HEIGHT = 34


def _ezi_dpi_scale(hwnd=None, form=None):
    try:
        if hwnd is None and form is not None:
            hwnd = int(form.Handle.ToInt64())
        if hwnd:
            u = ctypes.windll.user32
            u.GetDpiForWindow.argtypes = [ctypes.c_void_p]
            u.GetDpiForWindow.restype = ctypes.c_uint
            dpi = u.GetDpiForWindow(ctypes.c_void_p(hwnd))
            if dpi:
                return dpi / 96.0
    except Exception:
        pass
    try:
        if form is not None:
            return max(1.0, float(form.DeviceDpi) / 96.0)
    except Exception:
        pass
    return 1.0
_EZI_WINDOW_REF = {"window": None, "shell_expanded": True, "comfy_webview": None, "rec_overlay": None,
                   "comfy_slide_progress": 1.0, "comfy_slide_gen": 0}


def _ezi_cubic_bezier(x1, y1, x2, y2):
    def _bez(a, b, u):
        return 3 * (1 - u) ** 2 * u * a + 3 * (1 - u) * u * u * b + u ** 3

    def _ease(x):
        if x <= 0.0:
            return 0.0
        if x >= 1.0:
            return 1.0
        lo, hi = 0.0, 1.0
        for _ in range(24):
            mid = (lo + hi) / 2.0
            if _bez(x1, x2, mid) < x:
                lo = mid
            else:
                hi = mid
        return _bez(y1, y2, (lo + hi) / 2.0)
    return _ease


def _make_clickthrough(hwnd):
    if not hwnd:
        return
    try:
        import ctypes.wintypes
        GWL_EXSTYLE       = -20
        WS_EX_LAYERED     = 0x00080000
        WS_EX_TRANSPARENT = 0x00000020
        WS_EX_NOACTIVATE  = 0x08000000
        WS_EX_TOOLWINDOW  = 0x00000080

        user32 = ctypes.windll.user32
        is_64 = ctypes.sizeof(ctypes.c_void_p) == 8
        get_long = user32.GetWindowLongPtrW if is_64 else user32.GetWindowLongW
        set_long = user32.SetWindowLongPtrW if is_64 else user32.SetWindowLongW
        get_long.restype  = ctypes.c_void_p if is_64 else ctypes.c_long
        get_long.argtypes = [ctypes.wintypes.HWND, ctypes.c_int]
        set_long.restype  = ctypes.c_void_p if is_64 else ctypes.c_long
        set_long.argtypes = [ctypes.wintypes.HWND, ctypes.c_int, ctypes.c_void_p if is_64 else ctypes.c_long]

        want = WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW
        cur = int(get_long(hwnd, GWL_EXSTYLE) or 0)
        new_style = cur | want
        set_long(hwnd, GWL_EXSTYLE, ctypes.c_void_p(new_style) if is_64 else new_style)
        SWP_NOMOVE = 0x0002; SWP_NOSIZE = 0x0001; SWP_NOZORDER = 0x0004; SWP_FRAMECHANGED = 0x0020
        user32.SetWindowPos(hwnd, None, 0, 0, 0, 0,
                             SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED)
    except Exception:
        pass


def _ezi_on_core_ready(sender, args):
    if not getattr(args, 'IsSuccess', True):
        _ezi_report_webview2_failure(getattr(args, 'InitializationException', None))
        return
    try:
        core = sender.CoreWebView2
    except Exception:
        return
    try:
        core.Settings.IsNonClientRegionSupportEnabled = True
    except Exception:
        pass
    try:
        core.DownloadStarting += _ezi_on_download_starting
    except Exception:
        pass


class _EziCoreOk:
    IsSuccess = True
    InitializationException = None


def _ezi_hook_core_ready(window):
    form = getattr(window, 'native', None)
    wv = getattr(form, 'webview', None)
    if form is None or wv is None:
        return

    def _do():
        if wv.CoreWebView2 is not None:
            _ezi_on_core_ready(wv, _EziCoreOk())
        else:
            wv.CoreWebView2InitializationCompleted += _ezi_on_core_ready

    if form.InvokeRequired:
        import System
        form.Invoke(System.Action(_do))
    else:
        _do()


_EASY_MENU_SHIM = r"""
var _restartNoticeTimer = null;
function _showRestartNotice(text) {
  var old = document.getElementById('ezi-restart-notice');
  if (old && old.parentNode) old.parentNode.removeChild(old);
  if (_restartNoticeTimer) { clearTimeout(_restartNoticeTimer); _restartNoticeTimer = null; }
  var n = document.createElement('div');
  n.id = 'ezi-restart-notice';
  n.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);max-width:90vw;box-sizing:border-box;' +
    'white-space:normal;text-align:center;line-height:1.4;background:#1c3a1c;border:1px solid #50fa7b;color:#50fa7b;' +
    'padding:10px 22px;border-radius:6px;font-size:12px;font-family:inherit;z-index:2147483647;pointer-events:none;' +
    'box-shadow:0 4px 16px rgba(0,0,0,0.5);';
  n.textContent = text;
  document.body.appendChild(n);
  _restartNoticeTimer = setTimeout(function() {
    _restartNoticeTimer = null;
    if (n.parentNode) n.parentNode.removeChild(n);
  }, 5000);
}
"""


class _EziSkipComfyView(Exception):
    pass


def _ezi_setup_main_window(window):
    form = window.native
    shell = form.webview
    _ezi_hook_core_ready(window)
    try:
        import System.Windows.Forms as _WinForms
        shell.Dock   = getattr(_WinForms.DockStyle, 'None')
        shell.Anchor = _WinForms.AnchorStyles.Top | _WinForms.AnchorStyles.Left
        try:
            from System.Drawing import Color as _EziSysColor
            shell.DefaultBackgroundColor = _EziSysColor.Transparent
        except Exception:
            pass

        comfy_webview = None
        try:
            if ADV_CONSOLE:
                raise _EziSkipComfyView()
            _WebView2Class = type(shell)
            comfy_webview = _WebView2Class()
            comfy_webview.Anchor = _WinForms.AnchorStyles.Top | _WinForms.AnchorStyles.Left
            try:
                _comfy_userdata = os.path.join(CURRENT_SCRIPT_DIR, "EZi_cache")
                os.makedirs(_comfy_userdata, exist_ok=True)
                from Microsoft.Web.WebView2.WinForms import CoreWebView2CreationProperties as _EziCWV2CP
                _cprops = _EziCWV2CP()
                _cprops.UserDataFolder = _comfy_userdata
                comfy_webview.CreationProperties = _cprops
            except Exception as _cache_err:
                print("EZi_cache: could not set UserDataFolder:", _cache_err)
            form.Controls.Add(comfy_webview)
            comfy_webview.BringToFront()
            shell.BringToFront()
            _EZI_WINDOW_REF["comfy_webview"] = comfy_webview
            _EZI_WINDOW_REF["shell_webview"] = shell

            def _ezi_init_comfy_webview(sender=None, args=None):
                try:
                    shell.CoreWebView2InitializationCompleted -= _ezi_init_comfy_webview
                except Exception:
                    pass
                try:
                    comfy_webview.EnsureCoreWebView2Async(None)
                except Exception:
                    pass

            def _ezi_on_comfy_message(sender=None, args=None):
                try:
                    raw = args.WebMessageAsJson
                except Exception:
                    return
                if not raw:
                    return
                try:
                    parsed = json.loads(raw)
                except Exception:
                    parsed = None
                if isinstance(parsed, dict) and parsed.get("type") == "ezi_storage_save":
                    api_ref = _EZI_WINDOW_REF.get("api")
                    if api_ref is not None:
                        api_ref._store_comfy_storage(parsed)
                    return
                try:
                    shell.CoreWebView2.ExecuteScriptAsync(
                        "window.postMessage(" + raw + ", '*');"
                    )
                except Exception:
                    pass

            def _ezi_on_comfy_ready(sender=None, args=None):
                try:
                    ok = getattr(args, 'IsSuccess', True)
                    if not ok:
                        try:
                            exc = getattr(args, 'InitializationException', None)
                            detail = f"\n\nDetails: {exc}" if exc else ""
                            ctypes.windll.user32.MessageBoxW(
                                0,
                                "ComfyUI-EZi could not create the ComfyUI display "
                                "window (a second WebView2 instance)." + detail,
                                "ComfyUI-EZi - ComfyUI Display Unavailable",
                                0x30
                            )
                        except Exception:
                            _log_error('_ezi_on_comfy_ready')
                        return
                    _EZI_WINDOW_REF["comfy_ready"] = True

                    try:
                        comfy_webview.CoreWebView2.Settings.UserAgent = CHROME_UA
                    except Exception:
                        pass

                    try:
                        comfy_webview.CoreWebView2.CallDevToolsProtocolMethodAsync(
                            "Network.clearBrowserCache", "{}"
                        )
                    except Exception:
                        pass

                    try:
                        _ezi_beforeunload_guard_js = (
                            "(function(){"
                            "try{"
                            "Object.defineProperty(window,'onbeforeunload',{"
                            "get:function(){return null;},"
                            "set:function(){},"
                            "configurable:true"
                            "});"
                            "var _ael=window.EventTarget.prototype.addEventListener;"
                            "window.EventTarget.prototype.addEventListener=function(type,fn,opts){"
                            "if(type==='beforeunload')return;"
                            "return _ael.call(this,type,fn,opts);"
                            "};"
                            "}catch(e){}"
                            "})();"
                        )
                        comfy_webview.CoreWebView2.AddScriptToExecuteOnDocumentCreatedAsync(
                            _ezi_beforeunload_guard_js
                        )
                    except Exception as _beforeunload_guard_err:
                        print("EZi: could not install beforeunload guard:", _beforeunload_guard_err)

                    try:
                        comfy_webview.CoreWebView2.WebMessageReceived += _ezi_on_comfy_message
                    except Exception:
                        pass

                    try:
                        comfy_webview.CoreWebView2.DownloadStarting += _ezi_on_download_starting
                    except Exception:
                        pass

                    try:
                        comfy_webview.CoreWebView2.NewWindowRequested += _ezi_on_new_window
                    except Exception:
                        pass

                    def _ezi_comfy_nav_completed(sender2=None, args2=None):
                        try:
                            shell.CoreWebView2.ExecuteScriptAsync(
                                "if (typeof comfy_webview_ready === 'function') comfy_webview_ready();"
                            )
                        except Exception:
                            pass


                    comfy_webview.CoreWebView2.NavigationCompleted += _ezi_comfy_nav_completed

                    _zoom_state = {"applying": False, "ignore_until": 0.0, "timer": None}

                    def _ezi_zoom_clamp(value):
                        try:
                            return max(0.25, min(5.0, float(value)))
                        except Exception:
                            return 1.0

                    def _ezi_zoom_saved():
                        api_ref = _EZI_WINDOW_REF.get("api")
                        if api_ref is None:
                            return 1.0
                        return _ezi_zoom_clamp(api_ref._settings.get("comfy_zoom_factor", 1.0))

                    def _ezi_zoom_hold(seconds=1.5):
                        _zoom_state["ignore_until"] = time.time() + seconds

                    def _ezi_zoom_apply(sender3=None, args3=None):
                        try:
                            target = _ezi_zoom_saved()
                            _ezi_zoom_hold()
                            if abs(float(comfy_webview.ZoomFactor) - target) > 0.001:
                                _zoom_state["applying"] = True
                                try:
                                    comfy_webview.ZoomFactor = target
                                finally:
                                    _zoom_state["applying"] = False
                        except Exception:
                            _log_error('_ezi_zoom_apply')

                    def _ezi_zoom_nav_starting(sender3=None, args3=None):
                        _ezi_zoom_hold()

                    def _ezi_zoom_flush():
                        try:
                            api_ref = _EZI_WINDOW_REF.get("api")
                            if api_ref is not None:
                                _save_settings(api_ref._settings)
                        except Exception:
                            _log_error('_ezi_zoom_flush')

                    def _ezi_zoom_changed(sender3=None, args3=None):
                        try:
                            if _zoom_state["applying"] or time.time() < _zoom_state["ignore_until"]:
                                return
                            api_ref = _EZI_WINDOW_REF.get("api")
                            if api_ref is None:
                                return
                            current = _ezi_zoom_clamp(comfy_webview.ZoomFactor)
                            if abs(_ezi_zoom_saved() - current) < 0.001:
                                return
                            api_ref._settings["comfy_zoom_factor"] = round(current, 4)
                            if _zoom_state["timer"] is not None:
                                _zoom_state["timer"].cancel()
                            timer = threading.Timer(0.6, _ezi_zoom_flush)
                            timer.daemon = True
                            _zoom_state["timer"] = timer
                            timer.start()
                        except Exception:
                            _log_error('_ezi_zoom_changed')

                    _ezi_zoom_apply()
                    try:
                        comfy_webview.ZoomFactorChanged += _ezi_zoom_changed
                    except Exception:
                        try:
                            comfy_webview.CoreWebView2Controller.ZoomFactorChanged += _ezi_zoom_changed
                        except Exception:
                            _log_error('_ezi_zoom_subscribe')
                    try:
                        comfy_webview.CoreWebView2.NavigationStarting += _ezi_zoom_nav_starting
                        comfy_webview.CoreWebView2.NavigationCompleted += _ezi_zoom_apply
                    except Exception:
                        pass

                    pending_url = _EZI_WINDOW_REF.get("comfy_pending_url")
                    if pending_url:
                        comfy_webview.CoreWebView2.Navigate(pending_url)
                except Exception:
                    _log_error('_ezi_on_comfy_ready')

            comfy_webview.CoreWebView2InitializationCompleted += _ezi_on_comfy_ready
            try:
                if shell.CoreWebView2 is not None:
                    comfy_webview.EnsureCoreWebView2Async(None)
                else:
                    shell.CoreWebView2InitializationCompleted += _ezi_init_comfy_webview
            except Exception:
                shell.CoreWebView2InitializationCompleted += _ezi_init_comfy_webview
        except Exception as _e:
            if not isinstance(_e, _EziSkipComfyView):
                print("Could not create ComfyUI webview:", _e)
            comfy_webview = None

        def _ezi_apply_bounds(sender=None, args=None):
            try:
                target_w = max(0, form.ClientSize.Width)
                full_h = max(0, form.ClientSize.Height)
                _sc = _ezi_dpi_scale(form=form)
                bar_h = int(round(_EZI_BAR_HEIGHT * _sc))
                expanded = _EZI_WINDOW_REF.get("shell_expanded", True)
                if expanded is True:
                    shell_h = full_h
                elif isinstance(expanded, (int, float)) and expanded > 0:
                    shell_h = min(int(round(expanded * _sc)), full_h)
                elif comfy_webview is None:
                    shell_h = full_h
                else:
                    shell_h = bar_h
                if comfy_webview is not None:
                    ctop = bar_h
                    overlap = max(2, int(round(2 * _sc)))
                    _prog = _EZI_WINDOW_REF.get("comfy_slide_progress", 1.0)
                    comfy_x = int(round(target_w * (1.0 - _prog))) if _prog < 1.0 else 0
                    comfy_webview.SetBounds(comfy_x, ctop - overlap, target_w,
                                            max(0, form.ClientSize.Height - ctop + overlap))
                    _ext = _EZI_WINDOW_REF.get("ext_webview")
                    if _ext is not None:
                        _ext.SetBounds(comfy_x, ctop - overlap, target_w,
                                       max(0, form.ClientSize.Height - ctop + overlap))
                    shell.SetBounds(0, 0, target_w,
                                           max(bar_h, shell_h))
                    shell.BringToFront()
                else:
                    shell.SetBounds(0, 0, target_w, shell_h)
            except Exception:
                pass

        form.Resize += _ezi_apply_bounds
        try:
            form.Activated += _ezi_on_form_activated
        except Exception:
            _log_error('_ezi_form_activated_hook')
        _EZI_WINDOW_REF["apply_bounds"] = _ezi_apply_bounds
        _EZI_WINDOW_REF["winforms_form"] = form
        try:
            _ezi_bounds_fns[int(form.Handle.ToInt32())] = _ezi_apply_bounds
        except Exception:
            pass
        try:
            _EZI_WINDOW_REF["main_hwnd"] = int(form.Handle.ToInt64())
        except Exception:
            pass
        _ezi_apply_bounds()
    except Exception:
        _log_error('_ezi_setup_main_window')


import threading as _ezi_threading_early
_EZI_DL_LOCK = _ezi_threading_early.Lock()
_EZI_RECENT_DL_URIS = {}
_EZI_DL_DEDUP_WINDOW = 5.0


def _ezi_claim_download(uri):
    import time
    now = time.time()
    with _EZI_DL_LOCK:
        for k in list(_EZI_RECENT_DL_URIS.keys()):
            if now - _EZI_RECENT_DL_URIS[k] > _EZI_DL_DEDUP_WINDOW:
                del _EZI_RECENT_DL_URIS[k]
        last = _EZI_RECENT_DL_URIS.get(uri)
        if last is not None and (now - last) <= _EZI_DL_DEDUP_WINDOW:
            return False
        _EZI_RECENT_DL_URIS[uri] = now
        return True

_EZI_AUTH_URL_MARKERS = (
    'accounts.google.com',
    'github.com/login',
    'github.com/sessions',
    'login.microsoftonline.com',
    'login.live.com',
    'appleid.apple.com',
    'discord.com/oauth2',
    'discord.com/api/oauth2',
    '/__/auth/',
    '/oauth',
    '/authorize',
    '/api/auth/',
    'firebaseapp.com',
    'auth0.com',
    'clerk.accounts',
)


def _ezi_is_auth_url(uri):
    try:
        low = (uri or '').lower()
        return any(m in low for m in _EZI_AUTH_URL_MARKERS)
    except Exception:
        return False


def _ezi_is_auth_popup(args, uri):
    if _ezi_is_auth_url(uri):
        return True
    try:
        feats = getattr(args, 'WindowFeatures', None)
        if feats is not None and bool(getattr(feats, 'HasSize', False)):
            return True
    except Exception:
        pass
    return False


def _ezi_open_external(uri):
    def _do():
        try:
            if uri:
                if not _ezi_claim_download(uri):
                    return
                import webbrowser
                webbrowser.open(uri)
        except Exception:
            pass
    threading.Thread(target=_do, daemon=True).start()


def _ezi_ext_pages_enabled():
    api_ref = _EZI_WINDOW_REF.get("api")
    try:
        return bool(api_ref._settings.get("ext_pages_inside", True))
    except Exception:
        return True


def _ezi_local_ports():
    ports = set()
    cw = _EZI_WINDOW_REF.get("comfy_webview")
    try:
        if cw is not None and cw.CoreWebView2 is not None:
            from urllib.parse import urlparse
            p = urlparse(str(cw.CoreWebView2.Source or '')).port
            if p:
                ports.add(int(p))
    except Exception:
        pass
    api_ref = _EZI_WINDOW_REF.get("api")
    try:
        p = getattr(api_ref, '_proxy_port', None)
        if p:
            ports.add(int(p))
    except Exception:
        pass
    return ports


_EZI_EXT_FILE_PATHS = ('/view', '/api/view', '/api/userdata', '/download', '/api/download')


def _ezi_local_page_kind(uri):
    try:
        from urllib.parse import urlparse
        u = urlparse(uri or '')
        if u.scheme not in ('http', 'https'):
            return None
        if (u.hostname or '').lower() not in ('127.0.0.1', 'localhost', '::1'):
            return None
        if u.port is None or int(u.port) not in _ezi_local_ports():
            return None
    except Exception:
        return None
    path = (u.path or '/').lower()
    if path in ('/', '/index.html'):
        return 'root'
    if any(path == p or path.startswith(p + '/') for p in _EZI_EXT_FILE_PATHS):
        return 'file'
    if 'filename=' in (u.query or '').lower():
        return 'file'
    last = path.rstrip('/').rsplit('/', 1)[-1]
    if '.' in last and not last.endswith(('.html', '.htm')):
        return 'file'
    return 'page'


def _ezi_on_new_window(s4=None, e4=None):
    try:
        uri = str(getattr(e4, 'Uri', '') or '')
    except Exception:
        uri = ''
    if _ezi_is_auth_url(uri):
        return
    if uri and _ezi_ext_pages_enabled() and _ezi_local_page_kind(uri) == 'page':
        try:
            e4.Handled = True
        except Exception:
            pass
        try:
            if _ezi_ext_open(uri):
                return
        except Exception:
            _log_error('_ezi_on_new_window')
        _ezi_open_external(uri)
        return
    if _ezi_is_auth_popup(e4, uri):
        return
    try:
        e4.Handled = True
    except Exception:
        pass
    _ezi_open_external(uri)


def _ezi_ext_notify_shell():
    shell = _EZI_WINDOW_REF.get("shell_webview")
    if shell is None:
        return
    active = bool(_EZI_WINDOW_REF.get("ext_active"))
    title = ''
    ext = _EZI_WINDOW_REF.get("ext_webview")
    try:
        if active and ext is not None and ext.CoreWebView2 is not None:
            title = str(ext.CoreWebView2.DocumentTitle or '')
    except Exception:
        title = ''
    try:
        shell.CoreWebView2.ExecuteScriptAsync(
            "if (typeof __eziExtViewState === 'function') __eziExtViewState(%s, %s);"
            % ('true' if active else 'false', json.dumps(title))
        )
    except Exception:
        pass


def _ezi_ext_on_message(sender=None, args=None):
    try:
        raw = args.WebMessageAsJson
        parsed = json.loads(raw) if raw else None
    except Exception:
        return
    if not isinstance(parsed, dict) or parsed.get("type") != "ezi_save_blob":
        return
    shell = _EZI_WINDOW_REF.get("shell_webview")
    try:
        shell.CoreWebView2.ExecuteScriptAsync("window.postMessage(" + raw + ", '*');")
    except Exception:
        pass


def _ezi_ext_nav_starting(sender=None, e=None):
    try:
        uri = str(getattr(e, 'Uri', '') or '')
    except Exception:
        return
    low = uri.lower()
    if not uri or low.startswith(('about:', 'data:', 'blob:', 'javascript:')):
        return
    kind = _ezi_local_page_kind(uri)
    if kind in ('page', 'file'):
        return
    if kind is None and _ezi_is_auth_url(uri):
        return
    try:
        e.Cancel = True
    except Exception:
        return
    if kind == 'root':
        api_ref = _EZI_WINDOW_REF.get("api")
        if api_ref is not None:
            api_ref._ui_invoke(_ezi_ext_close)
        return
    _ezi_open_external(uri)


def _ezi_ext_on_ready(sender=None, args=None):
    ref = _EZI_WINDOW_REF
    if not getattr(args, 'IsSuccess', True):
        _log_error('_ezi_ext_on_ready')
        pending = ref.pop("ext_pending_url", None)
        try:
            import System
            ref.get("winforms_form").BeginInvoke(System.Action(_ezi_ext_dispose))
        except Exception:
            _ezi_ext_dispose()
        if pending:
            _ezi_open_external(pending)
        return
    ext = ref.get("ext_webview")
    if ext is None:
        return
    try:
        core = ext.CoreWebView2
        try:
            core.Settings.UserAgent = CHROME_UA
        except Exception:
            pass
        core.DownloadStarting += _ezi_on_download_starting
        core.NewWindowRequested += _ezi_on_new_window
        core.NavigationStarting += _ezi_ext_nav_starting
        core.WebMessageReceived += _ezi_ext_on_message
        try:
            core.DocumentTitleChanged += lambda s=None, a=None: _ezi_ext_notify_shell()
        except Exception:
            pass
        ref["ext_ready"] = True
        pending = ref.pop("ext_pending_url", None)
        if pending:
            core.Navigate(pending)
    except Exception:
        _log_error('_ezi_ext_on_ready')


def _ezi_ext_dispose():
    ref = _EZI_WINDOW_REF
    ext = ref.pop("ext_webview", None)
    ref["ext_ready"] = False
    ref["ext_active"] = False
    if ext is not None:
        try:
            form = ref.get("winforms_form")
            if form is not None:
                form.Controls.Remove(ext)
            ext.Dispose()
        except Exception:
            pass
    _ezi_ext_notify_shell()


def _ezi_ext_ensure():
    ref = _EZI_WINDOW_REF
    ext = ref.get("ext_webview")
    if ext is not None:
        return ext
    form = ref.get("winforms_form")
    shell = ref.get("shell_webview")
    comfy = ref.get("comfy_webview")
    if form is None or shell is None or comfy is None or not ref.get("comfy_ready"):
        return None
    import System.Windows.Forms as _WinForms
    ext = type(comfy)()
    ext.Anchor = _WinForms.AnchorStyles.Top | _WinForms.AnchorStyles.Left
    try:
        from System.Drawing import Color as _EziSysColor
        ext.DefaultBackgroundColor = _EziSysColor.FromArgb(255, 32, 32, 32)
    except Exception:
        pass
    try:
        from Microsoft.Web.WebView2.WinForms import CoreWebView2CreationProperties as _EziCWV2CP
        _cprops = _EziCWV2CP()
        _cprops.UserDataFolder = os.path.join(CURRENT_SCRIPT_DIR, "EZi_cache")
        ext.CreationProperties = _cprops
    except Exception:
        _log_error('_ezi_ext_ensure')
    form.Controls.Add(ext)
    ext.BringToFront()
    shell.BringToFront()
    ref["ext_webview"] = ext
    ref["ext_ready"] = False
    fn = ref.get("apply_bounds")
    if fn:
        fn()
    ext.CoreWebView2InitializationCompleted += _ezi_ext_on_ready
    ext.EnsureCoreWebView2Async(None)
    return ext


def _ezi_ext_open(uri):
    ref = _EZI_WINDOW_REF
    ext = _ezi_ext_ensure()
    if ext is None:
        return False
    if ref.get("ext_ready") and ext.CoreWebView2 is not None:
        try:
            cur = str(ext.CoreWebView2.Source or '')
        except Exception:
            cur = ''
        if cur != uri:
            ext.CoreWebView2.Navigate(uri)
    else:
        ref["ext_pending_url"] = uri
    ref["ext_active"] = True
    ext.Visible = True
    fn = ref.get("apply_bounds")
    if fn:
        fn()
    try:
        ext.Focus()
    except Exception:
        pass
    _ezi_ext_notify_shell()
    return True


def _ezi_ext_close(reset=False):
    ref = _EZI_WINDOW_REF
    ext = ref.get("ext_webview")
    ref["ext_active"] = False
    if ext is not None:
        try:
            ext.Visible = False
        except Exception:
            pass
        if reset:
            ref.pop("ext_pending_url", None)
            try:
                if ref.get("ext_ready") and ext.CoreWebView2 is not None:
                    ext.CoreWebView2.Navigate("about:blank")
            except Exception:
                pass
    comfy = ref.get("comfy_webview")
    try:
        if comfy is not None and not reset:
            comfy.Focus()
    except Exception:
        pass
    _ezi_ext_notify_shell()


_EZI_USER32 = None


def _ezi_user32():
    global _EZI_USER32
    if _EZI_USER32 is None:
        u = ctypes.WinDLL('user32')
        u.GetForegroundWindow.restype = ctypes.c_void_p
        u.GetAsyncKeyState.restype = ctypes.c_short
        u.GetAsyncKeyState.argtypes = [ctypes.c_int]
        _EZI_USER32 = u
    return _EZI_USER32


def _ezi_comfy_controller(comfy):
    try:
        ctl = comfy.CoreWebView2Controller
        if ctl is not None:
            return ctl
    except Exception:
        pass
    try:
        import System.Reflection as _Refl
        flags = _Refl.BindingFlags.Instance | _Refl.BindingFlags.NonPublic | _Refl.BindingFlags.Public
        t = comfy.GetType()
        while t is not None:
            f = t.GetField("_coreWebView2Controller", flags)
            if f is not None:
                return f.GetValue(comfy)
            pr = t.GetProperty("CoreWebView2Controller", flags)
            if pr is not None:
                return pr.GetValue(comfy)
            t = t.BaseType
    except Exception:
        _log_error('_ezi_comfy_controller')
    return None


def _ezi_restore_comfy_focus():
    ref = _EZI_WINDOW_REF
    comfy = ref.get("comfy_webview")
    form = ref.get("winforms_form")
    if comfy is None or form is None or not ref.get("comfy_ready"):
        return
    if ref.get("shell_expanded") is not False or ref.get("ext_active"):
        return
    try:
        if ref.get("comfy_slide_progress", 1.0) < 1.0 or not comfy.Visible:
            return
        u = _ezi_user32()
        if (u.GetAsyncKeyState(0x01) & 0x8000) or (u.GetAsyncKeyState(0x02) & 0x8000):
            return
        if int(u.GetForegroundWindow() or 0) != int(form.Handle.ToInt64()):
            return
    except Exception:
        return
    try:
        ctl = _ezi_comfy_controller(comfy)
        if ctl is not None:
            from Microsoft.Web.WebView2.Core import CoreWebView2MoveFocusReason as _EziMFR
            ctl.MoveFocus(_EziMFR.Programmatic)
            return
    except Exception:
        _log_error('_ezi_restore_comfy_focus')
    try:
        comfy.Focus()
    except Exception:
        pass


def _ezi_on_form_activated(sender=None, args=None):
    form = _EZI_WINDOW_REF.get("winforms_form")
    if form is None or _EZI_WINDOW_REF.get("comfy_webview") is None:
        return

    def _fire():
        try:
            import System
            form.BeginInvoke(System.Action(_ezi_restore_comfy_focus))
        except Exception:
            pass

    t = threading.Timer(0.08, _fire)
    t.daemon = True
    t.start()


def _ezi_format_bytes(n):
    n = float(n)
    for unit in ('B', 'KB', 'MB', 'GB'):
        if n < 1024.0:
            return f"{n:.1f}{unit}" if unit != 'B' else f"{int(n)}{unit}"
        n /= 1024.0
    return f"{n:.1f}TB"


def _ezi_download_with_progress(url, dest_path, println=None, label=None, headers=None, timeout=30):
    import urllib.request, time

    req = urllib.request.Request(url, headers=headers or {"User-Agent": "ComfyUI-EZi"})
    name = label or os.path.basename(dest_path) or "file"
    tmp_path = dest_path + ".part"
    chunk_size = 262144
    downloaded = 0
    start = time.time()
    last_print = 0.0
    owner = getattr(println, '__self__', None)
    dl_set = getattr(owner, '_dl_set', None)
    dl_done = getattr(owner, '_dl_done', None)
    if not (dl_set and dl_done):
        dl_set = dl_done = None
    dl_key = object()

    try:
        with urllib.request.urlopen(req, timeout=timeout, context=(_comfy_ssl() if url.startswith("https://127.0.0.1") else None)) as resp:
            total = 0
            try:
                total = int(resp.headers.get("Content-Length") or 0)
            except Exception:
                total = 0

            with open(tmp_path, "wb") as f:
                while True:
                    chunk = resp.read(chunk_size)
                    if not chunk:
                        break
                    f.write(chunk)
                    downloaded += len(chunk)

                    if println:
                        now = time.time()
                        if now - last_print >= 0.15:
                            last_print = now
                            elapsed = max(now - start, 0.001)
                            speed = downloaded / elapsed
                            speed_txt = f"{_ezi_format_bytes(speed)}/s"
                            if total > 0:
                                pct = min(downloaded / total * 100.0, 100.0)
                                bar_len = 24
                                filled = int(bar_len * downloaded / total)
                                bar = "█" * filled + " " * (bar_len - filled)
                                eta = (total - downloaded) / speed if speed > 0 else 0
                                line = (f"Downloading {name}: {pct:5.1f}%|{bar}| "
                                        f"{_ezi_format_bytes(downloaded)}/{_ezi_format_bytes(total)} "
                                        f"[{speed_txt}, ETA {int(eta)}s]")
                            else:
                                line = f"Downloading {name}: {_ezi_format_bytes(downloaded)} [{speed_txt}]"
                            if dl_set:
                                dl_set(dl_key, line)
                            else:
                                println(line + "\r")

            if println:
                elapsed = max(time.time() - start, 0.001)
                speed_txt = f"{_ezi_format_bytes(downloaded / elapsed)}/s"
                if total > 0:
                    bar = "█" * 24
                    line = (f"Downloading {name}: 100.0%|{bar}| "
                            f"{_ezi_format_bytes(downloaded)}/{_ezi_format_bytes(total)} [{speed_txt}]")
                else:
                    line = f"Downloading {name}: {_ezi_format_bytes(downloaded)} [{speed_txt}]"
                if dl_done:
                    dl_done(dl_key, line)
                else:
                    println(line + "\n")

        os.replace(tmp_path, dest_path)
        return dest_path
    except Exception:
        if dl_done:
            try:
                dl_done(dl_key)
            except Exception:
                pass
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except Exception:
            _log_error('_ezi_download_with_progress')
        raise


def _ezi_on_download_starting(sender, e):
    try:
        op = getattr(e, 'DownloadOperation', None)
        uri = str(getattr(op, 'Uri', '') or '') if op else ''
        try:
            e.Cancel = True
        except Exception:
            _log_error('_ezi_on_download_starting')
        if not uri:
            return
        if not _ezi_claim_download(uri):
            return

        if uri.startswith('blob:'):
            try:
                blob_name = os.path.basename(str(getattr(e, 'ResultFilePath', '') or '')) or "download"
                js = (
                    "(function(){var u=%s,n=%s;"
                    "var post=window._eziPostToShell||function(m){try{window.chrome.webview.postMessage(m);}catch(x){}};"
                    "fetch(u).then(function(r){return r.blob();}).then(function(b){"
                    "var t=/^(text\\/|application\\/json|application\\/xml|image\\/svg\\+xml)/.test(b.type)"
                    "||/\\.(json|txt|ya?ml|csv|svg)$/i.test(n);"
                    "var f=new FileReader();"
                    "f.onload=function(){post({type:'ezi_save_blob',filename:n,content:f.result,isBase64:!t});};"
                    "if(t){f.readAsText(b);}else{f.readAsDataURL(b);}"
                    "}).catch(function(x){console.error('EZi blob download failed:',x);});})();"
                ) % (json.dumps(uri), json.dumps(blob_name))
                sender.ExecuteScriptAsync(js)
            except Exception:
                _log_error('_ezi_on_download_starting')
            return

        suggested = os.path.basename(uri.split('?')[0]) or "download"
        try:
            from urllib.parse import urlparse, parse_qs
            qs = parse_qs(urlparse(uri).query)
            if qs.get('filename'):
                suggested = qs['filename'][0]
        except Exception:
            _log_error('_ezi_on_download_starting')

        def _manual_download():
            api_ref = _EZI_WINDOW_REF.get("api")
            println = api_ref._print if api_ref is not None else None
            try:
                w = _EZI_WINDOW_REF.get("window")
                if w is None:
                    return
                result = w.create_file_dialog(SAVE_DIALOG_TYPE, save_filename=suggested)
                path = result[0] if isinstance(result, (list, tuple)) else result
                if not path:
                    return
                _ezi_download_with_progress(
                    uri, path, println=println, label=suggested,
                    headers={"User-Agent": "ComfyUI-EZi"}, timeout=120
                )
                if api_ref is not None:
                    api_ref._println(f"\033[92m[Download] Saved to {path}\033[0m")
            except Exception as ex:
                if api_ref is not None:
                    api_ref._println(f"\033[91m[Download] Error: {ex}\033[0m")

        threading.Thread(target=_manual_download, daemon=True).start()
    except Exception:
        _log_error('_ezi_on_download_starting')



import subprocess
import threading
import json
import re
import codecs
import asyncio
import socket
import shlex
import base64
import time
import traceback

try:
    from aiohttp import web, ClientSession, ClientTimeout, WSMsgType
except ImportError:
    print("aiohttp not found - install it or use ComfyUI's python_embeded")
    sys.exit(1)


CURRENT_SCRIPT_DIR = os.path.abspath(os.path.dirname(__file__))
KEEP_CACHE_FLAG_PATH = os.path.join(CURRENT_SCRIPT_DIR, 'keep_cache.flag')

_PRESS_KEY_RE = re.compile(r'[^\r\n]*press any key[^\r\n]*(?:\r?\n|$)', re.IGNORECASE)

_PTY_ROWS = 40
_winpty_lock = threading.Lock()
_winpty_state = {'tried_install': False}

def _import_winpty():
    try:
        from winpty import PtyProcess
        return PtyProcess, None
    except Exception as e:
        return None, e

def _ensure_winpty(log=None):
    PtyProcess, err = _import_winpty()
    if PtyProcess:
        return PtyProcess, None
    with _winpty_lock:
        PtyProcess, err = _import_winpty()
        if PtyProcess or _winpty_state['tried_install']:
            return PtyProcess, err
        _winpty_state['tried_install'] = True
        try:
            exe = sys.executable
            if os.path.basename(exe).lower() == 'pythonw.exe':
                cand = os.path.join(os.path.dirname(exe), 'python.exe')
                if os.path.isfile(cand):
                    exe = cand
            if log:
                log("\033[93m[Console] pywinpty not found - installing it (needed for live pip progress bars)...\033[0m")
            r = subprocess.run([exe, '-m', 'pip', 'install', 'pywinpty', '--only-binary=:all:',
                                '--no-warn-script-location', '--disable-pip-version-check'],
                               capture_output=True, timeout=180, creationflags=0x08000000)
            if r.returncode != 0:
                tail = (r.stdout + r.stderr).decode('utf-8', errors='replace').strip().splitlines()[-1:]
                return None, RuntimeError('pip install pywinpty failed: ' + (tail[0] if tail else r.returncode))
            import importlib
            importlib.invalidate_caches()
            PtyProcess, err = _import_winpty()
            if log:
                if PtyProcess:
                    log("\033[92m[Console] pywinpty installed - live progress bars enabled.\033[0m")
                else:
                    log(f"\033[93m[Console] pywinpty installed but cannot be loaded: {err}\033[0m")
            return PtyProcess, err
        except Exception as e:
            return None, e

def _spawn_pty(cmd, cwd, env, cols, log=None):
    PtyProcess, err = _ensure_winpty(log)
    if PtyProcess is None:
        return None, err
    try:
        return PtyProcess.spawn([str(c) for c in cmd], cwd=cwd,
                                env={k: str(v) for k, v in env.items()},
                                dimensions=(_PTY_ROWS, max(40, int(cols)))), None
    except Exception as e:
        return None, e

ROOT_DIR = os.path.normpath(os.path.join(CURRENT_SCRIPT_DIR, "..", "..", ".."))

ICO_PATH = os.path.join(CURRENT_SCRIPT_DIR, "ComfyUI-EZi-Desktop.ico")
ICO_CMD_PATH = os.path.join(CURRENT_SCRIPT_DIR, "ComfyUI-EZi-CMD.ico")
SETTINGS_PATH = os.path.join(CURRENT_SCRIPT_DIR, "ComfyUI-EZi.settings.json")
LOG_PATH = os.path.join(CURRENT_SCRIPT_DIR, "ComfyUI-EZi.log")
_log_lock = threading.Lock()


def _log_error(where):
    try:
        with _log_lock:
            if os.path.exists(LOG_PATH) and os.path.getsize(LOG_PATH) > 512 * 1024:
                os.replace(LOG_PATH, LOG_PATH + ".1")
            with open(LOG_PATH, "a", encoding="utf-8") as f:
                f.write(time.strftime("%Y-%m-%d %H:%M:%S") + " [" + where + "]\n" + traceback.format_exc() + "\n")
    except Exception:
        pass


EZI_UA_TAG = "ComfyUI-EZi-Desktop"

def _get_browser_version():
    import winreg
    import subprocess
    candidates = [
        r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe",
        r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe",
    ]
    for key_path in candidates:
        for hive in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
            try:
                with winreg.OpenKey(hive, key_path) as k:
                    exe_path = winreg.QueryValue(k, None)
                if exe_path and os.path.isfile(exe_path):
                    r = subprocess.run(
                        ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command",
                         f"[System.Diagnostics.FileVersionInfo]::GetVersionInfo('{exe_path}').FileVersion"],
                        capture_output=True, timeout=5, creationflags=0x08000000
                    )
                    ver = r.stdout.decode(errors="replace").strip()
                    if ver:
                        return ver
            except Exception:
                continue
    return "154.0.0.0"

EZI_BROWSER_VER = _get_browser_version()

CHROME_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    f"(KHTML, like Gecko) Chrome/{EZI_BROWSER_VER} Safari/537.36 {EZI_UA_TAG}/{APP_VERSION}"
)

_argv_rest = sys.argv[1:]
DEV_MODE = '--dev' in _argv_rest
ADV_CONSOLE = '--advanced-console' in _argv_rest
_argv_rest = [a for a in _argv_rest if a not in ('--dev', '--advanced-console')]
_bat_arg = _argv_rest[0] if _argv_rest else "Start ComfyUI.bat"
BAT_FILE = _bat_arg if os.path.isabs(_bat_arg) else os.path.join(ROOT_DIR, _bat_arg)
COMFY_PORT = 8188

COMFYUI_URL_RE = re.compile(
    r'To see the GUI go to:\s+https?://(?:127\.0\.0\.1|localhost|0\.0\.0\.0):(\d+)',
    re.IGNORECASE
)

_COMFY_SCHEME = ["http"]
_LOOPBACK_SSL = [None]


def _comfy_origin(port):
    return f"{_COMFY_SCHEME[0]}://127.0.0.1:{port}"


def _comfy_ssl():
    if _COMFY_SCHEME[0] != "https":
        return None
    if _LOOPBACK_SSL[0] is None:
        import ssl
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        _LOOPBACK_SSL[0] = ctx
    return _LOOPBACK_SSL[0]


def _comfy_urlopen(url, timeout=5):
    import urllib.request as _ur
    return _ur.urlopen(url, timeout=timeout, context=_comfy_ssl())


def _setup_path():
    try:
        subprocess.run(['cmd', '/c', 'chcp', '65001'],
                       capture_output=True, creationflags=0x08000000)
    except Exception:
        pass
    windir = os.environ.get('windir', r'C:\Windows')
    localappdata = os.environ.get('LOCALAPPDATA', '')
    extra = []

    try:
        r = subprocess.run(
            ['cmd', '/c', 'where.exe', 'git.exe'],
            capture_output=True, timeout=5, creationflags=0x08000000
        )
        if r.returncode == 0:
            git_path = r.stdout.decode(errors='replace').strip().splitlines()[0]
            git_dir = os.path.dirname(git_path)
            if git_dir:
                extra.append(git_dir)
    except Exception:
        pass

    extra += [
        os.path.join(windir, 'System32'),
        os.path.join(windir, 'System32', 'WindowsPowerShell', 'v1.0'),
        os.path.join(localappdata, 'Microsoft', 'WindowsApps'),
    ]

    current = os.environ.get('PATH', '')
    additions = [p for p in extra if p and p.lower() not in current.lower()]
    if additions:
        os.environ['PATH'] = ';'.join(additions) + ';' + current

_setup_path()


def _find_bat_comfy_line(bat_content):
    lines = bat_content.splitlines()
    logical_lines = []
    i = 0
    while i < len(lines):
        line = lines[i]
        while line.rstrip('\r').rstrip().endswith('^') and i + 1 < len(lines):
            line = line.rstrip('\r').rstrip()[:-1] + ' ' + lines[i + 1].lstrip()
            i += 1
        logical_lines.append(line)
        i += 1

    for line in logical_lines:
        stripped = line.strip()
        if stripped.startswith('::') or re.match(r'(?i)^rem(\s|$)', stripped):
            continue
        if (re.search(r'python_embeded[/\\]python\.exe', stripped, re.IGNORECASE) and
                re.search(r'ComfyUI[/\\]main\.py', stripped, re.IGNORECASE)):
            return stripped
    return None


_ATTN_BAT_FLAGS = {
    'start comfyui kitchenattention.bat': '--use-ck-attention',
    'start comfyui sageattention.bat':    '--use-sage-attention',
    'start comfyui flashattention.bat':   '--use-flash-attention',
}


def _required_attn_flag(bat_path):
    return _ATTN_BAT_FLAGS.get(os.path.basename(bat_path or '').lower())


def _ensure_attention_flags():
    for bat_lower, flag in _ATTN_BAT_FLAGS.items():
        try:
            bat_path = None
            if os.path.isdir(ROOT_DIR):
                for fn in os.listdir(ROOT_DIR):
                    if fn.lower() == bat_lower:
                        bat_path = os.path.join(ROOT_DIR, fn)
                        break
            if not bat_path or not os.path.isfile(bat_path):
                continue
            with open(bat_path, 'r', encoding='utf-8', errors='replace', newline='') as f:
                content = f.read()
            lines = content.splitlines(keepends=True)
            flag_re = re.compile(r'(?<![\w-])' + re.escape(flag) + r'(?![\w-])')
            i = 0
            while i < len(lines):
                j = i
                acc = lines[i].rstrip('\r\n')
                while acc.rstrip().endswith('^') and j + 1 < len(lines):
                    acc = acc.rstrip()[:-1] + ' ' + lines[j + 1].lstrip().rstrip('\r\n')
                    j += 1
                acc_s = acc.strip()
                if (acc_s and
                        not acc_s.startswith('::') and
                        not re.match(r'(?i)^rem(\s|$)', acc_s) and
                        re.search(r'python_embeded[/\\]python\.exe', acc_s, re.IGNORECASE) and
                        re.search(r'ComfyUI[/\\]main\.py', acc_s, re.IGNORECASE)):
                    if flag_re.search(acc_s):
                        break
                    for k in range(i, j + 1):
                        new_line, n = re.subn(r'(?i)(main\.py["\']?)',
                                              lambda m: m.group(1) + ' ' + flag,
                                              lines[k], count=1)
                        if n:
                            lines[k] = new_line
                            with open(bat_path, 'w', encoding='utf-8', newline='') as f:
                                f.write(''.join(lines))
                            break
                    break
                i = j + 1
        except Exception:
            pass


def _ezi_force_foreground(hwnd):
    if not hwnd:
        return
    try:
        vp = ctypes.c_void_p
        u32 = ctypes.WinDLL('user32')
        u32.GetForegroundWindow.restype = vp
        u32.GetWindowThreadProcessId.argtypes = [vp, vp]
        u32.GetWindowThreadProcessId.restype = ctypes.c_uint
        u32.AttachThreadInput.argtypes = [ctypes.c_uint, ctypes.c_uint, ctypes.c_int]
        u32.SetWindowPos.argtypes = [vp, vp, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_uint]
        for fn in ('IsIconic', 'ShowWindow', 'BringWindowToTop', 'SetForegroundWindow'):
            getattr(u32, fn).argtypes = [vp] if fn != 'ShowWindow' else [vp, ctypes.c_int]
        h = vp(int(hwnd))
        if u32.IsIconic(h):
            u32.ShowWindow(h, 9)
        fg = u32.GetForegroundWindow()
        if fg and int(fg) == int(hwnd):
            return
        fg_tid = u32.GetWindowThreadProcessId(vp(fg), None) if fg else 0
        win_tid = u32.GetWindowThreadProcessId(h, None)
        attached = False
        if fg_tid and win_tid and fg_tid != win_tid:
            attached = bool(u32.AttachThreadInput(fg_tid, win_tid, 1))
        try:
            u32.SetWindowPos(h, vp(-1), 0, 0, 0, 0, 0x0043)
            u32.SetWindowPos(h, vp(-2), 0, 0, 0, 0, 0x0043)
            u32.BringWindowToTop(h)
            u32.SetForegroundWindow(h)
        finally:
            if attached:
                u32.AttachThreadInput(fg_tid, win_tid, 0)
    except Exception:
        pass

def _get_hwnd(window):
    _vp = ctypes.c_void_p
    try:
        if window is not None and window is _EZI_WINDOW_REF.get("window"):
            h = _EZI_WINDOW_REF.get("main_hwnd")
            if h and ctypes.windll.user32.IsWindow(h):
                return h
    except Exception:
        pass
    try:
        nh = window.native_handle
        if nh:
            return nh
    except Exception:
        pass
    try:
        user = ctypes.windll.user32
        current_pid = os.getpid()
        found = ctypes.c_void_p(0)

        WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, _vp, ctypes.POINTER(ctypes.c_long))

        def _enum_cb(hwnd, _lparam):
            pid = ctypes.c_ulong(0)
            user.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            if pid.value == current_pid:
                if user.IsWindowVisible(hwnd) and user.GetParent(hwnd) == 0:
                    found.value = hwnd
                    return False
            return True

        user.EnumWindows(WNDENUMPROC(_enum_cb), 0)
        if found.value:
            return found.value
    except Exception:
        pass
    return None

def _set_window_icon(hwnd, ico_path=None):
    ico_path = ico_path if (ico_path and os.path.exists(ico_path)) else ICO_PATH
    if not hwnd or not os.path.exists(ico_path):
        return
    try:
        ico = ctypes.windll.user32.LoadImageW(
            None, ico_path, 1, 0, 0, 0x00000010 | 0x00000040
        )
        if ico:
            ctypes.windll.user32.SendMessageW(hwnd, 0x0080, 0, ico)
            ctypes.windll.user32.SendMessageW(hwnd, 0x0080, 1, ico)
    except Exception:
        pass


import ctypes.wintypes as _wt


class _MONITORINFO(ctypes.Structure):
    _fields_ = [("cbSize", _wt.DWORD), ("rcMonitor", _wt.RECT),
                ("rcWork", _wt.RECT), ("dwFlags", _wt.DWORD)]

class EZI_WINDOWPLACEMENT(ctypes.Structure):
    _fields_ = [
        ("length",           ctypes.c_uint),
        ("flags",            ctypes.c_uint),
        ("showCmd",          ctypes.c_uint),
        ("ptMinPosition",    _wt.POINT),
        ("ptMaxPosition",    _wt.POINT),
        ("rcNormalPosition", _wt.RECT),
    ]

def _apply_captioned_frame_style(hwnd):
    if not hwnd:
        return
    try:
        import ctypes.wintypes
        GWL_STYLE      = -16
        WS_CAPTION     = 0x00C00000
        WS_SYSMENU     = 0x00080000
        WS_MINIMIZEBOX = 0x00020000
        WS_MAXIMIZEBOX = 0x00010000
        WS_THICKFRAME  = 0x00040000
        SWP_NOMOVE       = 0x0002
        SWP_NOSIZE       = 0x0001
        SWP_NOZORDER     = 0x0004
        SWP_FRAMECHANGED = 0x0020

        user32 = ctypes.windll.user32
        is_64 = ctypes.sizeof(ctypes.c_void_p) == 8
        get_long = user32.GetWindowLongPtrW if is_64 else user32.GetWindowLongW
        set_long = user32.SetWindowLongPtrW if is_64 else user32.SetWindowLongW
        get_long.restype  = ctypes.c_void_p if is_64 else ctypes.c_long
        get_long.argtypes = [ctypes.wintypes.HWND, ctypes.c_int]
        set_long.restype  = ctypes.c_void_p if is_64 else ctypes.c_long
        set_long.argtypes = [ctypes.wintypes.HWND, ctypes.c_int, ctypes.c_void_p if is_64 else ctypes.c_long]

        want = WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_THICKFRAME
        cur = int(get_long(hwnd, GWL_STYLE) or 0)
        if (cur & want) == want:
            return
        new_style = cur | want
        set_long(hwnd, GWL_STYLE, ctypes.c_void_p(new_style) if is_64 else new_style)
        user32.SetWindowPos(hwnd, None, 0, 0, 0, 0,
                             SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED)
    except Exception:
        _log_error('_apply_captioned_frame_style')


_hidden_titlebar_hooks = {}

_last_normal_rect = {}
_win_size_state   = {}
_correcting_rect  = set()
_in_sizemove      = set()
_settings_ref     = {"obj": None}


def _install_hidden_titlebar_hook(hwnd):
    if not hwnd or hwnd in _hidden_titlebar_hooks:
        return
    try:
        import ctypes.wintypes as wt

        GWLP_WNDPROC  = -4
        WM_NCCALCSIZE = 0x0083
        WM_NCACTIVATE = 0x0086
        WM_NCHITTEST  = 0x0084
        WM_GETMINMAXINFO = 0x0024
        WM_ACTIVATE   = 0x0006
        WM_SIZE       = 0x0005
        WM_DPICHANGED = 0x02E0
        WM_ENTERSIZEMOVE = 0x0231
        WM_EXITSIZEMOVE = 0x0232
        SIZE_RESTORED  = 0
        SIZE_MINIMIZED = 1
        SIZE_MAXIMIZED = 2
        MONITOR_DEFAULTTONEAREST = 2
        HTTOP      = 12
        HTTOPLEFT  = 13
        HTTOPRIGHT = 14
        SM_CXSIZEFRAME    = 32
        SM_CXPADDEDBORDER = 92

        user32 = ctypes.windll.user32

        class _NCCALCSIZE_PARAMS(ctypes.Structure):
            _fields_ = [('rgrc', wt.RECT * 3), ('lppos', ctypes.c_void_p)]

        class _MINMAXINFO(ctypes.Structure):
            _fields_ = [
                ('ptReserved',     wt.POINT),
                ('ptMaxSize',      wt.POINT),
                ('ptMaxPosition',  wt.POINT),
                ('ptMinTrackSize', wt.POINT),
                ('ptMaxTrackSize', wt.POINT),
            ]

        user32.SetWindowLongPtrW.restype  = ctypes.c_void_p
        user32.SetWindowLongPtrW.argtypes = [wt.HWND, ctypes.c_int, ctypes.c_void_p]
        user32.CallWindowProcW.restype    = ctypes.c_ssize_t
        user32.CallWindowProcW.argtypes   = [ctypes.c_void_p, wt.HWND, ctypes.c_uint, wt.WPARAM, wt.LPARAM]
        user32.DefWindowProcW.restype     = ctypes.c_ssize_t
        user32.DefWindowProcW.argtypes    = [wt.HWND, ctypes.c_uint, wt.WPARAM, wt.LPARAM]
        user32.IsZoomed.argtypes          = [wt.HWND]
        user32.IsIconic.argtypes          = [wt.HWND]
        user32.MonitorFromWindow.restype  = ctypes.c_void_p
        user32.MonitorFromWindow.argtypes = [wt.HWND, ctypes.c_uint]
        user32.MonitorFromRect.restype    = ctypes.c_void_p
        user32.MonitorFromRect.argtypes   = [ctypes.POINTER(wt.RECT), ctypes.c_uint]
        user32.GetMonitorInfoW.argtypes   = [ctypes.c_void_p, ctypes.c_void_p]
        user32.GetWindowPlacement.argtypes = [wt.HWND, ctypes.POINTER(EZI_WINDOWPLACEMENT)]
        user32.SetWindowPlacement.argtypes = [wt.HWND, ctypes.POINTER(EZI_WINDOWPLACEMENT)]

        user32.GetWindowRect.argtypes = [wt.HWND, ctypes.POINTER(wt.RECT)]

        def _ezi_resolve_target_monitor(hwnd_):
            try:
                rc = wt.RECT()
                stale_offscreen = False
                if user32.GetWindowRect(hwnd_, ctypes.byref(rc)):
                    if rc.left <= -20000 or rc.top <= -20000:
                        stale_offscreen = True
                if user32.IsIconic(hwnd_) or stale_offscreen:
                    wp = EZI_WINDOWPLACEMENT()
                    wp.length = ctypes.sizeof(EZI_WINDOWPLACEMENT)
                    if user32.GetWindowPlacement(hwnd_, ctypes.byref(wp)):
                        mon = user32.MonitorFromRect(ctypes.byref(wp.rcNormalPosition), MONITOR_DEFAULTTONEAREST)
                        if mon:
                            return mon
            except Exception:
                pass
            return user32.MonitorFromWindow(hwnd_, MONITOR_DEFAULTTONEAREST)

        WNDPROC_TYPE = ctypes.WINFUNCTYPE(ctypes.c_ssize_t, wt.HWND, ctypes.c_uint, wt.WPARAM, wt.LPARAM)

        def _wndproc(hwnd_, msg, wparam, lparam):
            try:
                if msg == WM_GETMINMAXINFO:
                    try:
                        user32.CallWindowProcW(holder['orig'], hwnd_, msg, wparam, lparam)
                        mmi = ctypes.cast(lparam, ctypes.POINTER(_MINMAXINFO)).contents
                        mon = _ezi_resolve_target_monitor(hwnd_)
                        if mon:
                            mi = _MONITORINFO()
                            mi.cbSize = ctypes.sizeof(_MONITORINFO)
                            if user32.GetMonitorInfoW(mon, ctypes.byref(mi)):
                                mmi.ptMaxPosition.x = mi.rcWork.left - mi.rcMonitor.left
                                mmi.ptMaxPosition.y = mi.rcWork.top - mi.rcMonitor.top
                                mmi.ptMaxSize.x = mi.rcWork.right - mi.rcWork.left
                                mmi.ptMaxSize.y = mi.rcWork.bottom - mi.rcWork.top
                    except Exception:
                        pass
                    return 0

                if msg == WM_NCCALCSIZE and wparam:
                    params = ctypes.cast(lparam, ctypes.POINTER(_NCCALCSIZE_PARAMS)).contents
                    if user32.IsZoomed(hwnd_):
                        mon = _ezi_resolve_target_monitor(hwnd_)
                        if mon:
                            mi = _MONITORINFO()
                            mi.cbSize = ctypes.sizeof(_MONITORINFO)
                            if user32.GetMonitorInfoW(mon, ctypes.byref(mi)):
                                params.rgrc[0].left   = mi.rcWork.left
                                params.rgrc[0].top    = mi.rcWork.top
                                params.rgrc[0].right  = mi.rcWork.right
                                params.rgrc[0].bottom = mi.rcWork.bottom
                        return 0
                    original_top = params.rgrc[0].top
                    ret = user32.DefWindowProcW(hwnd_, msg, wparam, lparam)
                    params.rgrc[0].top = original_top
                    return ret

                if msg == WM_NCHITTEST:
                    try:
                        if not user32.IsZoomed(hwnd_) and not user32.IsIconic(hwnd_):
                            x = ctypes.c_short(lparam & 0xFFFF).value
                            y = ctypes.c_short((lparam >> 16) & 0xFFFF).value
                            rc = wt.RECT()
                            if user32.GetWindowRect(hwnd_, ctypes.byref(rc)):
                                if rc.top <= y < rc.top + _EZI_TOP_RESIZE_GAP:
                                    h_margin = user32.GetSystemMetrics(SM_CXSIZEFRAME) + \
                                               user32.GetSystemMetrics(SM_CXPADDEDBORDER)
                                    if h_margin <= 0:
                                        h_margin = 8
                                    if x < rc.left + h_margin:
                                        return HTTOPLEFT
                                    elif x >= rc.right - h_margin:
                                        return HTTOPRIGHT
                                    else:
                                        return HTTOP
                    except Exception:
                        pass

                if msg == WM_NCACTIVATE:
                    _reapply_no_border(hwnd_)
                    return user32.DefWindowProcW(hwnd_, msg, wparam, lparam)

                if msg == WM_ACTIVATE:
                    _reapply_no_border(hwnd_)

                if msg == WM_ENTERSIZEMOVE:
                    _in_sizemove.add(hwnd_)

                if msg == WM_DPICHANGED:
                    try:
                        rc = ctypes.cast(lparam, ctypes.POINTER(wt.RECT)).contents
                        SWP_NOZORDER   = 0x0004
                        SWP_NOACTIVATE = 0x0010
                        user32.SetWindowPos(
                            hwnd_, None, rc.left, rc.top,
                            rc.right - rc.left, rc.bottom - rc.top,
                            SWP_NOZORDER | SWP_NOACTIVATE
                        )
                    except Exception:
                        pass
                    try:
                        fn = _ezi_bounds_fns.get(int(hwnd_))
                        if fn:
                            fn()
                        import threading as _th
                        for _delay in (0.05, 0.15, 0.35):
                            _th.Timer(_delay, lambda f=fn: f() if f else None).start()
                    except Exception:
                        pass

                if msg == WM_SIZE:
                    cur_state  = int(wparam)
                    prev_state = _win_size_state.get(hwnd_, SIZE_RESTORED)
                    _win_size_state[hwnd_] = cur_state

                    really_restored = (cur_state == SIZE_RESTORED
                                        and not user32.IsZoomed(hwnd_)
                                        and not user32.IsIconic(hwnd_))

                    if really_restored and prev_state in (SIZE_MAXIMIZED, SIZE_MINIMIZED) \
                            and hwnd_ not in _correcting_rect and hwnd_ not in _in_sizemove:
                        saved = _last_normal_rect.get(hwnd_)
                        if not saved:
                            try:
                                s_obj = _settings_ref.get("obj") or {}
                                wp = s_obj.get("window_placement") or {}
                                rc_data = wp.get("rcNormalPosition")
                                if rc_data and len(rc_data) == 4:
                                    saved = rc_data
                            except Exception:
                                saved = None
                        if saved:
                            l, t, r, b = saved
                            w, h = r - l, b - t
                            if w > 50 and h > 50:
                                def _deferred_restore_fix(target=(l, t, r, b), hh=hwnd_):
                                    try:
                                        if hh in _correcting_rect:
                                            return
                                        if user32.IsZoomed(hh) or user32.IsIconic(hh) \
                                                or hh in _in_sizemove:
                                            return
                                        rc2 = wt.RECT()
                                        if not user32.GetWindowRect(hh, ctypes.byref(rc2)):
                                            return
                                        cur = (rc2.left, rc2.top, rc2.right, rc2.bottom)
                                        if all(abs(cur[i] - target[i]) <= 3 for i in range(4)):
                                            return
                                        _correcting_rect.add(hh)
                                        try:
                                            wp_native = EZI_WINDOWPLACEMENT()
                                            wp_native.length = ctypes.sizeof(EZI_WINDOWPLACEMENT)
                                            wp_native.showCmd = 1
                                            wp_native.rcNormalPosition = wt.RECT(*target)
                                            user32.SetWindowPlacement(hh, ctypes.byref(wp_native))
                                        finally:
                                            _correcting_rect.discard(hh)
                                    except Exception:
                                        pass
                                import threading as _th
                                _th.Timer(0.1, _deferred_restore_fix).start()
                            try:
                                s_obj = _settings_ref.get("obj")
                                if s_obj is not None:
                                    wp2 = s_obj.get("window_placement")
                                    if not isinstance(wp2, dict):
                                        wp2 = {}
                                    wp2["rcNormalPosition"] = [l, t, r, b]
                                    wp2["showCmd"] = 1
                                    s_obj["window_placement"] = wp2
                                    _save_settings(s_obj)
                            except Exception:
                                pass
                    elif really_restored:
                        rc = wt.RECT()
                        if user32.GetWindowRect(hwnd_, ctypes.byref(rc)):
                            rect_now = [rc.left, rc.top, rc.right, rc.bottom]
                            _last_normal_rect[hwnd_] = rect_now
                            try:
                                s_obj = _settings_ref.get("obj")
                                if s_obj is not None:
                                    wp = s_obj.get("window_placement")
                                    if not isinstance(wp, dict):
                                        wp = {}
                                    wp["rcNormalPosition"] = rect_now
                                    wp["showCmd"] = 1
                                    s_obj["window_placement"] = wp
                            except Exception:
                                pass

                if msg == WM_EXITSIZEMOVE:
                    _in_sizemove.discard(hwnd_)
                    try:
                        if not user32.IsZoomed(hwnd_) and not user32.IsIconic(hwnd_) \
                                and hwnd_ not in _correcting_rect:
                            rc = wt.RECT()
                            if user32.GetWindowRect(hwnd_, ctypes.byref(rc)):
                                rect_now = [rc.left, rc.top, rc.right, rc.bottom]
                                _last_normal_rect[hwnd_] = rect_now
                                try:
                                    s_obj = _settings_ref.get("obj")
                                    if s_obj is not None:
                                        wp = s_obj.get("window_placement")
                                        if not isinstance(wp, dict):
                                            wp = {}
                                        wp["rcNormalPosition"] = rect_now
                                        wp["showCmd"] = 1
                                        s_obj["window_placement"] = wp
                                        _save_settings(s_obj)
                                except Exception:
                                    pass
                    except Exception:
                        pass
            except Exception:
                pass
            return user32.CallWindowProcW(holder['orig'], hwnd_, msg, wparam, lparam)

        holder = {'orig': None}
        ref = WNDPROC_TYPE(_wndproc)
        holder['orig'] = user32.SetWindowLongPtrW(hwnd, GWLP_WNDPROC, ctypes.cast(ref, ctypes.c_void_p))
        _hidden_titlebar_hooks[hwnd] = {'ref': ref, 'orig': holder['orig']}
        _apply_win11_rounded_corners(hwnd)
    except Exception:
        _log_error('_install_hidden_titlebar_hook')

def _reapply_no_border(hwnd):
    if not hwnd:
        return
    try:
        dwmapi = ctypes.windll.dwmapi
        DWMWA_BORDER_COLOR = 34
        DWMWA_COLOR_DEFAULT = ctypes.c_int(-1)
        dwmapi.DwmSetWindowAttribute(hwnd, DWMWA_BORDER_COLOR,
                                      ctypes.byref(DWMWA_COLOR_DEFAULT),
                                      ctypes.sizeof(DWMWA_COLOR_DEFAULT))
    except Exception:
        pass


def _apply_win11_rounded_corners(hwnd):
    if not hwnd:
        return
    try:
        dwmapi = ctypes.windll.dwmapi
        DWMWA_WINDOW_CORNER_PREFERENCE = 33
        DWMWC_ROUND = ctypes.c_int(2)
        dwmapi.DwmSetWindowAttribute(hwnd, DWMWA_WINDOW_CORNER_PREFERENCE,
                                      ctypes.byref(DWMWC_ROUND),
                                      ctypes.sizeof(DWMWC_ROUND))
    except Exception:
        pass


def _force_full_repaint(hwnd):
    if not hwnd:
        return
    try:
        user32 = ctypes.windll.user32
        RDW_INVALIDATE   = 0x0001
        RDW_ERASE        = 0x0004
        RDW_ALLCHILDREN  = 0x0080
        RDW_UPDATENOW    = 0x0100
        RDW_FRAME        = 0x0400
        user32.RedrawWindow(
            hwnd, None, None,
            RDW_INVALIDATE | RDW_ERASE | RDW_FRAME | RDW_ALLCHILDREN | RDW_UPDATENOW
        )
    except Exception:
        pass


def _suppress_dwm_border(hwnd):
    if not hwnd:
        return
    try:
        _reapply_no_border(hwnd)
        SWP_NOMOVE       = 0x0002
        SWP_NOSIZE       = 0x0001
        SWP_NOZORDER     = 0x0004
        SWP_NOACTIVATE   = 0x0010
        SWP_FRAMECHANGED = 0x0020
        ctypes.windll.user32.SetWindowPos(
            hwnd, None, 0, 0, 0, 0,
            SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED
        )
    except Exception:
        pass


import struct as _struct

def _guid_bytes(s):
    s = s.replace('{','').replace('}','').replace('-','')
    d1 = int(s[0:8],  16)
    d2 = int(s[8:12], 16)
    d3 = int(s[12:16],16)
    d4 = bytes(int(s[16+i*2:18+i*2],16) for i in range(8))
    return _struct.pack('<IHH', d1, d2, d3) + d4


_CLSID_TaskbarList = _guid_bytes('56FDF344-FD6D-11d0-958A-006097C9A090')
_IID_ITaskbarList3 = _guid_bytes('EA1AFB91-9E28-4B86-90E9-9E9F8A5EEFAF')

_TBPF_NORMAL        = 2

_taskbar_com_obj  = None
_taskbar_com_lock = __import__('threading').Lock()

def _get_taskbar_obj():
    global _taskbar_com_obj
    if _taskbar_com_obj is not None:
        return _taskbar_com_obj
    with _taskbar_com_lock:
        if _taskbar_com_obj is not None:
            return _taskbar_com_obj
        try:
            ole32 = ctypes.windll.ole32
            ole32.CoInitializeEx(None, 0)
            clsid = ctypes.create_string_buffer(_CLSID_TaskbarList, 16)
            iid   = ctypes.create_string_buffer(_IID_ITaskbarList3,  16)
            obj   = ctypes.c_void_p()
            hr = ole32.CoCreateInstance(
                ctypes.byref(clsid), None, 1,
                ctypes.byref(iid), ctypes.byref(obj)
            )
            if hr != 0 or not obj:
                return None
            vtbl = ctypes.cast(obj, ctypes.POINTER(ctypes.c_void_p))
            base = ctypes.cast(vtbl[0], ctypes.POINTER(ctypes.c_void_p))
            _F   = ctypes.WINFUNCTYPE
            _P   = ctypes.c_void_p
            _ULL = ctypes.c_ulonglong
            _INT = ctypes.c_int
            _LONG= ctypes.c_long
            hr2 = _F(_LONG, _P)(base[3])(obj)
            if hr2 != 0:
                return None
            _taskbar_com_obj = {
                'obj': obj,
                'MarkFullscreenWindow': _F(_LONG, _P, _P, _INT)(base[8]),
                'SetProgressValue': _F(_LONG, _P, _P, _ULL, _ULL)(base[9]),
                'SetProgressState': _F(_LONG, _P, _P, _INT)(base[10]),
            }
            return _taskbar_com_obj
        except Exception:
            return None

def _taskbar_mark_not_fullscreen(hwnd):
    if not hwnd:
        return
    try:
        tb = _get_taskbar_obj()
        if not tb:
            return
        tb['MarkFullscreenWindow'](tb['obj'], ctypes.c_void_p(hwnd), 0)
    except Exception:
        pass

def _taskbar_progress_ctypes(hwnd, value, maximum, state=2):
    if not hwnd:
        return
    try:
        tb = _get_taskbar_obj()
        if not tb:
            return
        hwnd_p = ctypes.c_void_p(hwnd)
        tb['SetProgressState'](tb['obj'], hwnd_p, state)
        if state == _TBPF_NORMAL and maximum > 0:
            tb['SetProgressValue'](tb['obj'], hwnd_p,
                                   ctypes.c_ulonglong(value),
                                   ctypes.c_ulonglong(maximum))
    except Exception:
        pass


def _get_desktop():
    try:
        import ctypes.wintypes
        buf = ctypes.create_unicode_buffer(ctypes.wintypes.MAX_PATH)
        ctypes.windll.shell32.SHGetFolderPathW(0, 0x0000, 0, 0, buf)
        path = buf.value
        if path and os.path.isdir(path):
            return path
    except Exception:
        pass
    return os.path.join(os.path.expanduser("~"), "Desktop")

EZI_ZIP_PATH = os.path.join(ROOT_DIR, "ComfyUI-Easy-Install.zip")
EZI_ZIP_URL = "https://github.com/Tavris1/ComfyUI-Easy-Install/releases/latest/download/ComfyUI-Easy-Install.zip"
UPDATE_CHECK_INTERVAL = 6 * 3600


def _ezi_zip_signature():
    try:
        st = os.stat(EZI_ZIP_PATH)
        return f"{st.st_size}:{int(st.st_mtime)}"
    except OSError:
        return ""


def _ezi_download_ua():
    ver = (EZI_BROWSER_VER or "").replace(" ", "") or "154.0.0.0"
    return ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            f"(KHTML, like Gecko) Chrome/{ver} Safari/537.36 Edge/{ver}")


def _ezi_fetch_to_file(url, dest, ua):
    import shutil
    import urllib.request as _ur

    def _via_urllib(ctx):
        req = _ur.Request(url, headers={"User-Agent": ua})
        with _ur.urlopen(req, timeout=30, context=ctx) as r, open(dest, "wb") as f:
            shutil.copyfileobj(r, f, 256 * 1024)

    def _via_powershell():
        env = dict(os.environ, EZI_URL=url, EZI_DEST=dest, EZI_UA=ua)
        ps = ("$ProgressPreference='SilentlyContinue';"
              "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12;"
              "$w=New-Object System.Net.WebClient;"
              "$w.Headers.Add('User-Agent',$env:EZI_UA);"
              "$w.DownloadFile($env:EZI_URL,$env:EZI_DEST)")
        r = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
                           env=env, capture_output=True, timeout=300, creationflags=0x08000000)
        if r.returncode != 0:
            raise RuntimeError(r.stderr.decode(errors="replace").strip() or "PowerShell download failed")

    methods = (
        (lambda: _via_urllib(None), 3),
        (_via_powershell, 1),
    )
    last_err = None
    for method, attempts in methods:
        for i in range(attempts):
            try:
                method()
                return
            except Exception as e:
                last_err = e
                if i + 1 < attempts:
                    time.sleep(2)
    raise last_err if last_err else RuntimeError("download failed")


def _download_ezi_zip():
    import zipfile
    part = EZI_ZIP_PATH + ".part"
    try:
        _ezi_fetch_to_file(EZI_ZIP_URL, part, _ezi_download_ua())
        with zipfile.ZipFile(part) as z:
            if "Helper-CEI.zip" not in z.namelist():
                raise ValueError("Helper-CEI.zip not found in the downloaded archive")
        os.replace(part, EZI_ZIP_PATH)
        return True
    except Exception:
        _log_error('_download_ezi_zip')
        try:
            os.remove(part)
        except OSError:
            pass
        return False


BAT_NAMES = (
    'Start ComfyUI.bat',
    'Start ComfyUI SageAttention.bat',
    'Start ComfyUI FlashAttention.bat',
    'Start ComfyUI KitchenAttention.bat',
)


def _installed_frontend_version():
    try:
        import importlib.metadata as im
        for pkg in ('comfyui_frontend_package', 'comfyui-frontend-package'):
            try:
                ver = im.version(pkg)
            except Exception:
                continue
            if ver and ver != '0.1.0':
                return ver
    except Exception:
        _log_error('_installed_frontend_version')
    try:
        import glob
        site = os.path.join(ROOT_DIR, 'python_embeded', 'Lib', 'site-packages')
        pattern = os.path.join(site, 'comfyui_frontend_package-*.dist-info', 'METADATA')
        for meta_path in sorted(glob.glob(pattern), reverse=True):
            with open(meta_path, 'r', encoding='utf-8', errors='replace') as f:
                for line in f:
                    if line.startswith('Version:'):
                        ver = line.split(':', 1)[1].strip()
                        if ver and ver != '0.1.0':
                            return ver
                        break
    except Exception:
        _log_error('_installed_frontend_version')
    return None


def _latest_release_tag(repo):
    import urllib.request as _ur
    req = _ur.Request(f"https://github.com/{repo}/releases/latest",
                      headers={"User-Agent": EZI_UA_TAG}, method="HEAD")
    with _ur.urlopen(req, timeout=8) as r:
        final_url = r.geturl()
    if "/releases/tag/" not in final_url:
        raise ValueError(f"could not parse tag from redirect target: {final_url!r}")
    return final_url.rstrip("/").rsplit("/", 1)[-1].strip()


def _read_bat():
    if not os.path.exists(BAT_FILE):
        return None
    with open(BAT_FILE, 'r', encoding='utf-8', errors='replace') as f:
        return f.read()


def _bat_env(bat_content, name):
    m = re.search(r'(?i)set\s+"?' + re.escape(name) + r'=([^"\n]+)"?', bat_content)
    return m.group(1).strip().strip('"') if m else None


def _bat_args(bat_content):
    m = re.search(r'python_embeded[/\\]python\.exe["\']?\s+(.*)',
                  _find_bat_comfy_line(bat_content) or '', re.IGNORECASE)
    return shlex.split(m.group(1).strip(), posix=False) if m else []


def _bat_flag_value(tokens, flag):
    for i, tok in enumerate(tokens):
        if tok == flag and i + 1 < len(tokens):
            return tokens[i + 1].strip('"\'')
    return None


_MANAGER_BAT_FLAGS = ('--enable-manager', '--enable-manager-legacy-ui')
_MANAGER_SECURITY_LEVELS = ('weak', 'normal-', 'normal', 'strong')


def _bat_manager_ui(bat_content):
    tokens = _bat_args(bat_content)
    if '--enable-manager-legacy-ui' in tokens:
        return 'legacy'
    if '--enable-manager' in tokens:
        return 'new'
    return 'off'


def _apply_manager_ui_to_bats(mode):
    if mode not in ('classic', 'legacy', 'new'):
        return False
    flags = {'legacy': ['--enable-manager', '--enable-manager-legacy-ui'], 'new': ['--enable-manager']}.get(mode, [])
    changed = False
    for bat_name in BAT_NAMES:
        bat_path = os.path.join(ROOT_DIR, bat_name)
        if not os.path.exists(bat_path):
            continue
        try:
            with open(bat_path, 'r', encoding='utf-8', errors='replace', newline='') as f:
                content = f.read()
            lines = content.splitlines(keepends=True)
            start_idx = end_idx = logical_line = None
            i = 0
            while i < len(lines):
                accumulated = lines[i].rstrip('\r\n')
                j = i
                while accumulated.rstrip().endswith('^') and j + 1 < len(lines):
                    accumulated = accumulated.rstrip()[:-1] + ' ' + lines[j + 1].lstrip().rstrip('\r\n')
                    j += 1
                acc_s = accumulated.strip()
                if (acc_s and
                        not acc_s.startswith('::') and
                        not re.match(r'(?i)^rem(\s|$)', acc_s) and
                        re.search(r'python_embeded[/\\]python\.exe', acc_s, re.IGNORECASE) and
                        re.search(r'ComfyUI[/\\]main\.py', acc_s, re.IGNORECASE)):
                    start_idx, end_idx, logical_line = i, j, acc_s
                    break
                i += 1
            if logical_line is None:
                continue
            m = re.search(r'(.*python_embeded[/\\]python\.exe[\"\']?)\s+(.*)', logical_line, re.IGNORECASE | re.DOTALL)
            if not m:
                continue
            tokens = shlex.split(m.group(2).strip(), posix=False)
            script_idx = None
            for idx, tok in enumerate(tokens):
                if re.search(r'main\.py', tok, re.IGNORECASE):
                    script_idx = idx
                    break
            if script_idx is None:
                continue
            head = tokens[:script_idx + 1]
            tail = [t for t in tokens[script_idx + 1:] if t not in _MANAGER_BAT_FLAGS]
            insert_at = tail.index('--windows-standalone-build') + 1 if '--windows-standalone-build' in tail else 0
            tail[insert_at:insert_at] = flags
            new_line = ' '.join([m.group(1)] + head + tail)
            ending = '\r\n' if lines[start_idx].endswith('\r\n') else '\n'
            new_lines = lines[:start_idx] + [new_line + ending] + lines[end_idx + 1:]
            with open(bat_path, 'w', encoding='utf-8', newline='') as f:
                f.write(''.join(new_lines))
            changed = True
        except Exception:
            _log_error('_apply_manager_ui_to_bats')
    return changed


def _get_comfy_user_dir():
    user_dir = None
    try:
        bat_content = _read_bat()
        if bat_content is not None:
            user_dir = (_bat_env(bat_content, 'COMFY_USER_DIR')
                        or _bat_flag_value(_bat_args(bat_content), '--user-directory'))
    except Exception:
        pass
    if user_dir:
        if not os.path.isabs(user_dir):
            user_dir = os.path.normpath(os.path.join(ROOT_DIR, user_dir))
        return os.path.join(user_dir, 'default')
    return os.path.join(ROOT_DIR, 'ComfyUI', 'user', 'default')


def _get_manager_config_path():
    user_dir_with_default = _get_comfy_user_dir()
    user_dir = os.path.dirname(user_dir_with_default)
    return os.path.join(user_dir, '__manager', 'config.ini')


def _get_comfy_current_theme():
    try:
        user_dir = _get_comfy_user_dir()
        settings_file = os.path.join(user_dir, 'comfy.settings.json')
        if os.path.exists(settings_file):
            with open(settings_file, 'r', encoding='utf-8', errors='replace') as f:
                data = json.load(f)
            palette_id = data.get('Comfy.ColorPalette', '')
            if not palette_id:
                palette_id = 'dark'
            return str(palette_id)
    except Exception:
        pass
    return ''


def _frontend_pkg_dir():
    site_pkgs = os.path.join(ROOT_DIR, 'python_embeded', 'Lib', 'site-packages')
    pkg_dir = os.path.join(site_pkgs, 'comfyui_frontend_package')
    if os.path.isdir(pkg_dir):
        return pkg_dir
    import glob
    candidates = glob.glob(os.path.join(site_pkgs, 'comfyui_frontend_package*'))
    return next((c for c in candidates if os.path.isdir(c) and 'dist-info' not in c), None)


def _get_builtin_palettes_from_frontend():
    pkg_dir = _frontend_pkg_dir()
    if not pkg_dir:
        return {}

    palettes_dir = os.path.join(pkg_dir, 'static', 'assets', 'palettes')
    if not os.path.isdir(palettes_dir):
        return {}

    palettes = {}
    try:
        for fname in os.listdir(palettes_dir):
            if not fname.endswith('.json'):
                continue
            fpath = os.path.join(palettes_dir, fname)
            try:
                with open(fpath, 'r', encoding='utf-8', errors='replace') as f:
                    data = json.load(f)
                pid = data.get('id')
                colors = data.get('colors', {})
                if pid and colors:
                    palettes[pid] = colors
            except Exception:
                continue
    except Exception:
        return {}

    return palettes


_BUILTIN_PALETTES_CACHE = None

_COMMON_NODE_SLOT = {
    'CLIP': '#FFD500', 'CLIP_VISION': '#A8DADC', 'CLIP_VISION_OUTPUT': '#ad7452',
    'CONDITIONING': '#FFA931', 'CONTROL_NET': '#6EE7B7', 'IMAGE': '#64B5F6',
    'LATENT': '#FF9CF9', 'MASK': '#81C784', 'MODEL': '#B39DDB',
    'STYLE_MODEL': '#C2FFAE', 'VAE': '#FF6E6E', 'NOISE': '#B0B0B0',
    'GUIDER': '#66FFFF', 'SAMPLER': '#ECB4B4', 'SIGMAS': '#CDFFCD', 'TAESD': '#DCC274',
}

_FALLBACK_PALETTES = {
    'dark': {
        'node_slot': _COMMON_NODE_SLOT,
        'litegraph_base': {
            'CLEAR_BACKGROUND_COLOR': '#141414', 'NODE_TITLE_COLOR': '#999',
            'NODE_SELECTED_TITLE_COLOR': '#FFF', 'NODE_TEXT_COLOR': '#AAA',
            'NODE_TEXT_HIGHLIGHT_COLOR': '#FFF', 'NODE_DEFAULT_COLOR': '#333',
            'NODE_DEFAULT_BGCOLOR': '#353535', 'NODE_DEFAULT_BOXCOLOR': '#666',
            'NODE_DEFAULT_SHAPE': 2, 'NODE_BOX_OUTLINE_COLOR': '#FFF',
            'NODE_BYPASS_BGCOLOR': '#FF00FF', 'NODE_ERROR_COLOUR': '#E00',
            'DEFAULT_SHADOW_COLOR': 'rgba(0,0,0,0.5)', 'WIDGET_BGCOLOR': '#222',
            'WIDGET_OUTLINE_COLOR': '#666', 'WIDGET_TEXT_COLOR': '#DDD',
            'WIDGET_SECONDARY_TEXT_COLOR': '#999', 'WIDGET_DISABLED_TEXT_COLOR': '#666',
            'LINK_COLOR': '#9A9', 'EVENT_LINK_COLOR': '#A86', 'CONNECTING_LINK_COLOR': '#AFA',
            'BADGE_FG_COLOR': '#FFF', 'BADGE_BG_COLOR': '#0F1F0F',
        },
        'comfy_base': {
            'fg-color': '#fff', 'bg-color': '#202020', 'comfy-menu-bg': '#171718',
            'comfy-menu-secondary-bg': '#303030', 'comfy-input-bg': '#222',
            'input-text': '#ddd', 'descrip-text': '#999', 'drag-text': '#ccc',
            'error-text': '#ff4444', 'border-color': '#4e4e4e',
            'tr-even-bg-color': '#222', 'tr-odd-bg-color': '#353535',
            'content-bg': '#4e4e4e', 'content-fg': '#fff',
            'content-hover-bg': '#222', 'content-hover-fg': '#fff',
            'bar-shadow': 'rgba(16, 16, 16, 0.5) 0 0 0.5rem',
        },
    },
    'light': {
        'node_slot': _COMMON_NODE_SLOT,
        'litegraph_base': {
            'CLEAR_BACKGROUND_COLOR': '#e0e0e0', 'NODE_TITLE_COLOR': '#222',
            'NODE_SELECTED_TITLE_COLOR': '#000', 'NODE_TEXT_COLOR': '#333',
            'NODE_TEXT_HIGHLIGHT_COLOR': '#000', 'NODE_DEFAULT_COLOR': '#ccc',
            'NODE_DEFAULT_BGCOLOR': '#f5f5f5', 'NODE_DEFAULT_BOXCOLOR': '#999',
            'NODE_DEFAULT_SHAPE': 2, 'NODE_BOX_OUTLINE_COLOR': '#000',
            'NODE_BYPASS_BGCOLOR': '#FF00FF', 'NODE_ERROR_COLOUR': '#E00',
            'DEFAULT_SHADOW_COLOR': 'rgba(0,0,0,0.1)', 'WIDGET_BGCOLOR': '#e0e0e0',
            'WIDGET_OUTLINE_COLOR': '#999', 'WIDGET_TEXT_COLOR': '#333',
            'WIDGET_SECONDARY_TEXT_COLOR': '#666', 'WIDGET_DISABLED_TEXT_COLOR': '#999',
            'LINK_COLOR': '#4CAF50', 'EVENT_LINK_COLOR': '#FF9800', 'CONNECTING_LINK_COLOR': '#2196F3',
            'BADGE_FG_COLOR': '#000', 'BADGE_BG_COLOR': '#e0f0e0',
        },
        'comfy_base': {
            'fg-color': '#222', 'bg-color': '#e9e9e9', 'comfy-menu-bg': '#f5f5f5',
            'comfy-menu-secondary-bg': '#e0e0e0', 'comfy-input-bg': '#d0d0d0',
            'input-text': '#222', 'descrip-text': '#666', 'drag-text': '#888',
            'error-text': '#cc0000', 'border-color': '#bbb',
            'tr-even-bg-color': '#e5e5e5', 'tr-odd-bg-color': '#f0f0f0',
            'content-bg': '#bbb', 'content-fg': '#222',
            'content-hover-bg': '#d0d0d0', 'content-hover-fg': '#000',
            'bar-shadow': 'rgba(0, 0, 0, 0.1) 0 0 0.5rem',
        },
    },
    'solarized': {
        'node_slot': _COMMON_NODE_SLOT,
        'litegraph_base': {
            'CLEAR_BACKGROUND_COLOR': '#002b36', 'NODE_TITLE_COLOR': '#93a1a1',
            'NODE_SELECTED_TITLE_COLOR': '#fdf6e3', 'NODE_TEXT_COLOR': '#839496',
            'NODE_TEXT_HIGHLIGHT_COLOR': '#fdf6e3', 'NODE_DEFAULT_COLOR': '#073642',
            'NODE_DEFAULT_BGCOLOR': '#073642', 'NODE_DEFAULT_BOXCOLOR': '#586e75',
            'NODE_DEFAULT_SHAPE': 2, 'NODE_BOX_OUTLINE_COLOR': '#268bd2',
            'NODE_BYPASS_BGCOLOR': '#FF00FF', 'NODE_ERROR_COLOUR': '#dc322f',
            'DEFAULT_SHADOW_COLOR': 'rgba(0,0,0,0.5)', 'WIDGET_BGCOLOR': '#003847',
            'WIDGET_OUTLINE_COLOR': '#586e75', 'WIDGET_TEXT_COLOR': '#839496',
            'WIDGET_SECONDARY_TEXT_COLOR': '#657b83', 'WIDGET_DISABLED_TEXT_COLOR': '#586e75',
            'LINK_COLOR': '#2aa198', 'EVENT_LINK_COLOR': '#cb4b16', 'CONNECTING_LINK_COLOR': '#859900',
            'BADGE_FG_COLOR': '#fdf6e3', 'BADGE_BG_COLOR': '#073642',
        },
        'comfy_base': {
            'fg-color': '#839496', 'bg-color': '#002b36', 'comfy-menu-bg': '#073642',
            'comfy-menu-secondary-bg': '#003847', 'comfy-input-bg': '#003847',
            'input-text': '#839496', 'descrip-text': '#657b83', 'drag-text': '#586e75',
            'error-text': '#dc322f', 'border-color': '#0d525e',
            'tr-even-bg-color': '#003847', 'tr-odd-bg-color': '#073642',
            'content-bg': '#0d525e', 'content-fg': '#839496',
            'content-hover-bg': '#003847', 'content-hover-fg': '#93a1a1',
            'bar-shadow': 'rgba(0, 0, 0, 0.5) 0 0 0.5rem',
        },
    },
    'arc': {
        'node_slot': _COMMON_NODE_SLOT,
        'litegraph_base': {
            'CLEAR_BACKGROUND_COLOR': '#2f343f', 'NODE_TITLE_COLOR': '#d3dae3',
            'NODE_SELECTED_TITLE_COLOR': '#fff', 'NODE_TEXT_COLOR': '#d3dae3',
            'NODE_TEXT_HIGHLIGHT_COLOR': '#fff', 'NODE_DEFAULT_COLOR': '#383c4a',
            'NODE_DEFAULT_BGCOLOR': '#383c4a', 'NODE_DEFAULT_BOXCOLOR': '#4b5162',
            'NODE_DEFAULT_SHAPE': 2, 'NODE_BOX_OUTLINE_COLOR': '#5294e2',
            'NODE_BYPASS_BGCOLOR': '#FF00FF', 'NODE_ERROR_COLOUR': '#E00',
            'DEFAULT_SHADOW_COLOR': 'rgba(0,0,0,0.5)', 'WIDGET_BGCOLOR': '#404552',
            'WIDGET_OUTLINE_COLOR': '#4b5162', 'WIDGET_TEXT_COLOR': '#d3dae3',
            'WIDGET_SECONDARY_TEXT_COLOR': '#9c9fa8', 'WIDGET_DISABLED_TEXT_COLOR': '#666',
            'LINK_COLOR': '#5294e2', 'EVENT_LINK_COLOR': '#cba6f7', 'CONNECTING_LINK_COLOR': '#5294e2',
            'BADGE_FG_COLOR': '#d3dae3', 'BADGE_BG_COLOR': '#2f343f',
        },
        'comfy_base': {
            'fg-color': '#d3dae3', 'bg-color': '#2f343f', 'comfy-menu-bg': '#383c4a',
            'comfy-menu-secondary-bg': '#404552', 'comfy-input-bg': '#404552',
            'input-text': '#d3dae3', 'descrip-text': '#9c9fa8', 'drag-text': '#9c9fa8',
            'error-text': '#ff4444', 'border-color': '#4b5162',
            'tr-even-bg-color': '#404552', 'tr-odd-bg-color': '#383c4a',
            'content-bg': '#4b5162', 'content-fg': '#d3dae3',
            'content-hover-bg': '#404552', 'content-hover-fg': '#fff',
            'bar-shadow': 'rgba(0, 0, 0, 0.5) 0 0 0.5rem',
        },
    },
    'nord': {
        'node_slot': _COMMON_NODE_SLOT,
        'litegraph_base': {
            'CLEAR_BACKGROUND_COLOR': '#2e3440', 'NODE_TITLE_COLOR': '#d8dee9',
            'NODE_SELECTED_TITLE_COLOR': '#eceff4', 'NODE_TEXT_COLOR': '#d8dee9',
            'NODE_TEXT_HIGHLIGHT_COLOR': '#eceff4', 'NODE_DEFAULT_COLOR': '#3b4252',
            'NODE_DEFAULT_BGCOLOR': '#3b4252', 'NODE_DEFAULT_BOXCOLOR': '#4c566a',
            'NODE_DEFAULT_SHAPE': 2, 'NODE_BOX_OUTLINE_COLOR': '#88c0d0',
            'NODE_BYPASS_BGCOLOR': '#FF00FF', 'NODE_ERROR_COLOUR': '#bf616a',
            'DEFAULT_SHADOW_COLOR': 'rgba(0,0,0,0.5)', 'WIDGET_BGCOLOR': '#434c5e',
            'WIDGET_OUTLINE_COLOR': '#4c566a', 'WIDGET_TEXT_COLOR': '#d8dee9',
            'WIDGET_SECONDARY_TEXT_COLOR': '#81a1c1', 'WIDGET_DISABLED_TEXT_COLOR': '#4c566a',
            'LINK_COLOR': '#88c0d0', 'EVENT_LINK_COLOR': '#d08770', 'CONNECTING_LINK_COLOR': '#a3be8c',
            'BADGE_FG_COLOR': '#eceff4', 'BADGE_BG_COLOR': '#2e3440',
        },
        'comfy_base': {
            'fg-color': '#d8dee9', 'bg-color': '#2e3440', 'comfy-menu-bg': '#3b4252',
            'comfy-menu-secondary-bg': '#434c5e', 'comfy-input-bg': '#434c5e',
            'input-text': '#d8dee9', 'descrip-text': '#81a1c1', 'drag-text': '#81a1c1',
            'error-text': '#bf616a', 'border-color': '#4c566a',
            'tr-even-bg-color': '#434c5e', 'tr-odd-bg-color': '#3b4252',
            'content-bg': '#4c566a', 'content-fg': '#d8dee9',
            'content-hover-bg': '#434c5e', 'content-hover-fg': '#eceff4',
            'bar-shadow': 'rgba(0, 0, 0, 0.5) 0 0 0.5rem',
        },
    },
    'github': {
        'node_slot': _COMMON_NODE_SLOT,
        'litegraph_base': {
            'CLEAR_BACKGROUND_COLOR': '#0d1117', 'NODE_TITLE_COLOR': '#c9d1d9',
            'NODE_SELECTED_TITLE_COLOR': '#f0f6fc', 'NODE_TEXT_COLOR': '#c9d1d9',
            'NODE_TEXT_HIGHLIGHT_COLOR': '#f0f6fc', 'NODE_DEFAULT_COLOR': '#161b22',
            'NODE_DEFAULT_BGCOLOR': '#161b22', 'NODE_DEFAULT_BOXCOLOR': '#30363d',
            'NODE_DEFAULT_SHAPE': 2, 'NODE_BOX_OUTLINE_COLOR': '#388bfd',
            'NODE_BYPASS_BGCOLOR': '#FF00FF', 'NODE_ERROR_COLOUR': '#f85149',
            'DEFAULT_SHADOW_COLOR': 'rgba(0,0,0,0.5)', 'WIDGET_BGCOLOR': '#21262d',
            'WIDGET_OUTLINE_COLOR': '#30363d', 'WIDGET_TEXT_COLOR': '#c9d1d9',
            'WIDGET_SECONDARY_TEXT_COLOR': '#8b949e', 'WIDGET_DISABLED_TEXT_COLOR': '#484f58',
            'LINK_COLOR': '#3fb950', 'EVENT_LINK_COLOR': '#d29922', 'CONNECTING_LINK_COLOR': '#388bfd',
            'BADGE_FG_COLOR': '#f0f6fc', 'BADGE_BG_COLOR': '#0d1117',
        },
        'comfy_base': {
            'fg-color': '#c9d1d9', 'bg-color': '#0d1117', 'comfy-menu-bg': '#161b22',
            'comfy-menu-secondary-bg': '#21262d', 'comfy-input-bg': '#21262d',
            'input-text': '#c9d1d9', 'descrip-text': '#8b949e', 'drag-text': '#8b949e',
            'error-text': '#f85149', 'border-color': '#30363d',
            'tr-even-bg-color': '#21262d', 'tr-odd-bg-color': '#161b22',
            'content-bg': '#30363d', 'content-fg': '#c9d1d9',
            'content-hover-bg': '#21262d', 'content-hover-fg': '#f0f6fc',
            'bar-shadow': 'rgba(0, 0, 0, 0.5) 0 0 0.5rem',
        },
    },
}


def _get_builtin_palettes():
    global _BUILTIN_PALETTES_CACHE
    if _BUILTIN_PALETTES_CACHE is not None:
        return _BUILTIN_PALETTES_CACHE
    from_frontend = _get_builtin_palettes_from_frontend()
    if from_frontend:
        _BUILTIN_PALETTES_CACHE = from_frontend
        return _BUILTIN_PALETTES_CACHE
    _BUILTIN_PALETTES_CACHE = _FALLBACK_PALETTES
    return _BUILTIN_PALETTES_CACHE


def _get_comfy_theme_css_vars():
    try:
        user_dir = _get_comfy_user_dir()
        settings_file = os.path.join(user_dir, 'comfy.settings.json')
        if not os.path.exists(settings_file):
            return {}
        with open(settings_file, 'r', encoding='utf-8', errors='replace') as f:
            data = json.load(f)

        custom_palettes = data.get('Comfy.CustomColorPalettes', {})
        palette_id = data.get('Comfy.ColorPalette', '') or 'dark'

        colors = {}
        if palette_id in custom_palettes:
            colors = custom_palettes[palette_id].get('colors', {})
        else:
            colors = _get_builtin_palettes().get(palette_id, {})

        cb = colors.get('comfy_base', {})
        lg = colors.get('litegraph_base', {})

        def c(key, fallback=''):
            return cb.get(key, fallback) or fallback

        def lg_c(key, fallback=''):
            return lg.get(key, fallback) or fallback

        bg        = c('bg-color', '#202020')
        menu_bg   = c('comfy-menu-bg', bg)
        input_bg  = c('comfy-input-bg', bg)
        fg        = c('fg-color', '#cccccc')
        border    = c('border-color', '#444444')
        lg_bg     = lg_c('CLEAR_BACKGROUND_COLOR', bg)
        node_bg   = lg_c('NODE_DEFAULT_BGCOLOR', menu_bg)
        node_title = lg_c('NODE_TITLE_COLOR', fg)

        accent = lg_c('NODE_BOX_OUTLINE_COLOR', c('border-color', '#388bfd'))

        def _hex_luminance(hex_color):
            try:
                h = hex_color.lstrip('#')
                if len(h) == 3:
                    h = h[0]*2 + h[1]*2 + h[2]*2
                r, g, b = int(h[0:2],16)/255, int(h[2:4],16)/255, int(h[4:6],16)/255
                def _lin(c): return c/12.92 if c <= 0.04045 else ((c+0.055)/1.055)**2.4
                return 0.2126*_lin(r) + 0.7152*_lin(g) + 0.0722*_lin(b)
            except Exception:
                return 0.5

        def _blend(hex1, hex2, t=0.35):
            try:
                h1, h2 = hex1.lstrip('#'), hex2.lstrip('#')
                if len(h1) == 3: h1 = h1[0]*2 + h1[1]*2 + h1[2]*2
                if len(h2) == 3: h2 = h2[0]*2 + h2[1]*2 + h2[2]*2
                r1,g1,b1 = int(h1[0:2],16), int(h1[2:4],16), int(h1[4:6],16)
                r2,g2,b2 = int(h2[0:2],16), int(h2[2:4],16), int(h2[4:6],16)
                r = int(r1*(1-t) + r2*t)
                g = int(g1*(1-t) + g2*t)
                b = int(b1*(1-t) + b2*t)
                return '#{:02x}{:02x}{:02x}'.format(r,g,b)
            except Exception:
                return hex1

        accent_lum = _hex_luminance(accent)
        if accent_lum > 0.80 or accent_lum < 0.05:
            link_color = lg_c('LINK_COLOR', '')
            if link_color:
                link_lum = _hex_luminance(link_color)
                if 0.05 <= link_lum <= 0.80:
                    accent = link_color
                    accent_lum = link_lum

        if accent_lum >= 0.18:
            accent_bg       = _blend(accent, '#000000', 0.60)
            accent_bg_hover = _blend(accent, '#000000', 0.45)
        else:
            accent_bg       = _blend(accent, '#ffffff', 0.60)
            accent_bg_hover = _blend(accent, '#ffffff', 0.45)

        acc_bg_lum = _hex_luminance(accent_bg)
        text_on_accent = '#ffffff' if acc_bg_lum < 0.35 else '#111111'
        accent_hover   = _blend(accent, '#ffffff', 0.30)

        return {
            '--bg':               lg_bg,
            '--bar-bg':           menu_bg,
            '--border':           border,
            '--border2':          border,
            '--border3':          border,
            '--btn-bg':           node_bg,
            '--btn-bg2':          node_bg,
            '--input-bg':         input_bg,
            '--modal-bg':         menu_bg,
            '--hover-row':        lg_bg,
            '--text':             fg,
            '--text2':            node_title,
            '--text3':            fg,
            '--accent':           accent,
            '--accent-hover':     accent_hover,
            '--accent-bg':        accent_bg,
            '--accent-bg-hover':  accent_bg_hover,
            '--text-on-accent':   text_on_accent,
        }
    except Exception:
        _log_error('_get_comfy_theme_css_vars')
        return {}


_EZI_AI_LANGS = (
    "en", "zh-CN", "zh-TW", "es", "ru", "ja", "ko", "de", "fr", "pt-BR", "it", "tr", "ar", "hi", "id", "vi", "pl", "uk", "nl",
    "th", "fa", "bg", "cs", "ro", "el", "hu", "sr", "he", "bn", "sv", "ms", "fil"
)


def _ezi_system_lang():
    try:
        k32 = ctypes.windll.kernel32
        buf = ctypes.create_unicode_buffer(85)
        name = ""
        try:
            lang_id = k32.GetUserDefaultUILanguage()
            if lang_id and k32.LCIDToLocaleName(lang_id, buf, 85, 0):
                name = buf.value
        except Exception:
            name = ""
        if not name and k32.GetUserDefaultLocaleName(buf, 85):
            name = buf.value
        low = name.lower().replace("_", "-")
        if not low:
            return "en"
        primary = low.split("-")[0]
        if primary == "zh":
            return "zh-TW" if any(t in low for t in ("tw", "hk", "mo", "hant")) else "zh-CN"
        if primary == "pt":
            return "pt-BR"
        primary = {"tl": "fil", "iw": "he", "in": "id"}.get(primary, primary)
        for code in _EZI_AI_LANGS:
            if code.lower() == primary:
                return code
    except Exception:
        pass
    return "en"


def _persist_comfy_theme_vars():
    try:
        vars_ = _get_comfy_theme_css_vars()
        if not vars_:
            _log_error('_persist_comfy_theme_vars: empty theme vars, looked in ' + os.path.join(_get_comfy_user_dir(), 'comfy.settings.json'))
            return
        if not os.path.exists(SETTINGS_PATH):
            return
        with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict) or data.get("theme") != "comfyui" or data.get("comfy_theme_vars") == vars_:
            return
        data["comfy_theme_vars"] = vars_
        tmp = SETTINGS_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        os.replace(tmp, SETTINGS_PATH)
    except Exception:
        _log_error('_persist_comfy_theme_vars')

EZI_AURORA_PALETTE_ID = "ezi_aurora"
EZI_AURORA_PALETTE_VERSION = 1

EZI_AURORA_PALETTE = {
    "id": EZI_AURORA_PALETTE_ID,
    "name": "EZi Aurora",
    "light_theme": False,
    "colors": {
        "node_slot": {
            "CLIP": "#ffd166", "CLIP_VISION": "#8fd3e0", "CLIP_VISION_OUTPUT": "#c08a64",
            "CONDITIONING": "#ffa65c", "CONTROL_NET": "#6ee7b7", "IMAGE": "#6cb8ff",
            "LATENT": "#f29cff", "MASK": "#8ddc9a", "MODEL": "#b49cf0",
            "STYLE_MODEL": "#c2ffae", "VAE": "#ff7a8a", "NOISE": "#b0bccd",
            "GUIDER": "#66f0e6", "SAMPLER": "#e8b4c4", "SIGMAS": "#cdf5d0", "TAESD": "#dcc274",
        },
        "litegraph_base": {
            "CLEAR_BACKGROUND_COLOR": "#0b1926", "NODE_TITLE_COLOR": "#a1b3cc",
            "NODE_SELECTED_TITLE_COLOR": "#ffffff", "NODE_TEXT_COLOR": "#b7c6dc",
            "NODE_TEXT_HIGHLIGHT_COLOR": "#ffffff", "NODE_DEFAULT_COLOR": "#304b63",
            "NODE_DEFAULT_BGCOLOR": "#22374b", "NODE_DEFAULT_BOXCOLOR": "#49758a",
            "NODE_DEFAULT_SHAPE": 2, "NODE_BOX_OUTLINE_COLOR": "#82dfcd",
            "NODE_BYPASS_BGCOLOR": "#FF00FF", "NODE_ERROR_COLOUR": "#ff3b4e",
            "DEFAULT_SHADOW_COLOR": "rgba(0,0,0,0.5)", "WIDGET_BGCOLOR": "#0d2433",
            "WIDGET_OUTLINE_COLOR": "#49758a", "WIDGET_TEXT_COLOR": "#e3ecfb",
            "WIDGET_SECONDARY_TEXT_COLOR": "#a1b3cc", "WIDGET_DISABLED_TEXT_COLOR": "#5f7893",
            "LINK_COLOR": "#7fc9bd", "EVENT_LINK_COLOR": "#e0a96d", "CONNECTING_LINK_COLOR": "#9be9d9",
            "BADGE_FG_COLOR": "#edf3ff", "BADGE_BG_COLOR": "#12303f",
        },
        "comfy_base": {
            "fg-color": "#edf3ff", "bg-color": "#0f2233", "comfy-menu-bg": "#102638",
            "comfy-menu-secondary-bg": "#122438", "comfy-input-bg": "#09232d",
            "input-text": "#e3ecfb", "descrip-text": "#a1b3cc", "drag-text": "#c3d1e6",
            "error-text": "#ff5d6c", "border-color": "#304659",
            "tr-even-bg-color": "#0d2230", "tr-odd-bg-color": "#162c40",
            "content-bg": "#304659", "content-fg": "#edf3ff",
            "content-hover-bg": "#203649", "content-hover-fg": "#ffffff",
            "bar-shadow": "rgba(4, 12, 20, 0.6) 0 0 0.5rem",
            "interface-stroke": "#3b566f", "interface-panel-surface": "#102638",
            "interface-panel-hover-surface": "#203649", "interface-panel-selected-surface": "#304b63",
            "interface-button-hover-surface": "#304b63",
        },
    },
}


def _ensure_ezi_aurora_palette(settings):
    try:
        if not isinstance(settings, dict):
            return
        try:
            done = int(settings.get("ezi_aurora_palette_ver", 0) or 0)
        except (TypeError, ValueError):
            done = 0
        if done >= EZI_AURORA_PALETTE_VERSION:
            return
        user_dir = _get_comfy_user_dir()
        settings_file = os.path.join(user_dir, "comfy.settings.json")
        data = {}
        if os.path.exists(settings_file):
            with open(settings_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict):
                return
        palettes = data.get("Comfy.CustomColorPalettes")
        if palettes is None:
            palettes = {}
        if not isinstance(palettes, dict):
            return
        palettes[EZI_AURORA_PALETTE_ID] = json.loads(json.dumps(EZI_AURORA_PALETTE))
        data["Comfy.CustomColorPalettes"] = palettes
        os.makedirs(user_dir, exist_ok=True)
        tmp = settings_file + ".ezi.tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
        os.replace(tmp, settings_file)
        settings["ezi_aurora_palette_ver"] = EZI_AURORA_PALETTE_VERSION
        _save_settings(settings)
    except Exception:
        _log_error('_ensure_ezi_aurora_palette')


def _load_settings():
    defaults = {
        "last_save_dir": _get_desktop(),
        "window_maximized": False,
        "window_placement": None,
        "show_tooltips": True,
        "theme": "aurora",
        "launcher_theme": "aurora",
        "console_detached": False,
        "console_placement": None,
        "rec_fps": 30,
        "console_bg_image": "",
        "console_bg_fit": "fit",
        "console_bg_opacity": 0.12,
        "sel_pop_copy": True,
        "sel_pop_google": True,
        "sel_pop_chatgpt": True,
        "sel_pop_claude": False,
        "sel_pop_save": True,
        "sel_ai_lang": _ezi_system_lang(),
        "console_zoom_attached": 12,
        "console_zoom_detached": 12,
        "comfy_zoom_factor": 1.0,
        "ext_pages_inside": True,
    }
    try:
        if os.path.exists(SETTINGS_PATH):
            with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
            if data.get("_dpi_aware_version", 0) < 1:
                data["window_placement"] = None
                data["console_placement"] = None
                data["_dpi_aware_version"] = 1
                try:
                    tmp = SETTINGS_PATH + ".tmp"
                    with open(tmp, "w", encoding="utf-8") as f:
                        json.dump(data, f, indent=2, ensure_ascii=False)
                    os.replace(tmp, SETTINGS_PATH)
                except Exception:
                    _log_error('_load_settings')
            defaults.update(data)
    except Exception:
        _log_error('_load_settings')
    if defaults.get("theme") == "comfyui":
        _persist_comfy_theme_vars()
    return defaults

def _save_settings(settings):
    try:
        if not settings or not isinstance(settings, dict):
            return
        ALLOWED = (
            "last_save_dir", "window_maximized", "comfy_storage", "show_tooltips",
            "window_placement", "custom_file_browser", "theme", "launcher_theme", "console_detached", "launcher_mode", "console_placement",
            "adv_console_placement", "adv_console_zoom_detached", "_dpi_aware_version", "rec_fps", "console_bg_image",
            "console_bg_fit", "console_bg_opacity", "console_bg_animate", "sel_pop_copy", "sel_pop_google", "sel_pop_chatgpt",
            "sel_pop_claude", "sel_pop_save", "sel_ai_lang", "console_zoom_attached", "console_zoom_detached", "comfy_zoom_factor",
            "cached_comfy_stable_version", "pinned_packages", "proxy_port", "ezi_updated_from", "ezi_zip_failed_sig", "auto_snapshot", "ezi_zip_tag", "ezi_aurora_palette_ver",
            "ext_pages_inside"
        )
        existing = {}
        try:
            if os.path.exists(SETTINGS_PATH):
                with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
                    existing = json.load(f)
                if not isinstance(existing, dict):
                    existing = {}
        except Exception:
            _log_error('_save_settings')
        keep_existing = ("launcher_mode", "auto_snapshot")
        if ADV_CONSOLE:
            keep_existing = ("launcher_mode", "window_placement", "window_maximized", "console_placement", "auto_snapshot")
        merged = {}
        for k in ALLOWED:
            if k in keep_existing and k in existing:
                merged[k] = existing[k]
            elif k in settings:
                merged[k] = settings[k]
            elif k in existing:
                merged[k] = existing[k]
        if merged.get("theme") == "comfyui":
            try:
                theme_vars = _get_comfy_theme_css_vars()
            except Exception:
                theme_vars = {}
            if not theme_vars and isinstance(existing.get("comfy_theme_vars"), dict):
                theme_vars = existing["comfy_theme_vars"]
            if theme_vars:
                merged["comfy_theme_vars"] = theme_vars
        if not merged:
            return
        tmp = SETTINGS_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(merged, f, indent=2, ensure_ascii=False)
        os.replace(tmp, SETTINGS_PATH)
    except Exception:
        _log_error('_save_settings')

def _get_save_dialog_type():
    try:
        return webview.FileDialog.SAVE
    except AttributeError:
        return webview.SAVE_DIALOG

SAVE_DIALOG_TYPE = _get_save_dialog_type()

SHELL_HTML_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ComfyUI-EZi-shell.html")

def _load_shell_html():
    try:
        with open(SHELL_HTML_PATH, "r", encoding="utf-8") as _f:
            return _f.read()
    except Exception as e:
        raise RuntimeError(
            f"Could not load {SHELL_HTML_PATH!r} - make sure it is next to ComfyUI-EZi.py. ({e})"
        )

SHELL_HTML = _load_shell_html()

def _parse_theme_names():
    try:
        block = re.search(r"const EZI_THEME_LIST\s*=\s*\[(.*?)\];", SHELL_HTML, re.S).group(1)
        names = tuple(re.findall(r"value:\s*'([^']+)'", block))
        if names:
            return names
    except (AttributeError, IndexError):
        pass
    return ("dark", "aurora", "pixaroma", "light", "comfyui")

EZI_THEME_NAMES = _parse_theme_names()
LAUNCHER_THEME_NAMES = EZI_THEME_NAMES + ("follow",)


def _load_ico_as_base64():
    ico_w, ico_h = 256, 256
    if not os.path.exists(ICO_PATH):
        return "", ico_w, ico_h
    try:
        from PIL import Image
        import io as _io
        with Image.open(ICO_PATH) as im:
            frames = []
            try:
                for _i in range(getattr(im, 'n_frames', 1)):
                    im.seek(_i)
                    frames.append((im.size[0] * im.size[1], im.copy()))
            except EOFError:
                pass
            best = max(frames, key=lambda x: x[0])[1] if frames else im
            ico_w, ico_h = best.size
            buf = _io.BytesIO()
            best.convert("RGBA").save(buf, format="PNG")
            b64 = base64.b64encode(buf.getvalue()).decode()
        return f'url("data:image/png;base64,{b64}")', ico_w, ico_h
    except Exception:
        pass
    try:
        with open(ICO_PATH, "rb") as _f:
            b64 = base64.b64encode(_f.read()).decode()
        return f'url("data:image/x-icon;base64,{b64}")', ico_w, ico_h
    except Exception:
        return "", ico_w, ico_h

def _get_shell_html(settings=None):
    settings = settings or {}
    custom_bg  = settings.get("console_bg_image", "").strip()
    bg_fit     = settings.get("console_bg_fit", "fit")
    bg_opacity = settings.get("console_bg_opacity", 0.12)

    ico_opacity = str(round(float(bg_opacity), 4))
    ico_repeat  = "no-repeat"

    _ico_css, ico_w, ico_h = _load_ico_as_base64()
    if custom_bg and os.path.isfile(custom_bg):
        ext  = os.path.splitext(custom_bg)[1].lower().lstrip(".")
        mime = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg",
                "webp": "image/webp", "svg": "image/svg+xml"}.get(ext, "image/png")
        try:
            with open(custom_bg, "rb") as _f:
                b64 = base64.b64encode(_f.read()).decode()
            ico_css = f'url("data:{mime};base64,{b64}")'
        except Exception:
            ico_css = ""
        fit_map = {
            "fit":     ("contain",   "no-repeat"),
            "stretch": ("100% 100%", "no-repeat"),
            "tile":    ("auto",      "repeat"),
            "center":  ("auto",      "no-repeat"),
        }
        ico_size, ico_repeat = fit_map.get(bg_fit, ("contain", "no-repeat"))
        ico_pos = "inset: 0; width: auto; height: auto; transform: none;"
    elif _ico_css:
        ico_css  = _ico_css
        ico_size = f"{ico_w}px {ico_h}px"
        ico_pos  = (f"width: {ico_w}px; height: {ico_h}px;\n"
                    f"    top: 50%; left: 50%; transform: translate(-50%, -50%);")
    else:
        ico_css  = ""
        ico_size = "256px 256px"
        ico_pos  = "width: 256px; height: 256px;\n    top: 50%; left: 50%; transform: translate(-50%, -50%);"

    return (SHELL_HTML
            .replace("{ICO_BG}",      ico_css)
            .replace("{ICO_POS}",     ico_pos)
            .replace("{ICO_SIZE}",    ico_size)
            .replace("{ICO_REPEAT}",  ico_repeat)
            .replace("{ICO_OPACITY}", ico_opacity)
            .replace("{EZI_VERSION}", APP_VERSION))

_CONSOLE_ICON_SVG = (
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" '
    'stroke-linejoin="round" aria-hidden="true" focusable="false">'
    '<path d="M11 21h-6a2 2 0 0 1-2-2v-14a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v6"/>'
    '<path d="M14 15a1 1 0 0 1 1-1h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1h-5a1 1 0 0 1-1-1z"/>'
    '<path d="M6.5 7.5l5 5"/>'
    '<path d="M6.5 11.5v-4h4"/>'
    '</svg>')

_CONSOLE_PAGE_BODY = r"""<body>
<div id="bar"><button id="attach-btn" tabindex="-1" data-tip="Attach console back to the ComfyUI-EZi window"
  onmousedown="event.preventDefault()" onclick="attachConsole()">__ICON__</button><div id="menu-wrap"><button id="menu-btn"
  tabindex="-1" data-tip="Console options" onmousedown="event.preventDefault()"
  onclick="toggleSelMenu(event)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
  stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="3" y="3" width="18" height="18"
  rx="2.5"/><path d="M12 7.5v9"/><path d="M9.5 7.5h5"/>
  <path d="M9.5 16.5h5"/></svg></button><div id="sel-menu"><div class="sm-row"
  data-tip="Search the console (Ctrl+F)" onclick="eziOpenSearch()"><span>Search<small class="sm-kbd">Ctrl+F</small></span><svg viewBox="0 0 24 24" fill="none"
  stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"
  focusable="false"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg></div><div class="sm-row"
  data-tip="Save the entire console log as a .txt file (Ctrl+S)" onclick="saveLog()"><span>Save log as .txt<small
  class="sm-kbd">Ctrl+S</small></span><svg viewBox="0 0 24 24"
  fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"
  focusable="false"><path d="M6 4h10l4 4v10a2 2 0 0 1-2 2h-12a2 2 0 0 1-2-2v-12a2 2 0 0 1 2-2"/><circle cx="12" cy="14" r="2"/>
  <path d="M14 4v4h-6v-4"/></svg></div><div class="sm-sep">Selection popup</div><label class="sm-row"
  data-tip="Show a Copy button when text is selected in the console"><span>Copy</span><span class="ezi-sw"><input type="checkbox"
  data-k="copy"><i></i></span></label><label class="sm-row"
  data-tip="Show a button that saves the selected text to a .txt file"><span>Save selection</span><span class="ezi-sw"><input
  type="checkbox" data-k="save"><i></i></span></label><label class="sm-row"
  data-tip="Show a button that searches the selected text on Google"><span>Google</span><span class="ezi-sw"><input
  type="checkbox" data-k="google"><i></i></span></label><div class="sm-sep">Account required</div><label class="sm-row"
  data-tip="Show a button that asks ChatGPT about the selected text (needs a ChatGPT account)"><span>Ask ChatGPT</span><span
  class="ezi-sw"><input type="checkbox" data-k="chatgpt"><i></i></span></label><label class="sm-row"
  data-tip="Show a button that asks Claude about the selected text (needs a Claude account)"><span>Ask Claude</span><span
  class="ezi-sw"><input type="checkbox"
  data-k="claude"><i></i></span></label><div class="sm-sep">AI answer language</div><div class="sm-lang"
  data-tip="Language in which ChatGPT and Claude should answer"><select id="sel-lang"></select></div><div
  class="sm-sep">Text size</div><div class="sm-zoom"><button type="button" class="sm-zb"
  data-tip="Decrease text size (Ctrl and -)" onmousedown="event.preventDefault()"
  onclick="__eziStepTermFont(-1)">&minus;</button><span id="zoom-val"
  data-tip="Current text size">100%</span><button type="button" class="sm-zb" data-tip="Increase text size (Ctrl and +)"
  onmousedown="event.preventDefault()" onclick="__eziStepTermFont(1)">+</button><button type="button" class="sm-zb sm-zreset"
  data-tip="Reset text size to 100% (Ctrl and 0)" onmousedown="event.preventDefault()"
  onclick="__eziResetTermFont()">Reset</button></div></div></div><div id="cap-wrap"
  style="margin-left:auto;display:flex;align-items:center;gap:8px;height:32px;"><div id="out-btn-wrap"><button id="out-btn"
  tabindex="-1" onmousedown="event.preventDefault()" onclick="toggleOutDropdown(event)" title="Folders"><svg class="btn-icon"
  viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
  aria-hidden="true" focusable="false"><path d="M3 7V5a2 2 0 0 1 2-2h5l2 3h7a2 2 0 0 1 2 2v2"/>
  <path d="M3 7h6l2 3h11l-3 10H3Z"/></svg> Folders <span class="out-chevron">&#x25BE;</span></button><div id="out-dropdown"><div
  class="out-drop-item" onclick="openOutputFolder()"><img class="btn-icon"
  src="https://cdnjs.cloudflare.com/ajax/libs/twemoji/14.0.2/svg/1f4c2.svg"> Output</div><div class="out-drop-item"
  onclick="openSubFolder('input')"><img class="btn-icon"
  src="https://cdnjs.cloudflare.com/ajax/libs/twemoji/14.0.2/svg/1f4e5.svg"> Input</div><div class="out-drop-item"
  onclick="openSubFolder('workflows')"><img class="btn-icon"
  src="https://cdnjs.cloudflare.com/ajax/libs/twemoji/14.0.2/svg/1f5c2.svg"> Workflows</div><div class="out-drop-item"
  onclick="openSubFolder('models')"><img class="btn-icon"
  src="https://cdnjs.cloudflare.com/ajax/libs/twemoji/14.0.2/svg/1f9e0.svg"> Models</div></div></div><div
  id="scr-btn-wrap"><button id="scr-btn" tabindex="-1" onmousedown="event.preventDefault()" onclick="toggleScrDropdown(event)"
  title="Capture"><svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
  stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">
  <path d="M14 4h-4L8 7H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-4Z"/><circle cx="12" cy="13"
  r="4"/></svg> Capture <span class="out-chevron">&#x25BE;</span></button><div id="scr-dropdown"><div class="scr-drop-item"
  onclick="startCrop('screenshot')"><img class="btn-icon"
  src="https://cdnjs.cloudflare.com/ajax/libs/twemoji/14.0.2/svg/1f4f7.svg"> Screenshot</div><div class="scr-drop-item"
  onclick="startCrop('video')"><img class="btn-icon"
  src="https://cdnjs.cloudflare.com/ajax/libs/twemoji/14.0.2/svg/1f3a5.svg"> Record Video</div></div></div><div id="rec-indicator"
  style="display:none"></div><button id="settings-btn" tabindex="-1" title="Easy menu" onmousedown="event.preventDefault()"
  onclick="openEasyMenu()">&#x2630;</button></div></div>
<div id="modal-overlay"><div id="modal-box"><div id="modal-icon"></div><div id="modal-title"></div><div id="modal-msg"></div><div
  id="modal-btns"></div></div></div>
<div id="crop-overlay"><div id="crop-shade-t"></div><div id="crop-shade-b"></div><div id="crop-shade-l"></div><div
  id="crop-shade-r"></div><div id="crop-sel"></div><div id="crop-hint"></div></div>
<div id="panels">
  <div id="term-panel"></div>
  <div id="ico-bg"></div>
  <button id="term-jump" onmousedown="event.preventDefault()" onclick="jumpBottom()">&#x2193; Jump to latest</button>
  __SEARCHBAR__
</div>
<script>
const EZI_INIT = __INIT__;
const ansi = new AnsiUp();
const term = document.getElementById('term-panel');
let showingUI = false;
window.__eziZoomKind = 'detached';
__EMU__
function applyTheme(theme, vars) {
  var root = document.documentElement;
  root.classList.remove('theme-pixaroma', 'theme-light', 'theme-comfyui', 'theme-aurora');
  if (theme === 'pixaroma') root.classList.add('theme-pixaroma');
  else if (theme === 'aurora') root.classList.add('theme-aurora');
  else if (theme === 'light') root.classList.add('theme-light');
  else if (theme === 'comfyui') {
    if (!vars && typeof eziSettings !== 'undefined') vars = eziSettings.comfyThemeVars;
    var cssBody = Object.entries(vars || {}).map(function(kv) { return kv[0] + ':' + kv[1]; }).join(';');
    var el = document.getElementById('ezi-comfyui-theme-style');
    if (!el) { el = document.createElement('style'); el.id = 'ezi-comfyui-theme-style'; document.head.appendChild(el); }
    el.textContent = ':root.theme-comfyui{' + cssBody + '}';
    root.classList.add('theme-comfyui');
  }
}
applyTheme(EZI_INIT.theme, EZI_INIT.comfyThemeVars);
function attachConsole() { try { pywebview.api.attach_console(); } catch (e) {} }
function send_columns() {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  ctx.font = (window.__eziTermFont || 12) + 'px Consolas, "Courier New", monospace';
  const charW = ctx.measureText('M').width || 7.2;
  const style = window.getComputedStyle(term);
  const padL = parseFloat(style.paddingLeft) || 0;
  const padR = parseFloat(style.paddingRight) || 0;
  const scrollbarW = Math.max(term.offsetWidth - term.clientWidth, 17);
  const usable = term.clientWidth - padL - padR - scrollbarW - 2;
  const cols = Math.floor(usable / charW);
  try { if (cols > 0) pywebview.api.set_columns(cols); } catch (e) {}
}
window.addEventListener('resize', send_columns);
(function waitForApi() {
  if (typeof pywebview !== 'undefined' && pywebview.api && pywebview.api.set_columns) send_columns();
  else setTimeout(waitForApi, 50);
})();
const CAP_CANCEL_BTN = '<button id="crop-cancel-btn" class="btn-danger" style="margin-left:8px;padding:0 10px;height:22px;font-family:inherit;' +
  'font-size:11px;font-weight:bold;border-radius:4px;cursor:pointer;pointer-events:auto;display:inline-flex;' +
  'align-items:center;gap:4px;box-sizing:border-box;">&#x2715; Cancel</button>';
const OVERLAY_TOP = 32;
const overlay = document.getElementById('crop-overlay');
const cropSel = document.getElementById('crop-sel');
const shadeT = document.getElementById('crop-shade-t');
const shadeB = document.getElementById('crop-shade-b');
const shadeL = document.getElementById('crop-shade-l');
const shadeR = document.getElementById('crop-shade-r');
let cropStart = null;
let _cropMode = 'screenshot';
let _cropPending = false;
let _recFps = EZI_INIT.recFps || 30;
let _easyLoaded = false;
let _easyLoading = false;
function openEasyMenu() {
  closeAllDropdowns();
  if (_easyLoading) return;
  var run = function() {
    pywebview.api.get_ui_settings().then(function(s) {
      try { if (s) Object.assign(eziSettings, JSON.parse(s)); } catch (e) {}
      show_settings();
    });
  };
  if (_easyLoaded) { run(); return; }
  _easyLoading = true;
  pywebview.api.get_easy_menu_js().then(function(js) {
    _easyLoading = false;
    if (!js) return;
    var sc = document.createElement('script');
    sc.textContent = js;
    document.head.appendChild(sc);
    _easyLoaded = true;
    run();
  }).catch(function() { _easyLoading = false; });
}
function closeAllDropdowns() {
  ['out-dropdown', 'scr-dropdown'].forEach(function(id) {
    var el = document.getElementById(id);
    if (el) el.classList.remove('open');
  });
}
function toggleOutDropdown(e) {
  e.stopPropagation();
  var dd = document.getElementById('out-dropdown');
  document.getElementById('scr-dropdown').classList.remove('open');
  dd.classList.toggle('open');
}
function toggleScrDropdown(e) {
  e.stopPropagation();
  var sd = document.getElementById('scr-dropdown');
  document.getElementById('out-dropdown').classList.remove('open');
  sd.classList.toggle('open');
}
function openOutputFolder() {
  closeAllDropdowns();
  try { pywebview.api.open_output_folder(); } catch (e) {}
}
function openSubFolder(type) {
  closeAllDropdowns();
  try { pywebview.api.open_sub_folder(type); } catch (e) {}
}
document.addEventListener('click', closeAllDropdowns);
(function waitForFolders() {
  if (typeof pywebview !== 'undefined' && pywebview.api && pywebview.api.check_output_folder) {
    pywebview.api.check_output_folder().then(function(path) {
      if (path) document.getElementById('out-btn-wrap').classList.add('visible');
    });
  } else setTimeout(waitForFolders, 100);
})();
function _fpsPickerHTML() {
  var btnStyle = 'margin-left:3px;padding:0 7px;height:22px;font-family:inherit;font-size:11px;font-weight:bold;border-radius:4px;' +
    'cursor:pointer;pointer-events:auto;display:inline-flex;align-items:center;border:1px solid #ff8888;background:#6e2020;' +
    'color:#ff8888;box-sizing:border-box;';
  return ' &nbsp;<span style="font-size:11px;opacity:0.85;">FPS:</span>'
    + [15, 30, 60].map(function(f) {
        return '<button onclick="event.stopPropagation();_recFps=' + f + ';_updateFpsBtns(true);" id="fps-btn-' + f + '" style="' + btnStyle + '">' + f + '</button>';
      }).join('')
    + ' &nbsp;';
}
function _updateFpsBtns(save) {
  [15, 30, 60].forEach(function(f) {
    var b = document.getElementById('fps-btn-' + f);
    if (!b) return;
    b.style.background = (_recFps === f) ? '#ff4444' : '#6e2020';
    b.style.color = (_recFps === f) ? '#fff' : '#ff8888';
  });
  if (save) { try { pywebview.api.save_ui_settings(JSON.stringify({ recFps: _recFps })); } catch (e) {} }
}
function _reattachCropCancelBtn() {
  var btn = document.getElementById('crop-cancel-btn');
  if (!btn) return;
  btn.addEventListener('mousedown', function(e) { e.stopPropagation(); e.preventDefault(); });
  btn.addEventListener('click', function(e) { e.stopPropagation(); e.preventDefault(); cropCancel(); });
  btn.addEventListener('mouseup', function(e) { e.stopPropagation(); e.preventDefault(); });
}
function startCrop(mode) {
  _cropMode = mode || 'screenshot';
  closeAllDropdowns();
  var hint = document.getElementById('crop-hint');
  if (_cropMode === 'video') {
    hint.innerHTML = '\uD83C\uDF9E\uFE0F Record: Click for full window &nbsp;|&nbsp; Drag to select area' + _fpsPickerHTML() + CAP_CANCEL_BTN.replace('margin-left:8px', 'margin-left:4px');
    hint.style.color = '#ff8888';
    _updateFpsBtns(false);
  } else {
    hint.innerHTML = 'Click for full window &nbsp;|&nbsp; Drag to select area &nbsp;' + CAP_CANCEL_BTN;
    hint.style.color = '';
  }
  _reattachCropCancelBtn();
  overlay.classList.add('active');
  cropSel.style.cssText = 'left:0;top:0;width:0;height:0;';
  shadeT.style.cssText = 'top:0;left:0;right:0;bottom:0;';
  shadeB.style.cssText = shadeL.style.cssText = shadeR.style.cssText = 'display:none';
  hint.style.display = '';
}
function cropCancel() {
  cropStart = null;
  overlay.classList.remove('active');
}
function screenshotFull(fullW, fullH) {
  if (_cropPending) return;
  _cropPending = true;
  var w = fullW || window.innerWidth;
  var h = fullH || window.innerHeight;
  if (_cropMode === 'video') {
    pywebview.api.console_start_recording(0, 0, w, h, _recFps);
  } else {
    pywebview.api.console_screenshot(0, 0, w, h).finally(function() { _cropPending = false; });
  }
}
function showRecIndicator() {
  _cropPending = false;
  var recIndicator = document.getElementById('rec-indicator');
  recIndicator.style.cssText = 'display:inline-flex;align-items:center;gap:6px;';
  recIndicator.innerHTML = '<span style="width:8px;height:8px;border-radius:50%;background:#ff4444;display:inline-block;' +
    'animation:rec-blink 1s ease-in-out infinite;flex-shrink:0;' +
    '"></span><button onclick="stopRecording()" style="padding:3px 10px;font-family:inherit;font-size:11px;' +
    'font-weight:bold;border:1px solid #ff4444;border-radius:4px;background:#6e2020;color:#ff8888;cursor:pointer;' +
    'animation:rec-blink 1s ease-in-out infinite;line-height:1;letter-spacing:0.5px;">&#x23F9; Stop REC</button>';
}
function stopRecording() {
  _cropPending = false;
  try { pywebview.api.stop_recording(); } catch (e) {}
  var recIndicator = document.getElementById('rec-indicator');
  recIndicator.style.display = 'none';
  recIndicator.innerHTML = '';
}
function updateShades(x, y, w, h) {
  shadeT.style.cssText = 'top:0;left:0;right:0;height:' + y + 'px;';
  shadeB.style.cssText = 'top:' + (y + h) + 'px;left:0;right:0;bottom:0;';
  shadeL.style.cssText = 'top:' + y + 'px;left:0;width:' + x + 'px;height:' + h + 'px;';
  shadeR.style.cssText = 'top:' + y + 'px;left:' + (x + w) + 'px;right:0;height:' + h + 'px;';
}
function _cropPt(e) {
  return {
    x: Math.min(Math.max(e.clientX, 0), window.innerWidth),
    y: Math.min(Math.max(e.clientY, OVERLAY_TOP), window.innerHeight)
  };
}
overlay.addEventListener('pointerdown', function(e) {
  if (e.target !== overlay || e.button !== 0) return;
  cropStart = _cropPt(e);
  try { overlay.setPointerCapture(e.pointerId); } catch (_) {}
  shadeT.style.cssText = shadeB.style.cssText = shadeL.style.cssText = shadeR.style.cssText = '';
  document.getElementById('crop-hint').style.display = 'none';
});
overlay.addEventListener('pointermove', function(e) {
  if (!cropStart) return;
  var p = _cropPt(e);
  var x = Math.min(p.x, cropStart.x);
  var y = Math.min(p.y, cropStart.y);
  var w = Math.abs(p.x - cropStart.x);
  var h = Math.abs(p.y - cropStart.y);
  cropSel.style.cssText = 'left:' + x + 'px;top:' + (y - OVERLAY_TOP) + 'px;width:' + w + 'px;height:' + h + 'px;';
  updateShades(x, y - OVERLAY_TOP, w, h);
});
overlay.addEventListener('pointerup', function(e) {
  if (!cropStart) return;
  try { overlay.releasePointerCapture(e.pointerId); } catch (_) {}
  var p = _cropPt(e);
  var x = Math.min(p.x, cropStart.x);
  var y = Math.min(p.y, cropStart.y);
  var w = Math.abs(p.x - cropStart.x);
  var h = Math.abs(p.y - cropStart.y);
  cropStart = null;
  var fullW = window.innerWidth, fullH = window.innerHeight;
  overlay.classList.remove('active');
  if (_cropPending) return;
  _cropPending = true;
  if (w > 5 && h > 5) {
    if (_cropMode === 'video') {
      pywebview.api.console_start_recording(Math.round(x), Math.round(y), Math.round(w), Math.round(h), _recFps);
    } else {
      pywebview.api.console_screenshot(Math.round(x), Math.round(y), Math.round(w), Math.round(h)).finally(function() { _cropPending = false; });
    }
  } else {
    _cropPending = false;
    screenshotFull(fullW, fullH);
  }
});
document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') cropCancel();
});
eziLazyTip(document.getElementById('attach-btn'));
eziLazyTip(document.getElementById('menu-btn'));
window.__eziSelMenuSync(EZI_INIT.selPop || {});
window.__eziSetTermFont(EZI_INIT.zoom || 12);
applyTooltips(EZI_INIT.tooltips !== false);
term.tabIndex = -1;
function _focusTerm() {
  var a = document.activeElement;
  if (!a || a === document.body || a.id === 'attach-btn') {
    try { if (a && a.blur) a.blur(); term.focus({ preventScroll: true }); } catch (e) {}
  }
}
window.addEventListener('focus', _focusTerm);
document.addEventListener('visibilitychange', _focusTerm);
_focusTerm();
</script>
</body>
</html>
"""

def _ezi_valid_lang(value):
    return isinstance(value, str) and re.fullmatch(r"[A-Za-z]{2,3}(-[A-Za-z0-9]{2,8})?", value) is not None


def _get_console_html(settings=None):
    html = _get_shell_html(settings)
    head = html[:html.index('</head>')]
    head = re.sub(r'<title>.*?</title>', '<title>ComfyUI Console</title>', head, count=1, flags=re.S)
    a = html.index('const T = {')
    b = html.index('\n})();', html.index('window.applyTooltips = function')) + len('\n})();')
    emu = html[a:b]
    theme = (settings or {}).get("theme", "aurora")
    try:
        theme_vars = _get_comfy_theme_css_vars() if theme == "comfyui" else {}
    except Exception:
        theme_vars = {}
    init = json.dumps({"theme": theme, "comfyThemeVars": theme_vars,
                       "tooltips": bool((settings or {}).get("show_tooltips", True)),
                       "selPop": {"copy": bool((settings or {}).get("sel_pop_copy", True)),
                                  "google": bool((settings or {}).get("sel_pop_google", True)),
                                  "chatgpt": bool((settings or {}).get("sel_pop_chatgpt", True)),
                                  "claude": bool((settings or {}).get("sel_pop_claude", False)),
                                  "save": bool((settings or {}).get("sel_pop_save", True)),
                                  "lang": str((settings or {}).get("sel_ai_lang", "en") or "en")},
                       "recFps": int((settings or {}).get("rec_fps", 30)),
                       "zoom": int((settings or {}).get("adv_console_zoom_detached", (settings or {}).get("console_zoom_detached", 12))
                                   if ADV_CONSOLE else (settings or {}).get("console_zoom_detached", 12))
                       }).replace('</', '<\\/')
    sb_a = html.index('<div id="term-search"')
    sb_b = html.index('<!--/term-search-->', sb_a)
    searchbar = html[sb_a:sb_b]
    body = (_CONSOLE_PAGE_BODY.replace('__ICON__', _CONSOLE_ICON_SVG)
                              .replace('__SEARCHBAR__', searchbar)
                              .replace('__INIT__', init)
                              .replace('__EMU__', emu))
    adv_css = '<style>#attach-btn{display:none!important}</style>' if ADV_CONSOLE else ''
    return head + adv_css + '</head>\n' + body

async def make_proxy_app(comfy_port_holder, storage_holder, settings_holder=None, api_holder=None):
    async def handle_shell(request):
        s = settings_holder[0] if settings_holder else {}
        return web.Response(text=_get_shell_html(s), content_type='text/html', charset='utf-8')

    async def handle_console(request):
        s = settings_holder[0] if settings_holder else {}
        return web.Response(text=_get_console_html(s), content_type='text/html', charset='utf-8')
    
    async def handle_favicon(request):
        if os.path.isfile(ICO_PATH):
            try:
                with open(ICO_PATH, 'rb') as f:
                    data = f.read()
                return web.Response(body=data, content_type='image/x-icon',
                                    headers={'Cache-Control': 'public, max-age=86400'})
            except Exception:
                pass
        return web.Response(status=404)

    async def handle_any(request):
        comfy_port = comfy_port_holder[0]
        comfy_host = f"127.0.0.1:{comfy_port}"
        up_scheme  = _COMFY_SCHEME[0]
        up_ws      = "wss" if up_scheme == "https" else "ws"
        up_ssl     = _comfy_ssl()
        path_qs    = request.path_qs
        api_ref = api_holder[0] if api_holder else None
        
        if (request.headers.get('Upgrade', '').lower() == 'websocket'):
            ws_server = web.WebSocketResponse(max_msg_size=134217728); await ws_server.prepare(request)
            try:
                async with ClientSession() as session:
                    async with session.ws_connect(f"{up_ws}://{comfy_host}{path_qs}", max_msg_size=134217728, ssl=up_ssl) as ws_client:
                        async def fwd(src, dst):
                            try:
                                async for msg in src:
                                    try:
                                        if msg.type == WSMsgType.TEXT:
                                            if dst is ws_server:
                                                try:
                                                    d = json.loads(msg.data)
                                                    t = d.get('type')
                                                    if t == 'progress':
                                                        pd = d.get('data', {})
                                                        val = pd.get('value', 0)
                                                        mx  = pd.get('max', 1)
                                                        if mx > 0:
                                                            api_ref._tb_set(val, mx, 2)
                                                    elif t in ('execution_success', 'execution_error', 'execution_interrupted'):
                                                        api_ref._tb_set(0, 1, 0)
                                                except Exception:
                                                    pass
                                            await dst.send_str(msg.data)
                                        elif msg.type == WSMsgType.BINARY:
                                            await dst.send_bytes(msg.data)
                                        elif msg.type in (WSMsgType.CLOSE, WSMsgType.ERROR, WSMsgType.CLOSING):
                                            break
                                    except (ConnectionResetError, OSError, asyncio.CancelledError):
                                        break
                                    except Exception:
                                        break
                            except (ConnectionResetError, OSError, asyncio.CancelledError):
                                pass
                            except Exception:
                                pass
                            if src is ws_client and not ws_server.closed and api_ref is not None:
                                api_ref._ws_lost.set()
                        await asyncio.gather(fwd(ws_server, ws_client), fwd(ws_client, ws_server), return_exceptions=True)
            except Exception:
                pass
            if not ws_server.closed:
                await ws_server.close()
            return ws_server

        try:
            async with ClientSession(timeout=ClientTimeout(total=120)) as session:
                fwd_hd = {k:v for k,v in request.headers.items() if k.lower() not in ('content-encoding','transfer-encoding')}
                fwd_hd.update({'Host': comfy_host, 'Origin': f"{up_scheme}://{comfy_host}"})
                async with session.request(request.method, f"{up_scheme}://{comfy_host}{path_qs}", headers=fwd_hd, data=await request.read(), allow_redirects=False, ssl=up_ssl) as resp:
                    body = await resp.read()
                    resp_hd = {k: v for k, v in resp.headers.items() if k.lower() not in ('content-encoding', 'transfer-encoding', 'content-length')}
                    
                    is_ezi_webview = EZI_UA_TAG in request.headers.get('User-Agent', '')
                    if is_ezi_webview and request.path == '/' and 'text/html' in resp.headers.get('Content-Type', '').lower():
                        html = body.decode('utf-8', errors='replace')

                        stored_data = storage_holder[0]
                        try:
                            data_str = (json.dumps(stored_data).replace('</', '<\\/')
                                        if stored_data else 'null')
                            inject_js = f"""<script>
    (function() {{
        window._eziPostToShell = function(msg) {{
            try {{
                if (window.chrome && window.chrome.webview) {{
                    window.chrome.webview.postMessage(msg);
                    return;
                }}
            }} catch(e) {{}}
            try {{ window.parent.postMessage(msg, '*'); }} catch(e) {{}}
        }};

        try {{
            if (window.chrome && window.chrome.webview) {{
                window.chrome.webview.addEventListener('message', function(ev) {{
                    try {{ window.postMessage(ev.data, '*'); }} catch(e) {{}}
                }});
            }}
        }} catch(e) {{}}

        try {{
            var data = {data_str};
            if (data && data.ls && Object.keys(data.ls).length && !sessionStorage.getItem('__ezi_restored') && localStorage.length === 0) {{
                Object.keys(data.ls).forEach(function(k) {{ try {{ localStorage.setItem(k, data.ls[k]); }} catch(e) {{}} }});
            }}
            sessionStorage.setItem('__ezi_restored', '1');
        }} catch(e) {{}}

        window.__eziFlushStorageNow = function() {{
            try {{
                var out = {{}};
                var ls = window.localStorage;
                for (var i = 0; i < ls.length; i++) {{
                    var k = ls.key(i);
                    if (k) out[k] = ls.getItem(k);
                }}
                window._eziPostToShell({{
                    type: 'ezi_storage_save',
                    settled: performance.now() > 5000,
                    ls: out
                }});
            }} catch(e) {{
                window._eziPostToShell({{ type: 'ezi_storage_save' }});
            }}
        }};

        var _origConsoleError = console.error;
        console.error = function() {{
            var args = Array.from(arguments);
            var errStr = args.join(' ');
            if (errStr.includes('Firebase: Error (auth/popup') ||
                errStr.includes('Firebase: Error (auth/cancelled-popup-request')) {{
                return;
            }}
            return _origConsoleError.apply(console, args);
        }};

        window.addEventListener('unhandledrejection', function(event) {{
            if (event.reason && event.reason.code && event.reason.code.startsWith('auth/')) {{
                event.preventDefault();
            }}
        }});

        function _eziSendBlobToShell(myBlob, filename) {{
            var isText = /^(text\\/|application\\/json|application\\/xml|image\\/svg\\+xml)/.test(myBlob.type) ||
                         /\\.(json|txt|ya?ml|csv|svg)$/i.test(filename);
            var reader = new FileReader();
            reader.onload = function() {{
                window._eziPostToShell({{
                    type: 'ezi_save_blob',
                    filename: filename,
                    content: reader.result,
                    isBase64: !isText
                }});
            }};
            if (isText) {{
                reader.readAsText(myBlob);
            }} else {{
                reader.readAsDataURL(myBlob);
            }}
        }}

        function _eziFindModelDir(href, filename) {{
            try {{
                var app = window.app;
                if (!app || !app.graph) return '';
                var strip = function(u) {{ return String(u || '').split('?')[0].split('#')[0]; }};
                var hrefBase = strip(href);
                var seen = [];
                var match = function(models) {{
                    if (!Array.isArray(models)) return '';
                    for (var i = 0; i < models.length; i++) {{
                        var m = models[i];
                        if (!m || !m.directory) continue;
                        if ((m.url && strip(m.url) === hrefBase) || (m.name && m.name === filename)) return String(m.directory);
                    }}
                    return '';
                }};
                var scan = function(graph) {{
                    if (!graph || seen.indexOf(graph) !== -1) return '';
                    seen.push(graph);
                    var nodes = graph._nodes || graph.nodes || [];
                    for (var i = 0; i < nodes.length; i++) {{
                        var n = nodes[i];
                        var r = match(n && n.properties && n.properties.models);
                        if (r) return r;
                        if (n && n.subgraph) {{
                            r = scan(n.subgraph);
                            if (r) return r;
                        }}
                    }}
                    if (graph.subgraphs && typeof graph.subgraphs.values === 'function') {{
                        var it = Array.from(graph.subgraphs.values());
                        for (var j = 0; j < it.length; j++) {{
                            var r2 = scan(it[j]);
                            if (r2) return r2;
                        }}
                    }}
                    return '';
                }};
                var found = scan(app.graph);
                if (found) return found;
                if (typeof app.graph.serialize === 'function') {{
                    var ser = app.graph.serialize();
                    found = match(ser && ser.models) || match(ser && ser.extra && ser.extra.models);
                    if (found) return found;
                }}
            }} catch(e) {{}}
            return '';
        }}

        function _eziHandleDownloadAnchor(a) {{
            try {{
                var filename = a.getAttribute('download') || 'download';
                var href = a.href;

                if (href.indexOf('blob:') === 0) {{
                    var xhr = new XMLHttpRequest();
                    xhr.open('GET', href, true);
                    xhr.responseType = 'blob';
                    xhr.onload = function(e) {{
                        if (this.status == 200) _eziSendBlobToShell(this.response, filename);
                    }};
                    xhr.send();
                    return;
                }}

                if (href.indexOf('data:') === 0) {{
                    fetch(href)
                        .then(function(r) {{ return r.blob(); }})
                        .then(function(b) {{ _eziSendBlobToShell(b, filename); }})
                        .catch(function(e) {{ console.error("Download interceptor error:", e); }});
                    return;
                }}

                var urlObj = new URL(href, window.location.origin);
                var sendUrl = urlObj.origin === window.location.origin ? urlObj.pathname + urlObj.search : urlObj.href;
                window._eziPostToShell({{ type: 'ezi_save_image', url: sendUrl, filename: filename, directory: _eziFindModelDir(urlObj.href, filename) }});
            }} catch(e) {{ console.error("Download interceptor error:", e); }}
        }}

        document.addEventListener('click', function(ev) {{
            var a = ev.target && ev.target.closest ? ev.target.closest('a[download]') : null;
            if (!a || !a.href) return;
            ev.preventDefault();
            ev.stopPropagation();
            _eziHandleDownloadAnchor(a);
        }}, true);

        try {{
            var _eziOrigAnchorClick = HTMLAnchorElement.prototype.click;
            HTMLAnchorElement.prototype.click = function() {{
                try {{
                    if (!this.isConnected && this.hasAttribute('download') && this.href) {{
                        _eziHandleDownloadAnchor(this);
                        return;
                    }}
                }} catch(e) {{}}
                return _eziOrigAnchorClick.apply(this, arguments);
            }};
        }} catch(e) {{}}
    }})();
    </script>"""
                            idx = html.lower().find('<head>')
                            if idx != -1:
                                html = html[:idx+6] + inject_js + html[idx+6:]
                            else:
                                html = inject_js + html
                        except Exception:
                            _log_error('handle_any')

                        cmenu_js = """<script>
    (function() {
        function initCMenu() {
            if (document.getElementById('ezi-cmenu')) return;
            var m = document.createElement('div');
            m.id = 'ezi-cmenu';
            m.style.cssText = 'position:fixed;background:var(--comfy-menu-bg, #1e1e1e);border:1px solid var(--border-color, #444);' +
              'border-radius:6px;padding:4px 0;z-index:9999999;display:none;font-size:12px;' +
              'color:var(--input-text, #cccccc);box-shadow:0 6px 16px rgba(0,0,0,0.3);' +
              'font-family:Segoe UI, Tahoma, Geneva, Verdana, sans-serif;min-width:220px;';
            document.body.appendChild(m);

            function addItem(txt, shortcut, fn, addSeparator) {
                if (addSeparator) {
                    var sep = document.createElement('div');
                    sep.style.cssText = 'height:1px;background-color:var(--border-color, #444);margin:4px 0;';
                    m.appendChild(sep);
                }
                var i = document.createElement('div');
                var textSpan = document.createElement('span');
                textSpan.innerText = txt;
                var shortcutSpan = document.createElement('span');
                shortcutSpan.innerText = shortcut;
                shortcutSpan.style.cssText = 'color:var(--descrip-text, #888);font-size:11px;float:right;margin-left:20px;';
                i.appendChild(textSpan);
                i.appendChild(shortcutSpan);
                i.style.cssText = 'padding:6px 24px 6px 12px;cursor:pointer;display:flex;justify-content:space-between;align-items:center;clear:both;';
                
                i.onmouseover = function() { 
                    this.style.background='var(--comfy-menu-secondary-bg, #2a2a2a)'; 
                    this.style.color='var(--fg-color, #ffffff)'; 
                }; 
                i.onmouseout = function() { 
                    this.style.background=''; 
                    this.style.color='var(--input-text, #cccccc)'; 
                };
                i.onclick = function(e) { e.stopPropagation(); fn(); m.style.display='none'; };
                m.appendChild(i);
            }

            addItem('Undo', 'Ctrl+Z', function() {
                var el = m.tgt; el.focus(); document.execCommand('undo');
            });
            
            addItem('Redo', 'Ctrl+Y', function() {
                var el = m.tgt; el.focus(); document.execCommand('redo');
            }, true);

            addItem('Cut', 'Ctrl+X', function() {
                var el = m.tgt; 
                window._eziPostToShell({ type: 'ezi_clipboard_request', action: 'cut', text: el.value.substring(el.selectionStart, el.selectionEnd) });
                el.focus();
                document.execCommand('delete');
            }, true);

            addItem('Copy', 'Ctrl+C', function() {
                var el = m.tgt;
                window._eziPostToShell({ type: 'ezi_clipboard_request', action: 'copy', text: el.value.substring(el.selectionStart, el.selectionEnd) });
            });

            addItem('Paste', 'Ctrl+V', function() {
                var el = m.tgt;
                el.focus();
                window._eziPostToShell({ type: 'ezi_clipboard_request', action: 'paste' });
                window.addEventListener('message', function handler(ev) {
                    if (ev.data && ev.data.type === 'ezi_clipboard_response') {
                        window.removeEventListener('message', handler);
                        document.execCommand('insertText', false, ev.data.text);
                    }
                });
            });

            addItem('Delete', 'Del', function() {
                var el = m.tgt; el.focus(); document.execCommand('delete');
            }, true);

            addItem('Select All', 'Ctrl+A', function() {
                var el = m.tgt; el.focus(); el.select();
            });

            document.addEventListener('click', function() { m.style.display='none'; });
            document.addEventListener('contextmenu', function(e) {
                var t = e.target;
                if (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable) {
                    e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
                    t.focus(); m.tgt = t;
                    m.style.left = e.clientX + 'px'; m.style.top = e.clientY + 'px'; m.style.display = 'block';
                } else { m.style.display='none'; }
            }, true);
        }
        if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', initCMenu); } else { initCMenu(); }
    })();
    </script>
    <script>
    (function() {
        var seen = new WeakSet();
        function scheduleKill(el) {
            if (seen.has(el)) return;
            seen.add(el);
            setTimeout(function() {
                if (!document.body.contains(el)) return;
                el.remove();
            }, 8000);
        }
        function scan(node) {
            if (!node || node.nodeType !== 1) return;
            if (node.matches && node.matches('.p-tooltip')) scheduleKill(node);
            if (node.querySelectorAll) {
                node.querySelectorAll('.p-tooltip').forEach(scheduleKill);
            }
        }
        function initTooltipFix() {
            document.querySelectorAll('.p-tooltip').forEach(scheduleKill);
            var obs = new MutationObserver(function(muts) {
                muts.forEach(function(m) {
                    m.addedNodes.forEach(scan);
                });
            });
            obs.observe(document.body, { childList: true, subtree: true });
        }
        if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', initTooltipFix); } else { initTooltipFix(); }
    })();
    </script>"""
                        tabs_css = """<style id="ezi-chrome-tabs">
    .workflow-tabs .p-togglebutton {
        border-top-left-radius: 10px !important;
        border-top-right-radius: 10px !important;
        border-bottom-left-radius: 0 !important;
        border-bottom-right-radius: 0 !important;
    }
    </style>"""
                        html = html.replace('</head>', tabs_css + '</head>', 1)
                        html = html.replace('</body>', cmenu_js + '</body>')

                        body = html.encode('utf-8')

                        _strip = {'etag', 'last-modified', 'cache-control', 'expires', 'age'}
                        resp_hd = {k: v for k, v in resp_hd.items() if k.lower() not in _strip}
                        resp_hd['Cache-Control'] = 'no-store, no-cache, must-revalidate'
                        resp_hd['Pragma'] = 'no-cache'
                        resp_hd['Expires'] = '0'

                    return web.Response(status=resp.status, headers=resp_hd, body=body)
        except: return web.Response(status=502)

    app = web.Application(client_max_size=1024*1024*1024)
    app.router.add_get('/__shell__', handle_shell)
    app.router.add_get('/__console__', handle_console)
    app.router.add_get('/favicon.ico', handle_favicon)
    app.router.add_route('*', '/{path_info:.*}', handle_any)
    return app

def _is_rect_on_active_monitor(left, top, right, bottom):
    try:
        import ctypes.wintypes as wt
        user32 = ctypes.windll.user32

        class MONITORINFO(ctypes.Structure):
            _fields_ = [("cbSize",    wt.DWORD),
                        ("rcMonitor", wt.RECT),
                        ("rcWork",    wt.RECT),
                        ("dwFlags",   wt.DWORD)]

        monitors = []
        MonitorEnumProc = ctypes.WINFUNCTYPE(
            ctypes.c_bool,
            ctypes.c_void_p, ctypes.c_void_p,
            ctypes.POINTER(wt.RECT), ctypes.c_double
        )

        def _cb(hmon, hdc, lprect, lparam):
            info = MONITORINFO()
            info.cbSize = ctypes.sizeof(MONITORINFO)
            if user32.GetMonitorInfoW(hmon, ctypes.byref(info)):
                r = info.rcWork
                monitors.append((r.left, r.top, r.right, r.bottom))
            return True

        user32.EnumDisplayMonitors(None, None, MonitorEnumProc(_cb), 0)

        MIN_W, MIN_H = 100, 50
        for ml, mt, mr, mb in monitors:
            ol = max(left, ml)
            ot = max(top,  mt)
            or_ = min(right, mr)
            ob  = min(bottom, mb)
            if (or_ - ol) >= MIN_W and (ob - ot) >= MIN_H:
                return True
        return False
    except Exception:
        return True


_MP_LOCK = threading.Lock()
_MP_KNOWN_DIRS = frozenset((
    'checkpoints', 'diffusion_models', 'unet', 'loras', 'vae', 'text_encoders', 'clip',
    'controlnet', 'upscale_models', 'latent_upscale_models', 'embeddings', 'clip_vision',
    'vae_approx', 'hypernetworks', 'gligen', 'style_models', 'configs', 'diffusers',
    'photomaker', 'classifiers', 'model_patches', 'audio_encoders',
))
_MP_SKIP_DIRS = frozenset(('system volume information', 'recycler', 'lost+found', 'base_path', 'is_default'))
_MP_MARK_RE = re.compile(r'^# --- (.+?) ---\s*$')
_MP_KEY_RE = re.compile(r'^([A-Za-z0-9_\-]+)\s*:\s*(#.*)?$')
_MP_ENTRY_RE = re.compile(r"^\s+(?:'((?:[^']|'')*)'|([^\s:#'][^:]*?))\s*:\s*\S")
_MP_HEADER = ('# Powered by Easy-Models-Linker, developed by Ivo', '# Pixaroma Community Edition')


def _mp_yaml_path():
    return os.path.join(ROOT_DIR, 'ComfyUI', 'extra_model_paths.yaml')


def _mp_norm(p):
    return os.path.normcase(os.path.normpath(p))


def _mp_read_text(path):
    try:
        with open(path, 'r', encoding='utf-8-sig', errors='replace') as f:
            return f.read()
    except OSError:
        return None


def _mp_subdirs(root):
    names = []
    try:
        with os.scandir(root) as it:
            for e in it:
                try:
                    if not e.is_dir():
                        continue
                    n = e.name
                    if n.startswith('.') or n.startswith('$') or n.lower() in _MP_SKIP_DIRS:
                        continue
                    if getattr(e.stat(), 'st_file_attributes', 0) & 0x6:
                        continue
                except OSError:
                    continue
                names.append(n)
    except OSError:
        return None
    names.sort(key=lambda s: s.lower())
    return names


def _mp_known_count(p):
    subs = _mp_subdirs(p)
    if not subs:
        return 0
    return sum(1 for s in subs if s.lower() in _MP_KNOWN_DIRS)


def _mp_parse(text):
    lines = text.replace('\r\n', '\n').replace('\r', '\n').split('\n')
    if lines and lines[-1] == '':
        lines.pop()
    raw = []
    blocks = []
    n = len(lines)
    i = 0
    while i < n:
        m = _MP_MARK_RE.match(lines[i])
        if m and i + 1 < n and _MP_KEY_RE.match(lines[i + 1]):
            j = i + 2
            while j < n and (lines[j][:1] in (' ', '\t') or lines[j].strip() == ''):
                j += 1
            base_line = None
            entries = []
            is_default = False
            keys = set()
            for ln in lines[i + 2:j]:
                s = ln.strip()
                if not s or s.startswith('#'):
                    continue
                if re.match(r'(?i)^base_path\s*:', s):
                    base_line = ln.rstrip()
                elif re.match(r'(?i)^is_default\s*:\s*true', s):
                    is_default = True
                elif re.match(r'(?i)^is_default\s*:', s):
                    continue
                else:
                    entries.append(ln.rstrip())
                    km = _MP_ENTRY_RE.match(ln)
                    if km:
                        k = km.group(1).replace("''", "'") if km.group(1) is not None else km.group(2)
                        keys.add(k.strip().lower())
            blocks.append({'root': m.group(1), 'default': is_default, 'keys': keys,
                           'keep': (base_line, entries)})
            i = j
            continue
        raw.append(lines[i])
        i += 1
    blocks.sort(key=lambda b: 0 if b['default'] else 1)
    return raw, blocks


def _mp_q(s):
    return s.replace("'", "''")


def _mp_block_lines(root, key, is_default, subs=None, keep=None):
    rootn = os.path.normpath(root)
    name = os.path.basename(rootn)
    if name:
        parent = os.path.dirname(rootn)
        rel = name + '\\'
    else:
        parent = rootn
        rel = ''
    out = ['# --- %s ---' % root, key + ':']
    if keep is not None and keep[0]:
        out.append(keep[0])
    else:
        out.append("    base_path: '%s'" % _mp_q(parent))
    if is_default:
        out.append('    is_default: true')
    out.append('')
    if keep is not None:
        out.extend(keep[1])
    else:
        for s in subs:
            k = s.lower()
            if not re.fullmatch(r'[A-Za-z0-9_][A-Za-z0-9_.\-]*', k):
                k = "'" + _mp_q(k) + "'"
            out.append("    %s: '%s%s\\'" % (k, _mp_q(rel), _mp_q(s)))
    out.append('')
    return out


def _mp_section_keys(raw, count):
    used = set()
    for ln in raw:
        m = _MP_KEY_RE.match(ln)
        if m:
            used.add(m.group(1).lower())
    keys = []
    n = 0
    while len(keys) < count:
        n += 1
        k = 'comfyui' if n == 1 else 'comfyui%d' % n
        if k not in used:
            keys.append(k)
    return keys


def _mp_render(raw, specs):
    raw = list(raw)
    while raw and raw[-1].strip() == '':
        raw.pop()
    meaningful = any(l.strip() and not l.lstrip().startswith('#') for l in raw)
    if not specs and not meaningful:
        return ''
    out = []
    if raw:
        out.extend(raw)
        if specs:
            out.append('')
    elif specs:
        out.extend(_MP_HEADER)
        out.append('')
    keys = _mp_section_keys(raw, len(specs))
    for idx, sp in enumerate(specs):
        out.extend(_mp_block_lines(sp['root'], keys[idx], idx == 0, sp.get('subs'), sp.get('keep')))
    return '\n'.join(out) + '\n'


def _mp_backup(path):
    import shutil
    d = os.path.dirname(path)
    stamp = time.strftime('%Y-%m-%d_%H-%M-%S')
    shutil.copy2(path, os.path.join(d, 'extra_model_paths_Backup_%s.yaml' % stamp))
    olds = sorted((f for f in os.listdir(d)
                   if f.startswith('extra_model_paths_Backup_') and f.endswith('.yaml')), reverse=True)
    for f in olds[5:]:
        try:
            os.remove(os.path.join(d, f))
        except OSError:
            pass


def _mp_sync(roots=None, backup=False):
    with _MP_LOCK:
        path = _mp_yaml_path()
        old_text = _mp_read_text(path)
        raw, blocks = _mp_parse(old_text) if old_text is not None else ([], [])
        result = {'changed': False, 'added': [], 'missing': [], 'count': 0}
        if not blocks and not roots:
            return result
        by_norm = {_mp_norm(b['root']): b for b in blocks}
        if roots is None:
            roots = [b['root'] for b in blocks]
        else:
            roots = [os.path.normpath(r) for r in roots]
        seen = set()
        specs = []
        for r in roots:
            n = _mp_norm(r)
            if n in seen:
                continue
            seen.add(n)
            old = by_norm.get(n)
            subs = _mp_subdirs(r)
            if subs is None:
                result['missing'].append(r)
                if old is not None:
                    specs.append({'root': r, 'keep': old['keep']})
                continue
            specs.append({'root': r, 'subs': subs})
            if old is not None:
                new = [s for s in subs if s.lower() not in old['keys']]
                if new:
                    result['added'].append((r, new))
        result['count'] = len(specs)
        new_text = _mp_render(raw, specs)
        old_norm = None if old_text is None else old_text.replace('\r\n', '\n').replace('\r', '\n')
        if new_text == (old_norm or ''):
            return result
        if backup and old_text is not None:
            try:
                _mp_backup(path)
            except Exception:
                _log_error('_mp_backup')
        if not new_text:
            try:
                os.remove(path)
            except OSError:
                pass
        else:
            tmp = path + '.tmp'
            with open(tmp, 'w', encoding='utf-8', newline='\r\n') as f:
                f.write(new_text)
            os.replace(tmp, path)
        result['changed'] = True
        return result


def _mp_validate(path, current):
    p = (path or '').strip().strip('"')
    if not p:
        return {'ok': False, 'error': 'Select a folder.'}
    p = os.path.normpath(p)
    if not os.path.isdir(p):
        return {'ok': False, 'error': 'Folder not found.'}
    note = ''
    if _mp_known_count(p) == 0:
        child = None
        for s in (_mp_subdirs(p) or []):
            if s.lower() == 'models':
                c = os.path.join(p, s)
                if _mp_known_count(c) > 0:
                    child = c
                break
        if child:
            p = os.path.normpath(child)
            note = 'Using the "models" sub-folder.'
        else:
            parent = os.path.dirname(p)
            if os.path.basename(p).lower() in _MP_KNOWN_DIRS and parent and _mp_known_count(parent) > 0:
                return {'ok': False, 'error': 'This is a single model type folder. Select its parent: ' + parent}
            return {'ok': False, 'error': 'This is NOT a MODELS folder.'}
    n = _mp_norm(p)
    if n == _mp_norm(os.path.join(ROOT_DIR, 'ComfyUI', 'models')):
        return {'ok': False, 'error': 'This is your NEW MODELS folder. Select your EXISTING models folder.'}
    sep = os.sep
    for r in current:
        rn = _mp_norm(r)
        if rn == n:
            return {'ok': False, 'error': 'This folder was already added.'}
        if n.startswith(rn.rstrip('\\/') + sep) or rn.startswith(n.rstrip('\\/') + sep):
            return {'ok': False, 'error': 'This folder overlaps with an already added folder: ' + r}
    subs = _mp_subdirs(p) or []
    return {'ok': True, 'path': p, 'count': len(subs), 'note': note}


class Api:
    _NO_WIN        = 0x08000000
    _ezi_check_lock = threading.Lock()
    _comfy_check_lock = threading.Lock()
    _ezi_last_state = None
    _comfy_last_tag = None
    _NO_WIN_HIDDEN = 0x08000000 | 0x20000000
    PY_EXE         = os.path.join(ROOT_DIR, "python_embeded", "python.exe")
    COMFY_DIR      = os.path.join(ROOT_DIR, "ComfyUI")
    _cap_win       = None

    def get_easy_menu_js(self):
        try:
            html = SHELL_HTML
            pre = html[html.index('const EZI_THEME_LIST'):html.index('function applyTheme(theme)')]
            modal = html[html.index('function showModal('):html.index('function show_close_confirm()')]
            body = html[html.index('let _settingsOpenId = 0;'):html.index('function set_dot_ready()')]
            return (pre + _EASY_MENU_SHIM + modal + body).replace("{EZI_VERSION}", APP_VERSION)
        except Exception:
            _log_error('get_easy_menu_js')
            return ""

    def _cap_hwnd(self):
        win = self._cap_win
        if win is not None:
            return self._console_hwnd or _get_hwnd(win)
        return _get_hwnd(self._window) if self._window else None

    def _cap_eval(self, js):
        win = self._cap_win
        if win is not None:
            try:
                win.evaluate_js(js)
            except Exception:
                pass
            return
        self._safe_eval(js)

    def restart_ezi(self):
        self.save_window_state()
        self._confirm_close = True
        self._flush_state_to_disk()

        try:
            self._kill_running_proc()
        except Exception:
            _log_error('restart_ezi')

        try:
            subprocess.Popen(
                [sys.executable] + sys.argv,
                cwd=os.getcwd(),
                creationflags=0x00000008,
                env=dict(os.environ, EZI_WAIT_PID=str(os.getpid())),
            )
        except Exception:
            _log_error('restart_ezi')

        self._close_window()

    def read_clipboard(self):
        try:
            import ctypes
            user32 = ctypes.windll.user32
            kernel32 = ctypes.windll.kernel32

            try:
                ctypes.windll.ole32.OleInitialize(None)
            except Exception:
                pass

            user32.OpenClipboard.argtypes = [ctypes.c_void_p]
            user32.OpenClipboard.restype = ctypes.c_int
            user32.GetClipboardData.argtypes = [ctypes.c_uint]
            user32.GetClipboardData.restype = ctypes.c_void_p
            kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
            kernel32.GlobalLock.restype = ctypes.c_void_p
            kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
            kernel32.GlobalUnlock.restype = ctypes.c_int
            user32.CloseClipboard.argtypes = []
            user32.CloseClipboard.restype = ctypes.c_int

            if not user32.OpenClipboard(0):
                return ""
            try:
                handle = user32.GetClipboardData(13)
                if not handle:
                    return ""
                ptr = kernel32.GlobalLock(handle)
                if not ptr:
                    return ""
                try:
                    return ctypes.c_wchar_p(ptr).value or ""
                finally:
                    kernel32.GlobalUnlock(handle)
            finally:
                user32.CloseClipboard()
        except Exception:
            return ""

    def write_clipboard(self, text):
        try:
            import ctypes
            user32 = ctypes.windll.user32
            kernel32 = ctypes.windll.kernel32

            try:
                ctypes.windll.ole32.OleInitialize(None)
            except Exception:
                pass

            user32.OpenClipboard.argtypes = [ctypes.c_void_p]
            user32.OpenClipboard.restype = ctypes.c_int
            user32.EmptyClipboard.argtypes = []
            user32.EmptyClipboard.restype = ctypes.c_int
            user32.SetClipboardData.argtypes = [ctypes.c_uint, ctypes.c_void_p]
            user32.SetClipboardData.restype = ctypes.c_void_p
            kernel32.GlobalAlloc.argtypes = [ctypes.c_uint, ctypes.c_size_t]
            kernel32.GlobalAlloc.restype = ctypes.c_void_p
            kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
            kernel32.GlobalLock.restype = ctypes.c_void_p
            kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
            kernel32.GlobalUnlock.restype = ctypes.c_int
            kernel32.GlobalFree.argtypes = [ctypes.c_void_p]
            kernel32.GlobalFree.restype = ctypes.c_void_p
            user32.CloseClipboard.argtypes = []
            user32.CloseClipboard.restype = ctypes.c_int

            if not user32.OpenClipboard(0):
                return
            user32.EmptyClipboard()
            
            try:
                buf = ctypes.create_unicode_buffer(text)
                size = ctypes.sizeof(buf)
                
                GMEM_MOVEABLE = 0x0002
                h_mem = kernel32.GlobalAlloc(GMEM_MOVEABLE, size)
                if not h_mem:
                    return
                
                ptr = kernel32.GlobalLock(h_mem)
                if not ptr:
                    kernel32.GlobalFree(h_mem)
                    return
                
                try:
                    ctypes.memmove(ptr, buf, size)
                finally:
                    kernel32.GlobalUnlock(h_mem)
                
                if not user32.SetClipboardData(13, h_mem):
                    kernel32.GlobalFree(h_mem)
            finally:
                user32.CloseClipboard()
        except Exception:
            pass

    def save_blob_data(self, filename, content, is_base64=False):
        threading.Thread(target=self._do_save_blob, args=(filename, content, is_base64), daemon=True).start()

    def _do_save_blob(self, filename, content, is_base64=False):
        if not self._window:
            return

        ext = os.path.splitext(filename)[1].lower()

        known_labels = {
            '.json': 'JSON Files',
            '.txt': 'Text Files',
            '.yaml': 'YAML Files',
            '.yml': 'YAML Files',
            '.png': 'PNG Image',
            '.jpg': 'JPEG Image',
            '.jpeg': 'JPEG Image',
            '.webp': 'WebP Image',
            '.gif': 'GIF Image',
            '.bmp': 'Bitmap Image',
            '.svg': 'SVG Image',
            '.mp4': 'MP4 Video',
            '.webm': 'WebM Video',
            '.mov': 'QuickTime Video',
            '.avi': 'AVI Video',
            '.mkv': 'Matroska Video',
            '.wav': 'WAV Audio',
            '.mp3': 'MP3 Audio',
            '.ogg': 'OGG Audio',
            '.flac': 'FLAC Audio',
            '.csv': 'CSV Files',
            '.zip': 'ZIP Archive',
            '.safetensors': 'SafeTensors Files',
        }

        if ext:
            label = known_labels.get(ext, f"{ext[1:].upper()} Files")
            file_types = (f"{label} (*{ext})", "All Files (*.*)")
        else:
            file_types = ("All Files (*.*)",)

        save_path = None
        try:
            with self._save_dialog_lock:
                result = self._window.create_file_dialog(
                    SAVE_DIALOG_TYPE,
                    directory=self._last_save_dir,
                    save_filename=filename,
                    file_types=file_types
                )
                if result:
                    save_path = result[0] if isinstance(result, (list, tuple)) else result
                    self._last_save_dir = os.path.dirname(save_path)
                    self._settings["last_save_dir"] = self._last_save_dir
                    _save_settings(self._settings)
        except Exception:
            _log_error('_do_save_blob')

        if save_path:
            try:
                if is_base64:
                    if ',' in content:
                        content = content.split(',', 1)[1]
                    data = base64.b64decode(content)
                    with open(save_path, 'wb') as f:
                        f.write(data)
                else:
                    with open(save_path, 'w', encoding='utf-8') as f:
                        f.write(content)
            except Exception as e:
                self._println(f"[Save Blob] Error: {e}\n")

    def __init__(self, proxy_port, comfy_port_holder, settings, storage_holder, settings_holder=None):
        self._window, self._proc = None, None
        self._job = None
        self._settings = settings
        self._storage_holder = storage_holder
        self._settings_holder = settings_holder
        self._last_save_dir = settings.get("last_save_dir", os.path.expanduser("~"))
        self._save_dialog_lock = threading.Lock()
        self._url_found, self._started, self._js_ready = False, False, threading.Event()
        self._updating = False
        self._confirm_close = False
        self._storage_ack = threading.Event()
        self._ws_lost = threading.Event()
        self._services_started = False
        self._restarting = False
        self._run_id = 0
        self._out_buf, self._out_lock = [], threading.Lock()
        self._columns = 120
        self._last_ch = '\n'
        self._dl_rows, self._dl_drawn, self._dl_pty = {}, None, False
        self._console_win, self._console_hwnd = None, None
        self._console_allow_close, self._console_geo_timer = False, None
        self._pump_lock = threading.Lock()
        self._console_op_lock = threading.Lock()
        threading.Thread(target=self._console_pump, daemon=True).start()
        self._main_hwnd = None
        self._proxy_port, self._comfy_port_holder = proxy_port, comfy_port_holder
        self._tb_hwnd = None
        import queue as _tbq
        self._tb_queue = _tbq.Queue()
        threading.Thread(target=self._tb_worker_start, daemon=True).start()
        if sys.platform == "win32":
            hwnd = ctypes.WinDLL('kernel32').GetConsoleWindow()
            if hwnd: ctypes.WinDLL('user32').ShowWindow(hwnd, 0)
				
    def handle_comfyui_download(self, url, filename, directory=''):
        threading.Thread(target=self._do_handle_download, args=(url, filename, directory), daemon=True).start()

    def _model_target_dir(self, directory):
        try:
            directory = str(directory or '').strip().replace('/', '\\').strip('\\')
            if not directory or os.path.isabs(directory) or ':' in directory:
                return None
            parts = [p for p in directory.split('\\') if p]
            if not parts or any(p in ('.', '..') for p in parts):
                return None
            models = self._resolve_models_dir()
            if not models:
                return None
            target = os.path.normpath(os.path.join(models, *parts))
            base = os.path.normcase(os.path.abspath(models))
            if not os.path.normcase(os.path.abspath(target)).startswith(base + os.sep):
                return None
            os.makedirs(target, exist_ok=True)
            return target if os.path.isdir(target) else None
        except Exception:
            _log_error('_model_target_dir')
            return None

    def _do_handle_download(self, url, filename, directory=''):
        port = self._comfy_port_holder[0]
        if not port:
            return

        if re.match(r'^https?://', str(url), re.IGNORECASE):
            full_url = url
        else:
            full_url = f"{_comfy_origin(port)}{url}"

        model_dir = self._model_target_dir(directory)

        if not self._window:
            return

        ext = os.path.splitext(filename)[1].lower()
        if ext in ('.mp4', '.webm', '.avi', '.mov', '.mkv'):
            file_types = ("Video Files (*.mp4;*.webm;*.avi;*.mov;*.mkv)", "All Files (*.*)")
        elif ext in ('.wav', '.mp3', '.ogg', '.flac', '.aac'):
            file_types = ("Audio Files (*.wav;*.mp3;*.ogg;*.flac;*.aac)", "All Files (*.*)")
        elif ext in ('.gif',):
            file_types = ("GIF Image (*.gif)", "All Files (*.*)")
        elif ext in ('.png', '.jpg', '.jpeg', '.webp', '.bmp'):
            file_types = ("Image Files (*.png;*.jpg;*.jpeg;*.webp;*.bmp)", "All Files (*.*)")
        elif ext:
            file_types = (f"{ext[1:].upper()} Files (*{ext})", "All Files (*.*)")
        else:
            file_types = ("All Files (*.*)",)

        save_path = None
        try:
            with self._save_dialog_lock:
                result = self._window.create_file_dialog(
                    SAVE_DIALOG_TYPE,
                    directory=model_dir or self._last_save_dir,
                    save_filename=filename,
                    file_types=file_types
                )
                if result:
                    save_path = result[0] if isinstance(result, (list, tuple)) else result
                    if not model_dir:
                        self._last_save_dir = os.path.dirname(save_path)
                        self._settings["last_save_dir"] = self._last_save_dir
                        _save_settings(self._settings)
        except Exception:
            _log_error('_do_handle_download')

        if not save_path:
            return

        try:
            _ezi_download_with_progress(
                full_url, save_path, println=self._print, label=filename, timeout=60
            )
            self._println(f"\033[92m[Save Media] Saved to {save_path}\033[0m")
        except Exception as e:
            self._println(f"\033[91m[Save Media] Error: {e}\033[0m")

    def modal_response(self, result, action):
        if action == 'close':
            if result:
                if not self._updating:
                    self.save_window_state()
                self._confirm_close = True
                self._graceful_close()
        elif action == 'update':
            if result:
                bat = os.path.join(ROOT_DIR, 'Update ComfyUI.bat')
                threading.Thread(target=self._do_update, args=(bat,), daemon=True).start()

    def _flush_state_to_disk(self, timeout=3.0):
        cw = _EZI_WINDOW_REF.get("comfy_webview")
        if cw is None or not _EZI_WINDOW_REF.get("comfy_ready"):
            return
        form = _EZI_WINDOW_REF.get("winforms_form")
        on_ui_thread = False
        try:
            on_ui_thread = form is not None and not form.InvokeRequired
        except Exception:
            pass
        self._storage_ack.clear()

        def _do_flush():
            try:
                cw.CoreWebView2.ExecuteScriptAsync(
                    "(window.__eziFlushStorageNow || function(){try{window.chrome.webview.postMessage({type:'ezi_storage_save'});}catch(e){}})();"
                )
            except Exception:
                self._storage_ack.set()

        self._ui_invoke(_do_flush)
        if not on_ui_thread:
            self._storage_ack.wait(timeout)

    def _close_window(self):
        def _delayed_destroy():
            time.sleep(0.4)
            if self._window:
                self._window.destroy()
        threading.Thread(target=_delayed_destroy, daemon=True).start()

    def _graceful_close(self):
        self._flush_state_to_disk()
        self._close_window()

    def set_window(self, w):
        self._window = w

    def minimize_window(self):
        try:
            if self._window:
                self._window.minimize()
        except Exception:
            pass

    def toggle_maximize_window(self):
        try:
            if not self._window:
                return
            if self._is_maximized():
                self._window.restore()
            else:
                self._window.maximize()
        except Exception:
            pass

    def close_window(self):
        try:
            if self._window:
                self._window.destroy()
        except Exception:
            pass

    def _tb_set(self, value, maximum, state=2):
        self._tb_queue.put_nowait((value, maximum, state))

    def _tb_worker_start(self):
        ctypes.windll.ole32.CoInitializeEx(None, 0)
        while True:
            try:
                value, maximum, state = self._tb_queue.get(timeout=2)
                if not self._tb_hwnd:
                    self._tb_hwnd = _get_hwnd(self._window)
                _taskbar_progress_ctypes(self._tb_hwnd, value, maximum, state)
            except Exception:
                pass

    def set_title(self, suffix: str = ""):
        if self._window:
            try:
                t = f'ComfyUI-EZi-Desktop  v{APP_VERSION}'
                self._window.set_title(t + (f' - {suffix}' if suffix else ''))
            except Exception:
                pass

    def js_ready(self, cols=0):
        try:
            if cols and int(cols) > 0:
                self._columns = max(40, int(cols))
        except Exception:
            pass
        self._js_ready.set()
        if not self._started:
            self._started = True
            if self._settings.get('ezi_updated_from'):
                self._settings['ezi_updated_from'] = ''
                _save_settings(self._settings)
                self._safe_eval(f"show_ezi_updated({json.dumps('v' + APP_VERSION)});")
            bat = os.path.join(ROOT_DIR, 'Update Easy-Install.bat')
            zip_sig = _ezi_zip_signature()
            if zip_sig and os.path.isfile(bat) and self._settings.get('ezi_zip_failed_sig') != zip_sig:
                threading.Thread(target=self._apply_ezi_update, args=(bat,), daemon=True).start()
            else:
                self._start_services()

    def _start_services(self):
        if self._services_started:
            return
        self._services_started = True
        threading.Thread(target=self._run, daemon=True).start()
        threading.Thread(target=self._check_update, daemon=True).start()
        threading.Thread(target=self._check_ezi_update, daemon=True).start()
        threading.Thread(target=self._port_monitor, daemon=True).start()
        threading.Thread(target=self._update_watcher, daemon=True).start()

    def _apply_ezi_update(self, bat):
        self._settings['ezi_updated_from'] = APP_VERSION
        _save_settings(self._settings)
        self._do_run_bat(bat, status_label='Updating EZi...')

    def _ezi_update_failed(self):
        self._settings['ezi_updated_from'] = ''
        self._settings['ezi_zip_failed_sig'] = _ezi_zip_signature()
        _save_settings(self._settings)
        self._println("\033[91m=== EZi update did not complete. The archive was kept; use the 'EZi Update ready' button to retry. ===\033[0m")
        self._safe_eval("show_ezi_update_ready('');")
        self._updating = False
        if self._services_started:
            self._safe_eval("switchToConsole()")
            self._restart_comfy(check_update=False)
        else:
            self._start_services()

    def set_columns(self, cols):
        try:
            self._columns = max(40, int(cols))
        except Exception:
            pass

    def _hwnd_maximized(self, hwnd):
        try:
            if not hwnd:
                return False
            wp = EZI_WINDOWPLACEMENT()
            wp.length = ctypes.sizeof(EZI_WINDOWPLACEMENT)
            ctypes.windll.user32.GetWindowPlacement(hwnd, ctypes.byref(wp))
            return wp.showCmd == 3
        except Exception:
            return False

    def _is_maximized(self):
        try:
            hwnd = _get_hwnd(self._window)
            if not hwnd:
                return False
            wp = EZI_WINDOWPLACEMENT()
            wp.length = ctypes.sizeof(EZI_WINDOWPLACEMENT)
            ctypes.windll.user32.GetWindowPlacement(hwnd, ctypes.byref(wp))
            return wp.showCmd == 3
        except Exception:
            return False

    def is_window_maximized(self):
        return bool(self._is_maximized())

    def start_top_resize(self, zone):
        try:
            if self._is_maximized():
                return
            hwnd = _get_hwnd(self._window)
            if not hwnd:
                return
            ht = int(zone)
            if ht not in (12, 13, 14):
                ht = 12
            u = ctypes.WinDLL('user32')
            u.SendMessageW.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_size_t, ctypes.c_ssize_t]
            u.SendMessageW.restype = ctypes.c_ssize_t

            def _do():
                try:
                    pt = _wt.POINT()
                    u.GetCursorPos(ctypes.byref(pt))
                    lp = ((pt.y & 0xFFFF) << 16) | (pt.x & 0xFFFF)
                    u.ReleaseCapture()
                    u.SendMessageW(hwnd, 0x00A1, ht, lp)
                except Exception:
                    _log_error('start_top_resize_ui')

            form = getattr(self._window, 'native', None)
            if form is not None and form.InvokeRequired:
                import System
                form.BeginInvoke(System.Action(_do))
            else:
                _do()
        except Exception:
            _log_error('start_top_resize')

    def _get_columns(self):
        try:
            win = self._console_win or self._window
            if win:
                result = win.evaluate_js(
                    "(function(){"
                    "var canvas=document.createElement('canvas');"
                    "var ctx=canvas.getContext('2d');"
                    "ctx.font='12px Consolas,\"Courier New\",monospace';"
                    "var charW=ctx.measureText('M').width||7.2;"
                    "var t=document.getElementById('term-panel');"
                    "var style=window.getComputedStyle(t);"
                    "var padL=parseFloat(style.paddingLeft)||0;"
                    "var padR=parseFloat(style.paddingRight)||0;"
                    "var scrollbarW=Math.max(t.offsetWidth-t.clientWidth,17);"
                    "var usable=t.clientWidth-padL-padR-scrollbarW-2;"
                    "var cols=Math.floor(usable/charW);"
                    "return cols>0?cols:0;"
                    "})()"
                )
                if result and int(result) > 0:
                    cols = max(40, int(result))
                    if self._console_win is not None:
                        maxed = self._hwnd_maximized(self._console_hwnd)
                    else:
                        maxed = self._is_maximized()
                    if not maxed:
                        cols = min(cols, 80)
                    return cols
        except Exception:
            pass
        return self._columns

    def on_loaded(self):
        hwnd = _get_hwnd(self._window)
        if hwnd:
            self._main_hwnd = hwnd
            _apply_captioned_frame_style(hwnd)
            _install_hidden_titlebar_hook(hwnd)
            _suppress_dwm_border(hwnd)
            _taskbar_mark_not_fullscreen(hwnd)
            if ADV_CONSOLE:
                ctypes.windll.user32.ShowWindow(hwnd, 0)
        _set_window_icon(hwnd)

    def _kill_process_tree(self, root_pid):
        try:
            kernel = ctypes.windll.kernel32
            PROCESS_TERMINATE = 0x0001
            SYNCHRONIZE = 0x00100000
            TH32CS_SNAPPROCESS = 0x00000002

            class PROCESSENTRY32(ctypes.Structure):
                _fields_ = [
                    ("dwSize",              ctypes.c_uint32),
                    ("cntUsage",            ctypes.c_uint32),
                    ("th32ProcessID",       ctypes.c_uint32),
                    ("th32DefaultHeapID",   ctypes.POINTER(ctypes.c_ulong)),
                    ("th32ModuleID",        ctypes.c_uint32),
                    ("cntThreads",          ctypes.c_uint32),
                    ("th32ParentProcessID", ctypes.c_uint32),
                    ("pcPriClassBase",      ctypes.c_long),
                    ("dwFlags",             ctypes.c_uint32),
                    ("szExeFile",           ctypes.c_char * 260),
                ]

            def _kill(pid):
                snap = kernel.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
                if snap == ctypes.c_void_p(-1).value:
                    return
                children = []
                try:
                    entry = PROCESSENTRY32()
                    entry.dwSize = ctypes.sizeof(PROCESSENTRY32)
                    if kernel.Process32First(snap, ctypes.byref(entry)):
                        while True:
                            if entry.th32ParentProcessID == pid:
                                children.append(entry.th32ProcessID)
                            if not kernel.Process32Next(snap, ctypes.byref(entry)):
                                break
                finally:
                    kernel.CloseHandle(snap)
                for child_pid in children:
                    _kill(child_pid)
                h = kernel.OpenProcess(PROCESS_TERMINATE | SYNCHRONIZE, False, pid)
                if h:
                    kernel.TerminateProcess(h, 1)
                    result = kernel.WaitForSingleObject(h, 3000)
                    kernel.CloseHandle(h)
                    if result != 0:
                        try:
                            subprocess.run(
                                ['taskkill', '/F', '/T', '/PID', str(pid)],
                                capture_output=True, timeout=5,
                                creationflags=self._NO_WIN
                            )
                        except Exception:
                            pass

            _kill(root_pid)
        except Exception:
            pass

    def _kill_port_owner(self, port):
        try:
            iphlpapi = ctypes.windll.iphlpapi

            class MIB_TCPROW_OWNER_PID(ctypes.Structure):
                _fields_ = [
                    ('dwState',      ctypes.c_ulong),
                    ('dwLocalAddr',  ctypes.c_ulong),
                    ('dwLocalPort',  ctypes.c_ulong),
                    ('dwRemoteAddr', ctypes.c_ulong),
                    ('dwRemotePort', ctypes.c_ulong),
                    ('dwOwningPid',  ctypes.c_ulong),
                ]

            buf_size = ctypes.c_ulong(0)
            iphlpapi.GetExtendedTcpTable(None, ctypes.byref(buf_size), False, 2, 5, 0)
            buf = (ctypes.c_byte * buf_size.value)()
            if iphlpapi.GetExtendedTcpTable(buf, ctypes.byref(buf_size), False, 2, 5, 0) == 0:
                count = ctypes.c_ulong.from_buffer(buf).value
                offset = ctypes.sizeof(ctypes.c_ulong)
                row_sz = ctypes.sizeof(MIB_TCPROW_OWNER_PID)
                for i in range(count):
                    row = MIB_TCPROW_OWNER_PID.from_buffer(buf, offset + i * row_sz)
                    local_port = ((row.dwLocalPort & 0xFF) << 8) | ((row.dwLocalPort >> 8) & 0xFF)
                    if local_port == port:
                        pid = row.dwOwningPid
                        if pid and pid != os.getpid():
                            try:
                                self._kill_process_tree(pid)
                            except Exception:
                                pass
        except Exception:
            pass

    def _job_kill(self):
        job, self._job = self._job, None
        if not job:
            return
        try:
            k32 = ctypes.WinDLL('kernel32')
            k32.TerminateJobObject.argtypes = [ctypes.c_void_p, ctypes.c_uint]
            k32.CloseHandle.argtypes = [ctypes.c_void_p]
            k32.TerminateJobObject(job, 1)
            k32.CloseHandle(job)
        except Exception:
            _log_error('_job_kill')

    def _job_attach(self, proc):
        self._job_kill()
        try:
            class IO_COUNTERS(ctypes.Structure):
                _fields_ = [(n, ctypes.c_ulonglong) for n in (
                    'ReadOperationCount', 'WriteOperationCount', 'OtherOperationCount',
                    'ReadTransferCount', 'WriteTransferCount', 'OtherTransferCount')]

            class BASIC_LIMITS(ctypes.Structure):
                _fields_ = [
                    ('PerProcessUserTimeLimit', ctypes.c_int64),
                    ('PerJobUserTimeLimit', ctypes.c_int64),
                    ('LimitFlags', ctypes.c_uint32),
                    ('MinimumWorkingSetSize', ctypes.c_size_t),
                    ('MaximumWorkingSetSize', ctypes.c_size_t),
                    ('ActiveProcessLimit', ctypes.c_uint32),
                    ('Affinity', ctypes.c_size_t),
                    ('PriorityClass', ctypes.c_uint32),
                    ('SchedulingClass', ctypes.c_uint32),
                ]

            class EXTENDED_LIMITS(ctypes.Structure):
                _fields_ = [
                    ('BasicLimitInformation', BASIC_LIMITS),
                    ('IoInfo', IO_COUNTERS),
                    ('ProcessMemoryLimit', ctypes.c_size_t),
                    ('JobMemoryLimit', ctypes.c_size_t),
                    ('PeakProcessMemoryUsed', ctypes.c_size_t),
                    ('PeakJobMemoryUsed', ctypes.c_size_t),
                ]

            k32 = ctypes.WinDLL('kernel32', use_last_error=True)
            k32.CreateJobObjectW.restype = ctypes.c_void_p
            k32.CreateJobObjectW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p]
            k32.SetInformationJobObject.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p, ctypes.c_uint32]
            k32.AssignProcessToJobObject.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
            k32.CloseHandle.argtypes = [ctypes.c_void_p]

            job = k32.CreateJobObjectW(None, None)
            if not job:
                return
            info = EXTENDED_LIMITS()
            info.BasicLimitInformation.LimitFlags = 0x2000
            if not k32.SetInformationJobObject(job, 9, ctypes.byref(info), ctypes.sizeof(info)) \
                    or not k32.AssignProcessToJobObject(job, int(proc._handle)):
                k32.CloseHandle(job)
                return
            self._job = job
        except Exception:
            _log_error('_job_attach')

    def _kill_running_proc(self, keep_restarting=False):
        port = self._comfy_port_holder[0]
        self._job_kill()

        if not keep_restarting:
            self._restarting = False

        started_own_proc = self._proc is not None

        if self._proc:
            try:
                self._kill_process_tree(self._proc.pid)
            except Exception:
                pass
            self._proc = None

        if port and started_own_proc:
            self._kill_port_owner(port)

        if port and started_own_proc:
            for i in range(80):
                try:
                    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                        s.settimeout(0.2)
                        if s.connect_ex(('127.0.0.1', port)) != 0:
                            break
                except Exception:
                    break
                if i > 0 and i % 5 == 0:
                    self._kill_port_owner(port)
                time.sleep(0.1)

    def _port_monitor(self):
        import urllib.request as _ur

        def _http_alive(port, timeout=5):
            try:
                r = _comfy_urlopen(f'{_comfy_origin(port)}/system_stats', timeout=timeout)
                return r.status == 200
            except Exception:
                return False

        was_up = False
        down_since = 0
        restart_start_time = 0
        ws_lost_at = -1e9
        gave_up = False
        _SOCK_DOWN_SECONDS = 12.0

        while self._window:
            if self._ws_lost.wait(0.5):
                self._ws_lost.clear()
                ws_lost_at = time.monotonic()
            if self._updating:
                was_up = False
                down_since = 0
                continue
            port = self._comfy_port_holder[0]
            if not port:
                continue
            sock_up = False
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.settimeout(0.5)
                    sock_up = s.connect_ex(('127.0.0.1', port)) == 0
            except Exception:
                pass
            if sock_up:
                down_since = 0
                if self._restarting:
                    gave_up = False
                    if restart_start_time == 0:
                        restart_start_time = time.time()
                    if _http_alive(port):
                        self._restarting = False
                        restart_start_time = 0
                        self._url_found = True
                        was_up = True
                        self._safe_eval("set_dot_ready();")
                        self._navigate_comfy_webview(f'http://127.0.0.1:{self._proxy_port}/')
                    else:
                        if time.time() - restart_start_time > 15:
                            self._restarting = False
                            restart_start_time = 0
                            self._url_found = True
                            was_up = True
                            self._safe_eval("set_dot_ready();")
                            self._navigate_comfy_webview(f'http://127.0.0.1:{self._proxy_port}/')
                elif not was_up:
                    if not gave_up:
                        was_up = True
                    elif _http_alive(port):
                        gave_up = False
                        self._url_found = True
                        was_up = True
                        self._safe_eval("set_dot_ready();")
                        self._navigate_comfy_webview(f'http://127.0.0.1:{self._proxy_port}/')
            else:
                if was_up and not self._restarting:
                    ws_dropped = time.monotonic() - ws_lost_at < 10
                    if not down_since:
                        down_since = time.monotonic()
                    if ws_dropped or time.monotonic() - down_since >= _SOCK_DOWN_SECONDS:
                        if ws_dropped or not _http_alive(port, timeout=2):
                            was_up = False
                            down_since = 0
                            ws_lost_at = -1e9
                            self._restarting = True
                            self._url_found = False
                            restart_start_time = time.time()
                            self._safe_eval("switchToConsole('Restarting...'); _showRestartNotice('⟳ ComfyUI is restarting...');")
                            self._flush_state_to_disk()
                        else:
                            down_since = 0
                if self._restarting:
                    if restart_start_time > 0 and time.time() - restart_start_time > 300:
                        self._restarting = False
                        restart_start_time = 0
                        self._url_found = False
                        was_up = False
                        gave_up = True
                        self._println("\n\033[91m⚠  Restart timed out. ComfyUI did not come back online.\033[0m")
                        self._safe_eval("switchToConsole('Stopped')")
    def _update_watcher(self):
        last = time.time()
        while True:
            time.sleep(60)
            now = time.time()
            if now < last:
                last = now
                continue
            if now - last < UPDATE_CHECK_INTERVAL or self._updating:
                continue
            last = now
            self._check_ezi_update(quiet=True)
            self._check_update(quiet=True)

    def _check_update(self, quiet=False):
        if not self._comfy_check_lock.acquire(blocking=False):
            return
        try:
            if not os.path.isdir(os.path.join(self.COMFY_DIR, '.git')):
                return
            if not quiet:
                self._println('\033[93mChecking for ComfyUI update...\033[0m')
            subprocess.run(['git', 'fetch', '--quiet', '--tags'], cwd=self.COMFY_DIR, capture_output=True, timeout=8, creationflags=self._NO_WIN)
            all_tags = subprocess.run(
                ['git', 'tag', '--sort=-version:refname'],
                cwd=self.COMFY_DIR, capture_output=True, timeout=5, creationflags=self._NO_WIN
            ).stdout.decode(errors='replace').strip().splitlines()
            latest_tag = all_tags[0].strip() if all_tags else ''
            if latest_tag:
                head_r = subprocess.run(
                    ['git', 'rev-parse', 'HEAD'],
                    cwd=self.COMFY_DIR, capture_output=True, timeout=5, creationflags=self._NO_WIN
                )
                tag_r = subprocess.run(
                    ['git', 'rev-parse', f'{latest_tag}^{{}}'],
                    cwd=self.COMFY_DIR, capture_output=True, timeout=5, creationflags=self._NO_WIN
                )
                head_hash = head_r.stdout.strip().decode(errors='replace')
                tag_hash = tag_r.stdout.strip().decode(errors='replace')
                if head_hash and tag_hash and head_hash != tag_hash:
                    if quiet and latest_tag == self._comfy_last_tag:
                        return
                    self._comfy_last_tag = latest_tag
                    stable_tag = self._stable_comfy_tag()
                    is_stable = bool(stable_tag and latest_tag == stable_tag)
                    self._safe_eval(f"show_update({json.dumps(latest_tag)}, {json.dumps(is_stable)})")
        except Exception:
            _log_error('_check_update')
        finally:
            self._comfy_check_lock.release()

    def _stable_comfy_tag(self):
        cached = self._settings.get('cached_comfy_stable_version') or None
        try:
            tag = _latest_release_tag('comfyanonymous/ComfyUI')
        except Exception:
            return cached
        if tag != cached:
            self._settings['cached_comfy_stable_version'] = tag
            _save_settings(self._settings)
        return tag

    def _get_latest_ezi_tag(self):
        return _latest_release_tag("Tavris1/ComfyUI-Easy-Install").lstrip("v")

    def _get_latest_ezi_tag_via_api(self):
        import urllib.request as _ur
        import json as _json
        url = "https://api.github.com/repos/Tavris1/ComfyUI-Easy-Install/releases/latest"
        req = _ur.Request(url, headers={"User-Agent": EZI_UA_TAG})
        with _ur.urlopen(req, timeout=8) as r:
            data = _json.loads(r.read())
        return data.get("tag_name", "").strip().lstrip("v")

    def _check_ezi_update(self, quiet=False):
        if not self._ezi_check_lock.acquire(blocking=False):
            return
        try:
            if not quiet:
                self._println('\033[95mChecking for Easy-Install update...\033[0m')
            try:
                tag = self._get_latest_ezi_tag()
            except Exception as e:
                if not quiet:
                    self._println(f'\033[93mredirect-based check failed ({e!r}), falling back to api.github.com...\033[0m')
                tag = self._get_latest_ezi_tag_via_api()
            if not tag:
                if not quiet:
                    self._println('\033[93mEasy-Install update check: could not determine latest tag\033[0m')
                return
            local_parts  = [int(x) for x in APP_VERSION.split(".") if x.isdigit()]
            remote_parts = [int(x) for x in tag.split(".")      if x.isdigit()]
            if remote_parts > local_parts:
                display = "v" + tag
                zip_tag = self._settings.get('ezi_zip_tag')
                ready = os.path.isfile(EZI_ZIP_PATH) and (not zip_tag or zip_tag == tag)
                if quiet and ready and self._ezi_last_state == (display, True):
                    return
                announce = not quiet or self._ezi_last_state is None or self._ezi_last_state[0] != display
                if announce:
                    self._println(f'\033[95mEasy-Install update available: v{APP_VERSION} -> {display}\033[0m')
                if not ready:
                    if announce:
                        self._println('\033[95mDownloading Easy-Install update...\033[0m')
                    ready = _download_ezi_zip()
                    if ready:
                        self._settings['ezi_zip_tag'] = tag
                        _save_settings(self._settings)
                        self._println('\033[92mEasy-Install update downloaded.\033[0m')
                    elif announce:
                        self._println('\033[93mEasy-Install update could not be downloaded.\033[0m')
                state = (display, bool(ready))
                if quiet and state == self._ezi_last_state:
                    return
                self._ezi_last_state = state
                if ready:
                    self._safe_eval(f"show_ezi_update_ready({json.dumps(display)})")
                else:
                    self._safe_eval(f"show_ezi_update({json.dumps(display)})")
            elif not quiet:
                self._println(f'\033[92mEasy-Install is up to date (v{APP_VERSION}, latest is v{tag})\033[0m')
        except Exception as e:
            if quiet:
                _log_error('_check_ezi_update')
            else:
                self._println(f'\033[91mEasy-Install update check failed: {e!r}\033[0m')
        finally:
            self._ezi_check_lock.release()

    def run_update(self):
        bat = os.path.join(ROOT_DIR, 'Update ComfyUI.bat')
        if not os.path.exists(bat):
            self._safe_eval(f"show_update_missing({json.dumps(ROOT_DIR)}, {json.dumps(os.path.basename(bat))})")
            return
        self._safe_eval("show_update_confirm()")

    def run_ezi_update(self):
        bat = os.path.join(ROOT_DIR, "Update Easy-Install.bat")
        if not os.path.exists(bat):
            self._safe_eval(f"show_update_missing({json.dumps(ROOT_DIR)}, {json.dumps(os.path.basename(bat))})")
            return
        threading.Thread(target=self._apply_ezi_update, args=(bat,), daemon=True).start()

    def _do_update(self, bat):
        self._do_run_bat(bat, status_label='Updating...', hide_update_notice=True)

    def retry(self, cols=0):
        try:
            if cols and int(cols) > 0:
                self._columns = max(40, int(cols))
                os.environ['TQDM_NCOLS'] = str(self._columns)
        except Exception:
            pass
        self._restart_comfy(check_update=False)

    def _restart_comfy(self, check_update=True):
        self._flush_state_to_disk()
        self._started = False
        self._url_found = False
        self._restarting = True
        self._run_id += 1

        def _kill_then_run():
            self._kill_running_proc(keep_restarting=True)
            self._run()

        threading.Thread(target=_kill_then_run, daemon=True).start()
        if check_update:
            threading.Thread(target=self._check_update, daemon=True).start()
            threading.Thread(target=self._check_ezi_update, daemon=True).start()

    def _resolve_output_dir(self):
        output_dir = None
        try:
            bat_content = _read_bat()
            if bat_content is not None:
                output_dir = (_bat_flag_value(_bat_args(bat_content), '--output-directory')
                              or _bat_env(bat_content, 'COMFY_OUTPUT_DIR'))
        except Exception:
            pass
        if not output_dir:
            output_dir = os.path.normpath(os.path.join(ROOT_DIR, 'ComfyUI', 'output'))
        output_dir = os.path.normpath(output_dir)
        return output_dir if os.path.isdir(output_dir) else None

    def get_system_info(self):
        import shutil
        from concurrent.futures import ThreadPoolExecutor

        def _ps(cmd, timeout=8):
            return subprocess.run(
                ['powershell', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', cmd],
                capture_output=True, stdin=subprocess.DEVNULL, timeout=timeout, creationflags=self._NO_WIN_HIDDEN
            )

        def _get_python():
            try:
                r = subprocess.run([self.PY_EXE, "--version"], capture_output=True, stdin=subprocess.DEVNULL, timeout=5, creationflags=self._NO_WIN)
                ver = r.stdout.decode(errors='replace').strip() or r.stderr.decode(errors='replace').strip()
                parts = ver.split()
                return parts[1] if len(parts) > 1 else ver
            except Exception:
                return 'N/A'

        def _get_torch():
            try:
                site = os.path.join(ROOT_DIR, 'python_embeded', 'Lib', 'site-packages')
                version_file = os.path.join(site, 'torch', 'version.py')
                with open(version_file, 'r', encoding='utf-8', errors='replace') as f:
                    content = f.read()
                torch_m = re.search(r'__version__\s*=\s*["\']([^"\']+)["\']', content)
                cuda_m  = re.search(r'\bcuda(?:\s*:\s*\S+)?\s*=\s*["\']([^"\']+)["\']', content)
                tv = torch_m.group(1).split('+')[0].rsplit('.', 1)[0] if torch_m else 'N/A'
                cv = cuda_m.group(1) if cuda_m else 'N/A'
                return tv, cv
            except Exception:
                _log_error('_get_torch')
            try:
                r = subprocess.run(
                    [self.PY_EXE, "-c", "import torch; v=torch.__version__.split('+')[0]; cv=torch.version.cuda or 'N/A'; print(v.rsplit('.',1)[0]+'|'+cv)"],
                    capture_output=True, stdin=subprocess.DEVNULL, timeout=10, creationflags=self._NO_WIN
                )
                out = r.stdout.decode(errors='replace').strip()
                if '|' in out:
                    torch_v, cuda_v = out.split('|', 1)
                    return torch_v, cuda_v
            except Exception:
                _log_error('_get_torch')
            return 'N/A', 'N/A'

        def _get_comfyui():
            try:
                r = subprocess.run(
                    ['git', 'describe', '--tags', '--exact-match', 'HEAD'],
                    cwd=self.COMFY_DIR, capture_output=True, stdin=subprocess.DEVNULL, timeout=5, creationflags=self._NO_WIN
                )
                if r.returncode == 0:
                    return r.stdout.decode(errors='replace').strip()
                r2 = subprocess.run(
                    ['git', 'describe', '--tags', '--abbrev=0', 'HEAD'],
                    cwd=self.COMFY_DIR, capture_output=True, stdin=subprocess.DEVNULL, timeout=5, creationflags=self._NO_WIN
                )
                return r2.stdout.decode(errors='replace').strip() or 'N/A'
            except Exception:
                return 'N/A'

        def _get_frontend():
            return _installed_frontend_version() or 'N/A'

        def _get_ram():
            try:
                r = _ps('[math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB)')
                return r.stdout.decode(errors='replace').strip() + ' GB'
            except Exception:
                return 'N/A'

        def _get_pagefile():
            try:
                r = _ps(
                    "$u = Get-CimInstance Win32_PageFileUsage | Select-Object -First 1; "
                    "$s = Get-CimInstance Win32_PageFileSetting | Select-Object -First 1; "
                    "$max = if ($s) { $s.MaximumSize } else { 0 }; "
                    "$cur = if ($u) { $u.AllocatedBaseSize } else { 0 }; "
                    "Write-Output ($max.ToString() + '|' + $cur.ToString())"
                )
                out = r.stdout.decode(errors='replace').strip()
                if '|' in out:
                    max_mb, cur_mb = out.split('|', 1)
                    max_mb, cur_mb = int(max_mb.strip()), int(cur_mb.strip())
                    return f'Auto (current: {cur_mb} MB)' if max_mb == 0 else f'{max_mb} MB (current: {cur_mb} MB)'
            except Exception:
                pass
            return 'N/A'

        def _find_nvsmi():
            p = shutil.which('nvidia-smi')
            if p:
                return p
            import glob
            windir = os.environ.get('windir', r'C:\Windows')
            cands = [
                os.path.join(windir, 'System32', 'nvidia-smi.exe'),
                os.path.join(os.environ.get('ProgramFiles', r'C:\Program Files'), 'NVIDIA Corporation', 'NVSMI', 'nvidia-smi.exe'),
            ]
            cands += glob.glob(os.path.join(windir, 'System32', 'DriverStore', 'FileRepository', 'nv*', 'nvidia-smi.exe'))
            for c in cands:
                if os.path.isfile(c):
                    return c
            return None

        def _get_gpu():
            try:
                nvsmi = _find_nvsmi()
                if nvsmi:
                    r = subprocess.run(
                        [nvsmi, '--query-gpu=name,memory.total,driver_version', '--format=csv,noheader'],
                        capture_output=True, stdin=subprocess.DEVNULL, timeout=5, creationflags=self._NO_WIN
                    )
                    out = r.stdout.decode(errors='replace').strip()
                    names, vrams, driver = [], [], 'N/A'
                    for line in out.splitlines():
                        parts = [p.strip() for p in line.split(',')]
                        if not parts or not parts[0]:
                            continue
                        names.append(parts[0])
                        if len(parts) > 1:
                            try:
                                vrams.append(str(round(int(parts[1].replace('MiB', '').strip()) / 1024)) + ' GB')
                            except Exception:
                                pass
                        if len(parts) > 2 and driver == 'N/A':
                            driver = parts[2]
                    gpu = ' + '.join(names) if names else 'N/A'
                    vram = ' + '.join(vrams) if vrams else 'N/A'
                    return gpu, vram, driver
                else:
                    return 'Not detected', 'N/A', 'N/A'
            except Exception:
                return 'N/A', 'N/A', 'N/A'

        def _get_long_paths():
            try:
                r = subprocess.run(
                    ['reg', 'query', r'HKLM\SYSTEM\CurrentControlSet\Control\FileSystem', '/v', 'LongPathsEnabled'],
                    capture_output=True, stdin=subprocess.DEVNULL, timeout=5, creationflags=self._NO_WIN
                )
                return '0x1' in r.stdout.decode(errors='replace')
            except Exception:
                return False

        info = {}
        with ThreadPoolExecutor(max_workers=8) as ex:
            f_python     = ex.submit(_get_python)
            f_torch      = ex.submit(_get_torch)
            f_comfyui    = ex.submit(_get_comfyui)
            f_frontend   = ex.submit(_get_frontend)
            f_ram        = ex.submit(_get_ram)
            f_pagefile   = ex.submit(_get_pagefile)
            f_gpu        = ex.submit(_get_gpu)
            f_long_paths = ex.submit(_get_long_paths)

            info['python']                    = f_python.result()
            info['torch'], info['cuda']       = f_torch.result()
            info['comfyui']                   = f_comfyui.result()
            info['frontend']                  = f_frontend.result()
            info['ram']                       = f_ram.result()
            info['pagefile']                  = f_pagefile.result()
            info['gpu'], info['vram'], info['driver'] = f_gpu.result()
            info['long_paths']                = f_long_paths.result()

        return info

    def get_cache_sizes(self):
        import shutil

        def _dir_size_mb(path):
            total = 0
            try:
                for dirpath, _dirnames, filenames in os.walk(path):
                    for f in filenames:
                        try:
                            total += os.path.getsize(os.path.join(dirpath, f))
                        except Exception:
                            pass
            except Exception:
                pass
            return total

        def _fmt(b):
            if b <= 0:
                return '0 MB'
            mb = b / (1024 * 1024)
            if mb >= 1024:
                return f'{mb/1024:.2f} GB'
            if mb < 0.1:
                return '0 MB'
            return f'{mb:.1f} MB'

        pip_size = 0
        try:
            r = subprocess.run(
                [self.PY_EXE, '-m', 'pip', 'cache', 'dir'],
                capture_output=True, stdin=subprocess.DEVNULL, timeout=10, creationflags=self._NO_WIN
            )
            pip_dir = r.stdout.decode(errors='replace').strip()
            if pip_dir and os.path.isdir(pip_dir):
                pip_size = _dir_size_mb(pip_dir)
        except Exception:
            pass

        uv_size = 0
        try:
            uv_exe = os.path.join(ROOT_DIR, 'python_embeded', 'Scripts', 'uv.exe')
            if not os.path.exists(uv_exe):
                import shutil as _sh
                uv_exe = _sh.which('uv') or ''
            if uv_exe:
                r = subprocess.run(
                    [uv_exe, 'cache', 'dir'],
                    capture_output=True, stdin=subprocess.DEVNULL, timeout=10, creationflags=self._NO_WIN
                )
                uv_dir = r.stdout.decode(errors='replace').strip()
                if uv_dir and os.path.isdir(uv_dir):
                    uv_size = _dir_size_mb(uv_dir)
        except Exception:
            pass

        return {'pip': _fmt(pip_size), 'uv': _fmt(uv_size), 'keep': os.path.exists(KEEP_CACHE_FLAG_PATH)}

    def set_keep_cache(self, enabled):
        try:
            if enabled:
                open(KEEP_CACHE_FLAG_PATH, 'a').close()
            elif os.path.exists(KEEP_CACHE_FLAG_PATH):
                os.remove(KEEP_CACHE_FLAG_PATH)
        except Exception:
            _log_error('set_keep_cache')
        _apply_cache_env()
        return os.path.exists(KEEP_CACHE_FLAG_PATH)

    def clear_cache(self, cache_type):
        import shutil as _sh

        def _fmt(b):
            if b <= 0:
                return '0 MB'
            mb = b / (1024 * 1024)
            if mb >= 1024:
                return f'{mb/1024:.2f} GB'
            if mb < 0.1:
                return '0 MB'
            return f'{mb:.1f} MB'

        if cache_type == 'pip':
            try:
                subprocess.run(
                    [self.PY_EXE, '-m', 'pip', 'cache', 'purge'],
                    capture_output=True, stdin=subprocess.DEVNULL, timeout=30, creationflags=self._NO_WIN
                )
            except Exception:
                _log_error('clear_cache')
            size = 0
            try:
                r = subprocess.run(
                    [self.PY_EXE, '-m', 'pip', 'cache', 'dir'],
                    capture_output=True, stdin=subprocess.DEVNULL, timeout=10, creationflags=self._NO_WIN
                )
                pip_dir = r.stdout.decode(errors='replace').strip()
                if pip_dir and os.path.isdir(pip_dir):
                    for dp, _d, fs in os.walk(pip_dir):
                        for f in fs:
                            try:
                                size += os.path.getsize(os.path.join(dp, f))
                            except Exception:
                                pass
            except Exception:
                pass
            return {'size': _fmt(size)}

        if cache_type == 'uv':
            uv_exe = os.path.join(ROOT_DIR, 'python_embeded', 'Scripts', 'uv.exe')
            if not os.path.exists(uv_exe):
                uv_exe = _sh.which('uv') or ''
            if uv_exe:
                try:
                    r = subprocess.run(
                        [uv_exe, 'cache', 'dir'],
                        capture_output=True, stdin=subprocess.DEVNULL, timeout=10, creationflags=self._NO_WIN
                    )
                    uv_dir = r.stdout.decode(errors='replace').strip()
                except Exception:
                    uv_dir = ''

                try:
                    subprocess.run(
                        [uv_exe, 'cache', 'clean'],
                        capture_output=True, stdin=subprocess.DEVNULL, timeout=60, creationflags=self._NO_WIN
                    )
                except Exception:
                    _log_error('clear_cache')

                if uv_dir and os.path.isdir(uv_dir):
                    try:
                        _sh.rmtree(uv_dir, ignore_errors=True)
                    except Exception:
                        pass

            size = 0
            try:
                if uv_exe and uv_dir and os.path.isdir(uv_dir):
                    for dp, _d, fs in os.walk(uv_dir):
                        for f in fs:
                            try:
                                size += os.path.getsize(os.path.join(dp, f))
                            except Exception:
                                pass
            except Exception:
                pass
            return {'size': _fmt(size)}

    def check_output_folder(self):
        path = self._resolve_output_dir()
        return path or ""

    def get_frontend_versions(self):
        import urllib.request as _ur, json as _json
        current = _installed_frontend_version()
        try:
            with _ur.urlopen('https://pypi.org/pypi/comfyui-frontend-package/json', timeout=8) as r:
                data = _json.loads(r.read())
            all_versions = sorted(
                data.get('releases', {}).keys(),
                key=lambda v: [int(x) for x in v.replace('.post', '.').split('.') if x.isdigit()],
                reverse=True
            )
            versions = all_versions[:100]
            if current and current not in versions:
                versions.append(current)
                versions.sort(key=lambda v: [int(x) for x in v.replace('.post', '.').split('.') if x.isdigit()], reverse=True)
        except Exception:
            versions = [current] if current else []
        is_nightly = self.get_frontend_is_nightly()
        return {'current': current, 'versions': versions, 'isNightly': bool(is_nightly)}

    def get_frontend_is_nightly(self):
        import glob as _glob

        pkg_dir = _frontend_pkg_dir()
        if not pkg_dir:
            return None

        assets_dir = os.path.join(pkg_dir, 'static', 'assets')
        if not os.path.isdir(assets_dir):
            return None

        patterns = [
            re.compile(r'__IS_NIGHTLY__\s*[=:]\s*(true|false)', re.IGNORECASE),
            re.compile(r'isNightly\s*=\s*(true|false)',           re.IGNORECASE),
        ]

        js_files = sorted(
            _glob.glob(os.path.join(assets_dir, 'index-*.js')),
            key=os.path.getsize, reverse=True
        )
        if not js_files:
            js_files = _glob.glob(os.path.join(assets_dir, '*.js'))

        for js_path in js_files[:3]:
            try:
                with open(js_path, 'r', encoding='utf-8', errors='replace') as f:
                    chunk_size = 256 * 1024
                    prev_tail  = ''
                    while True:
                        chunk = f.read(chunk_size)
                        if not chunk:
                            break
                        search_text = prev_tail + chunk
                        for pat in patterns:
                            m = pat.search(search_text)
                            if m:
                                return m.group(1).lower() == 'true'
                        prev_tail = chunk[-200:]
            except Exception:
                continue

        return None

    def get_comfyui_required_frontend(self, tag):
        import re as _re, urllib.request as _ur
        if not tag or tag == 'NIGHTLY':
            return None

        def _parse_fe_version(line):
            m = _re.search(r'==\s*([^\s,;#]+)', line)
            return m.group(1).strip() if m else None

        def _find_in_lines(lines):
            for line in lines:
                line = line.strip()
                if line.lower().startswith('comfyui-frontend-package'):
                    return _parse_fe_version(line)
            return None

        try:
            r = subprocess.run(
                ['git', 'show', f'tags/{tag}:requirements.txt'],
                cwd=self.COMFY_DIR, capture_output=True, timeout=5,
                creationflags=self._NO_WIN
            )
            if r.returncode == 0:
                result = _find_in_lines(r.stdout.decode(errors='replace').splitlines())
                if result is not None:
                    return result
                return None
        except Exception:
            _log_error('get_comfyui_required_frontend')

        try:
            url = (f'https://raw.githubusercontent.com/comfyanonymous/ComfyUI'
                   f'/{tag}/requirements.txt')
            req = _ur.Request(url, headers={'User-Agent': 'ComfyUI-EZi'})
            with _ur.urlopen(req, timeout=8) as resp:
                text = resp.read().decode('utf-8', errors='replace')
            result = _find_in_lines(text.splitlines())
            if result is not None:
                return result
            return None
        except Exception:
            _log_error('get_comfyui_required_frontend')

        try:
            current_tag = None
            r = subprocess.run(
                ['git', 'describe', '--tags', '--exact-match', 'HEAD'],
                cwd=self.COMFY_DIR, capture_output=True, timeout=3,
                creationflags=self._NO_WIN
            )
            if r.returncode == 0:
                current_tag = r.stdout.strip().decode(errors='replace')
            if current_tag and current_tag == tag:
                req_path = os.path.join(self.COMFY_DIR, 'requirements.txt')
                if os.path.exists(req_path):
                    with open(req_path, 'r', encoding='utf-8', errors='replace') as f:
                        return _find_in_lines(f)
        except Exception:
            _log_error('get_comfyui_required_frontend')

        return None

    def get_comfyui_versions(self):
        import urllib.request as _ur, json as _json

        def _ver_key(tag):
            t = tag.lstrip('v')
            parts = []
            for x in t.replace('-', '.').split('.'):
                try: parts.append(int(x))
                except ValueError: parts.append(0)
            return parts

        current = None
        is_stable = False
        try:
            r = subprocess.run(
                ['git', 'describe', '--tags', '--exact-match', 'HEAD'],
                cwd=self.COMFY_DIR, capture_output=True, timeout=5, creationflags=self._NO_WIN
            )
            if r.returncode == 0:
                current = r.stdout.strip().decode(errors='replace')
                is_stable = True
        except Exception:
            _log_error('get_comfyui_versions')

        if not current:
            try:
                r2 = subprocess.run(
                    ['git', 'describe', '--tags', '--abbrev=0', 'HEAD'],
                    cwd=self.COMFY_DIR, capture_output=True, timeout=5, creationflags=self._NO_WIN
                )
                if r2.returncode == 0:
                    current = r2.stdout.strip().decode(errors='replace') or None
            except Exception:
                _log_error('get_comfyui_versions')

        local_tags = []
        try:
            r = subprocess.run(
                ['git', 'tag', '--sort=-version:refname'],
                cwd=self.COMFY_DIR, capture_output=True, timeout=5, creationflags=self._NO_WIN
            )
            local_tags = [t.strip() for t in r.stdout.decode(errors='replace').strip().splitlines() if t.strip()]
        except Exception:
            _log_error('get_comfyui_versions')

        remote_tags = []
        for page in (1, 2):
            try:
                req = _ur.Request(
                    f'https://api.github.com/repos/comfyanonymous/ComfyUI/tags?per_page=100&page={page}',
                    headers={'User-Agent': 'ComfyUI-EZi'}
                )
                with _ur.urlopen(req, timeout=8) as resp:
                    data = _json.loads(resp.read())
                batch = [t['name'] for t in data if t.get('name')]
                remote_tags.extend(batch)
                if len(batch) < 100:
                    break
            except Exception:
                break

        all_tags = list({t for t in (local_tags + remote_tags) if re.match(r'^v?\d+\.\d+', t)})
        all_tags.sort(key=_ver_key, reverse=True)
        all_tags = all_tags[:20]
        if current and current not in all_tags:
            all_tags.insert(0, current)
            all_tags = all_tags[:20]
        if not current:
            all_tags.insert(0, 'NIGHTLY')
            current = 'NIGHTLY'

        stable_version = self._stable_comfy_tag()

        return {'current': current, 'versions': all_tags, 'stableVersion': stable_version, 'isStable': bool(is_stable)}

    def set_comfyui_version(self, tag):
        threading.Thread(target=self._do_set_comfyui_version, args=(tag,), daemon=True).start()

    def _do_set_comfyui_version(self, tag):
        self._safe_eval("switchToConsole('Switching...')")
        self._println(f"\033[93m=== Switching ComfyUI to {tag} ===\033[0m")
        self._kill_running_proc()
        try:
            self._println("\033[93mFetching tags...\033[0m")
            subprocess.run(['git', 'fetch', '--tags', '--quiet'],
                           cwd=self.COMFY_DIR, capture_output=True, timeout=30, creationflags=self._NO_WIN)
            r = subprocess.run(['git', 'checkout', f'tags/{tag}'],
                               cwd=self.COMFY_DIR, capture_output=True, timeout=15, creationflags=self._NO_WIN)
            out = (r.stdout + r.stderr).decode(errors='replace').strip()
            if out:
                self._println(out)
            if r.returncode == 0:
                self._println(f"\033[92m=== Switched to {tag} ===\033[0m")
                if not self._pip_install_requirements():
                    self._println("\033[91m=== Requirements install failed ===\033[0m")
                    return
                self._println("\033[92m=== Restarting ComfyUI... ===\033[0m")
                self._safe_eval("switchToConsole()")
                self._restart_comfy()
                self._updating = False
            else:
                self._println(f"\033[91m=== Checkout failed (exit {r.returncode}) ===\033[0m")
        except Exception as e:
            self._println(f"\033[91mError: {e}\033[0m")

    def set_comfyui_version_then_frontend(self, tag, fe_version):
        threading.Thread(target=self._do_set_comfyui_version_then_frontend, args=(tag, fe_version), daemon=True).start()

    def _do_set_comfyui_version_then_frontend(self, tag, fe_version):
        self._safe_eval("switchToConsole('Switching...')")
        self._println(f"\033[93m=== Switching ComfyUI to {tag} + frontend {fe_version} ===\033[0m")
        self._kill_running_proc()
        try:
            self._println("\033[93mFetching tags...\033[0m")
            subprocess.run(['git', 'fetch', '--tags', '--quiet'],
                           cwd=self.COMFY_DIR, capture_output=True, timeout=30, creationflags=self._NO_WIN)
            r = subprocess.run(['git', 'checkout', f'tags/{tag}'],
                               cwd=self.COMFY_DIR, capture_output=True, timeout=15, creationflags=self._NO_WIN)
            out = (r.stdout + r.stderr).decode(errors='replace').strip()
            if out:
                self._println(out)
            if r.returncode != 0:
                self._println(f"\033[91m=== Checkout failed (exit {r.returncode}) ===\033[0m")
                return
            self._println(f"\033[92m=== Switched to {tag} ===\033[0m")
            if not self._pip_install_requirements():
                self._println("\033[91m=== Requirements install failed ===\033[0m")
                return
            if not fe_version:
                req_path = os.path.join(self.COMFY_DIR, 'requirements.txt')
                try:
                    with open(req_path, 'r', encoding='utf-8') as _f:
                        for _line in _f:
                            _line = _line.strip()
                            if _line.lower().startswith('comfyui-frontend-package'):
                                import re as _re
                                _m = _re.search(r'==\s*([^\s]+)', _line)
                                if _m:
                                    fe_version = _m.group(1)
                                break
                except Exception:
                    _log_error('_do_set_comfyui_version_then_frontend')
            if fe_version:
                if not self._pip_install_frontend(fe_version):
                    self._println("\033[91m=== Frontend install failed ===\033[0m")
                    return
                self._println(f"\033[92m=== Installed frontend {fe_version}. Restarting ComfyUI... ===\033[0m")
            else:
                self._println("\033[93m=== No matching frontend version found, skipping. Restarting ComfyUI... ===\033[0m")
            self._safe_eval("switchToConsole()")
            self._restart_comfy()
            self._updating = False
        except Exception as e:
            self._println(f"\033[91mError: {e}\033[0m")

    def _pip_install_requirements(self):
        req_path = os.path.join(self.COMFY_DIR, 'requirements.txt')
        if not os.path.exists(req_path):
            self._println("\033[93m=== requirements.txt not found, skipping ===\033[0m")
            return True
        self._println("\033[93m=== Installing ComfyUI requirements ===\033[0m")
        if self._stream_cmd(
                [self.PY_EXE, '-I', '-m', 'pip', 'install', '-r', req_path, '--no-warn-script-location'],
                cwd=ROOT_DIR, use_pty=True) != 0:
            return False
        mgr_req_path = os.path.join(self.COMFY_DIR, 'manager_requirements.txt')
        if os.path.exists(mgr_req_path):
            self._println("\033[93m=== Installing ComfyUI-Manager requirements ===\033[0m")
            return self._stream_cmd(
                [self.PY_EXE, '-I', '-m', 'pip', 'install', '-r', mgr_req_path, '--no-warn-script-location'],
                cwd=ROOT_DIR, use_pty=True) == 0
        return True

    def _pip_install_frontend(self, version):
        self._println(f"\033[93m=== Installing comfyui-frontend-package=={version} ===\033[0m")
        return self._stream_cmd(
            [self.PY_EXE, '-m', 'pip', 'install', f'comfyui-frontend-package=={version}',
             '--no-warn-script-location'],
            cwd=ROOT_DIR, use_pty=True) == 0

    def set_frontend_version(self, version):
        threading.Thread(target=self._do_set_frontend_version, args=(version,), daemon=True).start()

    def _do_set_frontend_version(self, version):
        self._safe_eval("switchToConsole('Installing...')")
        try:
            if self._pip_install_frontend(version):
                self._println("\033[92m=== Installed. Restarting ComfyUI... ===\033[0m")
                self._kill_running_proc()
                time.sleep(1)
                self._safe_eval("switchToConsole()")
                self._restart_comfy()
                self._updating = False
            else:
                self._println("\033[91m=== Installation failed ===\033[0m")
        except Exception as e:
            self._println(f"\033[91mError: {e}\033[0m")

    def get_bat_state(self, rel_paths):
        exists = []
        for rel in rel_paths or []:
            rel_clean = str(rel).lstrip('./\\').replace('\\\\', '\\')
            exists.append(os.path.exists(os.path.normpath(os.path.join(ROOT_DIR, rel_clean))))
        torch_ver = ''
        try:
            version_file = os.path.join(ROOT_DIR, 'python_embeded', 'Lib', 'site-packages', 'torch', 'version.py')
            with open(version_file, 'r', encoding='utf-8', errors='replace') as f:
                m = re.search(r'__version__\s*=\s*["\']([^"\']+)["\']', f.read())
            torch_ver = m.group(1) if m else ''
        except Exception:
            torch_ver = ''
        return {'exists': exists, 'torch': torch_ver}

    def run_bat(self, rel_path):
        if self._updating:
            return
        rel_clean = rel_path.lstrip('./\\').replace('\\\\', '\\')
        bat = os.path.normpath(os.path.join(ROOT_DIR, rel_clean))
        if not os.path.exists(bat):
            self._safe_eval(f"show_update_missing({json.dumps(os.path.dirname(bat))}, {json.dumps(os.path.basename(bat))})")
            return
        threading.Thread(target=self._do_run_bat, args=(bat,), daemon=True).start()

    def _do_run_bat(self, bat, status_label=None, hide_update_notice=False):
        name = os.path.basename(bat)
        is_ezi_update = name.lower() == "update easy-install.bat"
        label = status_label or f'Running {name}...'
        self._updating = True
        self._safe_eval(f"switchToConsole({json.dumps(label)})")
        if is_ezi_update:
            self._safe_eval("show_ezi_updating();")
        else:
            self._safe_eval("document.getElementById('update-notice').style.display='none';")
        if self._proc is not None:
            self._println("\033[93m=== Stopping ComfyUI ===\033[0m")
        self._kill_running_proc()
        self._println(f"\033[93m=== Running {name} ===\033[0m")
        try:
            self._stream_cmd(
                ['cmd', '/c', 'chcp', '65001', '>', 'nul', '&&', bat, 'NoPause', '<', 'nul'],
                cwd=os.path.dirname(bat), use_pty=True, stdin_devnull=True)
        except Exception as e:
            self._println(f"\033[91mError running {name}: {e}\033[0m")
        
        self._println(f"\033[92m=== {name} finished. ===\033[0m")
        
        if hide_update_notice:
            self._safe_eval("document.getElementById('update-notice').style.display='none';")

        if is_ezi_update:
            if os.path.exists(EZI_ZIP_PATH):
                self._ezi_update_failed()
                return
            self._println("\033[92mRestarting ComfyUI-EZi...\033[0m")
            time.sleep(1)
            self.restart_ezi()
        else:
            self._println("\033[92mRestarting ComfyUI...\033[0m")
            time.sleep(1)
            self._safe_eval("switchToConsole()")
            self._restart_comfy(check_update=True)
            self._updating = False

    def open_output_folder(self):
        path = self._resolve_output_dir()
        if not path:
            return
        try:
            custom_browser = self._settings.get("custom_file_browser", "").strip()
            if custom_browser and os.path.isfile(custom_browser):
                subprocess.Popen([custom_browser, path])
            else:
                subprocess.Popen(['explorer', path])
        except Exception as e:
            self._println(f"[Output] Could not open folder: {e}\n")

    def _open_folder_path(self, path):
        if not path or not os.path.isdir(path):
            return False
        try:
            custom_browser = self._settings.get("custom_file_browser", "").strip()
            if custom_browser and os.path.isfile(custom_browser):
                subprocess.Popen([custom_browser, path])
            else:
                subprocess.Popen(['explorer', path])
            return True
        except Exception as e:
            self._println(f"[Folder] Could not open folder: {e}\n")
            return False

    def _resolve_input_dir(self):
        try:
            bat_content = _read_bat()
            if bat_content is not None:
                d = (_bat_env(bat_content, 'COMFY_INPUT_DIR')
                     or _bat_flag_value(_bat_args(bat_content), '--input-directory'))
                if d:
                    if not os.path.isabs(d):
                        d = os.path.normpath(os.path.join(ROOT_DIR, d))
                    return d if os.path.isdir(d) else None
        except Exception:
            pass
        d = os.path.normpath(os.path.join(ROOT_DIR, 'ComfyUI', 'input'))
        return d if os.path.isdir(d) else None

    def _resolve_workflows_dir(self):
        user_dir = _get_comfy_user_dir()
        d = os.path.join(user_dir, 'workflows')
        return d if os.path.isdir(d) else None

    def _resolve_models_dir(self):
        yaml_path = os.path.normpath(os.path.join(ROOT_DIR, 'ComfyUI', 'extra_model_paths.yaml'))
        if os.path.exists(yaml_path):
            try:
                with open(yaml_path, 'r', encoding='utf-8', errors='replace') as f:
                    content = f.read()

                base_path = None
                m_base = re.search(r'^\s+base_path\s*:\s*(.+)$', content, re.MULTILINE)
                if m_base:
                    base_path = m_base.group(1).strip().strip('"\'').rstrip('/\\')

                if base_path:
                    parent_votes = {}
                    for line in content.splitlines():
                        stripped = line.strip()
                        if (not stripped or stripped.startswith('#')
                                or re.match(r'(?i)base_path\s*:', stripped)
                                or re.match(r'(?i)is_default\s*:', stripped)):
                            continue
                        m_kv = re.match(r'^(\s{2,})\S[^:]+:\s*(.+)$', line)
                        if not m_kv:
                            continue
                        raw_val = m_kv.group(2).strip().strip('"\'').rstrip('/\\')
                        if not raw_val:
                            continue

                        if os.path.isabs(raw_val):
                            parent = os.path.normpath(os.path.dirname(raw_val))
                        else:
                            first_component = raw_val.replace('/', '\\').split('\\')[0]
                            parent = os.path.normpath(os.path.join(base_path, first_component))

                        if os.path.isdir(parent):
                            parent_votes[parent] = parent_votes.get(parent, 0) + 1

                    if parent_votes:
                        best = max(parent_votes, key=lambda p: parent_votes[p])
                        return best

            except Exception:
                _log_error('_resolve_models_dir')
        d = os.path.normpath(os.path.join(ROOT_DIR, 'ComfyUI', 'models'))
        return d if os.path.isdir(d) else None

    def open_sub_folder(self, folder_type):
        if folder_type == 'input':
            path = self._resolve_input_dir()
        elif folder_type == 'workflows':
            path = self._resolve_workflows_dir()
        elif folder_type == 'models':
            path = self._resolve_models_dir()
        else:
            return
        if not self._open_folder_path(path):
            self._println(f"[Folder] '{folder_type}' folder not found.\n")

    def browse_for_exe(self):
        try:
            result = self._window.create_file_dialog(
                webview.OPEN_DIALOG,
                allow_multiple=False,
                file_types=('Executable files (*.exe)', 'All files (*.*)')
            )
            if result and result[0]:
                return result[0]
        except Exception:
            pass
        return None

    def browse_for_folder(self):
        try:
            result = self._window.create_file_dialog(
                webview.FOLDER_DIALOG,
                allow_multiple=False
            )
            if result and result[0]:
                return result[0]
        except Exception:
            pass
        return None

    def browse_for_image(self):
        try:
            result = self._window.create_file_dialog(
                webview.OPEN_DIALOG,
                allow_multiple=False,
                file_types=('Image files (*.png;*.jpg;*.jpeg;*.webp;*.svg)', 'All files (*.*)')
            )
            if result and result[0]:
                return result[0]
        except Exception:
            pass
        return None

    def apply_console_bg(self):
        custom_bg  = self._settings.get("console_bg_image", "").strip()
        bg_fit     = self._settings.get("console_bg_fit", "fit")
        opacity    = float(self._settings.get("console_bg_opacity", 0.12))

        _ico_css, ico_w, ico_h = _load_ico_as_base64()

        if custom_bg and os.path.isfile(custom_bg):
            ext  = os.path.splitext(custom_bg)[1].lower().lstrip(".")
            mime = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg",
                    "webp": "image/webp", "svg": "image/svg+xml"}.get(ext, "image/png")
            try:
                with open(custom_bg, "rb") as _f:
                    b64 = base64.b64encode(_f.read()).decode()
                css_url = f'url("data:{mime};base64,{b64}")'
            except Exception:
                css_url = ""
            fit_map = {
                "fit":     ("contain",   "no-repeat"),
                "stretch": ("100% 100%", "no-repeat"),
                "tile":    ("auto",      "repeat"),
                "center":  ("auto",      "no-repeat"),
            }
            bg_size, bg_repeat = fit_map.get(bg_fit, ("contain", "no-repeat"))
            js = f"""
(function(){{
    var el = document.getElementById('ico-bg');
    if (!el) return;
    el.style.backgroundImage    = {json.dumps(css_url)};
    el.style.backgroundSize     = {json.dumps(bg_size)};
    el.style.backgroundRepeat   = {json.dumps(bg_repeat)};
    el.style.backgroundPosition = 'center';
    el.style.opacity   = {opacity};
    el.style.inset     = '0';
    el.style.width     = 'auto';
    el.style.height    = 'auto';
    el.style.transform = 'none';
}})();
"""
        else:
            css_url = _ico_css
            bg_size = f"{ico_w}px {ico_h}px" if _ico_css else "256px 256px"

            js = (
                "(function(){{"
                "var el = document.getElementById('ico-bg');"
                "if (!el) return;"
                f"el.style.backgroundImage    = {json.dumps(css_url)};"
                f"el.style.backgroundSize     = {json.dumps(bg_size)};"
                "el.style.backgroundRepeat   = 'no-repeat';"
                "el.style.backgroundPosition = 'center';"
                f"el.style.opacity            = '{opacity}';"
                "el.style.inset              = 'unset';"
                f"el.style.width              = '{ico_w}px';"
                f"el.style.height             = '{ico_h}px';"
                "el.style.top                = '50%';"
                "el.style.left               = '50%';"
                "el.style.transform          = 'translate(-50%, -50%)';"
                "}})()"
            )
        self._safe_eval(js)
        win = self._console_win
        if win is not None:
            try:
                win.evaluate_js(js)
            except Exception:
                pass


    def get_startup_args(self):
        try:
            bat_content = _read_bat()
            if bat_content is None:
                return ""
            tokens = _bat_args(bat_content)
            
            MANAGED_WITH_VAL = {
                '--input-directory', '--output-directory', '--user-directory',
            }
            MANAGED_FLAG = {'--windows-standalone-build', *_MANAGER_BAT_FLAGS}
            _req_attn = _required_attn_flag(BAT_FILE)
            if _req_attn:
                MANAGED_FLAG = MANAGED_FLAG | {_req_attn}
            
            script_idx = None
            for idx, tok in enumerate(tokens):
                if re.search(r'main\.py', tok, re.IGNORECASE):
                    script_idx = idx
                    break
            if script_idx is None:
                return ""
            post = tokens[script_idx + 1:]
            extra = []
            i = 0
            while i < len(post):
                tok = post[i]
                if tok in MANAGED_WITH_VAL:
                    i += 2
                elif tok in MANAGED_FLAG:
                    i += 1
                else:
                    extra.append(tok)
                    i += 1
            return ' '.join(extra)
        except Exception:
            return ""

    def set_startup_args(self, args_str):
        args_str = (args_str or '').strip()

        MANAGED_WITH_VAL = {
            '--input-directory', '--output-directory', '--user-directory',
        }
        MANAGED_FLAG = {'--windows-standalone-build', *_MANAGER_BAT_FLAGS}

        for bat_name in BAT_NAMES:
            bat_path = os.path.join(ROOT_DIR, bat_name)
            if not os.path.exists(bat_path):
                continue
            try:
                with open(bat_path, 'r', encoding='utf-8', errors='replace') as f:
                    content = f.read()
                lines = content.splitlines(keepends=True)
                start_idx = end_idx = None
                logical_line = None
                i = 0
                while i < len(lines):
                    stripped = lines[i].rstrip('\r\n')
                    accumulated = stripped
                    j = i
                    while accumulated.rstrip().endswith('^') and j + 1 < len(lines):
                        accumulated = accumulated.rstrip()[:-1] + ' ' + lines[j + 1].lstrip().rstrip('\r\n')
                        j += 1
                    acc_s = accumulated.strip()
                    if (acc_s and
                            not acc_s.startswith('::') and
                            not re.match(r'(?i)^rem(\s|$)', acc_s) and
                            re.search(r'python_embeded[/\\]python\.exe', acc_s, re.IGNORECASE) and
                            re.search(r'ComfyUI[/\\]main\.py', acc_s, re.IGNORECASE)):
                        start_idx = i
                        end_idx = j
                        logical_line = acc_s
                        break
                    i += 1
                if logical_line is None or start_idx is None:
                    continue
                m = re.search(r'(.*python_embeded[/\\]python\.exe["\'"]?)\s+(.*)',
                              logical_line, re.IGNORECASE | re.DOTALL)
                if not m:
                    continue
                py_prefix = m.group(1)
                rest = m.group(2).strip()
                tokens = shlex.split(rest, posix=False)
                script_idx = None
                for idx2, tok in enumerate(tokens):
                    if re.search(r'main\.py', tok, re.IGNORECASE):
                        script_idx = idx2
                        break
                if script_idx is None:
                    continue
                pre_script = tokens[:script_idx + 1]
                post_script = tokens[script_idx + 1:]
                _req_attn = _required_attn_flag(bat_path)
                _mflag = (MANAGED_FLAG | {_req_attn}) if _req_attn else MANAGED_FLAG
                kept_managed = []
                k = 0
                while k < len(post_script):
                    tok = post_script[k]
                    if tok in MANAGED_WITH_VAL:
                        kept_managed.append(tok)
                        if k + 1 < len(post_script):
                            kept_managed.append(post_script[k + 1])
                            k += 2
                        else:
                            k += 1
                    elif tok in _mflag:
                        kept_managed.append(tok)
                        k += 1
                    else:
                        k += 1
                
                if '--windows-standalone-build' not in kept_managed:
                    kept_managed.append('--windows-standalone-build')
                if _req_attn and _req_attn not in kept_managed:
                    kept_managed.append(_req_attn)

                new_extra = shlex.split(args_str, posix=False) if args_str else []
                _parsed = []
                _i2 = 0
                while _i2 < len(new_extra):
                    _tok = new_extra[_i2]
                    if _tok.startswith('-'):
                        if _i2 + 1 < len(new_extra) and not new_extra[_i2 + 1].startswith('-'):
                            _parsed.append((_tok, new_extra[_i2 + 1]))
                            _i2 += 2
                        else:
                            _parsed.append((_tok, None))
                            _i2 += 1
                    else:
                        _parsed.append((None, _tok))
                        _i2 += 1
                _managed_all = MANAGED_WITH_VAL | _mflag
                if _req_attn:
                    _managed_all = _managed_all | set(_ATTN_BAT_FLAGS.values())
                _seen_flags = set()
                _deduped = []
                for _flag, _val in reversed(_parsed):
                    if _flag is None:
                        _deduped.insert(0, (None, _val))
                        continue
                    if _flag in _managed_all:
                        continue
                    if _flag not in _seen_flags:
                        _seen_flags.add(_flag)
                        _deduped.insert(0, (_flag, _val))
                filtered_extra = []
                for _flag, _val in _deduped:
                    if _flag is not None:
                        filtered_extra.append(_flag)
                    if _val is not None:
                        filtered_extra.append(_val)
                if '--disable-manager-ui' in filtered_extra and '--enable-manager-legacy-ui' in kept_managed:
                    kept_managed = [_t for _t in kept_managed if _t != '--enable-manager-legacy-ui']
                    if '--enable-manager' not in kept_managed:
                        kept_managed.append('--enable-manager')
                rebuilt = kept_managed + filtered_extra
                new_cmd_parts = [py_prefix] + pre_script + rebuilt
                new_line = ' '.join(new_cmd_parts)
                orig_ending = '\r\n' if '\r\n' in lines[start_idx] else '\n'
                new_lines = (
                    lines[:start_idx] +
                    [new_line + orig_ending] +
                    lines[end_idx + 1:]
                )
                with open(bat_path, 'w', encoding='utf-8', newline='') as f:
                    f.write(''.join(new_lines))
            except Exception as e:
                self._println(f"[StartupArgs] Error updating {bat_name}: {e}\n")

        self._println("\n[StartupArgs] Restarting ComfyUI-EZi to apply new startup arguments...\n")
        
        self.restart_ezi()

    def get_custom_paths(self):
        paths = {'input': '', 'output': '', 'user': ''}
        try:
            bat_content = _read_bat()
            if bat_content is None:
                return json.dumps(paths)
            tokens = _bat_args(bat_content)
            param_map = {
                '--input-directory':  'input',
                '--output-directory': 'output',
                '--user-directory':   'user',
            }
            i = 0
            while i < len(tokens):
                tok = tokens[i]
                if tok in param_map and i + 1 < len(tokens):
                    paths[param_map[tok]] = tokens[i + 1].strip('"\'')
                    i += 2
                else:
                    i += 1
        except Exception:
            pass
        return json.dumps(paths)

    def set_custom_paths(self, input_dir, output_dir, user_dir):
        new_vals = {
            '--input-directory':  input_dir.strip().strip('"'),
            '--output-directory': output_dir.strip().strip('"'),
            '--user-directory':   user_dir.strip().strip('"'),
        }

        for bat_name in BAT_NAMES:
            bat_path = os.path.join(ROOT_DIR, bat_name)
            if not os.path.exists(bat_path):
                continue
            try:
                with open(bat_path, 'r', encoding='utf-8', errors='replace') as f:
                    content = f.read()

                lines = content.splitlines(keepends=True)

                i = 0
                start_idx = None
                end_idx = None
                logical_line = None

                while i < len(lines):
                    stripped = lines[i].rstrip('\r\n')
                    accumulated = stripped
                    j = i
                    while accumulated.rstrip().endswith('^') and j + 1 < len(lines):
                        accumulated = accumulated.rstrip()[:-1] + ' ' + lines[j + 1].lstrip().rstrip('\r\n')
                        j += 1

                    acc_s = accumulated.strip()
                    if (acc_s and
                            not acc_s.startswith('::') and
                            not re.match(r'(?i)^rem(\s|$)', acc_s) and
                            re.search(r'python_embeded[/\\]python\.exe', acc_s, re.IGNORECASE) and
                            re.search(r'ComfyUI[/\\]main\.py', acc_s, re.IGNORECASE)):
                        start_idx = i
                        end_idx = j
                        logical_line = acc_s
                        break
                    i += 1

                if logical_line is None or start_idx is None:
                    continue

                m = re.search(r'(.*python_embeded[/\\]python\.exe["\']?)\s+(.*)',
                              logical_line, re.IGNORECASE | re.DOTALL)
                if not m:
                    continue
                py_prefix = m.group(1)
                rest = m.group(2).strip()

                tokens = shlex.split(rest, posix=False)

                script_idx = None
                for idx, tok in enumerate(tokens):
                    if re.search(r'main\.py', tok, re.IGNORECASE):
                        script_idx = idx
                        break

                if script_idx is None:
                    continue

                pre_script = tokens[:script_idx + 1]
                post_script = tokens[script_idx + 1:]

                SINGLE_VAL_PARAMS = {
                    '--input-directory', '--output-directory', '--user-directory',
                    '--port', '--tls-keyfile', '--tls-certfile', '--max-upload-size',
                    '--base-directory', '--temp-directory', '--cuda-device',
                    '--default-device', '--oneapi-device-selector', '--preview-size',
                    '--cache-lru', '--reserve-vram', '--vram-headroom',
                    '--default-hashing-function',
                    '--front-end-version', '--front-end-root', '--comfy-api-base',
                    '--database-url', '--models-directory', '--feature-flag',
                }
                rebuilt = []
                k = 0
                while k < len(post_script):
                    tok = post_script[k]
                    if tok in new_vals:
                        k += 2 if (k + 1 < len(post_script)) else 1
                    elif tok in SINGLE_VAL_PARAMS:
                        rebuilt.append(tok)
                        if k + 1 < len(post_script):
                            rebuilt.append(post_script[k + 1])
                            k += 2
                        else:
                            k += 1
                    else:
                        rebuilt.append(tok)
                        k += 1

                for param, val in new_vals.items():
                    if val:
                        rebuilt.extend([param, f'"{val}"'])

                new_cmd_parts = [py_prefix] + pre_script + rebuilt
                new_line = ' '.join(new_cmd_parts)

                orig_ending = '\r\n' if '\r\n' in lines[start_idx] else '\n'

                new_lines = (
                    lines[:start_idx] +
                    [new_line + orig_ending] +
                    lines[end_idx + 1:]
                )

                with open(bat_path, 'w', encoding='utf-8', newline='') as f:
                    f.write(''.join(new_lines))

            except Exception as e:
                self._println(f"[CustomPaths] Error updating {bat_name}: {e}\n")

        self._println("\n[CustomPaths] Restarting ComfyUI to apply new folder settings...\n")
        self._safe_eval("switchToConsole('Restarting...')")
        self._kill_running_proc()
        self._restart_comfy(check_update=False)

    def _sync_model_paths(self):
        try:
            res = _mp_sync()
        except Exception:
            _log_error('_sync_model_paths')
            return
        for r in res.get('missing', []):
            self._println(f"\033[93m[Models] Folder not found: {r}\033[0m")
        if res.get('changed'):
            self._println("\033[92m[Models] extra_model_paths.yaml updated\033[0m")
            for r, names in res.get('added', []):
                self._println(f"\033[2m  {r}: +{', '.join(names)}\033[0m")

    def get_model_roots(self):
        try:
            text = _mp_read_text(_mp_yaml_path())
            roots = []
            if text is not None:
                _raw, blocks = _mp_parse(text)
                for b in blocks:
                    subs = _mp_subdirs(b['root'])
                    roots.append({'path': b['root'], 'exists': subs is not None, 'count': len(subs or [])})
            return json.dumps({'yaml': text is not None, 'roots': roots})
        except Exception:
            _log_error('get_model_roots')
            return json.dumps({'yaml': False, 'roots': []})

    def validate_model_root(self, path, current_json):
        try:
            current = json.loads(current_json) or []
        except Exception:
            current = []
        try:
            return json.dumps(_mp_validate(path, current))
        except Exception:
            _log_error('validate_model_root')
            return json.dumps({'ok': False, 'error': 'Could not read this folder.'})

    def set_model_roots(self, roots_json):
        try:
            roots = [str(r) for r in (json.loads(roots_json) or []) if str(r).strip()]
            res = _mp_sync(roots=roots, backup=True)
            for r in res.get('missing', []):
                self._println(f"\033[93m[Models] Folder not found: {r}\033[0m")
            if res.get('changed'):
                self._println(f"\033[92m[Models] extra_model_paths.yaml saved ({res.get('count', 0)} folder(s))\033[0m")
            return json.dumps({'ok': True, 'changed': bool(res.get('changed'))})
        except Exception:
            _log_error('set_model_roots')
            return json.dumps({'ok': False})

    def manager_config_exists(self):
        return os.path.exists(_get_manager_config_path())

    def get_security_level(self):
        try:
            config_path = _get_manager_config_path()
            if not os.path.exists(config_path):
                return 'weak'
            import configparser
            cfg = configparser.ConfigParser(strict=False, interpolation=None)
            cfg.read(config_path, encoding='utf-8')
            level = cfg.get('default', 'security_level', fallback='weak').strip()
            if level not in ('weak', 'normal-', 'normal', 'strong'):
                level = 'weak'
            return level
        except Exception:
            return 'weak'

    def set_security_level(self, level):
        if level not in ('weak', 'normal-', 'normal', 'strong'):
            return False
        try:
            config_path = _get_manager_config_path()
            if not os.path.exists(config_path):
                return False
            import configparser
            cfg = configparser.ConfigParser(strict=False, interpolation=None)
            cfg.read(config_path, encoding='utf-8')
            if not cfg.has_section('default'):
                cfg.add_section('default')
            cfg.set('default', 'security_level', level)
            tmp = config_path + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                cfg.write(f)
            os.replace(tmp, config_path)
            self._println(f"\n[Manager] Security level set to '{level}'. Restarting ComfyUI...\n")
            self._safe_eval("switchToConsole('Restarting...')")
            self._kill_running_proc()
            self._restart_comfy(check_update=False)
            return True
        except Exception:
            return False

    def get_manager_settings(self):
        result = {
            "configExists": False,
            "ui": "classic",
            "securityLevel": "normal",
            "allowGitUrl": False,
            "allowPip": False,
            "classicAvailable": os.path.isdir(os.path.join(ROOT_DIR, 'ComfyUI', 'custom_nodes', 'comfyui-manager')),
        }
        try:
            bat_content = _read_bat()
            if bat_content is not None:
                ui_now = _bat_manager_ui(bat_content)
                result["ui"] = 'classic' if ui_now == 'off' else ui_now
            config_path = _get_manager_config_path()
            if os.path.exists(config_path):
                import configparser
                cfg = configparser.ConfigParser(strict=False, interpolation=None)
                cfg.read(config_path, encoding='utf-8')
                level = cfg.get('default', 'security_level', fallback='normal').strip().lower()
                if level not in _MANAGER_SECURITY_LEVELS:
                    level = 'normal'
                result["configExists"] = True
                result["securityLevel"] = level
                result["allowGitUrl"] = cfg.get('default', 'allow_git_url_install', fallback='False').strip().lower() == 'true'
                result["allowPip"] = cfg.get('default', 'allow_pip_install', fallback='False').strip().lower() == 'true'
        except Exception:
            _log_error('get_manager_settings')
        return json.dumps(result)

    def set_manager_settings(self, payload_json):
        try:
            payload = json.loads(payload_json)
            if not isinstance(payload, dict):
                return False
        except Exception:
            return False
        try:
            ui = payload.get('ui')
            level = payload.get('securityLevel')
            if ui not in ('classic', 'legacy', 'new', None):
                return False
            if ui == 'classic' and not os.path.isdir(os.path.join(ROOT_DIR, 'ComfyUI', 'custom_nodes', 'comfyui-manager')):
                current_ui = _bat_manager_ui(_read_bat() or '')
                if current_ui != 'off':
                    return False
            if level is not None and level not in _MANAGER_SECURITY_LEVELS:
                return False
            config_path = _get_manager_config_path()
            if os.path.exists(config_path):
                import configparser
                cfg = configparser.ConfigParser(strict=False, interpolation=None)
                cfg.read(config_path, encoding='utf-8')
                if not cfg.has_section('default'):
                    cfg.add_section('default')
                if level is not None:
                    cfg.set('default', 'security_level', level)
                for key, name in (('allowGitUrl', 'allow_git_url_install'), ('allowPip', 'allow_pip_install')):
                    if isinstance(payload.get(key), bool):
                        cfg.set('default', name, 'True' if payload[key] else 'False')
                tmp = config_path + '.tmp'
                with open(tmp, 'w', encoding='utf-8') as f:
                    cfg.write(f)
                os.replace(tmp, config_path)
            ui_changed = False
            if ui is not None:
                bat_content = _read_bat()
                current = _bat_manager_ui(bat_content) if bat_content is not None else 'off'
                current = 'classic' if current == 'off' else current
                if ui != current:
                    ui_changed = _apply_manager_ui_to_bats(ui)
            self._println("\n[Manager] Settings updated. Restarting ComfyUI...\n")
            if ui_changed:
                self.restart_ezi()
                return True
            self._safe_eval("switchToConsole('Restarting...')")
            self._kill_running_proc()
            self._restart_comfy(check_update=False)
            return True
        except Exception:
            _log_error('set_manager_settings')
            return False

    def get_pinned_packages(self):
        try:
            if os.path.exists(SETTINGS_PATH):
                with open(SETTINGS_PATH, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                return json.dumps(data.get('pinned_packages') or [])
        except Exception:
            _log_error('get_pinned_packages')
        return json.dumps([])

    def set_pinned_packages(self, packages_json):
        try:
            packages = json.loads(packages_json)
            if not isinstance(packages, list):
                return False
            existing = {}
            try:
                if os.path.exists(SETTINGS_PATH):
                    with open(SETTINGS_PATH, 'r', encoding='utf-8') as f:
                        existing = json.load(f)
            except Exception:
                _log_error('set_pinned_packages')
            existing['pinned_packages'] = packages
            tmp = SETTINGS_PATH + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(existing, f, indent=2, ensure_ascii=False)
            os.replace(tmp, SETTINGS_PATH)
            if isinstance(self._settings, dict):
                self._settings['pinned_packages'] = packages
            return True
        except Exception:
            return False

    def check_pinned_packages(self, packages_json=None):
        try:
            packages = None
            if packages_json:
                try:
                    _p = json.loads(packages_json)
                    if isinstance(_p, list):
                        packages = [str(x) for x in _p]
                except Exception:
                    packages = None
            if packages is None:
                if os.path.exists(SETTINGS_PATH):
                    with open(SETTINGS_PATH, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                    packages = data.get('pinned_packages') or []
                else:
                    packages = []
            results = []
            for entry in packages:
                entry = entry.strip()
                if not entry:
                    continue
                if '==' in entry:
                    pkg, ver = entry.split('==', 1)
                    pkg = pkg.strip()
                    ver = ver.strip()
                else:
                    results.append({'pkg': entry, 'status': 'unknown'})
                    continue
                try:
                    r = subprocess.run(
                        [self.PY_EXE, '-c',
                         f'import importlib.metadata as _im; print(_im.version({pkg!r}))'],
                        capture_output=True, timeout=8,
                        creationflags=self._NO_WIN
                    )
                    if r.returncode == 0:
                        installed = r.stdout.decode(errors='replace').strip()
                        status = 'ok' if installed == ver else 'mismatch'
                        results.append({'pkg': entry, 'status': status, 'installed': installed})
                    else:
                        results.append({'pkg': entry, 'status': 'missing'})
                except Exception:
                    results.append({'pkg': entry, 'status': 'unknown'})
            return json.dumps(results)
        except Exception:
            return json.dumps([])

    def open_url(self, url):
        try:
            import webbrowser
            webbrowser.open(url)
        except Exception:
            pass

    def screenshot(self, x, y, w, h):
        self._cap_win = None
        threading.Thread(target=self._do_screenshot, args=(x, y, w, h), daemon=True).start()

    def start_recording(self, x, y, w, h, fps=15):
        self._cap_win = None
        threading.Thread(target=self._do_start_recording, args=(x, y, w, h, int(fps)), daemon=True).start()

    def console_screenshot(self, x, y, w, h):
        self._cap_win = self._console_win
        threading.Thread(target=self._do_screenshot, args=(x, y, w, h), daemon=True).start()

    def console_start_recording(self, x, y, w, h, fps=15):
        self._cap_win = self._console_win
        threading.Thread(target=self._do_start_recording, args=(x, y, w, h, int(fps)), daemon=True).start()

    def stop_recording(self):
        if hasattr(self, '_rec_stop_event') and self._rec_stop_event:
            self._rec_stop_event.set()

    def _make_gdi_capture_ctx(self, hwnd, x, y, w, h, even=True, cursor=True):
        import ctypes, ctypes.wintypes as wt
        gdi  = ctypes.windll.gdi32
        user = ctypes.windll.user32
        _vp  = ctypes.c_void_p

        gdi.CreateCompatibleDC.restype       = _vp
        gdi.CreateCompatibleDC.argtypes      = [_vp]
        gdi.CreateCompatibleBitmap.restype   = _vp
        gdi.CreateCompatibleBitmap.argtypes  = [_vp, ctypes.c_int, ctypes.c_int]
        gdi.SelectObject.restype             = _vp
        gdi.SelectObject.argtypes            = [_vp, _vp]
        gdi.DeleteObject.restype             = wt.BOOL
        gdi.DeleteObject.argtypes            = [_vp]
        gdi.DeleteDC.restype                 = wt.BOOL
        gdi.DeleteDC.argtypes                = [_vp]
        gdi.BitBlt.restype                   = wt.BOOL
        gdi.BitBlt.argtypes                  = [_vp, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                               ctypes.c_int, _vp, ctypes.c_int, ctypes.c_int, wt.DWORD]
        gdi.GetDIBits.restype                = ctypes.c_int
        gdi.GetDIBits.argtypes               = [_vp, _vp, wt.UINT, wt.UINT,
                                               ctypes.c_void_p, ctypes.c_void_p, wt.UINT]
        user.GetDC.restype                   = _vp
        user.GetDC.argtypes                  = [_vp]
        user.ReleaseDC.restype               = ctypes.c_int
        user.ReleaseDC.argtypes              = [_vp, _vp]
        user.DrawIconEx.restype              = wt.BOOL
        user.DrawIconEx.argtypes             = [_vp, ctypes.c_int, ctypes.c_int, _vp,
                                               ctypes.c_int, ctypes.c_int, wt.UINT, _vp, wt.UINT]
        user.ClientToScreen.restype          = wt.BOOL
        user.ClientToScreen.argtypes         = [_vp, ctypes.c_void_p]
        user.GetCursorInfo.restype           = wt.BOOL
        user.GetIconInfo.restype             = wt.BOOL
        user.SetThreadDpiAwarenessContext.argtypes = [_vp]
        user.SetThreadDpiAwarenessContext.restype  = _vp
        user.GetDpiForWindow.argtypes        = [_vp]
        user.GetDpiForWindow.restype         = wt.UINT

        try:
            prev_ctx = None
            try:
                prev_ctx = user.SetThreadDpiAwarenessContext(_vp(-4))
            except Exception:
                pass

            dpr = 1.0
            try:
                dpi = user.GetDpiForWindow(_vp(hwnd))
                if dpi: dpr = dpi / 96.0
            except Exception:
                pass

            phys_x = max(0, int(round(x * dpr)))
            phys_y = max(0, int(round(y * dpr)))
            cap_w  = max(1, int(round(w * dpr)))
            cap_h  = max(1, int(round(h * dpr)))
            if even:
                cap_w = max(2, cap_w - cap_w % 2)
                cap_h = max(2, cap_h - cap_h % 2)

            pt = wt.POINT(0, 0)
            user.ClientToScreen(_vp(hwnd), ctypes.byref(pt))
            src_x = pt.x + phys_x
            src_y = pt.y + phys_y

            hdc_screen = user.GetDC(None)
            hdc_mem    = gdi.CreateCompatibleDC(hdc_screen)
            hbm        = gdi.CreateCompatibleBitmap(hdc_screen, cap_w, cap_h)
            old_bm     = gdi.SelectObject(hdc_mem, hbm)

            class BITMAPINFOHEADER(ctypes.Structure):
                _fields_ = [("biSize",wt.DWORD),("biWidth",wt.LONG),("biHeight",wt.LONG),
                            ("biPlanes",wt.WORD),("biBitCount",wt.WORD),("biCompression",wt.DWORD),
                            ("biSizeImage",wt.DWORD),("biXPelsPerMeter",wt.LONG),
                            ("biYPelsPerMeter",wt.LONG),("biClrUsed",wt.DWORD),("biClrImportant",wt.DWORD)]
            bih = BITMAPINFOHEADER(biSize=ctypes.sizeof(BITMAPINFOHEADER),
                                   biWidth=cap_w, biHeight=-cap_h, biPlanes=1, biBitCount=32,
                                   biCompression=0)

            buf = (ctypes.c_char * (cap_w * cap_h * 4))()

            class CURSORINFO(ctypes.Structure):
                _fields_ = [("cbSize",wt.DWORD),("flags",wt.DWORD),
                            ("hCursor",_vp),("ptScreenPos",wt.POINT)]
            class ICONINFO(ctypes.Structure):
                _fields_ = [("fIcon",wt.BOOL),("xHotspot",wt.DWORD),("yHotspot",wt.DWORD),
                            ("hbmMask",_vp),("hbmColor",_vp)]
            ci = CURSORINFO()
            ci.cbSize = ctypes.sizeof(CURSORINFO)
            ii = ICONINFO()

            if prev_ctx is not None:
                try: user.SetThreadDpiAwarenessContext(prev_ctx)
                except Exception: pass

            class _Ctx:
                __slots__ = ('_gdi','_user','_vp','_hdc_screen','_hdc_mem','_hbm','_old_bm',
                             '_bih','_buf','_ci','_ii','cap_w','cap_h','src_x','src_y','size',
                             '_last_hcursor','_hotspot_x','_hotspot_y','_cursor')
                def __init__(self_):
                    self_._gdi = gdi; self_._user = user; self_._vp = _vp
                    self_._hdc_screen = hdc_screen; self_._hdc_mem = hdc_mem
                    self_._hbm = hbm; self_._old_bm = old_bm
                    self_._bih = bih; self_._buf = buf
                    self_._ci = ci; self_._ii = ii
                    self_.cap_w = cap_w; self_.cap_h = cap_h
                    self_.src_x = src_x; self_.src_y = src_y
                    self_.size = (cap_w, cap_h)
                    self_._cursor = cursor
                    self_._last_hcursor = None
                    self_._hotspot_x = 0
                    self_._hotspot_y = 0

                def capture(self_):
                    g = self_._gdi; u = self_._user; vp = self_._vp

                    cursor_visible = False
                    if self_._cursor:
                        self_._ci.cbSize = ctypes.sizeof(CURSORINFO)
                        cursor_visible = u.GetCursorInfo(ctypes.byref(self_._ci)) and self_._ci.flags == 1
                    cur_x = self_._ci.ptScreenPos.x - self_.src_x if cursor_visible else 0
                    cur_y = self_._ci.ptScreenPos.y - self_.src_y if cursor_visible else 0
                    h_cursor = vp(self_._ci.hCursor) if cursor_visible else None

                    g.BitBlt(self_._hdc_mem, 0, 0, self_.cap_w, self_.cap_h,
                             self_._hdc_screen, self_.src_x, self_.src_y, 0x00CC0020)

                    if cursor_visible and h_cursor:
                        if h_cursor != self_._last_hcursor:
                            if u.GetIconInfo(h_cursor, ctypes.byref(self_._ii)):
                                self_._hotspot_x = int(self_._ii.xHotspot)
                                self_._hotspot_y = int(self_._ii.yHotspot)
                                if self_._ii.hbmColor: g.DeleteObject(vp(self_._ii.hbmColor))
                                if self_._ii.hbmMask:  g.DeleteObject(vp(self_._ii.hbmMask))
                            self_._last_hcursor = h_cursor
                        try:
                            u.DrawIconEx(self_._hdc_mem,
                                         cur_x - self_._hotspot_x,
                                         cur_y - self_._hotspot_y,
                                         h_cursor, 0, 0, 0, None, 0x0003)
                        except Exception:
                            pass

                    g.GetDIBits(self_._hdc_mem, self_._hbm, 0, self_.cap_h,
                                self_._buf, ctypes.byref(self_._bih), 0)
                    return bytes(self_._buf)

                def release(self_):
                    try:
                        self_._gdi.SelectObject(self_._hdc_mem, self_._old_bm)
                        self_._gdi.DeleteObject(self_._hbm)
                        self_._gdi.DeleteDC(self_._hdc_mem)
                        self_._user.ReleaseDC(None, self_._hdc_screen)
                    except Exception:
                        pass

            return _Ctx()

        except Exception as e:
            self._println(f"[Record] GDI context error: {e}")
            return None

    def _do_start_recording(self, x, y, w, h, fps=15):
        import ctypes, ctypes.wintypes as wt
        FPS = max(1, min(60, int(fps)))
        self._rec_stop_event = threading.Event()

        try:
            from PIL import Image
        except ImportError:
            self._println("[Record] Error: Pillow is not installed.")
            self._cap_eval("stopRecording()")
            return

        hwnd = None
        for _attempt in range(10):
            hwnd = self._cap_hwnd()
            if hwnd:
                break
            time.sleep(0.3)
        if not hwnd:
            self._println("[Record] Error: could not find application window handle.")
            self._cap_eval("stopRecording()")
            return

        cap_ctx = self._make_gdi_capture_ctx(hwnd, x, y, w, h)
        if cap_ctx is None:
            self._println("[Record] Failed to create capture context.")
            self._cap_eval("stopRecording()")
            return

        fw, fh = cap_ctx.cap_w, cap_ctx.cap_h

        if fw < 16 or fh < 16:
            self._println(f"[Record] Region too small ({fw}x{fh}). Minimum is 16x16 pixels.")
            cap_ctx.release()
            self._cap_eval("stopRecording()")
            return

        self._cap_eval(f"showRecIndicator({x},{y},{w},{h})")

        try:
            _rc = wt.RECT()
            ctypes.windll.user32.GetClientRect(hwnd, ctypes.byref(_rc))
            _client_w = _rc.right - _rc.left
            _client_h = _rc.bottom - _rc.top
            _origin = wt.POINT(0, 0)
            ctypes.windll.user32.ClientToScreen(hwnd, ctypes.byref(_origin))
            _phys_x = cap_ctx.src_x - _origin.x
            _phys_y = cap_ctx.src_y - _origin.y
        except Exception:
            _client_w = _client_h = 0
            _phys_x = _phys_y = 0
        _is_full_area = (_phys_x <= 8 and _phys_y <= 8 and _client_w and _client_h
                          and cap_ctx.cap_w >= _client_w - 8
                          and cap_ctx.cap_h >= _client_h - 24)
        if not _is_full_area:
            self._show_rec_overlay(cap_ctx)

        import shutil, subprocess as sp
        ffmpeg = shutil.which('ffmpeg')
        if not ffmpeg:
            for candidate in [
                os.path.join(ROOT_DIR, 'ffmpeg.exe'),
                os.path.join(ROOT_DIR, 'ffmpeg', 'ffmpeg.exe'),
                os.path.join(ROOT_DIR, 'ffmpeg', 'bin', 'ffmpeg.exe'),
                r'C:\ffmpeg\bin\ffmpeg.exe',
                r'C:\ffmpeg\ffmpeg.exe',
            ]:
                if os.path.isfile(candidate):
                    ffmpeg = candidate
                    break
        if not ffmpeg:
            import glob
            bundled = glob.glob(os.path.join(ROOT_DIR, 'python_embeded', 'Lib', 'site-packages',
                                             'imageio_ffmpeg', 'binaries', 'ffmpeg*.exe'))
            if bundled:
                ffmpeg = bundled[0]

        tmp_file = os.path.join(self._last_save_dir, f'_ezi_rec_tmp_{int(time.time())}.mp4')

        try:
          if ffmpeg:
            cmd = [
                ffmpeg, '-y',
                '-f', 'rawvideo',
                '-vcodec', 'rawvideo',
                '-s', f'{fw}x{fh}',
                '-pix_fmt', 'bgra',
                '-r', str(FPS),
                '-i', 'pipe:0',
                '-an',
                '-vcodec', 'libx264',
                '-preset', 'ultrafast',
                '-crf', '23',
                '-pix_fmt', 'yuv420p',
                '-r', str(FPS),
                tmp_file
            ]
            try:
                proc = sp.Popen(cmd, stdin=sp.PIPE, stdout=sp.DEVNULL, stderr=sp.DEVNULL,
                                creationflags=0x08000000)
            except Exception as e:
                self._println(f"[Record] ffmpeg launch failed: {e}")
                self._cap_eval("stopRecording()")
                return

            self._println(f"[Record] Recording started (ffmpeg, {fw}x{fh} @ {FPS}fps)...")
            interval = 1.0 / FPS

            import queue as _queue
            frame_queue = _queue.Queue(maxsize=4)
            write_exc = [None]

            def _writer():
                last_raw = None
                frames_sent = 0
                t_start_w = None
                try:
                    while True:
                        try:
                            item = frame_queue.get(timeout=1.0)
                        except _queue.Empty:
                            if self._rec_stop_event.is_set():
                                break
                            continue
                        if item is None:
                            break
                        raw, t_captured = item
                        if raw is not None:
                            last_raw = raw
                        if t_start_w is None:
                            t_start_w = t_captured
                        if last_raw is None:
                            continue
                        elapsed = t_captured - t_start_w
                        frames_due = max(frames_sent + 1, int(elapsed / interval) + 1)
                        try:
                            while frames_sent < frames_due:
                                proc.stdin.write(last_raw)
                                frames_sent += 1
                        except (BrokenPipeError, OSError):
                            break
                except Exception as e:
                    write_exc[0] = e
                finally:
                    try:
                        proc.stdin.close()
                    except Exception:
                        pass

            writer_thread = threading.Thread(target=_writer, daemon=True)
            writer_thread.start()

            try:
                t_start = time.time()
                frame_index = 0
                while not self._rec_stop_event.is_set():
                    next_slot = t_start + frame_index * interval
                    now = time.time()
                    wait = next_slot - now
                    if wait > 0:
                        self._rec_stop_event.wait(wait)
                    if self._rec_stop_event.is_set():
                        break
                    t_capture = time.time()
                    raw = cap_ctx.capture()
                    try:
                        frame_queue.put_nowait((raw, t_capture - t_start))
                    except _queue.Full:
                        pass
                    frame_index += 1
            finally:
                frame_queue.put(None)
                writer_thread.join(timeout=20)
                try:
                    proc.wait(timeout=15)
                except Exception:
                    try: proc.kill()
                    except Exception: pass

          else:
            self._println("[Record] ffmpeg not found - collecting frames (may use more RAM)...")
            frames = []
            timestamps = []
            interval = 1.0 / FPS
            t_start = time.time()
            frame_index = 0
            while not self._rec_stop_event.is_set():
                next_frame_time = t_start + frame_index * interval
                now = time.time()
                wait_before = next_frame_time - now
                if wait_before > 0:
                    self._rec_stop_event.wait(wait_before)
                if self._rec_stop_event.is_set():
                    break
                raw = cap_ctx.capture()
                if raw is not None:
                    frames.append(raw)
                    timestamps.append(time.time() - t_start)
                frame_index += 1
                elapsed_total = time.time() - t_start
                expected_index = int(elapsed_total / interval)
                if frame_index < expected_index:
                    frame_index = expected_index

            if not frames:
                self._println("[Record] No frames captured.")
                self._cap_eval("stopRecording()")
                return

            if len(timestamps) > 1:
                actual_fps = max(1.0, (len(timestamps) - 1) / (timestamps[-1] - timestamps[0]))
            else:
                actual_fps = float(FPS)
            encode_fps = max(1, round(actual_fps))

            tmp_file = tmp_file.replace('.mp4', '.avi')
            try:
                self._write_mjpeg_avi(tmp_file, frames, fw, fh, encode_fps)
                self._println("[Record] Encoded as MJPEG AVI (ffmpeg not found; install ffmpeg or imageio-ffmpeg for much smaller files).")
            except Exception as e:
                self._println(f"[Record] Recording failed ({e}). Install ffmpeg for better results.")
                self._cap_eval("stopRecording()")
                return

        finally:
            cap_ctx.release()
            self._hide_rec_overlay()
            self._cap_eval("stopRecording()")

        self._println("[Record] Recording stopped. Saving...")

        ext = '.mp4' if tmp_file.endswith('.mp4') else '.avi'
        default_name = f"ComfyUI-EZi-recording-{time.strftime('%Y%m%d_%H%M%S')}{ext}"

        save_path = None
        dlg_win = self._cap_win or self._window
        if dlg_win and os.path.exists(tmp_file):
            try:
                ft = ("MP4 Video (*.mp4)", "All Files (*.*)") if tmp_file.endswith('.mp4') else ("AVI Video (*.avi)", "All Files (*.*)",)
                result = dlg_win.create_file_dialog(
                    SAVE_DIALOG_TYPE,
                    directory=self._last_save_dir,
                    save_filename=default_name,
                    file_types=ft
                )
                if result:
                    save_path = result[0] if isinstance(result, (list, tuple)) else result
                    self._last_save_dir = os.path.dirname(save_path)
                    self._settings["last_save_dir"] = self._last_save_dir
                    _save_settings(self._settings)
            except Exception:
                _log_error('_do_start_recording')

        if save_path and os.path.exists(tmp_file):
            import shutil as _sh
            try:
                _sh.move(tmp_file, save_path)
                self._println(f"[Record] Saved: {save_path}")
            except Exception as e:
                self._println(f"[Record] Save error: {e}")
        elif os.path.exists(tmp_file):
            try: os.remove(tmp_file)
            except Exception: pass

    def _write_mjpeg_avi(self, path, frames_raw, w, h, fps):
        import io, struct
        from PIL import Image

        jpegs = []
        for raw in frames_raw:
            img = Image.frombytes('RGB', (w, h), raw, 'raw', 'BGRX')
            buf = io.BytesIO()
            img.save(buf, 'JPEG', quality=65, optimize=True)
            jpegs.append(buf.getvalue())

        def dw(n):  return struct.pack('<I', n)
        def dd(n):  return struct.pack('<i', n)
        def dw2(n): return struct.pack('<H', n)

        n = len(jpegs)
        us_per_frame = int(1_000_000 / fps)

        movi_data = b''
        idx1_data = b''
        offset = 4
        for jpg in jpegs:
            padded = jpg + (b'\x00' if len(jpg) % 2 else b'')
            chunk = b'00dc' + dw(len(jpg)) + padded
            idx1_data += b'00dc' + dw(0x10) + dw(offset) + dw(len(jpg))
            offset += len(chunk)
            movi_data += chunk

        movi_size = len(movi_data) + 4
        idx1_size = len(idx1_data)

        strh = (b'vids' + b'MJPG' + dw(0)*3 + dw(1) + dw(fps) +
                dw(0) + dw(n) + dw(0) + dw(int(w*h*3)) +
                dw2(w) + dw2(h))
        strf = (dw(40) + dd(w) + dd(h) + dw2(1) + dw2(24) +
                b'MJPG' + dw(w*h*3) + dd(0)*2 + dw(0)*2)

        strl = (b'LIST' + dw(4 + 8 + len(strh) + 8 + len(strf)) + b'strl' +
                b'strh' + dw(len(strh)) + strh +
                b'strf' + dw(len(strf)) + strf)

        avih = (dw(us_per_frame) + dw(int(w*h*3*fps)) + dw(0) + dw(0x10) +
                dw(n) + dw(0) + dw(1) + dw(0) + dw(w) + dw(h))
        hdrl = b'LIST' + dw(4 + 8 + len(avih) + len(strl)) + b'hdrl' + b'avih' + dw(len(avih)) + avih + strl

        movi_chunk = b'LIST' + dw(movi_size) + b'movi' + movi_data
        idx1_chunk = b'idx1' + dw(idx1_size) + idx1_data

        riff_data = hdrl + movi_chunk + idx1_chunk
        with open(path, 'wb') as f:
            f.write(b'RIFF' + dw(len(riff_data) + 4) + b'AVI ' + riff_data)

    def _do_screenshot(self, x, y, w, h):
        time.sleep(0.15)
        try:
            try:
                from PIL import Image
            except ImportError:
                self._println("[Screenshot] Error: Pillow is not installed.\n"
                            "Run: python_embeded\\python.exe -m pip install Pillow")
                return

            hwnd = self._cap_hwnd()
            if not hwnd:
                self._println("[Screenshot] Error: No window handle found.")
                return

            ctx = self._make_gdi_capture_ctx(hwnd, x, y, w, h, even=False, cursor=False)
            if ctx is None:
                return
            try:
                raw = ctx.capture()
            finally:
                ctx.release()
            img = Image.frombytes("RGB", ctx.size, raw, "raw", "BGRX")

            default_name = f"ComfyUI-EZi-screenshot-{time.strftime('%Y%m%d_%H%M%S')}.png"
            save_path = None
            dlg_win = self._cap_win or self._window
            if dlg_win:
                try:
                    result = dlg_win.create_file_dialog(
                        SAVE_DIALOG_TYPE,
                        directory=self._last_save_dir,
                        save_filename=default_name,
                        file_types=("PNG Image (*.png)", "All Files (*.*)")
                    )
                    if result:
                        save_path = result[0] if isinstance(result, (list, tuple)) else result
                        self._last_save_dir = os.path.dirname(save_path)
                        self._settings["last_save_dir"] = self._last_save_dir
                        _save_settings(self._settings)
                except Exception:
                    save_path = None

            if save_path:
                img.save(save_path, "PNG")
        except Exception as e:
            self._println(f"Screenshot error: {e}")

    def save_window_state(self):
        if not self._window or ADV_CONSOLE:
            return
        try:
            hwnd = self._main_hwnd or _get_hwnd(self._window)
            if not hwnd:
                return

            import ctypes.wintypes as wt
            user = ctypes.windll.user32

            if bool(user.IsIconic(hwnd)):
                return

            wp = EZI_WINDOWPLACEMENT()
            wp.length = ctypes.sizeof(EZI_WINDOWPLACEMENT)
            if not user.GetWindowPlacement(hwnd, ctypes.byref(wp)):
                return

            is_maximized = (wp.showCmd == 3)
            nr = wp.rcNormalPosition
            normal_rect = [nr.left, nr.top, nr.right, nr.bottom]

            w = normal_rect[2] - normal_rect[0]
            h = normal_rect[3] - normal_rect[1]
            if w < 50 or h < 50:
                return

            try:
                user.GetDpiForWindow.argtypes = [ctypes.c_void_p]
                user.GetDpiForWindow.restype  = wt.UINT
                saved_dpi = user.GetDpiForWindow(ctypes.c_void_p(hwnd))
            except Exception:
                saved_dpi = 96
            if not saved_dpi:
                saved_dpi = 96

            saved_state = {
                "showCmd":          3 if is_maximized else 1,
                "rcNormalPosition": normal_rect,
                "saved_dpi":        saved_dpi,
            }

            if is_maximized:
                rc = wt.RECT()
                if user.GetWindowRect(hwnd, ctypes.byref(rc)):
                    saved_state["maximized_rect"] = [rc.left, rc.top, rc.right, rc.bottom]

            if self._settings.get("window_placement") != saved_state:
                self._settings["window_placement"] = saved_state
                _save_settings(self._settings)
        except Exception:
            _log_error('save_window_state')

        if self._console_win is not None and self._console_hwnd:
            self._save_console_placement(self._console_hwnd)

    def _store_comfy_storage(self, msg):
        try:
            ls = msg.get("ls") or {}
            if msg.get("settled") and ls:
                size = sum(len(k) + len(str(v)) for k, v in ls.items())
                if size <= 20 * 1024 * 1024:
                    data = {"ls": ls}
                    self._settings["comfy_storage"] = data
                    self._storage_holder[0] = data
                    _save_settings(self._settings)
        except Exception:
            _log_error('_store_comfy_storage')
        finally:
            self._storage_ack.set()

    def get_ui_settings(self):
        try:
            fb = self._settings.get("custom_file_browser", "")
            theme = self._settings.get("theme", "aurora")
            comfy_theme = _get_comfy_current_theme()
            comfy_theme_vars = _get_comfy_theme_css_vars()
            console_detached = self._settings.get("console_detached", False)
            if ADV_CONSOLE and not console_detached:
                console_detached = True
                self._startup_detach = True
            custom_paths_json = self.get_custom_paths()
            custom_paths = json.loads(custom_paths_json) if custom_paths_json else {'input': '', 'output': '', 'user': ''}
            return json.dumps({
                "showTooltips": bool(self._settings.get("show_tooltips", True)),
                "extPagesInside": bool(self._settings.get("ext_pages_inside", True)),
                "customFileBrowser": fb,
                "theme": theme,
                "launcherTheme": self._settings.get("launcher_theme", "aurora") if self._settings.get("launcher_theme", "aurora") in LAUNCHER_THEME_NAMES else "aurora",
                "comfyTheme": comfy_theme,
                "comfyThemeVars": comfy_theme_vars,
                "consoleDetached": console_detached,
                "customPaths": custom_paths,
                "recFps": self._settings.get("rec_fps", 15),
                "consoleBgImage":   self._settings.get("console_bg_image", ""),
                "consoleBgFit":     self._settings.get("console_bg_fit", "fit"),
                "consoleBgOpacity": self._settings.get("console_bg_opacity", 0.12),
                "consoleBgAnimate": self._settings.get("console_bg_animate", True),
                "selCopy":    bool(self._settings.get("sel_pop_copy", True)),
                "selGoogle":  bool(self._settings.get("sel_pop_google", True)),
                "selChatgpt": bool(self._settings.get("sel_pop_chatgpt", True)),
                "selClaude":  bool(self._settings.get("sel_pop_claude", False)),
                "selSave":    bool(self._settings.get("sel_pop_save", True)),
                "selLang":    str(self._settings.get("sel_ai_lang", "en") or "en"),
                "consoleZoomAttached": int(self._settings.get("console_zoom_attached", 12)),
                "consoleZoomDetached": int(
                    self._settings.get("adv_console_zoom_detached", self._settings.get("console_zoom_detached", 12))
                    if ADV_CONSOLE else self._settings.get("console_zoom_detached", 12)),
            })
        except Exception as e:
            print(f"[EZi DEBUG] get_ui_settings ERROR: {e}", flush=True)
            return None

    def save_ui_settings(self, settings_json):
        try:
            if not settings_json or not isinstance(settings_json, str) or not settings_json.strip():
                return
            data = json.loads(settings_json)
            if not isinstance(data, dict) or not data:
                return
            if "showTooltips" in data:
                self._settings["show_tooltips"] = bool(data["showTooltips"])
                self._console_push_tooltips()
            if "extPagesInside" in data:
                self._settings["ext_pages_inside"] = bool(data["extPagesInside"])
                if not self._settings["ext_pages_inside"]:
                    self._ui_invoke(_ezi_ext_close)
            if "customFileBrowser" in data:
                self._settings["custom_file_browser"] = str(data["customFileBrowser"]).strip()
            if "theme" in data and data["theme"] in EZI_THEME_NAMES:
                self._settings["theme"] = data["theme"]
                self._console_push_theme()
            if "launcherTheme" in data and data["launcherTheme"] in LAUNCHER_THEME_NAMES:
                self._settings["launcher_theme"] = data["launcherTheme"]
            if "recFps" in data and int(data["recFps"]) in (15, 30, 60):
                self._settings["rec_fps"] = int(data["recFps"])
            if "consoleBgImage" in data:
                self._settings["console_bg_image"] = str(data["consoleBgImage"]).strip()
            if "consoleBgFit" in data and data["consoleBgFit"] in ("fit", "stretch", "tile", "center"):
                self._settings["console_bg_fit"] = data["consoleBgFit"]
            if "consoleBgOpacity" in data:
                try:
                    val = float(data["consoleBgOpacity"])
                    if 0.03 <= val <= 0.60:
                        self._settings["console_bg_opacity"] = val
                except (ValueError, TypeError):
                    pass
            if "consoleBgAnimate" in data:
                self._settings["console_bg_animate"] = bool(data["consoleBgAnimate"])
            sel_changed = False
            for _jk, _sk, _df in (("selCopy", "sel_pop_copy", True), ("selGoogle", "sel_pop_google", True),
                                  ("selChatgpt", "sel_pop_chatgpt", True), ("selClaude", "sel_pop_claude", False),
                                  ("selSave", "sel_pop_save", True)):
                if _jk in data and bool(data[_jk]) != bool(self._settings.get(_sk, _df)):
                    self._settings[_sk] = bool(data[_jk])
                    sel_changed = True
            if "selLang" in data and _ezi_valid_lang(data["selLang"]) and data["selLang"] != self._settings.get("sel_ai_lang", "en"):
                self._settings["sel_ai_lang"] = data["selLang"]
                sel_changed = True
            if sel_changed:
                self._console_push_selpop()

            if self._settings_holder is not None:
                self._settings_holder[0] = self._settings
            _save_settings(self._settings)
        except Exception:
            _log_error('save_ui_settings')

    def send_to_comfy(self, message_json):
        try:
            if not message_json or not isinstance(message_json, str):
                return
            cw = _EZI_WINDOW_REF.get("comfy_webview")
            if cw is None:
                return

            def _do_post():
                try:
                    cw.CoreWebView2.PostWebMessageAsJson(message_json)
                except Exception:
                    pass
            self._ui_invoke(_do_post)
        except Exception:
            pass

    def _console_title(self):
        return f"ComfyUI Console  [EZi v{APP_VERSION}]"

    def _create_console_window(self):
        kw = dict(url=f'http://127.0.0.1:{self._proxy_port}/__console__', js_api=self,
                  width=900, height=500, min_size=(420, 220), resizable=True,
                  hidden=True, frameless=False, background_color='#1e1e1e')
        try:
            win = webview.create_window(self._console_title(), user_agent=CHROME_UA, **kw)
        except TypeError:
            win = webview.create_window(self._console_title(), **kw)
        if win is not None:
            try:
                _ezi_hook_core_ready(win)
            except Exception:
                pass
        return win

    def _console_hwnd_of(self, win):
        try:
            h = ctypes.windll.user32.FindWindowW(None, self._console_title())
            if h:
                return int(h)
        except Exception:
            pass
        try:
            h = int(win.native.Handle.ToInt64())
            if h:
                return h
        except Exception:
            pass
        return None

    def _apply_console_placement(self, hwnd):
        if not hwnd:
            return False
        want_max = False
        try:
            user32 = ctypes.windll.user32
            pl = self._settings.get("adv_console_placement" if ADV_CONSOLE else "console_placement")
            if pl and isinstance(pl, dict):
                x, y = pl.get("x", 100), pl.get("y", 100)
                cx, cy = pl.get("cx", 900), pl.get("cy", 500)
                if pl.get("showCmd", 1) == 3:
                    mr = pl.get("maximized_rect")
                    if mr and _is_rect_on_active_monitor(mr[0], mr[1], mr[2], mr[3]):
                        user32.MoveWindow(hwnd, x, y, cx, cy, False)
                    want_max = True
                elif _is_rect_on_active_monitor(x, y, x + cx, y + cy):
                    user32.MoveWindow(hwnd, x, y, cx, cy, True)
            try:
                dark = ctypes.c_int(0 if self._settings.get("theme", "aurora") == "light" else 1)
                for attr in (20, 19):
                    if ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, attr, ctypes.byref(dark), ctypes.sizeof(dark)) == 0:
                        break
            except Exception:
                pass
            _set_window_icon(hwnd, ICO_CMD_PATH)
        except Exception:
            pass
        return want_max

    def _push_console_state(self, win, state):
        CH = 200000
        win.evaluate_js("tImportBegin()")
        for i in range(0, len(state), CH):
            win.evaluate_js("tImportPart(%s)" % json.dumps(state[i:i + CH]))
        return bool(win.evaluate_js("tImportEnd()"))

    def _focus_console_window(self):
        win = self._console_win
        if win is None:
            return
        try:
            hwnd = self._console_hwnd
            if hwnd:
                u32 = ctypes.windll.user32
                if u32.IsIconic(hwnd):
                    u32.ShowWindow(hwnd, 9)
                u32.SetForegroundWindow(hwnd)
        except Exception:
            pass

    def _abort_console_window(self, win):
        if win is None:
            return
        self._console_allow_close = True
        try:
            win.destroy()
        except Exception:
            pass
        self._console_allow_close = False

    def _do_detach(self):
        if self._window is None:
            return False
        win = None
        with self._pump_lock:
            try:
                win = self._create_console_window()
                win.events.closing += self._on_console_closing
                for ev_name in ('moved', 'resized'):
                    ev = getattr(win.events, ev_name, None)
                    if ev is not None:
                        ev += self._on_console_geometry
                if not win.events.loaded.wait(30):
                    raise RuntimeError("the console window did not load")
                hwnd = self._console_hwnd_of(win)
                want_max = self._apply_console_placement(hwnd)
                state = self._window.evaluate_js("tExport()")
                if not state:
                    raise RuntimeError("could not read the console history")
                self._push_console_state(win, state)
                win.show()
                if hwnd:
                    try:
                        if want_max:
                            ctypes.windll.user32.ShowWindow(hwnd, 3)
                        ctypes.windll.user32.SetForegroundWindow(hwnd)
                    except Exception:
                        pass
                self._console_hwnd = hwnd
                self._console_win = win
                if getattr(self, "_startup_detach", False):
                    self._startup_detach = False
                else:
                    self._settings["console_detached"] = True
                    _save_settings(self._settings)
            except Exception as e:
                self._console_win, self._console_hwnd = None, None
                self._abort_console_window(win)
                self._println(f"\033[91m[Console] Could not detach: {e}\033[0m")
                return False
        self._safe_eval("window.__eziConsoleDetachedUI && window.__eziConsoleDetachedUI(true)")
        return True

    def _do_attach(self):
        with self._pump_lock:
            win = self._console_win
            if win is None:
                return True
            state = None
            try:
                state = win.evaluate_js("tExport()")
            except Exception:
                _log_error('_do_attach')
            if self._console_hwnd:
                self._save_console_placement(self._console_hwnd)
            if state and self._window is not None:
                try:
                    self._push_console_state(self._window, state)
                except Exception as e:
                    self._println(f"\033[91m[Console] History could not be moved back: {e}\033[0m")
            self._console_win, self._console_hwnd = None, None
            self._abort_console_window(win)
            self._settings["console_detached"] = False
            _save_settings(self._settings)
        self._safe_eval("window.__eziConsoleDetachedUI && window.__eziConsoleDetachedUI(false)")
        return True

    def _on_console_closing(self):
        if self._console_allow_close:
            return True
        if ADV_CONSOLE:
            self._confirm_close = True
            threading.Thread(target=self._graceful_close, daemon=True).start()
            return False
        threading.Thread(target=self.attach_console, daemon=True).start()
        return False

    def _on_console_geometry(self, *args):
        t = self._console_geo_timer
        if t is not None:
            t.cancel()
        t = threading.Timer(0.6, self._save_console_placement_now)
        t.daemon = True
        t.start()
        self._console_geo_timer = t

    def _save_console_placement_now(self):
        if self._console_win is not None and self._console_hwnd:
            self._save_console_placement(self._console_hwnd)

    def _console_push_theme(self):
        win = self._console_win
        if win is None:
            return
        try:
            theme = self._settings.get("theme", "aurora")
            vars_ = _get_comfy_theme_css_vars() if theme == "comfyui" else {}
            win.evaluate_js(f"applyTheme({json.dumps(theme)}, {json.dumps(vars_)})")
        except Exception:
            pass

    def _console_push_tooltips(self):
        win = self._console_win
        if win is None:
            return
        try:
            win.evaluate_js(f"applyTooltips({json.dumps(bool(self._settings.get('show_tooltips', True)))})")
        except Exception:
            pass

    def _sel_pop_state(self):
        return {
            "copy":    bool(self._settings.get("sel_pop_copy", True)),
            "google":  bool(self._settings.get("sel_pop_google", True)),
            "chatgpt": bool(self._settings.get("sel_pop_chatgpt", True)),
            "claude":  bool(self._settings.get("sel_pop_claude", False)),
            "save":    bool(self._settings.get("sel_pop_save", True)),
            "lang":    str(self._settings.get("sel_ai_lang", "en") or "en"),
        }

    def _console_push_selpop(self):
        win = self._console_win
        if win is None:
            return
        try:
            win.evaluate_js(f"window.__eziSelMenuSync && window.__eziSelMenuSync({json.dumps(self._sel_pop_state())})")
        except Exception:
            pass

    def save_console_log(self, text, kind="log"):
        try:
            if not isinstance(text, str) or not text:
                return False
            win = self._console_win or self._window
            if win is None:
                return False
            text = text.replace("\r\n", "\n").replace("\r", "\n")
            label = "selection" if kind == "selection" else "log"
            default_name = f"ComfyUI-EZi-console-{label}-{time.strftime('%Y%m%d_%H%M%S')}.txt"
            result = win.create_file_dialog(
                SAVE_DIALOG_TYPE,
                directory=self._last_save_dir,
                save_filename=default_name,
                file_types=("Text File (*.txt)", "All Files (*.*)")
            )
            if not result:
                return False
            path = result[0] if isinstance(result, (list, tuple)) else result
            with open(path, "w", encoding="utf-8", newline="\r\n") as f:
                f.write(text + "\n")
            self._last_save_dir = os.path.dirname(path)
            self._settings["last_save_dir"] = self._last_save_dir
            _save_settings(self._settings)
            return True
        except Exception:
            _log_error('save_console_log')
            return False

    def set_console_zoom(self, kind, size):
        try:
            key = {"attached": "console_zoom_attached", "detached": "adv_console_zoom_detached" if ADV_CONSOLE else "console_zoom_detached"}.get(kind)
            if key is None:
                return False
            self._settings[key] = max(6, min(40, int(size)))
            if self._settings_holder is not None:
                self._settings_holder[0] = self._settings
            _save_settings(self._settings)
            return True
        except Exception:
            _log_error('set_console_zoom')
            return False

    def set_sel_option(self, name, value):
        try:
            if name == "lang":
                if not _ezi_valid_lang(value):
                    return False
                self._settings["sel_ai_lang"] = value
                if self._settings_holder is not None:
                    self._settings_holder[0] = self._settings
                _save_settings(self._settings)
                self._safe_eval(f"window.__eziSelPopSync && window.__eziSelPopSync({json.dumps({'lang': value})})")
                self._console_push_selpop()
                return True
            key = {"copy": "sel_pop_copy", "google": "sel_pop_google", "chatgpt": "sel_pop_chatgpt",
                   "claude": "sel_pop_claude", "save": "sel_pop_save"}.get(name)
            if key is None:
                return False
            self._settings[key] = bool(value)
            if self._settings_holder is not None:
                self._settings_holder[0] = self._settings
            _save_settings(self._settings)
            self._safe_eval(f"window.__eziSelPopSync && window.__eziSelPopSync({json.dumps({name: bool(value)})})")
            self._console_push_selpop()
            return True
        except Exception:
            _log_error('set_sel_option')
            return False

    def _destroy_console_window(self):
        win = self._console_win
        if win is None:
            return
        self._console_win, self._console_hwnd = None, None
        self._abort_console_window(win)

    def detach_console(self):
        if self._console_win is not None:
            self._focus_console_window()
            self._safe_eval("window.__eziConsoleDetachedUI && window.__eziConsoleDetachedUI(true)")
            return True
        if not self._console_op_lock.acquire(blocking=False):
            return False
        try:
            return bool(self._do_detach())
        finally:
            self._console_op_lock.release()

    def attach_console(self):
        if self._console_win is None:
            self._safe_eval("window.__eziConsoleDetachedUI && window.__eziConsoleDetachedUI(false)")
            return True
        if not self._console_op_lock.acquire(blocking=False):
            return False
        try:
            return bool(self._do_attach())
        finally:
            self._console_op_lock.release()

    def _save_console_placement(self, hwnd):
        try:
            import ctypes.wintypes as wt
            user32 = ctypes.windll.user32

            is_maximized = bool(user32.IsZoomed(hwnd))
            if bool(user32.IsIconic(hwnd)):
                return

            rc = wt.RECT()
            if not user32.GetWindowRect(hwnd, ctypes.byref(rc)):
                return
            placement = {
                "x":       rc.left,
                "y":       rc.top,
                "cx":      rc.right  - rc.left,
                "cy":      rc.bottom - rc.top,
                "showCmd": 3 if is_maximized else 1,
            }

            if is_maximized:
                placement["maximized_rect"] = [rc.left, rc.top, rc.right, rc.bottom]

            pl_key = "adv_console_placement" if ADV_CONSOLE else "console_placement"
            if self._settings.get(pl_key) != placement:
                self._settings[pl_key] = placement
                _save_settings(self._settings)
        except Exception:
            _log_error('_save_console_placement')

    def stop(self):
        try:
            self.save_window_state()
        except Exception:
            _log_error('stop')
        try:
            self._destroy_console_window()
        except Exception:
            _log_error('stop')
        self._window = None
        self._kill_running_proc()

    def _run(self):
        try:
            if not os.path.isdir(os.path.join(ROOT_DIR, "python_embeded")):
                self._println(
                    f"\033[91m✖  Wrong script location!\033[0m\n"
                    f"\n"
                    f"ComfyUI-EZi.py must be placed three levels below the ComfyUI root:\n"
                    f"\033[93m  <ComfyUI Root>\\Add-Ons\\Tools\\Helper-CEI\\ComfyUI-EZi.py\033[0m\n"
                    f"\n"
                    f"Current location:\n"
                    f"\033[93m  {CURRENT_SCRIPT_DIR}\033[0m"
                )
                return
            main_path = None
            for loc in [os.path.join(ROOT_DIR, "main.py"), os.path.join(ROOT_DIR, "ComfyUI", "main.py")]:
                if os.path.exists(loc):
                    main_path = loc; break
            
            if not main_path:
                self._println("Error: main.py not found!"); return

            self._sync_model_paths()

            extra_args = []
            py_flags = ['-X', 'utf8=1']
            if not os.path.exists(BAT_FILE):
                bat_name = os.path.basename(BAT_FILE)
                self._safe_eval(f"show_bat_missing({json.dumps(bat_name)})")
            bat_content = _read_bat()
            if bat_content is not None:
                ENV_TO_ARG = {
                    'COMFY_INPUT_DIR':  '--input-directory',
                    'COMFY_OUTPUT_DIR': '--output-directory',
                    'COMFY_USER_DIR':   '--user-directory',
                }
                env_dirs = {}
                for env_name, arg_name in ENV_TO_ARG.items():
                    env_val = _bat_env(bat_content, env_name)
                    if env_val is not None:
                        env_dirs[arg_name] = env_val

                parsed = _bat_args(bat_content)
                if parsed:

                    script_idx = None
                    for idx, token in enumerate(parsed):
                        if token.endswith('.py'):
                            script_idx = idx
                            break

                    if script_idx is not None:
                        pre_script = parsed[:script_idx]
                        post_script = parsed[script_idx + 1:]
                    else:
                        pre_script = []
                        post_script = parsed

                    PY_FLAGS_WITH_VALUE = {'-W', '-X'}
                    j = 0
                    while j < len(pre_script):
                        tok = pre_script[j]
                        if tok in PY_FLAGS_WITH_VALUE and j + 1 < len(pre_script):
                            py_flags.extend([tok, pre_script[j + 1]])
                            j += 2
                        elif tok.startswith('-'):
                            py_flags.append(tok)
                            j += 1
                        else:
                            j += 1

                    ARGS_SINGLE_VAL = {
                        '--port', '--tls-keyfile', '--tls-certfile',
                        '--max-upload-size', '--base-directory',
                        '--output-directory', '--temp-directory', '--input-directory',
                        '--cuda-device', '--default-device',
                        '--oneapi-device-selector',
                        '--preview-size', '--cache-lru',
                        '--reserve-vram', '--vram-headroom', '--default-hashing-function',
                        '--front-end-version', '--front-end-root',
                        '--user-directory', '--comfy-api-base', '--database-url',
                        '--models-directory', '--feature-flag',
                    }
                    ARGS_OPT_VAL = {
                        '--listen', '--enable-cors-header', '--directml',
                        '--preview-method', '--async-offload',
                    }
                    ARGS_MULTI_VAL = {
                        '--extra-model-paths-config', '--whitelist-custom-nodes',
                    }
                    ARGS_OPT_MULTI_VAL = {
                        '--fast', '--cache-ram', '--verbose',
                    }
                    i = 0
                    while i < len(post_script):
                        arg = post_script[i]
                        if arg in ARGS_SINGLE_VAL:
                            if i + 1 < len(post_script):
                                val = post_script[i + 1].strip('"\'')
                                extra_args.extend([arg, val])
                                env_dirs.pop(arg, None)
                                i += 2
                            else:
                                i += 1
                        elif arg in ARGS_OPT_VAL:
                            extra_args.append(arg)
                            if (i + 1 < len(post_script) and
                                    not post_script[i + 1].startswith('--')):
                                extra_args.append(post_script[i + 1].strip('"\''))
                                i += 2
                            else:
                                i += 1
                        elif arg in ARGS_MULTI_VAL:
                            extra_args.append(arg)
                            i += 1
                            while i < len(post_script) and not post_script[i].startswith('--'):
                                extra_args.append(post_script[i].strip('"\''))
                                i += 1
                        elif arg in ARGS_OPT_MULTI_VAL:
                            extra_args.append(arg)
                            i += 1
                            while i < len(post_script) and not post_script[i].startswith('--'):
                                extra_args.append(post_script[i].strip('"\''))
                                i += 1
                        elif arg.startswith('--'):
                            if 'auto-launch' not in arg:
                                extra_args.append(arg)
                            i += 1
                        else:
                            i += 1

                for arg_name, path_val in env_dirs.items():
                    extra_args.extend([arg_name, path_val])

            final_args = py_flags + [main_path] + extra_args
            if not ADV_CONSOLE:
                final_args.append("--disable-auto-launch")

            target_port = self._comfy_port_holder[0]
            for arg_i, arg_v in enumerate(extra_args):
                if arg_v == '--port' and arg_i + 1 < len(extra_args):
                    try: target_port = int(extra_args[arg_i + 1])
                    except ValueError: pass

            def _port_busy(port):
                try:
                    result = subprocess.run(
                        ['powershell', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command',
                         f'if (Get-NetTCPConnection -LocalPort {port} -State Listen '
                         f'-ErrorAction SilentlyContinue) {{ 1 }} else {{ 0 }}'],
                        capture_output=True, stdin=subprocess.DEVNULL, timeout=5, creationflags=0x08000000
                    )
                    return result.stdout.decode().strip() == '1'
                except Exception:
                    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as _s:
                        _s.settimeout(0.5)
                        return _s.connect_ex(('127.0.0.1', port)) == 0

            if _port_busy(target_port):
                self._println(
                    f"\033[93m⚠  Port {target_port} is already in use!\033[0m\n"
                    f"Another application is occupying this port.\n"
                    f"Please close it, then press \033[92mRetry\033[0m."
                )
                self._safe_eval("show_port_error()")
                return

            _cols = self._get_columns()
            cmd_display = os.path.relpath(self.PY_EXE, ROOT_DIR) + ' ' + ' '.join(final_args)
            self._println('\033[2m' + cmd_display + '\033[0m\n')
            my_run_id = self._run_id
            run_env = os.environ.copy()
            for _k in ("CUDA_PATH", "CUDA_HOME", "CUDA_BIN_PATH", "CUDNN_PATH", "CUDNN_HOME",
                       "PYTHONPATH", "PYTHONHOME", "VIRTUAL_ENV", "CONDA_PREFIX", "CONDA_DEFAULT_ENV"):
                run_env.pop(_k, None)
            for _k in [k for k in run_env if k.upper().startswith("CUDA_PATH_V")]:
                run_env.pop(_k, None)
            run_env |= {"PYTHONUTF8": "1", "PYTHONUNBUFFERED": "1", "PYTHONIOENCODING": "utf-8", "TQDM_NCOLS": str(_cols)}
            try:
                _pinned = self._settings.get('pinned_packages') or []
                if not _pinned:
                    try:
                        if os.path.exists(SETTINGS_PATH):
                            with open(SETTINGS_PATH, 'r', encoding='utf-8') as _sf:
                                _pinned = json.load(_sf).get('pinned_packages') or []
                    except Exception:
                        _log_error('_run')
                for _entry in _pinned:
                    _entry = _entry.strip()
                    if not _entry or '==' not in _entry:
                        continue
                    _pkg, _ver = _entry.split('==', 1)
                    _pkg, _ver = _pkg.strip(), _ver.strip()
                    _chk = subprocess.run(
                        [self.PY_EXE, '-c',
                         f'import sys, importlib.metadata as _im; v=_im.version({_pkg!r}); sys.exit(0 if v=={_ver!r} else 1)'],
                        capture_output=True, stdin=subprocess.DEVNULL, timeout=10, creationflags=self._NO_WIN,
                        env=run_env
                    )
                    if _chk.returncode != 0:
                        self._println(f'\033[93m[Pinned] {_pkg} version mismatch - reinstalling {_entry}...\033[0m')
                        _pip_cmd = [self.PY_EXE, '-I', '-m', 'pip', 'install',
                                    '--force-reinstall', _entry,
                                    '--no-deps', '--no-warn-script-location']
                        if not os.path.exists(KEEP_CACHE_FLAG_PATH):
                            _pip_cmd.append('--no-cache-dir')
                        _rc = self._stream_cmd(_pip_cmd, env=run_env, use_pty=True)
                        if _rc == 0:
                            self._println(f'\033[92m[Pinned] {_entry} restored.\033[0m')
                        else:
                            self._println(f'\033[91m[Pinned] Failed to restore {_entry}.\033[0m')
            except Exception:
                _log_error('_run')

            _COMFY_SCHEME[0] = "https" if ('--tls-keyfile' in extra_args and '--tls-certfile' in extra_args) else "http"
            self._proc = subprocess.Popen(
                [self.PY_EXE] + final_args,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                cwd=ROOT_DIR, env=run_env,
                creationflags=0x08000000|0x00000200
            )
            self._job_attach(self._proc)
            dec = codecs.getincrementaldecoder('utf-8')(errors='replace')
            fd = self._proc.stdout.fileno()
            url_tail = ''
            while True:
                if self._run_id != my_run_id:
                    break
                try:
                    chunk = os.read(fd, 65536)
                except OSError:
                    break
                if not chunk:
                    break
                text = dec.decode(chunk)
                if not text:
                    continue
                self._print(text)
                url_tail += text
                m = None
                if '\n' in url_tail:
                    head, _, url_tail = url_tail.rpartition('\n')
                    m = COMFYUI_URL_RE.search(head)
                elif len(url_tail) > 8192:
                    url_tail = url_tail[-1024:]
                if m and not self._url_found and not self._restarting:
                    self._url_found = True
                    detected_port = int(m.group(1))
                    _COMFY_SCHEME[0] = "https" if "https://" in m.group(0).lower() else "http"
                    self._comfy_port_holder[0] = detected_port
                    self._safe_eval("set_dot_ready()")
                    def _wait_and_load(port, proxy_port):
                        import urllib.request as _ur
                        for _ in range(40):
                            try:
                                _comfy_urlopen(f'{_comfy_origin(port)}/system_stats', timeout=5)
                                self._navigate_comfy_webview(f'http://127.0.0.1:{proxy_port}/')
                                return
                            except Exception:
                                time.sleep(0.5)
                        self._navigate_comfy_webview(f'http://127.0.0.1:{proxy_port}/')
                    threading.Thread(target=_wait_and_load,
                                     args=(detected_port, self._proxy_port),
                                     daemon=True).start()
                elif m and self._restarting:
                    _COMFY_SCHEME[0] = "https" if "https://" in m.group(0).lower() else "http"
                    self._comfy_port_holder[0] = int(m.group(1))
            tail = dec.decode(b'', final=True)
            if tail:
                self._print(tail)
            self._ensure_nl()
        except Exception as e: self._println(f"Error: {str(e)}")

    def _dl_erase(self):
        if self._dl_drawn is None:
            return
        down = '' if self._dl_drawn else '\x1b[1B'
        self._out_buf.append('\x1b[s' + down + '\r\x1b[J\x1b[u')
        self._dl_drawn = None

    def _dl_draw(self):
        if not self._dl_rows or self._dl_pty:
            return
        same = self._last_ch == '\n'
        lead = '' if same else '\r\n'
        body = '\r\n'.join('\r\x1b[2K\x1b[0m' + t for t in self._dl_rows.values())
        self._out_buf.append('\x1b[s' + lead + body + '\x1b[0m\x1b[u')
        self._dl_drawn = same

    def _dl_set(self, key, text):
        with self._out_lock:
            self._dl_erase()
            self._dl_rows[key] = text
            self._dl_draw()

    def _dl_done(self, key, text=None):
        with self._out_lock:
            self._dl_erase()
            self._dl_rows.pop(key, None)
            if text:
                if self._last_ch != '\n':
                    self._sink('\n')
                self._sink(text + '\n')
            else:
                self._dl_draw()

    def _sink(self, text):
        if not text:
            return
        self._dl_erase()
        self._last_ch = text[-1]
        self._out_buf.append(text)
        self._dl_draw()

    def _print(self, text):
        if not text:
            return
        with self._out_lock:
            self._sink(text)

    def _println(self, text):
        if text.endswith('\n'):
            text = text[:-1]
        for line in text.split('\n'):
            self._print(line + '\n')

    def _ensure_nl(self):
        with self._out_lock:
            if self._last_ch != '\n':
                self._sink('\n')

    def _ctl(self, seq):
        with self._out_lock:
            self._dl_erase()
            if 'ezi-pty;start' in seq:
                self._dl_pty = True
            elif 'ezi-pty;end' in seq:
                self._dl_pty = False
            self._out_buf.append(seq)
            self._dl_draw()

    def _console_pump(self):
        CHUNK = 262144
        while True:
            time.sleep(0.03)
            if not self._js_ready.is_set():
                continue
            with self._pump_lock:
                win = self._console_win or self._window
                if win is None:
                    continue
                with self._out_lock:
                    if not self._out_buf:
                        continue
                    data, self._out_buf = ''.join(self._out_buf), []
                for k in range(0, len(data), CHUNK):
                    try:
                        win.evaluate_js(f"add_to_console({json.dumps(data[k:k + CHUNK])})")
                    except Exception:
                        pass

    def _forward_pipe(self, proc):
        dec = codecs.getincrementaldecoder('utf-8')(errors='replace')
        fd = proc.stdout.fileno()
        while True:
            try:
                chunk = os.read(fd, 65536)
            except OSError:
                break
            if not chunk:
                break
            text = _PRESS_KEY_RE.sub('', dec.decode(chunk))
            if text:
                self._print(text)
        tail = _PRESS_KEY_RE.sub('', dec.decode(b'', final=True))
        if tail:
            self._print(tail)

    def _stream_cmd(self, cmd, cwd=None, env=None, use_pty=False, stdin_devnull=False):
        cmd = [str(c) for c in cmd]
        env = env if env is not None else os.environ.copy()
        if use_pty:
            cols = max(40, int(self._columns))
            pty, err = _spawn_pty(cmd, cwd, env, cols, log=self._println)
            if pty is None:
                self._println(f"\033[93m[Console] ConPTY unavailable ({err}) - live progress bars are disabled\033[0m")
            else:
                self._ensure_nl()
                self._ctl(f"\x1b]777;ezi-pty;start;{_PTY_ROWS};{cols}\x07")
                try:
                    while True:
                        try:
                            chunk = pty.read(4096)
                        except (EOFError, OSError):
                            break
                        if not chunk:
                            break
                        if isinstance(chunk, bytes):
                            chunk = chunk.decode('utf-8', errors='replace')
                        self._print(_PRESS_KEY_RE.sub('', chunk))
                finally:
                    try:
                        pty.wait()
                    except Exception:
                        pass
                    self._ctl("\x1b]777;ezi-pty;end\x07")
                    with self._out_lock:
                        self._last_ch = '\n'
                return pty.exitstatus or 0
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                cwd=cwd, env=env,
                                stdin=subprocess.DEVNULL,
                                creationflags=self._NO_WIN)
        try:
            self._forward_pipe(proc)
        finally:
            try:
                proc.stdout.close()
            except Exception:
                pass
            proc.wait()
        self._ensure_nl()
        return proc.returncode or 0

    def _safe_eval(self, js):
        if self._window:
            try: self._window.evaluate_js(js)
            except: pass

    def _ui_invoke(self, action):
        try:
            form = _EZI_WINDOW_REF.get("winforms_form")
            if form is None:
                action()
                return
            if form.InvokeRequired:
                import System
                form.BeginInvoke(System.Action(action))
            else:
                action()
        except Exception:
            pass

    def _show_rec_overlay(self, cap_ctx):
        def _do():
            try:
                import System.Windows.Forms as _WinForms
                import System.Drawing as _Drawing

                self._hide_rec_overlay_now()

                sx, sy = cap_ctx.src_x, cap_ctx.src_y
                sw, sh = max(1, cap_ctx.cap_w), max(1, cap_ctx.cap_h)
                THICK = 3
                red = _Drawing.Color.FromArgb(255, 68, 68)

                def _make_strip(x, y, w, h):
                    f = _WinForms.Form()
                    f.AutoScaleMode  = getattr(_WinForms.AutoScaleMode, 'None')
                    f.FormBorderStyle = getattr(_WinForms.FormBorderStyle, 'None')
                    f.ShowInTaskbar   = False
                    f.StartPosition   = _WinForms.FormStartPosition.Manual
                    f.TopMost         = True
                    f.MinimumSize     = _Drawing.Size(0, 0)
                    f.BackColor       = red
                    f.Bounds          = _Drawing.Rectangle(x, y, max(1, w), max(1, h))
                    f.Show()
                    f.Bounds = _Drawing.Rectangle(x, y, max(1, w), max(1, h))
                    _make_clickthrough(f.Handle.ToInt64())
                    return f

                top    = _make_strip(sx - THICK, sy - THICK, sw + THICK * 2, THICK)
                bottom = _make_strip(sx - THICK, sy + sh,     sw + THICK * 2, THICK)
                left   = _make_strip(sx - THICK, sy,          THICK, sh)
                right  = _make_strip(sx + sw,    sy,          THICK, sh)

                stopf = _WinForms.Form()
                stopf.AutoScaleMode  = getattr(_WinForms.AutoScaleMode, 'None')
                stopf.FormBorderStyle = getattr(_WinForms.FormBorderStyle, 'None')
                stopf.ShowInTaskbar   = False
                stopf.StartPosition   = _WinForms.FormStartPosition.Manual
                stopf.TopMost         = True
                stopf.MinimumSize     = _Drawing.Size(0, 0)

                btn = _WinForms.Button()
                btn.Text      = "\u23F9 Stop REC"
                btn.FlatStyle = _WinForms.FlatStyle.Flat
                btn.FlatAppearance.BorderColor = red
                btn.BackColor = _Drawing.Color.FromArgb(0x6e, 0x20, 0x20)
                btn.ForeColor = _Drawing.Color.FromArgb(0xff, 0x88, 0x88)
                btn.Font      = _Drawing.Font("Consolas", 8.5, _Drawing.FontStyle.Bold)
                btn.AutoSize  = True
                btn.Click += lambda s, e: self.stop_recording()

                stopf.Controls.Add(btn)
                stopf.Show()
                stopf.ClientSize = btn.Size
                stopf.Location = _Drawing.Point(sx, max(0, sy - btn.Height - THICK - 2))

                _EZI_WINDOW_REF["rec_overlay"] = (top, bottom, left, right, stopf)
            except Exception as _e:
                self._println(f"[Record] overlay error: {_e}")
        self._ui_invoke(_do)

    def _hide_rec_overlay_now(self):
        pair = _EZI_WINDOW_REF.get("rec_overlay")
        _EZI_WINDOW_REF["rec_overlay"] = None
        if not pair:
            return
        for f in pair:
            try:
                f.Close()
                f.Dispose()
            except Exception:
                pass

    def _hide_rec_overlay(self):
        self._ui_invoke(self._hide_rec_overlay_now)

    def _navigate_comfy_webview(self, url):
        if ADV_CONSOLE:
            return
        def _do():
            cw = _EZI_WINDOW_REF.get("comfy_webview")
            if cw is None:
                return
            _ezi_ext_close(reset=True)
            if _EZI_WINDOW_REF.get("comfy_ready") and cw.CoreWebView2 is not None:
                cw.CoreWebView2.Navigate(url)
            else:
                _EZI_WINDOW_REF["comfy_pending_url"] = url
        self._ui_invoke(_do)

    def close_ext_view(self):
        self._ui_invoke(_ezi_ext_close)

    def reload_comfy_view(self):
        def _do():
            if _EZI_WINDOW_REF.get("ext_active"):
                ext = _EZI_WINDOW_REF.get("ext_webview")
                if ext is not None and ext.CoreWebView2 is not None:
                    ext.CoreWebView2.Reload()
                    return
            cw = _EZI_WINDOW_REF.get("comfy_webview")
            if cw is not None and cw.CoreWebView2 is not None:
                cw.CoreWebView2.Reload()
        self._ui_invoke(_do)

    def set_shell_expanded(self, expanded):
        if isinstance(expanded, bool):
            _EZI_WINDOW_REF["shell_expanded"] = expanded
        elif isinstance(expanded, (int, float)) and expanded > 0:
            _EZI_WINDOW_REF["shell_expanded"] = expanded
        elif isinstance(expanded, str) and expanded.lower() == 'full':
            _EZI_WINDOW_REF["shell_expanded"] = True
        else:
            _EZI_WINDOW_REF["shell_expanded"] = False
        def _do():
            fn = _EZI_WINDOW_REF.get("apply_bounds")
            if fn:
                fn()
        self._ui_invoke(_do)

    def slide_comfy_in(self, duration_ms=300):
        ref = _EZI_WINDOW_REF
        try:
            if ref.get("comfy_webview") is None or not ref.get("apply_bounds"):
                return False
            dur = max(0.05, float(duration_ms) / 1000.0)
            ref["comfy_slide_gen"] = ref.get("comfy_slide_gen", 0) + 1
            gen = ref["comfy_slide_gen"]
            ease = _ezi_cubic_bezier(0.4, 0.0, 0.2, 1.0)

            def _apply(p):
                if ref.get("comfy_slide_gen") != gen:
                    return
                ref["comfy_slide_progress"] = p
                fn = ref.get("apply_bounds")
                if fn:
                    fn()

            parked = threading.Event()

            def _park():
                try:
                    _apply(0.0)
                finally:
                    parked.set()
            self._ui_invoke(_park)
            parked.wait(0.5)

            def _runner():
                t0 = time.perf_counter()
                pending = {"v": False}

                def _step():
                    try:
                        t = min(1.0, (time.perf_counter() - t0) / dur)
                        _apply(ease(t))
                    finally:
                        pending["v"] = False
                try:
                    while ref.get("comfy_slide_gen") == gen and (time.perf_counter() - t0) < dur:
                        if not pending["v"]:
                            pending["v"] = True
                            self._ui_invoke(_step)
                        time.sleep(0.004)
                finally:
                    self._ui_invoke(lambda: _apply(1.0))
            threading.Thread(target=_runner, daemon=True).start()
            return True
        except Exception:
            ref["comfy_slide_progress"] = 1.0
            try:
                fn = ref.get("apply_bounds")
                if fn:
                    self._ui_invoke(fn)
            except Exception:
                pass
            return False

if __name__ == '__main__':
    def find_free_port(preferred=None):
        try:
            preferred = int(preferred) if preferred else None
        except (TypeError, ValueError):
            preferred = None
        if preferred and 1024 <= preferred <= 65535 and preferred != COMFY_PORT:
            try:
                with socket.socket() as s:
                    s.bind(('127.0.0.1', preferred))
                return preferred
            except OSError:
                pass
        with socket.socket() as s: s.bind(('', 0)); return s.getsockname()[1]

    _wait_pid = os.environ.pop('EZI_WAIT_PID', '')
    if _wait_pid.isdigit():
        try:
            _k32 = ctypes.WinDLL('kernel32')
            _k32.OpenProcess.restype = ctypes.c_void_p
            _k32.OpenProcess.argtypes = [ctypes.c_uint32, ctypes.c_int, ctypes.c_uint32]
            _k32.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
            _k32.CloseHandle.argtypes = [ctypes.c_void_p]
            _h = _k32.OpenProcess(0x00100000, False, int(_wait_pid))
            if _h:
                _k32.WaitForSingleObject(_h, 15000)
                _k32.CloseHandle(_h)
        except Exception:
            _log_error('wait_old_instance')

    _autorun_bat = os.path.normpath(os.path.join(CURRENT_SCRIPT_DIR, "..", "AutoRun.bat"))
    try:
        if os.path.isfile(_autorun_bat):
            os.remove(_autorun_bat)
    except Exception:
        pass

    _ensure_attention_flags()

    settings = _load_settings()
    settings["_dpi_aware_version"] = 1
    _settings_ref["obj"] = settings
    _ensure_ezi_aurora_palette(settings)
    p_port = find_free_port(settings.get("proxy_port"))
    if settings.get("proxy_port") != p_port:
        settings["proxy_port"] = p_port
        _save_settings(settings)
    c_port_h = [COMFY_PORT]
    storage_holder = [settings.get("comfy_storage")]
    settings_holder = [settings]

    _proxy_ready = threading.Event()
    _api_holder = [None]

    loop = asyncio.new_event_loop()
    def start_proxy():
        asyncio.set_event_loop(loop)
        async def _run():
            app = await make_proxy_app(c_port_h, storage_holder, settings_holder, _api_holder)
            runner = web.AppRunner(app)
            await runner.setup()
            site = web.TCPSite(runner, '127.0.0.1', p_port)
            await site.start()
            _proxy_ready.set()
            await asyncio.Event().wait()
        loop.run_until_complete(_run())

    threading.Thread(target=start_proxy, daemon=True).start()
    _proxy_ready.wait(timeout=10)

    def _clear_webview2_cache():
        try:
            import shutil
            base = os.environ.get('LOCALAPPDATA', '')
            temp = os.environ.get('TEMP', '')
            candidates = [
                os.path.join(base, 'pywebview', 'EBWebView'),
                os.path.join(temp, 'pywebview', 'EBWebView'),
            ]
            for path in candidates:
                if os.path.isdir(path):
                    try:
                        shutil.rmtree(path, ignore_errors=True)
                    except Exception:
                        pass
        except Exception:
            pass
    _clear_webview2_cache()

    api = Api(p_port, c_port_h, settings, storage_holder, settings_holder)
    _api_holder[0] = api
    _EZI_WINDOW_REF["api"] = api

    import atexit
    atexit.register(api._kill_running_proc)

    try:
        window = webview.create_window(
            f'ComfyUI-EZi Desktop  v{APP_VERSION}',
            url=f'http://127.0.0.1:{p_port}/__shell__',
            js_api=api,
            user_agent=CHROME_UA,
            frameless=False,
            resizable=True,
            hidden=ADV_CONSOLE,
            background_color='#1e1e1e',
        )
    except TypeError:
        window = webview.create_window(
            f'ComfyUI-EZi Desktop  v{APP_VERSION}',
            url=f'http://127.0.0.1:{p_port}/__shell__',
            js_api=api,
            frameless=False,
            resizable=True,
            hidden=ADV_CONSOLE,
            background_color='#1e1e1e',
        )
    api.set_window(window)
    _EZI_WINDOW_REF["window"] = window
    window.events.before_show += _ezi_setup_main_window
    window.events.loaded += api.on_loaded
    window.events.closed  += api.stop

    def _titlebar_push_max_state(is_max):
        try:
            window.evaluate_js(
                "window.__eziSetMaxState && window.__eziSetMaxState(%s)"
                % ('true' if is_max else 'false')
            )
        except Exception:
            pass
    def _ezi_reapply_bounds_for(hwnd):
        try:
            fn = _ezi_bounds_fns.get(int(hwnd)) if hwnd else None
            if fn:
                fn()
        except Exception:
            pass

    def _on_maximized():
        _titlebar_push_max_state(True)
        hwnd = _get_hwnd(window)
        _taskbar_mark_not_fullscreen(hwnd)
        _ezi_reapply_bounds_for(hwnd)
        _force_full_repaint(hwnd)
        import threading as _th
        for _delay in (0.05, 0.15, 0.35):
            _th.Timer(_delay, lambda h=hwnd: (_ezi_reapply_bounds_for(h), _force_full_repaint(h))).start()
    def _on_restored():
        _titlebar_push_max_state(False)
        hwnd = _get_hwnd(window)
        _ezi_reapply_bounds_for(hwnd)
    window.events.maximized += _on_maximized
    window.events.restored  += _on_restored

    def _on_closing():
        if api._updating or api._confirm_close:
            return True
        def _ask():
            try:
                u32 = ctypes.windll.user32
                hwnd = _get_hwnd(window)
                if hwnd:
                    try:
                        if u32.IsIconic(hwnd):
                            u32.ShowWindow(hwnd, 9)
                        u32.SetForegroundWindow(hwnd)
                        u32.BringWindowToTop(hwnd)
                    except Exception:
                        pass
                api._window.evaluate_js("show_close_confirm();")
                time.sleep(0.08)
                if hwnd:
                    try:
                        u32.SetForegroundWindow(hwnd)
                    except Exception:
                        pass
            except Exception:
                api._confirm_close = True
                try:
                    api._window.destroy()
                except Exception:
                    pass
        threading.Thread(target=_ask, daemon=True).start()
        return False
    window.events.closing += _on_closing

    def _restore_on_shown():
        if ADV_CONSOLE:
            return
        try:
            hwnd = _get_hwnd(window)
            if not hwnd:
                threading.Timer(0.3, _restore_on_shown).start()
                return

            wp_data = settings.get("window_placement")
            if not wp_data or not isinstance(wp_data, dict):
                return

            import ctypes.wintypes as wt
            user = ctypes.windll.user32

            prev_dpi_ctx = None
            try:
                prev_dpi_ctx = user.SetThreadDpiAwarenessContext(ctypes.c_void_p(-4))
            except Exception:
                pass

            try:
                wp = EZI_WINDOWPLACEMENT()
                wp.length = ctypes.sizeof(EZI_WINDOWPLACEMENT)

                show_cmd = wp_data.get("showCmd", 1)
                rc_data  = wp_data.get("rcNormalPosition")
                if not rc_data or len(rc_data) != 4:
                    return

                saved_dpi = wp_data.get("saved_dpi", 96) or 96
                current_dpi = 96
                try:
                    user.GetDpiForWindow.argtypes = [ctypes.c_void_p]
                    user.GetDpiForWindow.restype  = wt.UINT
                    current_dpi = user.GetDpiForWindow(ctypes.c_void_p(hwnd)) or 96
                except Exception:
                    pass

                if saved_dpi != current_dpi:
                    scale = current_dpi / saved_dpi
                    def _scale_rect(r):
                        left  = int(round(r[0] * scale))
                        top   = int(round(r[1] * scale))
                        right = int(round(left + (r[2] - r[0]) * scale))
                        bottom= int(round(top  + (r[3] - r[1]) * scale))
                        return [left, top, right, bottom]
                    rc_data = _scale_rect(rc_data)
                    mx_rect = wp_data.get("maximized_rect")
                    if mx_rect:
                        mx_rect = _scale_rect(mx_rect)
                    else:
                        mx_rect = None
                else:
                    mx_rect = wp_data.get("maximized_rect")

                def _primary_monitor_center_rect(w=1100, h=700):
                    try:
                        sw = user.GetSystemMetrics(0)
                        sh = user.GetSystemMetrics(1)
                        x = max(0, (sw - w) // 2)
                        y = max(0, (sh - h) // 2)
                        return [x, y, x + w, y + h]
                    except Exception:
                        return [100, 100, 1200, 800]

                if show_cmd == 3:
                    check_rect = mx_rect if mx_rect else rc_data
                    if not _is_rect_on_active_monitor(check_rect[0], check_rect[1], check_rect[2], check_rect[3]):
                        fallback = _primary_monitor_center_rect()
                        wp.showCmd = 1
                        wp.rcNormalPosition = wt.RECT(fallback[0], fallback[1], fallback[2], fallback[3])
                    else:
                        wp.showCmd = 3
                        wp.rcNormalPosition = wt.RECT(rc_data[0], rc_data[1], rc_data[2], rc_data[3])
                else:
                    if not _is_rect_on_active_monitor(rc_data[0], rc_data[1], rc_data[2], rc_data[3]):
                        fallback = _primary_monitor_center_rect()
                        wp.showCmd = 1
                        wp.rcNormalPosition = wt.RECT(fallback[0], fallback[1], fallback[2], fallback[3])
                    else:
                        wp.showCmd = 1
                        wp.rcNormalPosition = wt.RECT(rc_data[0], rc_data[1], rc_data[2], rc_data[3])

                user.SetWindowPlacement(hwnd, ctypes.byref(wp))
                def _reapply():
                    try:
                        user.SetWindowPlacement(hwnd, ctypes.byref(wp))
                    except Exception:
                        pass
                threading.Timer(0.25, _reapply).start()
            finally:
                if prev_dpi_ctx is not None:
                    try:
                        user.SetThreadDpiAwarenessContext(prev_dpi_ctx)
                    except Exception:
                        pass
        except Exception:
            _log_error('_restore_on_shown')

    window.events.shown += _restore_on_shown

    def _bring_main_to_front():
        if ADV_CONSOLE:
            return
        threading.Timer(0.4, lambda: _ezi_force_foreground(_get_hwnd(window))).start()

    window.events.shown += _bring_main_to_front

    try:
        try:
            webview.start(user_agent=CHROME_UA, debug=DEV_MODE)
        except TypeError:
            webview.start(debug=DEV_MODE)
    except Exception as _start_err:
        _err_text = f"{type(_start_err).__module__}.{type(_start_err).__name__}: {_start_err}".lower()
        if any(tok in _err_text for tok in (
            "webview2", "corewebview2", "0x80070002", "0x8007007e", "0x80004005"
        )):
            _ezi_report_webview2_failure(_start_err)
        else:
            raise
