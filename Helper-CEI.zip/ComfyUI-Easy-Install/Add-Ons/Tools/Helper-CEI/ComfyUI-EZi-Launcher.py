VERSION = '3.1.1'

import os
import sys
import subprocess
import ctypes
import threading

try:
    import webview
except ImportError:
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'pywebview'])
    import webview

SCRIPT_DIR = os.path.abspath(os.path.dirname(__file__))
ROOT_DIR   = os.path.normpath(os.path.join(SCRIPT_DIR, '..', '..', '..'))
EZI_PY     = os.path.join(SCRIPT_DIR, 'ComfyUI-EZi.py')

def root(name):
    return os.path.join(ROOT_DIR, name)

HAS_DESK_SAGE  = os.path.exists(root('ComfyUI-EZi SageAttention.bat'))
HAS_DESK_FLASH = os.path.exists(root('ComfyUI-EZi FlashAttention.bat'))
HAS_BROW_SAGE  = os.path.exists(root('Start ComfyUI SageAttention.bat'))
HAS_BROW_FLASH = os.path.exists(root('Start ComfyUI FlashAttention.bat'))

WIN_W = 360
WIN_H = 260

def get_cursor_pos():
    if sys.platform == 'win32':
        class POINT(ctypes.Structure):
            _fields_ = [('x', ctypes.c_long), ('y', ctypes.c_long)]
        pt = POINT()
        ctypes.windll.user32.GetCursorPos(ctypes.byref(pt))
        return pt.x, pt.y
    return 100, 100

def get_screen_size():
    if sys.platform == 'win32':
        u = ctypes.windll.user32
        return u.GetSystemMetrics(0), u.GetSystemMetrics(1)
    return 1920, 1080

def calc_position():
    cx, cy = get_cursor_pos()
    sw, sh = get_screen_size()
    x = cx + 16
    y = cy + 16
    if x + WIN_W > sw: x = sw - WIN_W - 8
    if y + WIN_H > sh: y = sh - WIN_H - 8
    if x < 0: x = 8
    if y < 0: y = 8
    return x, y

class Api:
    def launch_ezi(self):
        subprocess.Popen(
            [sys.executable, EZI_PY],
            cwd=SCRIPT_DIR,
            creationflags=subprocess.DETACHED_PROCESS if sys.platform == 'win32' else 0
        )
        webview.windows[0].destroy()

    def launch_bat(self, name):
        bat = root(name)
        if os.path.exists(bat) and sys.platform == 'win32':
            subprocess.Popen(
                ['cmd', '/c', 'start', '', bat],
                cwd=ROOT_DIR,
                creationflags=subprocess.DETACHED_PROCESS
            )
        webview.windows[0].destroy()

    def get_config(self):
        import json
        return json.dumps({
            'hasDeskSage':  HAS_DESK_SAGE,
            'hasDeskFlash': HAS_DESK_FLASH,
            'hasBrowSage':  HAS_BROW_SAGE,
            'hasBrowFlash': HAS_BROW_FLASH,
        })

    def close(self):
        webview.windows[0].destroy()

HTML = """<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --bg:        #141518;
    --surface:   #1a1b1f;
    --border:    rgba(255,255,255,0.07);
    --orange:    #f66744;
    --green:     #91f445;
    --text:      rgba(255,255,255,0.75);
    --text-dim:  rgba(255,255,255,0.3);
  }

  html, body {
    height: 100%;
    overflow: hidden;
    font-family: 'Inter', 'Segoe UI', sans-serif;
    font-size: 13px;
    color: var(--text);
    background: var(--bg);
    user-select: none;
    border: 1px solid rgba(255,255,255,0.09);
    border-radius: 12px;
  }

  /* ── Drag region titlebar ── */
  #titlebar {
    display: flex;
    align-items: center;
    height: 36px;
    padding: 0 8px 0 12px;
    background: rgba(0,0,0,0.2);
    border-bottom: 1px solid var(--border);
    border-radius: 11px 11px 0 0;
    flex-shrink: 0;
    -webkit-app-region: drag;
    gap: 8px;
  }

  #titlebar img {
    width: 20px;
    height: 20px;
    object-fit: contain;
    flex-shrink: 0;
    -webkit-app-region: no-drag;
  }

  #titlebar .title {
    font-size: 12px;
    font-weight: 600;
    color: rgba(255,255,255,0.8);
    letter-spacing: -0.01em;
    flex: 1;
  }

  #close {
    -webkit-app-region: no-drag;
    width: 22px; height: 22px;
    border-radius: 50%;
    border: 1px solid rgba(255,255,255,0.08);
    background: rgba(255,255,255,0.04);
    color: var(--text-dim);
    cursor: pointer;
    display: flex; align-items: center; justify-content: center;
    font-size: 10px;
    transition: all .15s;
  }
  #close:hover { background: rgba(255,80,60,0.2); border-color: rgba(255,80,60,0.3); color: #ff6b6b; }

  /* Accent stripe */
  .stripe {
    height: 2px;
    background: linear-gradient(90deg, var(--orange), #c86840 45%, #6fa830 55%, var(--green));
    flex-shrink: 0;
  }

  /* ── Main content ── */
  #content {
    display: flex;
    gap: 1px;
    flex: 1;
    overflow: hidden;
    background: rgba(255,255,255,0.04);
  }

  /* ── Section ── */
  .section {
    flex: 1;
    display: flex;
    flex-direction: column;
    background: var(--bg);
    padding: 10px 8px 10px;
    gap: 4px;
  }

  .section-title {
    font-size: 8.5px;
    font-weight: 700;
    letter-spacing: 0.14em;
    text-transform: uppercase;
    margin-bottom: 4px;
    padding: 0 4px;
    display: flex;
    align-items: center;
    gap: 6px;
  }

  .section-title::before {
    content: '';
    width: 4px; height: 4px;
    border-radius: 50%;
    flex-shrink: 0;
  }

  .section.desktop .section-title { color: var(--orange); }
  .section.desktop .section-title::before { background: var(--orange); box-shadow: 0 0 6px var(--orange); }
  .section.browser  .section-title { color: var(--green); }
  .section.browser  .section-title::before { background: var(--green); box-shadow: 0 0 6px var(--green); }

  /* ── Buttons ── */
  .btn {
    display: flex;
    align-items: center;
    width: 100%;
    padding: 8px 10px;
    border-radius: 7px;
    border: 1px solid rgba(255,255,255,0.06);
    background: rgba(255,255,255,0.03);
    color: rgba(255,255,255,0.6);
    font-family: inherit;
    font-size: 12px;
    font-weight: 400;
    cursor: pointer;
    text-align: left;
    transition: all .12s;
    letter-spacing: -0.01em;
    gap: 7px;
  }

  .btn:hover {
    background: rgba(255,255,255,0.07);
    border-color: rgba(255,255,255,0.12);
    color: rgba(255,255,255,0.9);
  }

  .btn:active { transform: scale(0.98); }

  /* Primary button */
  .btn.primary {
    font-weight: 600;
    font-size: 12.5px;
  }

  .section.desktop .btn.primary {
    background: rgba(246,103,68,0.1);
    border-color: rgba(246,103,68,0.25);
    color: #f77a5c;
  }
  .section.desktop .btn.primary:hover {
    background: rgba(246,103,68,0.18);
    border-color: rgba(246,103,68,0.45);
    color: #f89070;
  }

  .section.browser .btn.primary {
    background: rgba(145,244,69,0.07);
    border-color: rgba(145,244,69,0.2);
    color: #a2f560;
  }
  .section.browser .btn.primary:hover {
    background: rgba(145,244,69,0.14);
    border-color: rgba(145,244,69,0.4);
    color: #b4f672;
  }

  /* Bottom bar */
  #footer {
    height: 24px;
    border-top: 1px solid var(--border);
    background: rgba(0,0,0,0.15);
    display: flex;
    align-items: center;
    padding: 0 12px;
    border-radius: 0 0 11px 11px;
    flex-shrink: 0;
  }

  .status {
    display: flex;
    align-items: center;
    gap: 5px;
    font-size: 9px;
    color: rgba(145,244,69,0.5);
    letter-spacing: 0.06em;
    text-transform: uppercase;
    margin-left: auto;
  }

  .status-dot {
    width: 4px; height: 4px;
    border-radius: 50%;
    background: var(--green);
    animation: pulse 2s ease-in-out infinite;
  }

  @keyframes pulse {
    0%,100% { opacity: 1; }
    50% { opacity: 0.3; }
  }

  body {
    display: flex;
    flex-direction: column;
  }
</style>
</head>
<body>

<!-- Titlebar (draggable) -->
<div id="titlebar">
  <img src="uploads/launch.png" onerror="this.style.display='none'" alt="">
  <span class="title">ComfyUI EZi Launcher</span>
  <div id="close" onclick="pywebview.api.close()">&#x2715;</div>
</div>

<div class="stripe"></div>

<!-- Two-column content -->
<div id="content">

  <!-- Desktop -->
  <div class="section desktop">
    <div class="section-title">ComfyUI Desktop</div>
    <button class="btn primary" onclick="pywebview.api.launch_ezi()">ComfyUI EZi</button>
    <button id="desk-sage"  class="btn" style="display:none" onclick="pywebview.api.launch_bat('ComfyUI-EZi SageAttention.bat')">Sage Attention</button>
    <button id="desk-flash" class="btn" style="display:none" onclick="pywebview.api.launch_bat('ComfyUI-EZi FlashAttention.bat')">Flash Attention</button>
  </div>

  <!-- Browser -->
  <div class="section browser">
    <div class="section-title">ComfyUI Browser</div>
    <button class="btn primary" onclick="pywebview.api.launch_bat('Start ComfyUI.bat')">ComfyUI EZi</button>
    <button id="brow-sage"  class="btn" style="display:none" onclick="pywebview.api.launch_bat('Start ComfyUI SageAttention.bat')">Sage Attention</button>
    <button id="brow-flash" class="btn" style="display:none" onclick="pywebview.api.launch_bat('Start ComfyUI FlashAttention.bat')">Flash Attention</button>
  </div>

</div>

<!-- Footer -->
<div id="footer">
  <span style="font-size:9px;color:rgba(255,255,255,0.12);letter-spacing:0.04em;">v""" + VERSION + """</span>
  <div class="status"><div class="status-dot"></div>Ready</div>
</div>

<script>
  function applyConfig(cfg) {
    if (cfg.hasDeskSage)  document.getElementById('desk-sage').style.display  = 'flex';
    if (cfg.hasDeskFlash) document.getElementById('desk-flash').style.display = 'flex';
    if (cfg.hasBrowSage)  document.getElementById('brow-sage').style.display  = 'flex';
    if (cfg.hasBrowFlash) document.getElementById('brow-flash').style.display = 'flex';
  }

  window.addEventListener('pywebviewready', function () {
    pywebview.api.get_config().then(function (raw) {
      applyConfig(JSON.parse(raw));
    });
  });
</script>
</body>
</html>"""

if __name__ == '__main__':
    x, y = calc_position()
    api = Api()
    window = webview.create_window(
        'ComfyUI EZi Launcher',
        html=HTML,
        js_api=api,
        width=WIN_W,
        height=WIN_H,
        x=x,
        y=y,
        resizable=False,
        frameless=True,
        on_top=True,
    )
    def focus_watcher():
        if sys.platform != 'win32':
            return
        import time
        user32 = ctypes.windll.user32
        time.sleep(1.5)
        hwnd = user32.FindWindowW(None, 'ComfyUI EZi Launcher')
        while True:
            time.sleep(0.15)
            fg = user32.GetForegroundWindow()
            if fg != hwnd:
                try:
                    webview.windows[0].destroy()
                except Exception:
                    pass
                break

    t = threading.Thread(target=focus_watcher, daemon=True)
    t.start()
    webview.start()
