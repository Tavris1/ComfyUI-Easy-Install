VERSION = '3.3.3'

import os
import sys
import subprocess
import ctypes
import ctypes.wintypes as wt
import threading

SCRIPT_DIR = os.path.abspath(os.path.dirname(__file__))
ROOT_DIR   = os.path.normpath(os.path.join(SCRIPT_DIR, '..', '..', '..'))
EZI_PY     = os.path.join(SCRIPT_DIR, 'ComfyUI-EZi.py')

def root(name):
    return os.path.join(ROOT_DIR, name)

HAS_DESK_SAGE  = os.path.exists(root('Start ComfyUI SageAttention.bat'))
HAS_DESK_FLASH = os.path.exists(root('Start ComfyUI FlashAttention.bat'))
HAS_BROW_SAGE  = os.path.exists(root('Start ComfyUI SageAttention.bat'))
HAS_BROW_FLASH = os.path.exists(root('Start ComfyUI FlashAttention.bat'))

WS_POPUP         = 0x80000000
WS_VISIBLE       = 0x10000000
WS_CLIPCHILDREN  = 0x02000000
WS_EX_TOPMOST    = 0x00000008
WS_EX_TOOLWINDOW = 0x00000080
WS_EX_NOACTIVATE = 0x08000000
WS_CHILD         = 0x40000000
BS_OWNERDRAW     = 0x0000000B
TTS_ALWAYSTIP    = 0x0001
TTS_NOPREFIX     = 0x0002
TTM_ADDTOOLW     = 0x0432
TTM_SETMAXTIPWIDTH = 0x0418
TTDT_AUTOPOP     = 2
TTM_SETDELAYTIME = 0x0403
WM_DESTROY       = 0x0002
WM_PAINT         = 0x000F
WM_ERASEBKGND    = 0x0014
WM_COMMAND       = 0x0111
WM_NCHITTEST     = 0x0084
WM_ACTIVATE      = 0x0006
WM_DRAWITEM      = 0x002B
WM_MOUSEMOVE     = 0x0200
WM_MOUSELEAVE    = 0x02A3
WM_CTLCOLORBTN   = 0x0135
HTCAPTION        = 2
IDC_ARROW        = 32512
CS_HREDRAW       = 0x0002
CS_VREDRAW       = 0x0001
SW_SHOW          = 5
PS_SOLID         = 0
DT_LEFT          = 0x0000
DT_CENTER        = 0x0001
DT_VCENTER       = 0x0004
DT_SINGLELINE    = 0x0020
SRCCOPY          = 0x00CC0020
RDW_INVALIDATE   = 0x0001
RDW_UPDATENOW    = 0x0100
RDW_ALLCHILDREN  = 0x0080

# Pixaroma theme
C_BG            = 0x111111
C_TITLEBAR      = 0x1A1A1A
C_BORDER        = 0x252525
C_ORANGE        = 0x0A53E8
C_GREEN         = 0x14A030

C_DP_BG         = 0x222222
C_DP_BORDER     = 0x0A53E8
C_DP_TEXT       = 0x0A53E8
C_DPH_BG        = 0x00226E
C_DPH_BORDER    = 0x4070FF
C_DPH_TEXT      = 0x4070FF

C_BP_BG         = 0x222222
C_BP_BORDER     = 0x14A030
C_BP_TEXT       = 0x14A030
C_BPH_BG        = 0x003800
C_BPH_BORDER    = 0x40FF70
C_BPH_TEXT      = 0x40FF70

C_SEC_BG        = 0x222222
C_SEC_BORDER    = 0x2E2E2E
C_SEC_TEXT      = 0x888888
C_SECH_BG       = 0x2A2A2A
C_SECH_BORDER   = 0x444444
C_SECH_TEXT     = 0xE0E0E0

# Layout
WIN_W           = 360
TITLE_H         = 36
STRIPE_H        = 2
SEC_TOP_PAD     = 8
SEC_LABEL_H     = 22
SEC_LABEL_PAD   = 0
CONTENT_TOP     = TITLE_H + STRIPE_H + SEC_TOP_PAD + SEC_LABEL_H + SEC_LABEL_PAD
BTN_H           = 36
BTN_GAP         = 6
FOOTER_H        = 24
BOT_PAD         = 6
ARROW_W         = 20
ARROW_GAP       = 2

desk_btns = 1 + (1 if HAS_DESK_SAGE else 0) + (1 if HAS_DESK_FLASH else 0)
brow_btns = 1 + (1 if HAS_BROW_SAGE else 0) + (1 if HAS_BROW_FLASH else 0)
max_btns  = max(desk_btns, brow_btns)

WIN_H = CONTENT_TOP + (max_btns * BTN_H) + ((max_btns - 1) * BTN_GAP) + BOT_PAD + FOOTER_H

user32   = ctypes.windll.user32
gdi32    = ctypes.windll.gdi32
kernel32 = ctypes.windll.kernel32

if sys.maxsize > 2**32:
    LRESULT = ctypes.c_int64
    WPARAM  = ctypes.c_uint64
    LPARAM  = ctypes.c_int64
else:
    LRESULT = ctypes.c_long
    WPARAM  = ctypes.c_uint
    LPARAM  = ctypes.c_long

WNDPROC       = ctypes.WINFUNCTYPE(LRESULT, wt.HWND, wt.UINT, WPARAM, LPARAM)
BTN_PROC_TYPE = ctypes.WINFUNCTYPE(LRESULT, wt.HWND, wt.UINT, WPARAM, LPARAM)

user32.DefWindowProcW.argtypes    = [wt.HWND, wt.UINT, WPARAM, LPARAM]
user32.DefWindowProcW.restype     = LRESULT
user32.CallWindowProcW.argtypes   = [WNDPROC, wt.HWND, wt.UINT, WPARAM, LPARAM]
user32.CallWindowProcW.restype    = LRESULT
user32.GetWindowLongPtrW.argtypes = [wt.HWND, ctypes.c_int]
user32.GetWindowLongPtrW.restype  = ctypes.c_void_p
user32.SetWindowLongPtrW.argtypes = [wt.HWND, ctypes.c_int, ctypes.c_void_p]
user32.SetWindowLongPtrW.restype  = ctypes.c_void_p
user32.FillRect.argtypes          = [wt.HDC, ctypes.POINTER(wt.RECT), wt.HBRUSH]
user32.FillRect.restype           = ctypes.c_int
user32.GetDlgCtrlID.argtypes      = [wt.HWND]
user32.GetDlgCtrlID.restype       = ctypes.c_int
user32.SendMessageW.argtypes      = [wt.HWND, wt.UINT, WPARAM, LPARAM]
user32.SendMessageW.restype       = LRESULT

class WNDCLASSEX(ctypes.Structure):
    _fields_ = [
        ('cbSize',        wt.UINT),
        ('style',         wt.UINT),
        ('lpfnWndProc',   WNDPROC),
        ('cbClsExtra',    ctypes.c_int),
        ('cbWndExtra',    ctypes.c_int),
        ('hInstance',     wt.HINSTANCE),
        ('hIcon',         wt.HICON),
        ('hCursor',       wt.HANDLE),
        ('hbrBackground', wt.HBRUSH),
        ('lpszMenuName',  wt.LPCWSTR),
        ('lpszClassName', wt.LPCWSTR),
        ('hIconSm',       wt.HICON),
    ]

class PAINTSTRUCT(ctypes.Structure):
    _fields_ = [
        ('hdc',         wt.HDC),
        ('fErase',      wt.BOOL),
        ('rcPaint',     wt.RECT),
        ('fRestore',    wt.BOOL),
        ('fIncUpdate',  wt.BOOL),
        ('rgbReserved', ctypes.c_byte * 32),
    ]

class LOGFONT(ctypes.Structure):
    _fields_ = [
        ('lfHeight',         ctypes.c_long),
        ('lfWidth',          ctypes.c_long),
        ('lfEscapement',     ctypes.c_long),
        ('lfOrientation',    ctypes.c_long),
        ('lfWeight',         ctypes.c_long),
        ('lfItalic',         ctypes.c_byte),
        ('lfUnderline',      ctypes.c_byte),
        ('lfStrikeOut',      ctypes.c_byte),
        ('lfCharSet',        ctypes.c_byte),
        ('lfOutPrecision',   ctypes.c_byte),
        ('lfClipPrecision',  ctypes.c_byte),
        ('lfQuality',        ctypes.c_byte),
        ('lfPitchAndFamily', ctypes.c_byte),
        ('lfFaceName',       ctypes.c_wchar * 32),
    ]

class DRAWITEMSTRUCT(ctypes.Structure):
    _fields_ = [
        ('CtlType',    wt.UINT),
        ('CtlID',      wt.UINT),
        ('itemID',     wt.UINT),
        ('itemAction', wt.UINT),
        ('itemState',  wt.UINT),
        ('_pad',       ctypes.c_uint),
        ('hwndItem',   wt.HWND),
        ('hDC',        wt.HDC),
        ('rcItem',     wt.RECT),
        ('itemData',   ctypes.c_size_t),
    ]

class TRACKMOUSEEVENT(ctypes.Structure):
    _pack_ = 8
    _fields_ = [
        ('cbSize',      wt.DWORD),
        ('dwFlags',     wt.DWORD),
        ('hwndTrack',   wt.HWND),
        ('dwHoverTime', wt.DWORD),
    ]

def make_font(size, weight=400, face='Segoe UI'):
    lf = LOGFONT()
    lf.lfHeight         = size
    lf.lfWeight         = weight
    lf.lfQuality        = 5
    lf.lfPitchAndFamily = 0x22
    lf.lfFaceName       = face
    return gdi32.CreateFontIndirectW(ctypes.byref(lf))

def make_solid_brush(c):
    return gdi32.CreateSolidBrush(c)

class POINT(ctypes.Structure):
    _fields_ = [('x', ctypes.c_long), ('y', ctypes.c_long)]

def calc_position():
    pt = POINT()
    user32.GetCursorPos(ctypes.byref(pt))
    sw, sh = user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)
    x, y = pt.x + 16, pt.y + 16
    if x + WIN_W > sw: x = sw - WIN_W - 8
    if y + WIN_H > sh: y = sh - WIN_H - 8
    if x < 0: x = 8
    if y < 0: y = 8
    return x, y

ID_CLOSE      = 1
ID_EZI_DESK   = 10
ID_SAGE_DESK  = 11
ID_FLASH_DESK = 12
ID_EZI_BROW   = 20
ID_SAGE_BROW  = 21
ID_FLASH_BROW = 22

ID_SC_EZI_DESK   = 110
ID_SC_SAGE_DESK  = 111
ID_SC_FLASH_DESK = 112
ID_SC_EZI_BROW   = 120
ID_SC_SAGE_BROW  = 121
ID_SC_FLASH_BROW = 122

SHORTCUT_META = {
    ID_SC_EZI_DESK:   (ID_EZI_DESK,   'ComfyUI-EZi-Desktop.ico', 'ComfyUI-EZi Desktop'),
    ID_SC_SAGE_DESK:  (ID_SAGE_DESK,  'ComfyUI-EZi-Desktop.ico', 'ComfyUI-EZi SA'),
    ID_SC_FLASH_DESK: (ID_FLASH_DESK, 'ComfyUI-EZi-Desktop.ico', 'ComfyUI-EZi FA'),
    ID_SC_EZI_BROW:   (ID_EZI_BROW,   'ComfyUI-EZi.ico',         'ComfyUI-EZi'),
    ID_SC_SAGE_BROW:  (ID_SAGE_BROW,  'ComfyUI-Sage.ico',        'ComfyUI-SA'),
    ID_SC_FLASH_BROW: (ID_FLASH_BROW, 'ComfyUI-Flash.ico',       'ComfyUI-FA'),
}

WM_APP_CLOSE = 0x8001
g_fonts          = {}
g_brushes        = {}
g_hover_btn      = None
g_gradient_memdc = None
g_gradient_bmp   = None
g_tooltip_hwnd   = None
g_creating_shortcut = False

class TOOLINFOW(ctypes.Structure):
    _fields_ = [
        ('cbSize',   wt.UINT),
        ('uFlags',   wt.UINT),
        ('hwnd',     wt.HWND),
        ('uId',      ctypes.c_size_t),
        ('rect',     wt.RECT),
        ('hinst',    wt.HINSTANCE),
        ('lpszText', wt.LPCWSTR),
        ('lParam',   ctypes.c_size_t),
        ('lpReserved', ctypes.c_void_p),
    ]

BTN_META = {
    ID_EZI_DESK:   ('ComfyUI EZi',    True,  True),
    ID_SAGE_DESK:  ('Sage Attention',  True,  True),
    ID_FLASH_DESK: ('Flash Attention', True,  True),
    ID_EZI_BROW:   ('ComfyUI EZi',    True,  False),
    ID_SAGE_BROW:  ('Sage Attention',  True,  False),
    ID_FLASH_BROW: ('Flash Attention', True,  False),
    ID_CLOSE:      ('\u2715',          False, True),
}

def get_brush(c):
    if c not in g_brushes:
        g_brushes[c] = make_solid_brush(c)
    return g_brushes[c]

def btn_default_bg(btn_id):
    if btn_id in (ID_EZI_DESK,  ID_SAGE_DESK,  ID_FLASH_DESK,
                  ID_SC_EZI_DESK, ID_SC_SAGE_DESK, ID_SC_FLASH_DESK):
        return C_DP_BG
    if btn_id in (ID_EZI_BROW,  ID_SAGE_BROW,  ID_FLASH_BROW,
                  ID_SC_EZI_BROW, ID_SC_SAGE_BROW, ID_SC_FLASH_BROW):
        return C_BP_BG
    return C_BG

def launch_ezi():
    subprocess.Popen([sys.executable, EZI_PY], cwd=SCRIPT_DIR, creationflags=0x8)
    user32.PostMessageW(g_hwnd, WM_APP_CLOSE, 0, 0)

def launch_bat(name):
    bat = root(name)
    if os.path.exists(bat):
        subprocess.Popen(['cmd', '/c', 'start', '', bat], cwd=ROOT_DIR, creationflags=0x8)
    user32.PostMessageW(g_hwnd, WM_APP_CLOSE, 0, 0)

def launch_ezi_with_bat(bat_name):
    pythonw = os.path.join(ROOT_DIR, 'python_embeded', 'pythonw.exe')
    subprocess.Popen([pythonw, EZI_PY, bat_name], cwd=SCRIPT_DIR, creationflags=0x8)
    user32.PostMessageW(g_hwnd, WM_APP_CLOSE, 0, 0)

ACTIONS = {
    ID_EZI_DESK:   lambda: launch_ezi(),
    ID_EZI_BROW:   lambda: launch_bat('Start ComfyUI.bat'),
    ID_SAGE_DESK:  lambda: launch_ezi_with_bat('Start ComfyUI SageAttention.bat'),
    ID_FLASH_DESK: lambda: launch_ezi_with_bat('Start ComfyUI FlashAttention.bat'),
    ID_SAGE_BROW:  lambda: launch_bat('Start ComfyUI SageAttention.bat'),
    ID_FLASH_BROW: lambda: launch_bat('Start ComfyUI FlashAttention.bat'),
}

def create_shortcut(sc_btn_id):
    meta = SHORTCUT_META.get(sc_btn_id)
    if not meta:
        return
    main_id, ico_name, label = meta

    if main_id == ID_EZI_DESK:
        target   = sys.executable
        args     = '"{}"'.format(EZI_PY)
        work_dir = SCRIPT_DIR
    elif main_id in (ID_SAGE_DESK, ID_FLASH_DESK):
        pythonw  = os.path.join(ROOT_DIR, 'python_embeded', 'pythonw.exe')
        bat_map_desk = {
            ID_SAGE_DESK:  'Start ComfyUI SageAttention.bat',
            ID_FLASH_DESK: 'Start ComfyUI FlashAttention.bat',
        }
        target   = pythonw
        args     = '"{}" "{}"'.format(EZI_PY, bat_map_desk[main_id])
        work_dir = SCRIPT_DIR
    else:
        bat_map = {
            ID_EZI_BROW:   'Start ComfyUI.bat',
            ID_SAGE_BROW:  'Start ComfyUI SageAttention.bat',
            ID_FLASH_BROW: 'Start ComfyUI FlashAttention.bat',
        }
        target   = os.path.join(ROOT_DIR, bat_map[main_id])
        args     = ''
        work_dir = ROOT_DIR

    ico_path = os.path.join(SCRIPT_DIR, ico_name)

    def ps(s):
        return s.replace("'", "''")

    windir = os.environ.get('windir', r'C:\Windows')
    ps_exe = os.path.join(windir, r'System32\WindowsPowerShell\v1.0\powershell.exe')

    ps_cmd = (
        "$desktop=[Environment]::GetFolderPath('Desktop');"
        "$p=New-Object -ComObject WScript.Shell;"
        "$s=$p.CreateShortcut($desktop+'\\{label}.lnk');"
        "$s.TargetPath='{target}';"
        "$s.Arguments='{args}';"
        "$s.WorkingDirectory='{work_dir}';"
        "$s.IconLocation='{ico_path},0';"
        "$s.WindowStyle=1;"
        "$s.Save()"
    ).format(
        label    = ps(label),
        target   = ps(target),
        args     = ps(args),
        work_dir = ps(work_dir),
        ico_path = ps(ico_path),
    )

    global g_creating_shortcut
    g_creating_shortcut = True
    si = subprocess.STARTUPINFO()
    si.dwFlags    = subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = 0
    proc = subprocess.Popen(
        [ps_exe, '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass',
         '-WindowStyle', 'Hidden', '-Command', ps_cmd],
        startupinfo=si,
    )

    def _finish():
        proc.wait()
        global g_creating_shortcut
        g_creating_shortcut = False
        user32.PostMessageW(g_hwnd, WM_APP_CLOSE, 0, 0)

    threading.Thread(target=_finish, daemon=True).start()


def create_gradient_cache():
    global g_gradient_memdc, g_gradient_bmp
    hdc_screen       = user32.GetDC(0)
    g_gradient_memdc = gdi32.CreateCompatibleDC(hdc_screen)
    g_gradient_bmp   = gdi32.CreateCompatibleBitmap(hdc_screen, WIN_W, STRIPE_H)
    gdi32.SelectObject(g_gradient_memdc, g_gradient_bmp)
    steps = WIN_W
    for i in range(steps):
        t   = i / (steps - 1)
        r   = int(0xE8 + (0x30 - 0xE8) * t)
        g   = int(0x53 + (0xA0 - 0x53) * t)
        b   = int(0x0A + (0x14 - 0x0A) * t)
        col = (b << 16) | (g << 8) | r
        pen = gdi32.CreatePen(PS_SOLID, 1, col)
        old = gdi32.SelectObject(g_gradient_memdc, pen)
        gdi32.MoveToEx(g_gradient_memdc, i, 0, None)
        gdi32.LineTo(g_gradient_memdc, i, STRIPE_H)
        gdi32.SelectObject(g_gradient_memdc, old)
        gdi32.DeleteObject(pen)
    user32.ReleaseDC(0, hdc_screen)

def draw_arrow_button(hdc, hw, rc):
    sc_id  = user32.GetDlgCtrlID(hw)
    meta   = SHORTCUT_META.get(sc_id)
    if not meta:
        return
    main_id = meta[0]
    hovered = (hw == g_hover_btn)

    if main_id in (ID_EZI_DESK, ID_SAGE_DESK, ID_FLASH_DESK):
        bg       = C_DPH_BG     if hovered else C_DP_BG
        border   = C_DPH_BORDER if hovered else C_DP_BORDER
        text_col = C_DPH_TEXT   if hovered else C_DP_TEXT
    else:
        bg       = C_BPH_BG     if hovered else C_BP_BG
        border   = C_BPH_BORDER if hovered else C_BP_BORDER
        text_col = C_BPH_TEXT   if hovered else C_BP_TEXT

    if rc.right <= rc.left or rc.bottom <= rc.top:
        return

    user32.FillRect(hdc, ctypes.byref(rc), get_brush(bg))

    pen = gdi32.CreatePen(PS_SOLID, 1, border)
    op  = gdi32.SelectObject(hdc, pen)
    ob  = gdi32.SelectObject(hdc, gdi32.GetStockObject(5))
    gdi32.RoundRect(hdc, rc.left, rc.top, rc.right, rc.bottom, 7, 7)
    gdi32.SelectObject(hdc, op)
    gdi32.SelectObject(hdc, ob)
    gdi32.DeleteObject(pen)

    old_font = gdi32.SelectObject(hdc, g_fonts['arrow'])
    gdi32.SetBkMode(hdc, 1)
    gdi32.SetTextColor(hdc, text_col)
    user32.DrawTextW(hdc, '\u2197', -1, ctypes.byref(rc),
                     DT_CENTER | DT_VCENTER | DT_SINGLELINE)
    gdi32.SelectObject(hdc, old_font)

def draw_button(hdc, hw, rc):
    btn_id = user32.GetDlgCtrlID(hw)
    meta   = BTN_META.get(btn_id)
    if not meta:
        return
    label, is_primary, is_desktop = meta
    hovered = (hw == g_hover_btn)

    if btn_id == ID_CLOSE:
        bg       = C_SECH_BG     if hovered else C_BG
        border   = C_SECH_BORDER if hovered else 0x2A1015
        text_col = 0x4070FF      if hovered else 0x666666
        font     = g_fonts['close']
    elif is_primary and is_desktop:
        bg       = C_DPH_BG     if hovered else C_DP_BG
        border   = C_DPH_BORDER if hovered else C_DP_BORDER
        text_col = C_DPH_TEXT   if hovered else C_DP_TEXT
        font     = g_fonts['btn_pri']
    elif is_primary and not is_desktop:
        bg       = C_BPH_BG     if hovered else C_BP_BG
        border   = C_BPH_BORDER if hovered else C_BP_BORDER
        text_col = C_BPH_TEXT   if hovered else C_BP_TEXT
        font     = g_fonts['btn_pri']
    else:
        bg       = C_SECH_BG     if hovered else C_SEC_BG
        border   = C_SECH_BORDER if hovered else C_SEC_BORDER
        text_col = C_SECH_TEXT   if hovered else C_SEC_TEXT
        font     = g_fonts['btn_sec']

    if rc.right <= rc.left or rc.bottom <= rc.top:
        return

    user32.FillRect(hdc, ctypes.byref(rc), get_brush(bg))

    pen = gdi32.CreatePen(PS_SOLID, 1, border)
    op  = gdi32.SelectObject(hdc, pen)
    ob  = gdi32.SelectObject(hdc, gdi32.GetStockObject(5))
    gdi32.RoundRect(hdc, rc.left, rc.top, rc.right, rc.bottom, 7, 7)
    gdi32.SelectObject(hdc, op)
    gdi32.SelectObject(hdc, ob)
    gdi32.DeleteObject(pen)

    old_font = gdi32.SelectObject(hdc, font)
    gdi32.SetBkMode(hdc, 1)
    gdi32.SetTextColor(hdc, text_col)
    user32.DrawTextW(hdc, label, -1, ctypes.byref(rc),
                     DT_CENTER | DT_VCENTER | DT_SINGLELINE)
    gdi32.SelectObject(hdc, old_font)

_subclass_procs = []

def make_btn_subclass(hwnd_btn, is_arrow=False):
    orig = user32.GetWindowLongPtrW(hwnd_btn, -4)

    @BTN_PROC_TYPE
    def sub_proc(hw, msg, wp, lp):
        global g_hover_btn
        if msg == WM_PAINT:
            ps  = PAINTSTRUCT()
            hdc = user32.BeginPaint(hw, ctypes.byref(ps))
            rc  = wt.RECT()
            user32.GetClientRect(hw, ctypes.byref(rc))
            if is_arrow:
                draw_arrow_button(hdc, hw, rc)
            else:
                draw_button(hdc, hw, rc)
            user32.EndPaint(hw, ctypes.byref(ps))
            return 0

        if msg == WM_ERASEBKGND:
            return 1

        if msg == WM_MOUSEMOVE:
            if g_hover_btn != hw:
                prev        = g_hover_btn
                g_hover_btn = hw
                if prev:
                    user32.InvalidateRect(prev, None, False)
                user32.InvalidateRect(hw, None, False)
                tme = TRACKMOUSEEVENT(
                    ctypes.sizeof(TRACKMOUSEEVENT), 0x00000002, hw, 0)
                user32.TrackMouseEvent(ctypes.byref(tme))

        elif msg == WM_MOUSELEAVE:
            if g_hover_btn == hw:
                g_hover_btn = None
                user32.InvalidateRect(hw, None, False)

        orig_proc = ctypes.cast(orig, BTN_PROC_TYPE)
        return user32.CallWindowProcW(orig_proc, hw, msg, wp, lp)

    _subclass_procs.append((orig, sub_proc))
    user32.SetWindowLongPtrW(hwnd_btn, -4,
                             ctypes.cast(sub_proc, ctypes.c_void_p))

def create_tooltip_window(parent):
    global g_tooltip_hwnd
    hinstance = kernel32.GetModuleHandleW(None)
    g_tooltip_hwnd = user32.CreateWindowExW(
        WS_EX_TOPMOST,
        'tooltips_class32', None,
        TTS_ALWAYSTIP | TTS_NOPREFIX,
        0, 0, 0, 0,
        parent, None, hinstance, None,
    )
    user32.SendMessageW(g_tooltip_hwnd, TTM_SETDELAYTIME, TTDT_AUTOPOP, 5000)
    user32.SendMessageW(g_tooltip_hwnd, TTM_SETMAXTIPWIDTH, 0, 300)

def add_arrow_tooltip(hwnd_btn, text):
    if not g_tooltip_hwnd:
        return
    ti = TOOLINFOW()
    ti.cbSize   = ctypes.sizeof(TOOLINFOW)
    ti.uFlags   = 0x0011
    ti.hwnd     = hwnd_btn
    ti.uId      = hwnd_btn
    ti.lpszText = text

    SendMsg = ctypes.WINFUNCTYPE(
        ctypes.c_void_p,
        wt.HWND, wt.UINT, ctypes.c_void_p, ctypes.c_void_p
    )(ctypes.cast(user32.SendMessageW, ctypes.c_void_p).value)
    SendMsg(g_tooltip_hwnd, TTM_ADDTOOLW, None, ctypes.byref(ti))

ARROW_TIPS = {
    ID_SC_EZI_DESK:   'Create Desktop shortcut\nComfyUI-EZi Desktop',
    ID_SC_SAGE_DESK:  'Create Desktop shortcut\nComfyUI-EZi SA',
    ID_SC_FLASH_DESK: 'Create Desktop shortcut\nComfyUI-EZi FA',
    ID_SC_EZI_BROW:   'Create Desktop shortcut\nComfyUI-EZi',
    ID_SC_SAGE_BROW:  'Create Desktop shortcut\nComfyUI-SA',
    ID_SC_FLASH_BROW: 'Create Desktop shortcut\nComfyUI-FA',
}

def create_button(parent, btn_id, x, y, w, h, is_arrow=False):
    ex_style = WS_EX_NOACTIVATE if is_arrow else 0
    hwnd_btn = user32.CreateWindowExW(
        ex_style, 'BUTTON', '',
        WS_CHILD | WS_VISIBLE | BS_OWNERDRAW,
        x, y, w, h,
        parent, btn_id,
        kernel32.GetModuleHandleW(None), None,
    )
    make_btn_subclass(hwnd_btn, is_arrow=is_arrow)
    if is_arrow:
        tip = ARROW_TIPS.get(btn_id)
        if tip:
            add_arrow_tooltip(hwnd_btn, tip)
    return hwnd_btn

# Main Window
@WNDPROC
def wnd_proc(hwnd, msg, wp, lp):
    global g_hwnd, g_hover_btn

    if msg == WM_DESTROY:
        for br  in g_brushes.values(): gdi32.DeleteObject(br)
        for fnt in g_fonts.values():   gdi32.DeleteObject(fnt)
        if g_gradient_bmp:   gdi32.DeleteObject(g_gradient_bmp)
        if g_gradient_memdc: gdi32.DeleteDC(g_gradient_memdc)
        user32.PostQuitMessage(0)
        return 0

    if msg == WM_PAINT:
        ps  = PAINTSTRUCT()
        hdc = user32.BeginPaint(hwnd, ctypes.byref(ps))

        # 1. Main background
        user32.FillRect(hdc, ctypes.byref(wt.RECT(0, 0, WIN_W, WIN_H)),
                        get_brush(C_BG))
        # 2. Titlebar
        user32.FillRect(hdc, ctypes.byref(wt.RECT(0, 0, WIN_W, TITLE_H)),
                        get_brush(C_TITLEBAR))
        user32.FillRect(hdc,
                        ctypes.byref(wt.RECT(0, TITLE_H - 1, WIN_W, TITLE_H)),
                        get_brush(C_BORDER))
        # 3. Title text
        old_font = gdi32.SelectObject(hdc, g_fonts['title'])
        gdi32.SetBkMode(hdc, 1)
        gdi32.SetTextColor(hdc, 0xCCCCCC)
        user32.DrawTextW(hdc, 'ComfyUI EZi Launcher', -1,
                         ctypes.byref(wt.RECT(12, 0, WIN_W - 36, TITLE_H)),
                         DT_CENTER | DT_VCENTER | DT_SINGLELINE)
        gdi32.SelectObject(hdc, old_font)
        # 4. Gradient stripe
        if g_gradient_memdc:
            gdi32.BitBlt(hdc, 0, TITLE_H, WIN_W, STRIPE_H,
                         g_gradient_memdc, 0, 0, SRCCOPY)
        # 5. Section labels
        old_font = gdi32.SelectObject(hdc, g_fonts['sec_title'])
        gdi32.SetBkMode(hdc, 1)
        gdi32.SetTextColor(hdc, C_ORANGE)
        user32.DrawTextW(hdc, '-- DESKTOP --', -1,
                         ctypes.byref(wt.RECT(12, CONTENT_TOP - SEC_LABEL_H,
                                              175, CONTENT_TOP)),
                         DT_CENTER | DT_SINGLELINE)
        gdi32.SetTextColor(hdc, C_GREEN)
        user32.DrawTextW(hdc, '-- BROWSER --', -1,
                         ctypes.byref(wt.RECT(188, CONTENT_TOP - SEC_LABEL_H,
                                              WIN_W - 8, CONTENT_TOP)),
                         DT_CENTER | DT_SINGLELINE)
        gdi32.SelectObject(hdc, old_font)
        # 6. Separator
        user32.FillRect(hdc,
                        ctypes.byref(wt.RECT(179, TITLE_H + STRIPE_H,
                                             180, WIN_H - FOOTER_H)),
                        get_brush(0x252525))
        # 7. Footer
        user32.FillRect(hdc,
                        ctypes.byref(wt.RECT(0, WIN_H - FOOTER_H, WIN_W, WIN_H)),
                        get_brush(0x0D0D0D))
        user32.FillRect(hdc,
                        ctypes.byref(wt.RECT(0, WIN_H - FOOTER_H - 1,
                                             WIN_W, WIN_H - FOOTER_H)),
                        get_brush(C_BORDER))
        old_font = gdi32.SelectObject(hdc, g_fonts['footer'])
        gdi32.SetBkMode(hdc, 1)
        gdi32.SetTextColor(hdc, 0x888888)
        user32.DrawTextW(hdc, f'v{VERSION}', -1,
                         ctypes.byref(wt.RECT(12, WIN_H - FOOTER_H, 100, WIN_H)),
                         DT_LEFT | DT_VCENTER | DT_SINGLELINE)
        fcy = WIN_H - (FOOTER_H // 2)
        pen = gdi32.CreatePen(PS_SOLID, 1, C_ORANGE)
        op  = gdi32.SelectObject(hdc, pen)
        ob  = gdi32.SelectObject(hdc, get_brush(C_ORANGE))
        gdi32.Ellipse(hdc, WIN_W - 58, fcy - 3, WIN_W - 52, fcy + 4)
        gdi32.SelectObject(hdc, op)
        gdi32.SelectObject(hdc, ob)
        gdi32.DeleteObject(pen)
        gdi32.SetTextColor(hdc, 0x005090)
        user32.DrawTextW(hdc, 'READY', -1,
                         ctypes.byref(wt.RECT(WIN_W - 50, WIN_H - FOOTER_H,
                                              WIN_W - 8, WIN_H)),
                         DT_LEFT | DT_VCENTER | DT_SINGLELINE)
        gdi32.SelectObject(hdc, old_font)

        user32.EndPaint(hwnd, ctypes.byref(ps))
        return 0

    if msg == WM_ERASEBKGND:
        return 1

    if msg == WM_DRAWITEM:
        dis = ctypes.cast(ctypes.c_void_p(lp),
                          ctypes.POINTER(DRAWITEMSTRUCT)).contents
        if dis.CtlID in SHORTCUT_META:
            draw_arrow_button(dis.hDC, dis.hwndItem, dis.rcItem)
        else:
            draw_button(dis.hDC, dis.hwndItem, dis.rcItem)
        return 1

    if msg == WM_CTLCOLORBTN:
        hw     = ctypes.cast(ctypes.c_void_p(lp), wt.HWND)
        btn_id = user32.GetDlgCtrlID(hw)
        bg     = btn_default_bg(btn_id)
        gdi32.SetBkColor(wt.HDC(wp), bg)
        return ctypes.cast(get_brush(bg), ctypes.c_void_p).value

    if msg == WM_COMMAND:
        btn_id = wp & 0xFFFF
        if btn_id == ID_CLOSE:
            user32.DestroyWindow(hwnd)
            return 0
        if btn_id in SHORTCUT_META:
            create_shortcut(btn_id)
            return 0
        action = ACTIONS.get(btn_id)
        if action:
            action()
            return 0

    if msg == WM_NCHITTEST:
        x  = ctypes.c_short(lp & 0xFFFF).value
        y  = ctypes.c_short((lp >> 16) & 0xFFFF).value
        rc = wt.RECT()
        user32.GetWindowRect(hwnd, ctypes.byref(rc))
        lx, ly = x - rc.left, y - rc.top
        if 0 <= ly < TITLE_H and 0 <= lx < WIN_W - 30:
            return HTCAPTION
        return user32.DefWindowProcW(hwnd, msg, wp, lp)

    if msg == WM_APP_CLOSE:
        user32.DestroyWindow(hwnd)
        return 0

    if msg == WM_ACTIVATE:
        if (wp & 0xFFFF) == 0:
            if g_creating_shortcut:
                return 0
            other_hwnd = ctypes.c_void_p(lp).value
            if other_hwnd and user32.IsChild(hwnd, other_hwnd):
                return 0
            hw_focus = user32.GetFocus()
            if not user32.IsChild(hwnd, hw_focus):
                user32.DestroyWindow(hwnd)
        return 0

    return user32.DefWindowProcW(hwnd, msg, wp, lp)


# Main
def main():
    global g_hwnd

    if sys.platform != 'win32':
        sys.exit(1)

    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass

    hinstance = kernel32.GetModuleHandleW(None)

    g_fonts['title']     = make_font(-15, 600)
    g_fonts['sec_title'] = make_font(-12, 700)
    g_fonts['btn_pri']   = make_font(-16, 700)
    g_fonts['btn_sec']   = make_font(-14, 500)
    g_fonts['footer']    = make_font(-11, 400)
    g_fonts['close']     = make_font(-12, 600)
    g_fonts['arrow']     = make_font(-14, 600)

    CLASS_NAME = 'ComfyUI_EZi_Launcher'

    wc = WNDCLASSEX()
    wc.cbSize        = ctypes.sizeof(WNDCLASSEX)
    wc.style         = CS_HREDRAW | CS_VREDRAW
    wc.lpfnWndProc   = wnd_proc
    wc.hInstance     = hinstance
    wc.hCursor       = user32.LoadCursorW(None, IDC_ARROW)
    wc.hbrBackground = make_solid_brush(C_BG)
    wc.lpszClassName = CLASS_NAME

    if not user32.RegisterClassExW(ctypes.byref(wc)):
        raise ctypes.WinError()

    x, y = calc_position()

    g_hwnd = user32.CreateWindowExW(
        WS_EX_TOPMOST | WS_EX_TOOLWINDOW,
        CLASS_NAME, 'ComfyUI EZi Launcher',
        WS_POPUP | WS_VISIBLE | WS_CLIPCHILDREN,
        x, y, WIN_W, WIN_H,
        None, None, hinstance, None,
    )
    if not g_hwnd:
        raise ctypes.WinError()

    rgn = gdi32.CreateRoundRectRgn(0, 0, WIN_W + 1, WIN_H + 1, 24, 24)
    user32.SetWindowRgn(g_hwnd, rgn, True)

    create_gradient_cache()
    create_tooltip_window(g_hwnd)

    SEP_X   = 180
    PAD     = 8
    BTN_W   = SEP_X - PAD * 2
    MAIN_W  = BTN_W - ARROW_W - ARROW_GAP

    bw      = WIN_W - SEP_X - PAD * 2
    MAIN_BW = bw - ARROW_W - ARROW_GAP

    y_d = CONTENT_TOP
    create_button(g_hwnd, ID_CLOSE,
                  WIN_W - 28, (TITLE_H - 22) // 2, 22, 22)

    create_button(g_hwnd, ID_EZI_DESK,
                  PAD, y_d, MAIN_W, BTN_H)
    create_button(g_hwnd, ID_SC_EZI_DESK,
                  PAD + MAIN_W + ARROW_GAP, y_d, ARROW_W, BTN_H, is_arrow=True)
    y_d += BTN_H + BTN_GAP

    if HAS_DESK_SAGE:
        create_button(g_hwnd, ID_SAGE_DESK,
                      PAD, y_d, MAIN_W, BTN_H)
        create_button(g_hwnd, ID_SC_SAGE_DESK,
                      PAD + MAIN_W + ARROW_GAP, y_d, ARROW_W, BTN_H, is_arrow=True)
        y_d += BTN_H + BTN_GAP

    if HAS_DESK_FLASH:
        create_button(g_hwnd, ID_FLASH_DESK,
                      PAD, y_d, MAIN_W, BTN_H)
        create_button(g_hwnd, ID_SC_FLASH_DESK,
                      PAD + MAIN_W + ARROW_GAP, y_d, ARROW_W, BTN_H, is_arrow=True)

    y_b = CONTENT_TOP
    bx  = SEP_X + PAD

    create_button(g_hwnd, ID_EZI_BROW,
                  bx, y_b, MAIN_BW, BTN_H)
    create_button(g_hwnd, ID_SC_EZI_BROW,
                  bx + MAIN_BW + ARROW_GAP, y_b, ARROW_W, BTN_H, is_arrow=True)
    y_b += BTN_H + BTN_GAP

    if HAS_BROW_SAGE:
        create_button(g_hwnd, ID_SAGE_BROW,
                      bx, y_b, MAIN_BW, BTN_H)
        create_button(g_hwnd, ID_SC_SAGE_BROW,
                      bx + MAIN_BW + ARROW_GAP, y_b, ARROW_W, BTN_H, is_arrow=True)
        y_b += BTN_H + BTN_GAP

    if HAS_BROW_FLASH:
        create_button(g_hwnd, ID_FLASH_BROW,
                      bx, y_b, MAIN_BW, BTN_H)
        create_button(g_hwnd, ID_SC_FLASH_BROW,
                      bx + MAIN_BW + ARROW_GAP, y_b, ARROW_W, BTN_H, is_arrow=True)

    user32.ShowWindow(g_hwnd, SW_SHOW)
    user32.UpdateWindow(g_hwnd)
    user32.SetForegroundWindow(g_hwnd)

    user32.RedrawWindow(g_hwnd, None, None,
                        RDW_INVALIDATE | RDW_UPDATENOW | RDW_ALLCHILDREN)

    msg = wt.MSG()
    while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
        user32.TranslateMessage(ctypes.byref(msg))
        user32.DispatchMessageW(ctypes.byref(msg))

if __name__ == '__main__':
    main()
