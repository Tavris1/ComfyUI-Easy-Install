@echo off&&cd /D %~dp0
Title Update ComfyUI by ivo
:: Pixaroma Community Edition ::

set "DIR_LVL=.\"
call :SET_COLORS
call :CHECK_FOLDER "ComfyUI-Easy-Install"
call :CHECK_INUSE "Start ComfyUI.bat"

echo %green%::::::::::::::: Updating ComfyUI :::::::::::::::%reset%
echo.

cd %DIR_LVL%update
call update_comfyui_stable.bat nopause
cd %~dp0

:: Install working version of av!!! ::
set "SP=%DIR_LVL%python_embeded\Lib\site-packages"
for /d %%D in ("%SP%\av-*.dist-info") do if not exist "%%D\RECORD" rmdir /s /q "%SP%\av" "%SP%\av.libs" "%%D" 2>nul
%PYTHON_EXE% -I -m pip install av==18.0.0 --no-deps --no-warn-script-location >nul 2>&1

:: Patching for NumPy 2.x ::
set "PIPE_PY=%SP%\nunchaku\pipeline\__init__.py"
set "MASK_PY=%SP%\insightface\app\mask_renderer.py"

if exist "%PIPE_PY%" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$f=(Resolve-Path '%PIPE_PY%').Path; $t=[IO.File]::ReadAllText($f); $n=$t -replace 'except ImportError:','except Exception:'; if($n -ne $t){[IO.File]::WriteAllText($f,$n,(New-Object Text.UTF8Encoding $false))}"
)

if exist "%MASK_PY%" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$f=(Resolve-Path '%MASK_PY%').Path; $t=[IO.File]::ReadAllText($f); if($t -match 'face3d = None'){exit 0}; $r='try:'+[char]10+'    from ..thirdparty import face3d'+[char]10+'except Exception:'+[char]10+'    face3d = None'; $n=$t -replace '(?m)^from \.\.thirdparty import face3d[ \t]*\r?$',$r; [IO.File]::WriteAllText($f,$n,(New-Object Text.UTF8Encoding $false))"
)

:: Final Messages ::
echo.
echo %green%::::::::::::::: Update completed :::::::::::::::%reset%
echo.
if "%~1"=="" (
    echo %yellow%:::::::::::: Press any key to exit :::::::::::::%reset%&Pause>nul
    exit
)

exit /b

:: ---------------------------------------- END ---------------------------------------- ::

:SET_COLORS
set warning=[33m
set    gray=[90m
set     red=[91m
set   green=[92m
set  yellow=[93m
set    blue=[94m
set magenta=[95m
set    cyan=[96m
set   white=[97m
set   reset=[0m
GOTO :EOF

:CHECK_INUSE
set "INUSE=0"
for /f %%A in ('powershell -NoProfile -ExecutionPolicy Bypass -Command "$py=[IO.Path]::GetFullPath('%DIR_LVL%python_embeded\python.exe'); @(Get-Process python -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $py }).Count"') do set "INUSE=%%A"
if not "%INUSE%"=="0" (
    echo.
    echo    %white%ComfyUI%reset% is still running from this folder ^(maybe on another port^). %white%Please close it first.%reset%
    echo.
    echo    %gray%Press any key to exit...%reset%&&pause>nul&&exit
)
GOTO :EOF

:CHECK_FOLDER
set "PYTHON_EXE="
set "PREF_FOLDER=%~1"

if exist "%DIR_LVL%python_embeded\python.exe" (set "PYTHON_EXE=%DIR_LVL%python_embeded\python.exe")

if "%PYTHON_EXE%"=="" (
	echo.
    echo    %green%Please run this file from the %yellow%%PREF_FOLDER%%green% folder.%reset%
	echo.
    echo    %gray%Press any key to exit...%reset%&Pause>nul
    exit
)
GOTO :EOF