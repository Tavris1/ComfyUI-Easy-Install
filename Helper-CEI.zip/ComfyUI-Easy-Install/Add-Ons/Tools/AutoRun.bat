@Echo off&&cd /D %~dp0
Title 'Update Add-ons' v0.1.0 by ivo
:: Pixaroma Community Edition ::

:: Set colors ::
call :set_colors

:: get the parrent folder ::
cd ..\..\
set "parent_dir=%cd%"
cd %~dp0

echo.
echo %green%::: Copying the images into the %yellow%ComfyUI\input%green% folder :::%reset%
echo.

if exist ".\Helper-CEI\*.jpeg" move ".\Helper-CEI\*.jpeg" "..\..\ComfyUI\input\" >nul 2>&1
if exist ".\Helper-CEI\*.jpg" move ".\Helper-CEI\*.jpg" "..\..\ComfyUI\input\" >nul 2>&1
if exist ".\Helper-CEI\*.png" move ".\Helper-CEI\*.png" "..\..\ComfyUI\input\" >nul 2>&1

echo %green%:::::::::::::::: Updating the bat files ::::::::::::::::%reset%
echo.
if exist ".\Helper-CEI\*.bat" move ".\Helper-CEI\*.bat" "..\..\" >nul 2>&1

if exist "%USERPROFILE%\Desktop\ComgyUI-Sage.lnk" ren "%USERPROFILE%\Desktop\ComgyUI-Sage.lnk" "ComfyUI-SA.lnk" >nul 2>&1

if exist ".\Helper-CEI\ComfyUI-Flash.ico" if exist "..\..\Start ComfyUI FlashAttention.bat" (
	echo.
	echo %green%:::::: Creating desktop shortcut to start ComfyUI ::::::%reset%
	powershell -command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%USERPROFILE%\Desktop\ComfyUI-FA.lnk'); $s.TargetPath='%parent_dir%\Start ComfyUI FlashAttention.bat'; $s.WorkingDirectory='%parent_dir%\'; $s.IconLocation='%~dp0\Helper-CEI\ComfyUI-Flash.ico'; $s.Save();"
)

:set_colors
set warning=[33m
set     red=[91m
set   green=[92m
set  yellow=[93m
set    bold=[97m
set   reset=[0m
goto :eof
