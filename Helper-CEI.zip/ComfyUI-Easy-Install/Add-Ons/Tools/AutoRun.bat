@Echo off&&cd /D "%~dp0"
set "PSModulePath="
Title 'Update Easy-Install Modules' by ivo v3.30.0
:: Pixaroma Community Edition ::

:: ===== CEI installer mode ===== ::
set "FROM_CEI="
if defined CEI_FROM_INSTALLER set "FROM_CEI=1"
:: ============================== ::

set "GIT_TERMINAL_PROMPT=0"
set "GIT_ASKPASS=echo"
set "GCM_INTERACTIVE=never"

:: Add a path just in case ::
for /f "delims=" %%G in ('cmd /c "where.exe git.exe 2>nul"') do (set "GIT_PATH=%%~dpG")
set "path=%GIT_PATH%;%windir%\System32;%windir%\System32\WindowsPowerShell\v1.0;%localappdata%\Microsoft\WindowsApps;%PATH%"

set "DIR_LVL=..\..\"
set "UV_NC=--no-cache"&if exist "%DIR_LVL%Add-Ons\Tools\Helper-CEI\keep_cache.flag" set "UV_NC="
call :SET_COLORS
call :CHECK_FOLDER "ComfyUI-Easy-Install\Add-ons\Tools"
call :CHECK_INUSE "Start ComfyUI.bat"

:: get the parrent folder ::
set "AutoRun_dir=%cd%"
cd /D "%DIR_LVL%"
set "parent_dir=%cd%"
cd /D "%AutoRun_dir%"

:: Renaming bat files, just in case ::
call :rename_files "%DIR_LVL%Add-Ons\1. Easy-Models-Linker.bat" "Easy-Models-Linker.bat"
call :rename_files "%DIR_LVL%Add-Ons\2. Easy-System-Checker.bat" "Easy-System-Checker.bat"

:: Erase old bat files ::
if exist "%DIR_LVL%Add-Ons\SageAttention.bat" del "%DIR_LVL%Add-Ons\SageAttention.bat"
if exist "%DIR_LVL%Add-Ons\SageAttention3.bat" del "%DIR_LVL%Add-Ons\SageAttention3.bat"
if exist "%DIR_LVL%Add-Ons\Torch-Pack\Torch 2.9.1+cu130 (default).bat" del "%DIR_LVL%Add-Ons\Torch-Pack\Torch 2.9.1+cu130 (default).bat"
if exist "%DIR_LVL%Add-Ons\Torch-Pack\Torch 2.10.0+cu130 (default).bat" del "%DIR_LVL%Add-Ons\Torch-Pack\Torch 2.10.0+cu130 (default).bat"
if exist "%DIR_LVL%update\update_comfyui_and_python_dependencies.bat" del "%DIR_LVL%update\update_comfyui_and_python_dependencies.bat"
if exist "%DIR_LVL%Add-Ons\Tools\ComfyUI-Version-Switcher.bat" del "%DIR_LVL%Add-Ons\Tools\ComfyUI-Version-Switcher.bat"
if exist "%DIR_LVL%Add-Ons\Trellis2 (requires Torch 2.8.0+cu128).bat" del "%DIR_LVL%Add-Ons\Trellis2 (requires Torch 2.8.0+cu128).bat"
if exist "%DIR_LVL%Add-Ons\Easy-Models-Linker.bat" del "%DIR_LVL%Add-Ons\1. Easy-Models-Linker.bat" >nul 2>&1
if exist "%DIR_LVL%Add-Ons\Easy-System-Checker.bat" del "%DIR_LVL%Add-Ons\2. Easy-System-Checker.bat" >nul 2>&1

:: Updating the bat files ::
if exist ".\Helper-CEI\Update Easy-Install.bat" move ".\Helper-CEI\Update Easy-Install.bat" "%DIR_LVL%" >nul 2>&1
if exist ".\Helper-CEI\Update ComfyUI.bat" move ".\Helper-CEI\Update ComfyUI.bat" "%DIR_LVL%" >nul 2>&1
if exist ".\Helper-CEI\Update ComfyUI Nightly.bat" move ".\Helper-CEI\Update ComfyUI Nightly.bat" "%DIR_LVL%" >nul 2>&1
if exist ".\Helper-CEI\Update ComfyUI and Nodes.bat" move ".\Helper-CEI\Update ComfyUI and Nodes.bat" "%DIR_LVL%" >nul 2>&1

if exist ".\Helper-CEI\python312._pth" move ".\Helper-CEI\python312._pth" "%DIR_LVL%python_embeded" >nul 2>&1

if NOT exist "%DIR_LVL%Start ComfyUI.bat" move ".\Helper-CEI\Start ComfyUI.bat" "%DIR_LVL%" >nul 2>&1
if NOT exist "%DIR_LVL%Start ComfyUI KitchenAttention.bat" move ".\Helper-CEI\Start ComfyUI KitchenAttention.bat" "%DIR_LVL%" >nul 2>&1

:: Add EZi-Console-Filter node ::
rd /s /q "%DIR_LVL%ComfyUI\custom_nodes\ComfyUI-EZi-Console-Filter" >nul 2>&1
rd /s /q "%DIR_LVL%ComfyUI\custom_nodes\.disabled\ComfyUI-EZi-Console-Filter" >nul 2>&1
move ".\Helper-CEI\EZi_Console_Filter.py" "%DIR_LVL%ComfyUI\custom_nodes" >nul 2>&1

:: Patching rgthree-comfy ::
if exist "%DIR_LVL%ComfyUI\custom_nodes\rgthree-comfy" echo {"patch_recursive_execution": false} > "%DIR_LVL%ComfyUI\custom_nodes\rgthree-comfy\rgthree_config.json"

:: Creating 'ComfyUI-EZi Launcher.lnk' on the parrent and the Desktop folders ::
set "LNK_NAME=ComfyUI-EZi Launcher.lnk"

if exist ".\Helper-CEI\ComfyUI-EZi-Launcher.ico" if exist ".\Helper-CEI\ComfyUI-EZi-Launcher.py" (
	echo %green%:::::: Creating shortcut to%yellow% ComfyUI-EZi-Launcher%reset%
	powershell -NoProfile -ExecutionPolicy Bypass -command "$p=$env:parent_dir; $a=$env:AutoRun_dir; $q=[char]34; $s=(New-Object -ComObject WScript.Shell).CreateShortcut($p+'\'+$env:LNK_NAME); $s.TargetPath=$p+'\python_embeded\pythonw.exe'; $s.Arguments=$q+$a+'\Helper-CEI\ComfyUI-EZi-Launcher.py'+$q; $s.WorkingDirectory=$p+'\'; $s.IconLocation=$a+'\Helper-CEI\ComfyUI-EZi-Launcher.ico'; $s.Save()"

	:: Copy the shortcut to the real Desktop ::
	if exist "%parent_dir%\%LNK_NAME%" (
		powershell -NoProfile -ExecutionPolicy Bypass -command "Copy-Item -LiteralPath ($env:parent_dir+'\'+$env:LNK_NAME) -Destination ([Environment]::GetFolderPath('Desktop')) -Force -ErrorAction Stop" >nul 2>&1 && echo %green%:::::: Shortcut copied to Desktop%reset%
	)
)


for %%e in (jpeg jpg png mp3 mp4 bat) do del ".\Helper-CEI\*.%%e" >nul 2>&1

:Kitchen_bat_create
if NOT exist "%DIR_LVL%Start ComfyUI KitchenAttention.bat" goto Sage_bat_create
:: Creating 'ComfyUI-EZi KitchenAttention.bat' file ::
set "BATCH-NAME=%DIR_LVL%ComfyUI-EZi KitchenAttention.bat"
if not exist "%BATCH-NAME%" (
	echo.
	echo %green%:::::::::::::: Creating%yellow% ComfyUI-EZi KitchenAttention.bat%reset%

	echo @Echo off^&^&cd /D "%%~dp0">"%BATCH-NAME%"
	echo Title 'ComfyUI-EZi KitchenAttention' by ivo>>"%BATCH-NAME%"
	echo.>>"%BATCH-NAME%"
    
	echo .\python_embeded\python.exe .\Add-Ons\Tools\Helper-CEI\ComfyUI-EZi.py "Start ComfyUI KitchenAttention.bat">>"%BATCH-NAME%"
)

:Sage_bat_create
if NOT exist "%DIR_LVL%Start ComfyUI SageAttention.bat" goto Flash_bat_create
:: Creating 'ComfyUI-EZi SageAttention.bat' file ::
set "BATCH-NAME=%DIR_LVL%ComfyUI-EZi SageAttention.bat"
if not exist "%BATCH-NAME%" (
	echo.
	echo %green%:::::::::::::: Creating%yellow% ComfyUI-EZi SageAttention.bat%reset%

	echo @Echo off^&^&cd /D "%%~dp0">"%BATCH-NAME%"
	echo Title 'ComfyUI-EZi SageAttention' by ivo>>"%BATCH-NAME%"
	echo.>>"%BATCH-NAME%"
	
	echo .\python_embeded\python.exe .\Add-Ons\Tools\Helper-CEI\ComfyUI-EZi.py "Start ComfyUI SageAttention.bat">>"%BATCH-NAME%"
)

:Flash_bat_create
if NOT exist "%DIR_LVL%Start ComfyUI FlashAttention.bat" goto Install_nodes
:: Creating 'ComfyUI-EZi FlashAttention.bat' file ::
set "BATCH-NAME=%DIR_LVL%ComfyUI-EZi FlashAttention.bat"
if not exist "%BATCH-NAME%" (
	echo.
	echo %green%:::::::::::::: Creating%yellow% ComfyUI-EZi FlashAttention.bat%reset%

	echo @Echo off^&^&cd /D "%%~dp0">"%BATCH-NAME%"
	echo Title 'ComfyUI-EZi FlashAttention' by ivo>>"%BATCH-NAME%"
	echo.>>"%BATCH-NAME%"
	
	echo .\python_embeded\python.exe .\Add-Ons\Tools\Helper-CEI\ComfyUI-EZi.py "Start ComfyUI FlashAttention.bat">>"%BATCH-NAME%"
)

:Install_nodes

:: Install new nodes (skipped in CEI installer mode - already installed) ::
call :get_node_update https://gitlab.com/pixaroma/ComfyUI-Pixaroma.git  ComfyUI-Pixaroma
if defined FROM_CEI goto Skip_new_nodes
REM call :get_node https://github.com/capitan01R/ComfyUI-Krea2T-Enhancer    ComfyUI-Krea2T-Enhancer
call :get_node https://github.com/lbouaraba/comfyui-krea2edit           comfyui-krea2edit
:Skip_new_nodes

:: Postinstall
%DIR_LVL%python_embeded\python.exe -I -m uv pip uninstall kornia --quiet
%DIR_LVL%python_embeded\python.exe -I -m uv pip install kornia==0.7.4 %UV_NC% --link-mode=copy --quiet
%DIR_LVL%python_embeded\python.exe -I -m uv pip install pywebview %UV_NC% --quiet
%DIR_LVL%python_embeded\python.exe -I -m uv pip install -r "%parent_dir%\ComfyUI\manager_requirements.txt" %UV_NC% --quiet

if exist ".\Add-DynamicVRAM.bat" del ".\Add-DynamicVRAM.bat"

:: Check if SoX is already installed - skip silently if found ::
where sox.exe >nul 2>&1
if not errorlevel 1 goto SkipSoX

echo.
echo %green%::::::::::::::::::::: %yellow%Installing SoX%green% :::::::::::::::::::::%reset%
echo.

set "SOX_ROOT=%LocalAppData%\SoX"
set "SOX_DIR=%SOX_ROOT%\sox-14.4.2"
set "SOX_ZIP=%TEMP%\sox-14.4.2-win32.zip"

curl.exe -fL --progress-bar --ssl-no-revoke --retry 5 --retry-delay 2 -o "%SOX_ZIP%" "https://downloads.sourceforge.net/project/sox/sox/14.4.2/sox-14.4.2-win32.zip"
if not exist "%SOX_ZIP%" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "try { Start-BitsTransfer -Source 'https://downloads.sourceforge.net/project/sox/sox/14.4.2/sox-14.4.2-win32.zip' -Destination $env:SOX_ZIP -ErrorAction Stop } catch { exit 1 }"
)

if exist "%SOX_ZIP%" (
    if not exist "%SOX_ROOT%" mkdir "%SOX_ROOT%"
    tar.exe -xmf "%SOX_ZIP%" -C "%SOX_ROOT%"
    del "%SOX_ZIP%"
)

if exist "%SOX_DIR%\sox.exe" (
    set "path=%path%;%SOX_DIR%"
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$d=$env:SOX_DIR; $p=[Environment]::GetEnvironmentVariable('Path','User'); if(-not (($p -split ';') -contains $d)){[Environment]::SetEnvironmentVariable('Path', ([string]$p).TrimEnd(';')+';'+$d, 'User')}"
    echo %green%SoX installed successfully.%reset%
) else (
    echo %warning%WARNING:%reset% Could not install SoX. You can install it manually later from %yellow%https://sourceforge.net/projects/sox/%reset%
)
:SkipSoX
:: Reset errorlevel ::
cd .\
echo.

:: Install working version of av!!! ::
set "SP=%DIR_LVL%python_embeded\Lib\site-packages"
for /d %%D in ("%SP%\av-*.dist-info") do if not exist "%%D\RECORD" (
    echo %warning%Repairing a half-installed av...%reset%
    rmdir /s /q "%SP%\av" "%SP%\av.libs" "%%D" 2>nul
)
%DIR_LVL%python_embeded\python.exe -I -m uv pip install av==18.0.0 %UV_NC% --quiet
if errorlevel 1 echo %red%Could not install av 18.0.0. Close every ComfyUI window and run this update again.%reset%
echo.

:: Patching for NumPy 2.x ::
set "SP=%DIR_LVL%python_embeded\Lib\site-packages"
set "PIPE_PY=%SP%\nunchaku\pipeline\__init__.py"
set "MASK_PY=%SP%\insightface\app\mask_renderer.py"

if exist "%PIPE_PY%" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$f=(Resolve-Path '%PIPE_PY%').Path; $t=[IO.File]::ReadAllText($f); $n=$t -replace 'except ImportError:','except Exception:'; if($n -ne $t){[IO.File]::WriteAllText($f,$n,(New-Object Text.UTF8Encoding $false))}"
)

if exist "%MASK_PY%" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$f=(Resolve-Path '%MASK_PY%').Path; $t=[IO.File]::ReadAllText($f); if($t -match 'face3d = None'){exit 0}; $r='try:'+[char]10+'    from ..thirdparty import face3d'+[char]10+'except Exception:'+[char]10+'    face3d = None'; $n=$t -replace '(?m)^from \.\.thirdparty import face3d[ \t]*\r?$',$r; [IO.File]::WriteAllText($f,$n,(New-Object Text.UTF8Encoding $false))"
)

:: Final Messages ::
echo.
echo %green%::::::::: Done. You can read what's new here: ::::::::::%reset%
echo %yellow%https://github.com/Tavris1/ComfyUI-Easy-Install/releases%reset%

REM (goto) 2>nul & (timeout /t 2 /nobreak >nul & del /f /q "%CD%\%~nx0" & echo. & echo %green%::::::::::::::::: Press any key to exit ::::::::::::::::%reset% & pause >nul & exit)

REM if defined FROM_CEI (
    REM echo.
    REM exit /b 0
REM )

if not defined start goto SkipTime
for /f "delims=" %%i in ('powershell -NoProfile -ExecutionPolicy Bypass -command "$s=[datetime]::ParseExact('%start%','yyyy-MM-dd_HH:mm:ss',$null); $e=Get-Date; [math]::Truncate(($e-$s).TotalSeconds)"') do set diff=%%i
echo. & echo %green%::::::::::::::::: Total Running Time:%red% %diff% %green%seconds%reset%

:SkipTime
echo. & echo %gray%::::::::::::::::: Press any key to exit ::::::::::::::::%reset% & pause >nul & exit

:: ================================ END ===========================

:rename_files
if not exist "%~1" goto :eof
if exist "%~dp1%~2" goto :eof
echo %green%::::::::::::::: Renaming %yellow%%~1%green% to %yellow%%~2 %reset%
ren "%~1" "%~2"
goto :eof

:: Install nodes ::
:get_node
set "git_url=%~1"
set "git_folder=%~2"

set "GIT_TERMINAL_PROMPT=0"

if exist "%DIR_LVL%ComfyUI\custom_nodes\%git_folder%\" goto :eof

git.exe -c credential.interactive=never ls-remote --exit-code "%git_url%" HEAD >nul 2>&1
if errorlevel 1 (
    echo.
    echo %yellow%[SKIPPED]%reset% %git_folder% - repository not reachable, skipping.
    goto :eof
)

echo.
echo %green%::::::::::::::: Installing%yellow% %git_folder% %green%:::::::::::::::%reset%
echo.

cd /D "%parent_dir%"

git.exe -c credential.interactive=never clone "%git_url%" "ComfyUI/custom_nodes/%git_folder%"
if errorlevel 1 (
    echo %yellow%[SKIPPED]%reset% %git_folder% could not be downloaded, skipping.
    cd /D "%AutoRun_dir%"
    goto :eof
)

setlocal enabledelayedexpansion
if exist ".\ComfyUI\custom_nodes\%git_folder%\requirements.txt" (
    for %%F in (".\ComfyUI\custom_nodes\%git_folder%\requirements.txt") do set filesize=%%~zF
    if not !filesize! equ 0 (
        .\python_embeded\python.exe -I -m uv pip install -r ".\ComfyUI\custom_nodes\%git_folder%\requirements.txt" %UV_NC% --link-mode=copy
    )
)

if exist ".\ComfyUI\custom_nodes\%git_folder%\install.py" (
    for %%F in (".\ComfyUI\custom_nodes\%git_folder%\install.py") do set filesize=%%~zF
    if not !filesize! equ 0 (
        .\python_embeded\python.exe -I ".\ComfyUI\custom_nodes\%git_folder%\install.py"
    )
)
endlocal

cd /D "%AutoRun_dir%"

goto :eof

:get_node_update

set "git_url=%~1"
set "git_folder=%~2"

cd /D "%parent_dir%"

if exist ".\ComfyUI\custom_nodes\%git_folder%\" if not exist ".\ComfyUI\custom_nodes\%git_folder%\.git\config" (
    echo.
    echo %yellow%[SKIPPED]%reset% %git_folder% is not a git repository, skipping update.
    cd /D "%AutoRun_dir%"
    goto :eof
)

if exist ".\ComfyUI\custom_nodes\%git_folder%\" (
    git.exe -C ".\ComfyUI\custom_nodes\%git_folder%" remote set-url origin "%git_url%"
    git.exe -C ".\ComfyUI\custom_nodes\%git_folder%" fetch origin main --quiet 2>nul
    git.exe -C ".\ComfyUI\custom_nodes\%git_folder%" checkout main --quiet 2>nul
    if errorlevel 1 (
        echo.
        echo %red%::::::::::::::: WARNING: Could not checkout main branch for %git_folder% :::::::::::::::%reset%
        cd /D "%AutoRun_dir%"
        goto :eof
    )

    setlocal enabledelayedexpansion
    for /f %%H in ('git.exe -C ".\ComfyUI\custom_nodes\%git_folder%" rev-parse HEAD') do set "LOCAL=%%H"
    for /f %%H in ('git.exe -C ".\ComfyUI\custom_nodes\%git_folder%" rev-parse origin/main') do set "REMOTE=%%H"

    if not "!LOCAL!"=="!REMOTE!" (
        echo.
        echo %green%::::::::::::::: Updated%yellow% %git_folder% %green%:::::::::::::::%reset%
        echo.
        git.exe -C ".\ComfyUI\custom_nodes\%git_folder%" reset --hard origin/main --quiet 2>nul
    )
    endlocal
) else (
    echo.
    echo %green%::::::::::::::: Installing%yellow% %git_folder% %green%:::::::::::::::%reset%
    echo.
    git.exe clone --branch main "%git_url%" "ComfyUI/custom_nodes/%git_folder%"
    if errorlevel 1 (
        echo %yellow%[SKIPPED]%reset% %git_folder% could not be downloaded, skipping.
        cd /D "%AutoRun_dir%"
        goto :eof
    )
    if exist ".\ComfyUI\custom_nodes\%git_folder%\requirements.txt" (
        .\python_embeded\python.exe -I -m uv pip install -r ".\ComfyUI\custom_nodes\%git_folder%\requirements.txt" %UV_NC% --link-mode=copy
    )
)

cd /D "%AutoRun_dir%"

goto :eof

:SET_COLORS
if defined CEI_WORKER goto :eof
set warning=[33m
set    gray=[90m
set     red=[91m
set   green=[92m
set  yellow=[93m
set    blue=[94m
set magenta=[95m
set    cyan=[96m
set   white=[97m
set   reset=[0m
GOTO :EOF

:CHECK_INUSE
set "INUSE=0"
for /f %%A in ('powershell -NoProfile -ExecutionPolicy Bypass -Command "$py=[IO.Path]::GetFullPath('%DIR_LVL%python_embeded\python.exe'); @(Get-Process python,pythonw -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $py }).Count"') do set "INUSE=%%A"
if not "%INUSE%"=="0" (
    echo.
    echo    %white%ComfyUI%reset% is still running from this folder ^(maybe on another port^). %white%Please close it first.%reset%
    echo.
    echo    %gray%Press any key to exit...%reset%&&pause>nul&&exit
)
GOTO :EOF

:CHECK_FOLDER
set "PYTHON_EXE="
set "PREF_FOLDER=%~1"

if exist "%DIR_LVL%python_embeded\python.exe" (set "PYTHON_EXE=%DIR_LVL%python_embeded\python.exe")

if "%PYTHON_EXE%"=="" (
	echo.
    echo    %green%Please run this file from the %yellow%%~1%green% folder.%reset%
	echo.
    echo    %gray%Press any key to exit...%reset%&Pause>nul
    exit
)
GOTO :EOF
