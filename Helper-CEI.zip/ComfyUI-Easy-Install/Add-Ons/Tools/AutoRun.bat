@Echo off&&cd /D %~dp0
Title 'Update Easy-Install Modules' by ivo v3.16.4
:: Pixaroma Community Edition ::

:: ===== CEI installer mode ===== ::
set "FROM_CEI="
if defined CEI_FROM_INSTALLER set "FROM_CEI=1"
:: ============================== ::

set "GIT_TERMINAL_PROMPT=0"
set "GIT_ASKPASS=echo"
set "GCM_INTERACTIVE=never"

:: Add a path just in case ::
for /f "delims=" %%G in ('cmd /c "where.exe git.exe 2>nul"') do (set "GIT_PATH=%%~dpG")
set "path=%GIT_PATH%;%windir%\System32;%windir%\System32\WindowsPowerShell\v1.0;%localappdata%\Microsoft\WindowsApps;%PATH%"

set "DIR_LVL=..\..\"
call :SET_COLORS
call :CHECK_FOLDER "ComfyUI-Easy-Install\Add-ons\Tools"
call :CHECK_INUSE "Start ComfyUI.bat"

:: get the parrent folder ::
set "AutoRun_dir=%cd%"
cd %DIR_LVL%
set "parent_dir=%cd%"
cd %AutoRun_dir%

:: Erase old SageAttention bat files ::
if exist %DIR_LVL%Add-Ons\SageAttention.bat del %DIR_LVL%Add-Ons\SageAttention.bat
if exist %DIR_LVL%Add-Ons\SageAttention3.bat del %DIR_LVL%Add-Ons\SageAttention3.bat
if exist "%DIR_LVL%Add-Ons\Torch-Pack\Torch 2.9.1+cu130 (default).bat" del "%DIR_LVL%Add-Ons\Torch-Pack\Torch 2.9.1+cu130 (default).bat"
if exist "%DIR_LVL%Add-Ons\Torch-Pack\Torch 2.10.0+cu130 (default).bat" del "%DIR_LVL%Add-Ons\Torch-Pack\Torch 2.10.0+cu130 (default).bat"
if exist "%DIR_LVL%update\update_comfyui_and_python_dependencies.bat" del "%DIR_LVL%update\update_comfyui_and_python_dependencies.bat"
if exist "%DIR_LVL%Add-Ons\Trellis2 (requires Torch 2.8.0+cu128).bat" del "%DIR_LVL%Add-Ons\Trellis2 (requires Torch 2.8.0+cu128).bat"

:: Updating the bat files ::
if exist ".\Helper-CEI\Update Easy-Install.bat" move ".\Helper-CEI\Update Easy-Install.bat" "%DIR_LVL%" >nul 2>&1
if exist ".\Helper-CEI\Update ComfyUI.bat" move ".\Helper-CEI\Update ComfyUI.bat" "%DIR_LVL%" >nul 2>&1
if exist ".\Helper-CEI\Update ComfyUI Nightly.bat" move ".\Helper-CEI\Update ComfyUI Nightly.bat" "%DIR_LVL%" >nul 2>&1
if exist ".\Helper-CEI\Update ComfyUI and Nodes.bat" move ".\Helper-CEI\Update ComfyUI and Nodes.bat" "%DIR_LVL%" >nul 2>&1

if NOT exist "%DIR_LVL%Start ComfyUI.bat" move ".\Helper-CEI\Start ComfyUI.bat" "%DIR_LVL%" >nul 2>&1
if NOT exist "%DIR_LVL%Start ComfyUI KitchenAttention.bat" move ".\Helper-CEI\Start ComfyUI KitchenAttention.bat" "%DIR_LVL%" >nul 2>&1

:: Creating 'ComfyUI-EZi Launcher.lnk' on the parrent and the Desktop folders ::
for /f "delims=" %%D in ('powershell -NoProfile -ExecutionPolicy Bypass -command "[Environment]::GetFolderPath('Desktop')"') do set "DESKTOP=%%D"
set "LNK_NAME=ComfyUI-EZi Launcher.lnk"

if exist ".\Helper-CEI\ComfyUI-EZi-Launcher.ico" if exist ".\Helper-CEI\ComfyUI-EZi-Launcher.py" (
	echo %green%:::::: Creating shortcut to%yellow% ComfyUI-EZi-Launcher%reset%
	powershell -NoProfile -ExecutionPolicy Bypass -command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%parent_dir%\%LNK_NAME%'); $s.TargetPath='%parent_dir%\python_embeded\pythonw.exe'; $s.Arguments=('\"{0}\"' -f '%AutoRun_dir%\Helper-CEI\ComfyUI-EZi-Launcher.py'); $s.WorkingDirectory='%parent_dir%\'; $s.IconLocation='%AutoRun_dir%\Helper-CEI\ComfyUI-EZi-Launcher.ico'; $s.Save();"

	:: Copy the shortcut to the real Desktop ::
	if exist "%parent_dir%\%LNK_NAME%" if exist "%DESKTOP%\" (
		copy /y "%parent_dir%\%LNK_NAME%" "%DESKTOP%\%LNK_NAME%" >nul 2>&1
		echo %green%:::::: Shortcut copied to Desktop%reset%
	)
)


for %%e in (jpeg jpg png mp3 mp4 bat) do del ".\Helper-CEI\*.%%e" >nul 2>&1

:Kitchen_bat_create
if NOT exist "%DIR_LVL%Start ComfyUI KitchenAttention.bat" goto Sage_bat_create
:: Creating 'ComfyUI-EZi KitchenAttention.bat' file ::
set "BATCH-NAME=%DIR_LVL%ComfyUI-EZi KitchenAttention.bat"
if not exist "%BATCH-NAME%" (
	echo.
	echo %green%:::::::::::::: Creating%yellow% ComfyUI-EZi KitchenAttention.bat%reset%

	echo @Echo off^&^&cd /D %%^~dp0>"%BATCH-NAME%"
	echo Title 'ComfyUI-EZi KitchenAttention' by ivo>>"%BATCH-NAME%"
	echo.>>"%BATCH-NAME%"
    
	echo .\python_embeded\python.exe .\Add-Ons\Tools\Helper-CEI\ComfyUI-EZi.py "Start ComfyUI KitchenAttention.bat">>"%BATCH-NAME%"
)

:Sage_bat_create
if NOT exist "%DIR_LVL%Start ComfyUI SageAttention.bat" goto Flash_bat_create
:: Creating 'ComfyUI-EZi SageAttention.bat' file ::
set "BATCH-NAME=%DIR_LVL%ComfyUI-EZi SageAttention.bat"
if not exist "%BATCH-NAME%" (
	echo.
	echo %green%:::::::::::::: Creating%yellow% ComfyUI-EZi SageAttention.bat%reset%

	echo @Echo off^&^&cd /D %%^~dp0>"%BATCH-NAME%"
	echo Title 'ComfyUI-EZi SageAttention' by ivo>>"%BATCH-NAME%"
	echo.>>"%BATCH-NAME%"
	
	echo .\python_embeded\python.exe .\Add-Ons\Tools\Helper-CEI\ComfyUI-EZi.py "Start ComfyUI SageAttention.bat">>"%BATCH-NAME%"
)

:Flash_bat_create
if NOT exist "%DIR_LVL%Start ComfyUI FlashAttention.bat" goto Install_nodes
:: Creating 'ComfyUI-EZi FlashAttention.bat' file ::
set "BATCH-NAME=%DIR_LVL%ComfyUI-EZi FlashAttention.bat"
if not exist "%BATCH-NAME%" (
	echo.
	echo %green%:::::::::::::: Creating%yellow% ComfyUI-EZi FlashAttention.bat%reset%

	echo @Echo off^&^&cd /D %%^~dp0>"%BATCH-NAME%"
	echo Title 'ComfyUI-EZi FlashAttention' by ivo>>"%BATCH-NAME%"
	echo.>>"%BATCH-NAME%"
	
	echo .\python_embeded\python.exe .\Add-Ons\Tools\Helper-CEI\ComfyUI-EZi.py "Start ComfyUI FlashAttention.bat">>"%BATCH-NAME%"
)

:Install_nodes

:: Install new nodes (skipped in CEI installer mode - already installed) ::
if defined FROM_CEI goto Skip_new_nodes
call :get_node_update https://gitlab.com/pixaroma/ComfyUI-Pixaroma.git  ComfyUI-Pixaroma
call :get_node https://github.com/capitan01R/ComfyUI-Krea2T-Enhancer    ComfyUI-Krea2T-Enhancer
call :get_node https://github.com/lbouaraba/comfyui-krea2edit           comfyui-krea2edit
:Skip_new_nodes

:: Postinstall
%DIR_LVL%python_embeded\python.exe -I -m uv pip uninstall kornia --quiet
%DIR_LVL%python_embeded\python.exe -I -m uv pip install kornia==0.7.4 --no-cache --link-mode=copy --quiet
%DIR_LVL%python_embeded\python.exe -I -m uv pip install pywebview --no-cache --quiet
%DIR_LVL%python_embeded\python.exe -I -m uv pip install -r "%parent_dir%\ComfyUI\manager_requirements.txt" --no-cache --quiet

if exist ".\Add-DynamicVRAM.bat" del ".\Add-DynamicVRAM.bat"

:: Check if SoX is already installed - skip silently if found
where sox.exe >nul 2>&1
if not errorlevel 1 goto SkipSoX

echo.
echo %green%::::::::::::::::::::: %yellow%Installing SoX%green% :::::::::::::::::::::%reset%
echo.

set "SOX_ROOT=%LocalAppData%\SoX"
set "SOX_DIR=%SOX_ROOT%\sox-14.4.2"
set "SOX_ZIP=%TEMP%\sox-14.4.2-win32.zip"

curl.exe -L --progress-bar --ssl-no-revoke --retry 5 --retry-delay 2 -o "%SOX_ZIP%" "https://downloads.sourceforge.net/project/sox/sox/14.4.2/sox-14.4.2-win32.zip"
if not exist "%SOX_ZIP%" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "try { Start-BitsTransfer -Source 'https://downloads.sourceforge.net/project/sox/sox/14.4.2/sox-14.4.2-win32.zip' -Destination '%SOX_ZIP%' -ErrorAction Stop } catch { exit 1 }"
)

if exist "%SOX_ZIP%" (
    if not exist "%SOX_ROOT%" mkdir "%SOX_ROOT%"
    tar.exe -xmf "%SOX_ZIP%" -C "%SOX_ROOT%"
    del "%SOX_ZIP%"
    
    set "path=%path%;%SOX_DIR%"
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$p=[Environment]::GetEnvironmentVariable('Path','User'); $d='%SOX_DIR%'; if(-not ($p -like \"*$d*\")){[Environment]::SetEnvironmentVariable('Path', $p+';'+$d, 'User')}"
    echo %green%SoX installed successfully.%reset%
) else (
    echo %warning%WARNING:%reset% Could not download SoX. You can install it manually later from %yellow%https://sourceforge.net/projects/sox/%reset%
)

:SkipSoX
cd .\
echo.

:: Install working version of av!!! ::
%DIR_LVL%python_embeded\python.exe -I -m uv pip uninstall av --quiet
%DIR_LVL%python_embeded\python.exe -I -m uv pip install av==18.0.0 --quiet
echo.

:: Patching for NumPy 2.x ::
set "SP=%DIR_LVL%python_embeded\Lib\site-packages"
set "PIPE_PY=%SP%\nunchaku\pipeline\__init__.py"
set "MASK_PY=%SP%\insightface\app\mask_renderer.py"

if exist "%PIPE_PY%" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$f=(Resolve-Path '%PIPE_PY%').Path; $t=[IO.File]::ReadAllText($f); $n=$t -replace 'except ImportError:','except Exception:'; if($n -ne $t){[IO.File]::WriteAllText($f,$n,(New-Object Text.UTF8Encoding $false))}"
)

if exist "%MASK_PY%" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$f=(Resolve-Path '%MASK_PY%').Path; $t=[IO.File]::ReadAllText($f); if($t -match 'face3d = None'){exit 0}; $r='try:'+[char]10+'    from ..thirdparty import face3d'+[char]10+'except Exception:'+[char]10+'    face3d = None'; $n=$t -replace '(?m)^from \.\.thirdparty import face3d[ \t]*\r?$',$r; [IO.File]::WriteAllText($f,$n,(New-Object Text.UTF8Encoding $false))"
)

:: Final Messages ::
echo.
echo %green%::::::::: Done. You can read what's new here: ::::::::::%reset%
echo %yellow%https://github.com/Tavris1/ComfyUI-Easy-Install/releases%reset%

REM (goto) 2>nul & (timeout /t 2 /nobreak >nul & del /f /q "%CD%\%~nx0" & echo. & echo %green%::::::::::::::::: Press any key to exit ::::::::::::::::%reset% & pause >nul & exit)

if defined FROM_CEI (
    echo.
    exit /b 0
)

if not defined start goto SkipTime
for /f "delims=" %%i in ('powershell -NoProfile -ExecutionPolicy Bypass -command "$s=[datetime]::ParseExact('%start%','yyyy-MM-dd_HH:mm:ss',$null); $e=Get-Date; [math]::Truncate(($e-$s).TotalSeconds)"') do set diff=%%i
echo. & echo %green%::::::::::::::::: Total Running Time:%red% %diff% %green%seconds%reset%

:SkipTime
echo. & echo %gray%::::::::::::::::: Press any key to exit ::::::::::::::::%reset% & pause >nul & exit

:: ================================ END ===========================

:: Install nodes ::
:get_node
set "git_url=%~1"
set "git_folder=%~2"

set "GIT_TERMINAL_PROMPT=0"

if exist "%DIR_LVL%ComfyUI\custom_nodes\%git_folder%\" goto :eof

git.exe -c credential.interactive=never ls-remote --exit-code "%git_url%" HEAD >nul 2>&1
if errorlevel 1 (
    echo.
    echo %yellow%[SKIPPED]%reset% %git_folder% - repository not reachable, skipping.
    goto :eof
)

echo.
echo %green%::::::::::::::: Installing%yellow% %git_folder% %green%:::::::::::::::%reset%
echo.

cd "%parent_dir%"

git.exe -c credential.interactive=never clone "%git_url%" "ComfyUI/custom_nodes/%git_folder%"
if errorlevel 1 (
    echo %yellow%[SKIPPED]%reset% %git_folder% could not be downloaded, skipping.
    cd "%AutoRun_dir%"
    goto :eof
)

setlocal enabledelayedexpansion
if exist ".\ComfyUI\custom_nodes\%git_folder%\requirements.txt" (
    for %%F in (".\ComfyUI\custom_nodes\%git_folder%\requirements.txt") do set filesize=%%~zF
    if not !filesize! equ 0 (
        .\python_embeded\python.exe -I -m uv pip install -r ".\ComfyUI\custom_nodes\%git_folder%\requirements.txt" --no-cache --link-mode=copy
    )
)

if exist ".\ComfyUI\custom_nodes\%git_folder%\install.py" (
    for %%F in (".\ComfyUI\custom_nodes\%git_folder%\install.py") do set filesize=%%~zF
    if not !filesize! equ 0 (
        .\python_embeded\python.exe -I ".\ComfyUI\custom_nodes\%git_folder%\install.py"
    )
)
endlocal

cd "%AutoRun_dir%"

goto :eof

:get_node_update

set "git_url=%~1"
set "git_folder=%~2"

cd "%parent_dir%"

if exist ".\ComfyUI\custom_nodes\%git_folder%\" (
    git.exe -C ".\ComfyUI\custom_nodes\%git_folder%" remote set-url origin %git_url%
    git.exe -C ".\ComfyUI\custom_nodes\%git_folder%" fetch origin main --quiet 2>nul
    git.exe -C ".\ComfyUI\custom_nodes\%git_folder%" checkout main --quiet 2>nul
    if errorlevel 1 (
        echo.
        echo %red%::::::::::::::: WARNING: Could not checkout main branch for %git_folder% :::::::::::::::%reset%
        cd %AutoRun_dir%
        goto :eof
    )

    setlocal enabledelayedexpansion
    for /f %%H in ('git.exe -C ".\ComfyUI\custom_nodes\%git_folder%" rev-parse HEAD') do set "LOCAL=%%H"
    for /f %%H in ('git.exe -C ".\ComfyUI\custom_nodes\%git_folder%" rev-parse origin/main') do set "REMOTE=%%H"

    if not "!LOCAL!"=="!REMOTE!" (
        echo.
        echo %green%::::::::::::::: Updated%yellow% %git_folder% %green%:::::::::::::::%reset%
        echo.
        git.exe -C ".\ComfyUI\custom_nodes\%git_folder%" reset --hard origin/main --quiet 2>nul
    )
    endlocal
) else (
    echo.
    echo %green%::::::::::::::: Installing%yellow% %git_folder% %green%:::::::::::::::%reset%
    echo.
    git.exe clone --branch main %git_url% ComfyUI/custom_nodes/%git_folder%
    if exist ".\ComfyUI\custom_nodes\%git_folder%\requirements.txt" (
        .\python_embeded\python.exe -I -m uv pip install -r ".\ComfyUI\custom_nodes\%git_folder%\requirements.txt" --no-cache --link-mode=copy
    )
)

cd %AutoRun_dir%

goto :eof

:SET_COLORS
set warning=[33m
set    gray=[90m
set     red=[91m
set   green=[92m
set  yellow=[93m
set    blue=[94m
set magenta=[95m
set    cyan=[96m
set   white=[97m
set   reset=[0m
GOTO :EOF

:CHECK_INUSE
set "StartComfyUI=%DIR_LVL%%~1"
if exist %StartComfyUI% (
	set PORT=8188
	for /f %%A in ('powershell -NoProfile -ExecutionPolicy Bypass -Command "([regex]::Match((Get-Content '%StartComfyUI%' -Raw), '--port\s+(\d+)')).Groups[1].Value"') do set PORT=%%A
	for /f %%A in ('powershell -NoProfile -ExecutionPolicy Bypass -Command "if (Get-NetTCPConnection -LocalPort %PORT% -State Listen -ErrorAction SilentlyContinue) { 1 } else { 0 }"') do set INUSE=%%A
	if "%INUSE%"=="1" (
		echo.
		echo    %white%ComfyUI%reset% is already running on port %green%%PORT%%reset%. %white%Please close it first.%reset%
		echo.
		echo    %gray%Press any key to exit...%reset%&&pause>nul&&exit
)
)
GOTO :EOF

:CHECK_FOLDER
set "PYTHON_EXE="
set "PREF_FOLDER=%~1"

if exist "%DIR_LVL%python_embeded\python.exe" (set "PYTHON_EXE=%DIR_LVL%python_embeded\python.exe")

if "%PYTHON_EXE%"=="" (
	echo.
    echo    %green%Please run this file from the %yellow%%~1%green% folder.%reset%
	echo.
    echo    %gray%Press any key to exit...%reset%&Pause>nul
    exit
)
GOTO :EOF
