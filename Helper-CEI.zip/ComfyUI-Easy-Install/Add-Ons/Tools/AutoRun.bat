@Echo off&&cd /D %~dp0&&chcp 65001 >nul
Title 'Update Easy-Install Modules' v0.1.1 by ivo
:: Pixaroma Community Edition ::

set warning=[33m
set    gray=[90m
set     red=[91m
set   green=[92m
set  yellow=[93m
set    blue=[94m
set magenta=[95m
set    cyan=[96m
set   white=[97m
set   reset=[0m

:: Add a path just in case ::
for /f "delims=" %%G in ('cmd /c "where.exe git.exe 2>nul"') do (set "GIT_PATH=%%~dpG")
set "path=%GIT_PATH%;%PATH%"
if exist "%windir%\System32" set "path=%PATH%;%windir%\System32"
if exist "%windir%\System32\WindowsPowerShell\v1.0" set "path=%PATH%;%windir%\System32\WindowsPowerShell\v1.0"
if exist "%localappdata%\Microsoft\WindowsApps" set "path=%PATH%;%localappdata%\Microsoft\WindowsApps"

:: get the parrent folder ::
set "AutoRun_dir=%cd%"
cd ..\..\
set "parent_dir=%cd%"
cd %AutoRun_dir%

:: Copying the images into the ComfyUI\input folder ::

if exist ".\Helper-CEI\*.jpeg" move ".\Helper-CEI\*.jpeg" "..\..\ComfyUI\input\" >nul 2>&1
if exist ".\Helper-CEI\*.jpg" move ".\Helper-CEI\*.jpg" "..\..\ComfyUI\input\" >nul 2>&1
if exist ".\Helper-CEI\*.png" move ".\Helper-CEI\*.png" "..\..\ComfyUI\input\" >nul 2>&1
if exist ".\Helper-CEI\*.mp3" move ".\Helper-CEI\*.mp3" "..\..\ComfyUI\input\" >nul 2>&1
if exist ".\Helper-CEI\*.mp4" move ".\Helper-CEI\*.mp4" "..\..\ComfyUI\input\" >nul 2>&1

:: Erase old SageAttention bat files ::
if exist ..\..\Add-Ons\SageAttention.bat del ..\..\Add-Ons\SageAttention.bat
if exist ..\..\Add-Ons\SageAttention3.bat del ..\..\Add-Ons\SageAttention3.bat

:: Updating the bat files ::
if exist ".\Helper-CEI\Update ComfyUI and Nodes.bat" move ".\Helper-CEI\Update ComfyUI and Nodes.bat" "..\..\" >nul 2>&1
if exist ".\Helper-CEI\Update ComfyUI.bat" move ".\Helper-CEI\Update ComfyUI.bat" "..\..\" >nul 2>&1
if exist ".\Helper-CEI\Update Easy-Install.bat" move ".\Helper-CEI\Update Easy-Install.bat" "..\..\" >nul 2>&1
if NOT exist "..\..\Start ComfyUI.bat" move ".\Helper-CEI\Start ComfyUI.bat" "..\..\" >nul 2>&1

:: usage: call :create_shortcut bat ico lnk ::
call :create_shortcut "Start ComfyUI.bat" "ComfyUI-EZi.ico" "ComfyUI-EZi.lnk"
call :create_shortcut "ComfyUI\output" "ComfyUI-EZi-output.ico" "ComfyUI-EZi output.lnk"
call :create_shortcut "Start ComfyUI SageAttention.bat" "ComfyUI-Sage.ico" "ComfyUI-SA.lnk"
call :create_shortcut "Start ComfyUI FlashAttention.bat" "ComfyUI-Flash.ico" "ComfyUI-FA.lnk"

:: Install new nodes ::
call :get_node https://github.com/numz/ComfyUI-SeedVR2_VideoUpscaler	seedvr2_videoupscaler
call :get_node https://github.com/chflame163/ComfyUI_LayerStyle			comfyui_layerstyle
call :get_node https://github.com/kijai/ComfyUI-WanAnimatePreprocess	ComfyUI-WanAnimatePreprocess
call :get_node https://github.com/yolain/ComfyUI-Easy-Sam3				comfyui-easy-sam3
call :get_node https://github.com/kijai/ComfyUI-SCAIL-Pose				ComfyUI-SCAIL-Pose
call :get_node https://github.com/kijai/ComfyUI-MelBandRoFormer			ComfyUI-MelBandRoFormer
call :get_node https://github.com/flybirdxx/ComfyUI-Qwen-TTS			qwen3-tts-comfyui

if exist ".\Add-DynamicVRAM.bat" del ".\Add-DynamicVRAM.bat"
if exist ".\Toggle-DynamicVRAM.bat" call ".\Toggle-DynamicVRAM.bat" -add

Title 'Update Easy-Install Modules' v0.1.1 by ivo

echo.
echo %green%::::::::::::::: %yellow%Installation/Updating SoX%green% :::::::::::::::%reset%
echo.
winget.exe install --id ChrisBagwell.SoX -e --accept-source-agreements --accept-package-agreements --silent
echo.

:: Reset numpy to v1.26.4 ::
for /f "tokens=*" %%i in ('..\..\python_embeded\python.exe -c "import numpy; print(numpy.__version__)"') do set NUMPY_VERSION=%%i

if not "%NUMPY_VERSION%"=="1.26.4" (
	echo.
	echo %green%::::::::::::::: Restoring%yellow% Numpy v1.26.4 %green%:::::::::::::::%reset%
	echo.
	..\..\python_embeded\python.exe -I -m pip install --force-reinstall numpy==1.26.4 --no-deps --no-warn-script-location
)

:: Final Messages ::
echo.
echo %green%::::::::: Done. You can read what's new here: ::::::::::%reset%
echo %yellow%https://github.com/Tavris1/ComfyUI-Easy-Install/releases%reset%
echo.
if "%~1"=="" (
    echo %green%::::::::::::::::: Press any key to exit ::::::::::::::::%reset%&Pause>nul
    exit
)

exit /b

:: ================================ END ===========================

:create_shortcut

set "bat_name=%~1"
set "ico_name=%~2"
set "lnk_name=%~3"

:: Get real Desktop path ::
for /f "delims=" %%D in ('powershell -NoProfile -ExecutionPolicy Bypass -command "[Environment]::GetFolderPath('Desktop')"') do set "DESKTOP=%%D"
:: Create a shortcut on the desktop ::
if exist ".\Helper-CEI\%ico_name%" if exist "..\..\%bat_name%" (
	echo %green%:::::: Creating desktop shortcut to%yellow% %bat_name%%reset%
	powershell -NoProfile -ExecutionPolicy Bypass -command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%DESKTOP%\%lnk_name%'); $s.TargetPath='%parent_dir%\%bat_name%'; $s.WorkingDirectory='%parent_dir%\'; $s.IconLocation='%AutoRun_dir%\Helper-CEI\%ico_name%'; $s.Save();"
)
goto :eof


:: Install nodes ::
:get_node
set "git_url=%~1"
set "git_folder=%~2"

if exist "..\..\ComfyUI\custom_nodes\%git_folder%\" goto :eof
echo.
echo %green%::::::::::::::: Installing%yellow% %git_folder% %green%:::::::::::::::%reset%
echo.

cd %parent_dir%

git.exe clone %git_url% ComfyUI/custom_nodes/%git_folder%

setlocal enabledelayedexpansion
if exist ".\ComfyUI\custom_nodes\%git_folder%\requirements.txt" (
    for %%F in (".\ComfyUI\custom_nodes\%git_folder%\requirements.txt") do set filesize=%%~zF
    if not !filesize! equ 0 (
        .\python_embeded\python.exe -I -m uv pip install -r ".\ComfyUI\custom_nodes\%git_folder%\requirements.txt" --no-cache --link-mode=copy
    )
)

if exist ".\ComfyUI\custom_nodes\%git_folder%\install.py" (
    for %%F in (".\ComfyUI\custom_nodes\%git_folder%\install.py") do set filesize=%%~zF
    if not !filesize! equ 0 (
	.\python_embeded\python.exe -I ".\ComfyUI\custom_nodes\%git_folder%\install.py"
	)
)
endlocal

cd %AutoRun_dir%

goto :eof