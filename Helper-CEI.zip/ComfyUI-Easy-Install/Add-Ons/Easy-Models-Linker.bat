@echo off
Title Easy-Models-Linker by ivo v3.27.0
:: Pixaroma Community Edition ::

setlocal DisableDelayedExpansion

:: Switch to UTF-8 for non-ASCII ::
set "oldcp="
for /f "tokens=2 delims=:" %%c in ('chcp') do for /f "tokens=1 delims=. " %%d in ("%%c") do set "oldcp=%%d"
chcp 65001 >nul

cd /D "%~dp0"
set "PSModulePath="
set "mb_self=%~f0"

set warning=[33m
set    gray=[90m
set     red=[91m
set   green=[92m
set  yellow=[93m
set    blue=[94m
set magenta=[95m
set    cyan=[96m
set   white=[97m
set   reset=[0m

cd ..\
set "main_folder=%cd%"
set "yaml=%main_folder%\ComfyUI\extra_model_paths.yaml"
set "yaml_tmp=%main_folder%\ComfyUI\extra_model_paths.yaml.tmp"
set "mb_title=Easy-Models-Linker"

if not exist "%main_folder%\ComfyUI\models" goto :wrong_place

set "ln=%yellow%extra_model_paths.yaml%green% will be created in the %yellow%%main_folder%\ComfyUI%green% folder.%reset%"
call :say
echo %green%This way, you can use your %yellow%EXISTING 'MODELS'%green% folders without downloading them again.%reset%
echo %green%You can add %yellow%ONE OR MORE%green% 'MODELS' folders.%reset%

if exist "%windir%\System32\WindowsPowerShell\v1.0" set "path=%PATH%;%windir%\System32\WindowsPowerShell\v1.0"

set "count=0"

:: Creating a temp file first ::
if exist "%yaml_tmp%" erase "%yaml_tmp%"
>"%yaml_tmp%" echo # Powered by Easy-Models-Linker, developed by Ivo
>>"%yaml_tmp%" echo # Pixaroma Community Edition
>>"%yaml_tmp%" echo.

:: ----------------------------- Select a folder ----------------------------- ::
:select
set "models="
cd /d "%main_folder%"
echo.
if %count% EQU 0 echo %green%Select the location of your %yellow%EXISTING 'MODELS'%green% folder.%reset%
if %count% GTR 0 echo %green%Select the location of the %yellow%NEXT 'MODELS'%green% folder.%reset%

for /f "delims=" %%i in ('powershell -NoProfile -ExecutionPolicy Bypass -command "$folder = New-Object -ComObject Shell.Application; $selection = $folder.BrowseForFolder(0, 'Select the location of your EXISTING ''MODELS'' folder', 512+1+64, 17); if($selection) { $selection.Self.Path }"') do set "models=%%i"

if not defined models goto :cancelled

set "ln=%green%Selected: %yellow%%models%%reset%"
call :say

if not exist "%models%\diffusion_models" goto :not_models
if /i "%models%"=="%main_folder%\ComfyUI\models" goto :is_new_models

findstr /l /i /x /c:"# --- %models% ---" "%yaml_tmp%" >nul 2>&1
if not errorlevel 1 goto :already_added

goto :process

:not_models
echo.
echo %warning%WARNING: %green%This is %red%NOT a MODELS%green% folder.%reset%
set "mb_text=This is NOT a MODELS folder."
goto :retry

:is_new_models
echo.
echo %warning%WARNING: %green%This is %red%YOUR NEW MODELS%green% folder.%reset%
set "mb_text=This is your NEW models folder.|Select your EXISTING models folder."
goto :retry

:already_added
echo.
echo %warning%WARNING: %green%This folder was %red%ALREADY ADDED%green%.%reset%
set "mb_text=This folder was already added."
goto :retry

:retry
set "mb_icon=Warning"
set "mb_btn1=Select again"
set "mb_btn2=Finish"
if %count% EQU 0 set "mb_btn2=Exit"
call :choose
if "%mb_result%"=="1" goto :select
goto :cancelled

:cancelled
if %count% GTR 0 goto :done
echo Cancelled.
if exist "%yaml_tmp%" erase "%yaml_tmp%"
goto :quit

:: ----------------------------- Write the section ----------------------------- ::
:process
set /a count+=1
if %count% EQU 1 (set "section=comfyui") else (set "section=comfyui%count%")

set "modelsname="
for %%M in ("%models%") do set "modelsname=%%~nxM"
set "parent=%models%"
set "rel="
if defined modelsname for %%P in ("%models%\..") do set "parent=%%~fP"
if defined modelsname set "rel=%modelsname:'=''%\"
set "parentq=%parent:'=''%"

set "ln=# --- %models% ---"
call :writeln
>>"%yaml_tmp%" echo %section%:
set "ln=    base_path: '%parentq%'"
call :writeln
:: The first folder is the default one ::
if %count% EQU 1 >>"%yaml_tmp%" echo     is_default: true
>>"%yaml_tmp%" echo.

cd /d "%models%"
for /f "usebackq delims=" %%a in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -Directory | ForEach-Object { '    {0}: ''{1}{2}\''' -f ($_.Name.ToLowerInvariant() -replace '''',''''''), $env:rel, ($_.Name -replace '''','''''') }"`) do >>"%yaml_tmp%" echo %%a
>>"%yaml_tmp%" echo.
cd /d "%main_folder%"

echo.
echo %green%::::: Folder %yellow%%count%%green% added.%reset%

set "mb_text=Folder %count% added.|Do you want to add another MODELS folder or finish?"
set "mb_icon=Information"
set "mb_btn1=Add another folder"
set "mb_btn2=Finish"
call :choose
if "%mb_result%"=="1" goto :select

:: ----------------------------------- Done ----------------------------------- ::
:done
cd /d "%main_folder%"

set "backup_msg="
if not exist "%yaml%" goto :backup_done

:: Backup to extra_model_paths_Backup_YYYY-MM-DD_HH-MM-SS.yaml ::
set "stamp="
for /f %%t in ('powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-Date -Format yyyy-MM-dd_HH-mm-ss"') do set "stamp=%%t"
if not defined stamp set "stamp=%random%"
set "yaml_backup=extra_model_paths_Backup_%stamp%.yaml"

ren "%yaml%" "%yaml_backup%"
if exist "%main_folder%\ComfyUI\%yaml_backup%" set "backup_msg=%green%::::: Backup file%yellow% %yaml_backup% %green%has been created%reset%"

:: Keep the 5 newest backups ::
set "bk_dir=%main_folder%\ComfyUI"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath $env:bk_dir -Filter 'extra_model_paths_Backup_*.yaml' | Sort-Object Name -Descending | Select-Object -Skip 5 | Remove-Item -Force"

:backup_done
ren "%yaml_tmp%" "extra_model_paths.yaml"

echo.
type "%yaml%"
if defined backup_msg echo.
if defined backup_msg echo %backup_msg%
echo.
set "ln=%green%::::: %yellow%extra_model_paths.yaml%green% has been created in %yellow%%main_folder%\ComfyUI%green% with %yellow%%count%%green% folder(s)%reset%"
call :say

if not "%~1"=="" goto :quit
set "mb_text=extra_model_paths.yaml has been created with %count% folder(s)."
set "mb_icon=Information"
call :ask
goto :quit

:wrong_place
echo.
echo %warning%WARNING: %green%Start this file from the %yellow%Add-ons%green% folder%reset%
set "mb_text=Start this file from the Add-ons folder."
set "mb_icon=Warning"
call :ask
goto :quit

:quit
if defined oldcp chcp %oldcp% >nul 2>&1
if "%~1"=="" exit
exit /b

:: --------------------------------- Subroutines --------------------------------- ::

:: Mouse dialog with one button. Input: mb_text (| = new line), mb_title, mb_icon. Output: mb_result
:ask
set "mb_btn1=OK"
set "mb_btn2="
goto :choose

:: Mouse dialog with custom buttons. Input: mb_text (| = new line), mb_title, mb_icon, mb_btn1, mb_btn2
:: Output: mb_result = 1 (first button) or 2 (second button / Esc / close)
:choose
set "mb_result="
for /f "usebackq delims=" %%r in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "iex ((Get-Content -LiteralPath $env:mb_self -Raw) -split ('#P'+'S#'))[1]"`) do set "mb_result=%%r"
exit /b

:: Append %ln% to the yaml (safe for & ) ^ characters)
:writeln
setlocal EnableDelayedExpansion
>>"%yaml_tmp%" echo(!ln!
endlocal
exit /b

:: Print %ln% to the console (safe for & ) ^ characters)
:say
setlocal EnableDelayedExpansion
echo(!ln!
endlocal
exit /b

:: ---------------------------------------- END ---------------------------------------- ::
#PS#
Add-Type -AssemblyName System.Windows.Forms,System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()
$c={param($h) [Drawing.ColorTranslator]::FromHtml($h)}
$accent=if($env:mb_icon -eq 'Warning'){'#fbbf24'}else{'#4ade80'}
$parts=$env:mb_text -split '\|',2
$head=$parts[0]
$body=''
if($parts.Count -gt 1){$body=$parts[1].Replace('|',[Environment]::NewLine)}
$two=-not [string]::IsNullOrEmpty($env:mb_btn2)
$fc=New-Object Drawing.Font('Segoe UI',9)
$fh=New-Object Drawing.Font('Segoe UI',14,[Drawing.FontStyle]::Bold)
$fb=New-Object Drawing.Font('Segoe UI',10)
$fl=[Windows.Forms.TextFormatFlags]::WordBreak
$sz=New-Object Drawing.Size(420,5000)
$h1=[Windows.Forms.TextRenderer]::MeasureText($head,$fh,$sz,$fl).Height+6
$h2=0
if($body){$h2=[Windows.Forms.TextRenderer]::MeasureText($body,$fb,$sz,$fl).Height+6}
$f=New-Object Windows.Forms.Form
$f.FormBorderStyle='None'
$f.StartPosition='CenterScreen'
$f.TopMost=$true
$f.ShowInTaskbar=$false
$f.BackColor=&$c '#1e1e24'
$bar=New-Object Windows.Forms.Panel
$bar.Location=New-Object Drawing.Point(0,0)
$bar.Size=New-Object Drawing.Size(460,4)
$bar.BackColor=&$c $accent
$cap=New-Object Windows.Forms.Label
$cap.Text=$env:mb_title
$cap.Font=$fc
$cap.ForeColor=&$c '#6b7280'
$cap.Location=New-Object Drawing.Point(20,18)
$cap.AutoSize=$true
$t1=New-Object Windows.Forms.Label
$t1.Text=$head
$t1.Font=$fh
$t1.ForeColor=&$c '#ffffff'
$t1.Location=New-Object Drawing.Point(20,42)
$t1.Size=New-Object Drawing.Size(420,$h1)
$y=42+$h1
$f.Controls.AddRange(@($bar,$cap,$t1))
if($body){
    $t2=New-Object Windows.Forms.Label
    $t2.Text=$body
    $t2.Font=$fb
    $t2.ForeColor=&$c '#9ca3af'
    $t2.Location=New-Object Drawing.Point(20,($y+6))
    $t2.Size=New-Object Drawing.Size(420,$h2)
    $f.Controls.Add($t2)
    $y+=6+$h2
}
$y+=26
$ok=New-Object Windows.Forms.Button
$ok.Text=$env:mb_btn1
$ok.Font=New-Object Drawing.Font('Segoe UI',10,[Drawing.FontStyle]::Bold)
$ok.Location=New-Object Drawing.Point(20,$y)
$ok.FlatStyle='Flat'
$ok.FlatAppearance.BorderSize=0
$ok.BackColor=&$c $accent
$ok.ForeColor=&$c '#0b0b0f'
$ok.DialogResult='OK'
$f.Controls.Add($ok)
$f.AcceptButton=$ok
$f.CancelButton=$ok
if($two){
    $ok.Size=New-Object Drawing.Size(200,42)
    $no=New-Object Windows.Forms.Button
    $no.Text=$env:mb_btn2
    $no.Font=$fb
    $no.Location=New-Object Drawing.Point(240,$y)
    $no.Size=New-Object Drawing.Size(200,42)
    $no.FlatStyle='Flat'
    $no.FlatAppearance.BorderSize=0
    $no.BackColor=&$c '#2f2f38'
    $no.ForeColor=&$c '#e5e7eb'
    $no.DialogResult='Cancel'
    $f.Controls.Add($no)
    $f.CancelButton=$no
}else{
    $ok.Size=New-Object Drawing.Size(420,42)
}
$f.ClientSize=New-Object Drawing.Size(460,($y+42+24))
$f.Add_Shown({$f.Activate()})
if($f.ShowDialog() -eq 'OK'){'1'}else{'2'}
#PS#