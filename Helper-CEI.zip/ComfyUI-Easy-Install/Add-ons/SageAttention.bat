@echo off
Title SageAttention for 'ComfyUI Easy Install' by ivo
:: Pixaroma Community Edition ::

cd /d %~dp0

:: Set colors ::
call :set_colors

:: Set arguments ::
set "PIPargs=--no-cache-dir --no-warn-script-location --timeout=1000 --retries 200"

:: Check Add-ons folder ::
if not exist ..\python_embeded\python.exe (
    cls
    echo %green%::::::::::::::: Run this file from the %red%'ComfyUI-Easy-Install\Add-ons'%green% folder
    echo %green%::::::::::::::: Press any key to exit...%reset%&Pause>nul
	exit
)

:: Clear Pip Cache ::
if exist "%localappdata%\pip\cache" rd /s /q "%localappdata%\pip\cache"&&md "%localappdata%\pip\cache"
echo %green%::::::::::::::: Clearing Pip Cache %yellow%Done%green% :::::::::::::::%reset%
echo.




:: Installing SageAttention ::
echo %green%::::::::::::::: Installing%yellow% SageAttention %green%:::::::::::::::%reset%
echo.
..\python_embeded\python.exe -m pip install --upgrade --force-reinstall triton-windows %PIPargs%
..\python_embeded\python.exe -m pip install --upgrade --force-reinstall https://github.com/woct0rdho/SageAttention/releases/download/v2.2.0-windows/sageattention-2.2.0+cu128torch2.7.1-cp311-cp311-win_amd64.whl %PIPargs%




:: Final Messages ::
echo.
echo %green%:::::::::::::::::::::: Installation Complete :::::::::::::::::::::%reset%
echo.
echo %yellow%:::::::::::::::::::::: Press any key to exit :::::::::::::::::::::%reset%&Pause>nul
exit

:set_colors
set warning=[33m
set     red=[91m
set   green=[92m
set  yellow=[93m
set    bold=[1m
set   reset=[0m
goto :eof