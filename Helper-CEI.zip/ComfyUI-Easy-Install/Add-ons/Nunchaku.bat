REM @echo off
Title Nunchaku for 'ComfyUI Easy Install' by ivo
:: Pixaroma Community Edition ::

cd /d %~dp0

:: Set colors ::
call :set_colors

:: Set arguments ::
set "PIPargs=--no-cache-dir --no-warn-script-location --timeout=1000 --retries 200"

:: Check Add-ons folder ::
if not exist ..\python_embeded\python.exe (
    cls
    echo %green%::::::::::::::: Run this file from the %red%'ComfyUI-Easy-Install\Add-ons'%green% folder
    echo %green%::::::::::::::: Press any key to exit...%reset%&Pause>nul
	exit
)

:: Clear Pip Cache ::
if exist "%localappdata%\pip\cache" rd /s /q "%localappdata%\pip\cache"&&md "%localappdata%\pip\cache"
echo %green%::::::::::::::: Clearing Pip Cache %yellow%Done%green% :::::::::::::::%reset%
echo.




:: Installing Nunchaku ::
echo %green%::::::::::::::: Installing%yellow% Nunchaku %green%:::::::::::::::%reset%
echo.
if exist ..\ComfyUI\custom_nodes\ComfyUI-nunchaku (
    pushd %CD%
    cd ..\ComfyUI\custom_nodes\ComfyUI-nunchaku
	git.exe pull
	popd
) else (
	git.exe clone https://github.com/mit-han-lab/ComfyUI-nunchaku ..\ComfyUI\custom_nodes\ComfyUI-nunchaku
)
echo.
:: Install Nunchaku wheel ::
..\python_embeded\python.exe -m pip install https://github.com/nunchaku-tech/nunchaku/releases/download/v0.3.2dev20250715/nunchaku-0.3.2.dev20250715+torch2.7-cp311-cp311-win_amd64.whl %PIPargs%




:: Final Messages ::
echo.
echo %green%:::::::::::::::::::::: Installation Complete :::::::::::::::::::::%reset%
echo.
echo %yellow%:::::::::::::::::::::: Press any key to exit :::::::::::::::::::::%reset%&Pause>nul
exit

:set_colors
set warning=[33m
set     red=[91m
set   green=[92m
set  yellow=[93m
set    bold=[1m
set   reset=[0m
goto :eof