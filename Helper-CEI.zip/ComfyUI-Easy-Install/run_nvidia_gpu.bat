@Title ComfyUI-Easy-Install
.\python_embeded\python.exe ComfyUI\main.py --windows-standalone-build
pause
