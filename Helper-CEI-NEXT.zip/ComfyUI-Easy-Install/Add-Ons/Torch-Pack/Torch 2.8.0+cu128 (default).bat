@echo off&&cd /d %~dp0
Title Torch 2.8.0 for 'ComfyUI Easy Install' by ivo
:: Pixaroma Community Edition ::

:: Set colors ::
call :set_colors

:: Set arguments ::
set "PIPargs=--no-cache-dir --no-warn-script-location --no-deps --timeout=1000 --retries 200"

:: Check Add-ons folder ::
if not exist ..\..\python_embeded\python.exe (
    cls
    echo %green%::::::::::::::: Run this file from the %red%'ComfyUI-Easy-Install\Add-ons\Torch-Pack'%green% folder
    echo %green%::::::::::::::: Press any key to exit...%reset%&Pause>nul
	exit
)

:: Clear Pip Cache ::
if exist "%localappdata%\pip\cache" rd /s /q "%localappdata%\pip\cache"&&md "%localappdata%\pip\cache"
echo %green%::::::::::::::: Clearing Pip Cache %yellow%Done%green% :::::::::::::::%reset%
echo.




:: Installing Torch 2.8.0 ::
echo %green%::::::::::::::: Updating%yellow% Torch 2.8.0 %green%:::::::::::::::%reset%
echo.

..\..\python_embeded\python.exe -I -m pip uninstall torch torchvision torchaudio -y
..\..\python_embeded\python.exe -I -m pip install torch==2.8.0 torchvision torchaudio --index-url https://download.pytorch.org/whl/cu128 %PIPargs%



:: Final Messages ::
echo.
echo.
echo %green%::::::::::::::::::::::: Installation Complete ::::::::::::::::::::::%reset%
echo     %red% !!! Make sure to reinstall SageAttention and Nunchaku !!!%reset%
echo %yellow%::::::::::::::::::::::: Press any key to exit ::::::::::::::::::::::%reset%&Pause>nul
exit

:set_colors
set warning=[33m
set     red=[91m
set   green=[92m
set  yellow=[93m
set    bold=[1m
set   reset=[0m
goto :eof