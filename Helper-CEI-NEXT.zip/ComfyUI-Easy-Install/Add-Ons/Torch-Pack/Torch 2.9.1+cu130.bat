@echo off&&cd /d %~dp0
Title Torch 2.9.1 for 'ComfyUI Easy Install' by ivo
:: Pixaroma Community Edition ::

:: Set colors ::
call :set_colors

:: Set arguments ::
set "PIPargs=--no-cache-dir --no-warn-script-location --no-deps --timeout=1000 --retries 200"

:: Check Add-ons folder ::
if not exist ..\..\python_embeded\python.exe (
    cls
    echo %green%::::::::::::::: Run this file from the %red%'ComfyUI-Easy-Install\Add-ons\Torch-Pack'%green% folder
    echo %green%::::::::::::::: Press any key to exit...%reset%&Pause>nul
	exit
)

:: Clear Pip Cache ::
if exist "%localappdata%\pip\cache" rd /s /q "%localappdata%\pip\cache"&&md "%localappdata%\pip\cache"
echo %green%::::::::::::::: Clearing Pip Cache %yellow%Done%green% :::::::::::::::%reset%
echo.




:: Installing Torch 2.9.1 ::
echo %green%::::::::::::::: Updating%yellow% Torch 2.9.1 %green%:::::::::::::::%reset%
echo.

..\..\python_embeded\python.exe -I -m pip uninstall torch torchvision torchaudio -y
..\..\python_embeded\python.exe -I -m pip install torch==2.9.1 torchvision==0.24.1 torchaudio==2.9.1 --index-url https://download.pytorch.org/whl/cu130 %PIPargs%

if not exist ..\..\ComfyUI\custom_nodes\.disabled md ..\..\ComfyUI\custom_nodes\.disabled
if exist "..\..\ComfyUI\custom_nodes\ComfyUI_Searge_LLM" (
	echo.
	echo %green%::::::::::::::: Disabling%yellow% Searge_LLM %green%:::::::::::::::%reset%
    move "..\..\ComfyUI\custom_nodes\ComfyUI_Searge_LLM" "..\..\ComfyUI\custom_nodes\.disabled\ComfyUI_Searge_LLM" >nul
    echo %green%::::::::: %yellow%Searge_LLM %green%disabled successfully :::::::::%reset%
)

:: Final Messages ::
echo.
echo.
echo %green%::::::::::::::::::::::: Installation Complete ::::::::::::::::::::::%reset%
echo     %red% !!! Make sure to reinstall SageAttention and Nunchaku !!!%reset%
echo %yellow%::::::::::::::::::::::: Press any key to exit ::::::::::::::::::::::%reset%&Pause>nul
exit

:set_colors
set warning=[33m
set     red=[91m
set   green=[92m
set  yellow=[93m
set    bold=[1m
set   reset=[0m
goto :eof